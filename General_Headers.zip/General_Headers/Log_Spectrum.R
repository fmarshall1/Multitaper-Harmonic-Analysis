#Francois Marshall, Boston University
#Header file for analysis of logarithmic spectrum.

###################################################################################################################

log_spectrum_analysis.function<-function(mt_sa_ha_object.par,sampling_period.par=1,log_frequencies.par,frequencies.par,voltage_extracted_frequency_indices.par,
                                         F_test_threshold.par=threshold.percentile,cepstral_F_threshold.par=threshold.percentile,NW.par,
                                         sampling_rate.par=1,threshold_crossings_LB.par=0,measured_quantity.par="Measured quantity",
                                         Rsq_threshold.par=0.95,Kolmogorov_percentile.par=0,TPT_threshold.par=0,outlier_percentile.par=0.99,
                                         units.par1="units",units.par2="units",new_directory.par="Multitaper_F_Test",old_directory.par="",
                                         cepstral_bool.par=FALSE,output.par=FALSE,ts_interp_bool.par=FALSE,mdss_bool.par=FALSE,remove_outliers_bool.par=FALSE,
                                         spectral_power_bool.par=TRUE,residual_eigencoeffs_bool.par=TRUE,
                                         whitened_log_spectrum_bool.par=FALSE,cleaned_log_spectrum_bool.par=FALSE,
                                         plot_quadratic_diagnostics_bool.par=FALSE,cepstral_jk_spectral_power_bool.par=FALSE,
                                         cepstral_measured_quantity.par="Measured quantity",cepstral_units.par="units",cepstral_output.par=FALSE,
                                         cepstral_plot_spectral_power_bool.par=FALSE,cepstral_power_bool.par=FALSE,
                                         cepstral_output_jk_spectral_power.par=FALSE,cepstral_ha_bool.par=FALSE,
                                         cepstral_residual_eigencoeffs_bool.par=FALSE,cepstrum_new_directory.par="Multitaper_Cepstral_F_Test",
                                         cepstral_power.verbose_par=FALSE,verbose.par=FALSE,spectral_powers.par=NA,first_time.par=0){
  if(verbose.par==TRUE){
    tic()
  }
  temp.sampling_rate=1/sampling_period.par
  temp.M2=mt_sa_ha_object.par$out.M2
  temp.extracted_frequency_indices<-1:temp.M2
  temp.log_spectrum<-rep(0,temp.M2)
  temp.N_log=0
  temp.run_failure_parameter=NULL
  temp.attempt_number<-1
  temp.running_threshold=cepstral_F_threshold.par
  temp.quefrencies<-c()
  temp.quefrencies_full<-c()
  temp.extracted_quefrequency_indices<-c()
  temp.eigencoefficients<-c()
  temp.log_harmonic_powers<-c()
  temp.significant_cyclic_frequencies<-c()
  temp.quefrency_spacing=0
  if(spectral_power_bool.par==TRUE & residual_eigencoeffs_bool.par==TRUE){
    temp.spectral_power_estimates<-spectral_powers.par
    if(!is.na(spectral_powers.par)){
      temp.spectral_power_estimates<-mt_sa_ha_object.par$out.spectral_power_estimates
    }
    temp.residual_spectral_power_estimates<-mt_sa_ha_object.par$out.residual_spectral_power_estimates
    temp.M2=length(temp.spectral_power_estimates)
    temp.M=2*(temp.M2-1)
    temp.cepstral_sampling_rate=sampling_period.par*temp.M
    temp.log_spectrum_object<-log_spectrum_tsa.function(temp.spectral_power_estimates,temp.residual_spectral_power_estimates,log_frequencies.par,
                                                        frequencies.par=frequencies.par,frequency_indices.par=voltage_extracted_frequency_indices.par,
                                                        F_test_threshold.par=F_test_threshold.par,sampling_period.par=sampling_period.par,
                                                        measured_quantity.par=measured_quantity.par,
                                                        Rsq_threshold.par=Rsq_threshold.par,Kolmogorov_percentile.par=Kolmogorov_percentile.par,
                                                        TPT_threshold.par=TPT_threshold.par,outlier_percentile.par=outlier_percentile.par,
                                                        units.par1=units.par1,units.par2=units.par2,
                                                        new_directory.par=new_directory.par,old_directory.par=old_directory.par,
                                                        cepstral_bool.par=cepstral_bool.par,output.par=output.par,ts_interp_bool.par=ts_interp_bool.par,
                                                        mdss_bool.par=mdss_bool.par,remove_outliers_bool.par=remove_outliers_bool.par,
                                                        plot_quadratic_diagnostics_bool.par=plot_quadratic_diagnostics_bool.par,
                                                        first_time.par=first_time.par)
    #Use the original multitaper F-test threshold for the un-whitened, uncleaned log spectrum,
    #and use the lower threshold for the whitened and whitened+cleaned estimates.
    temp.F_test_thresholds<-c(F_test_threshold.par,rep(temp.running_threshold,2))
    temp.log_spectrum_list<-list()
    temp.log_spectrum_list[[1]]<-temp.log_spectrum_object$out.log_PSD
    temp.N_log=length(temp.log_spectrum_list[[1]])
    temp.residual_powers<-rep(0,temp.N_log)
    temp.peak_frequencies<-c()
    temp.peak_areas<-c()
    if(remove_outliers_bool.par==TRUE){
      temp.log_spectrum_list[[2]]<-temp.log_spectrum_object$out.cleaned_log_PSD
      temp.log_spectrum_list[[3]]<-temp.log_spectrum_object$out.cleaned_log_whitened_PSD
      temp.residual_powers<-temp.log_spectrum_list[[1]]-temp.log_spectrum_list[[2]]
      temp.peak_frequencies<-temp.log_spectrum_object$out.peak_frequencies
      temp.peak_areas<-temp.log_spectrum_object$out.peak_areas
    }
    temp.num_log_spectrum_list_items=length(temp.log_spectrum_list)
    temp.index=2
    temp.string<-"_Whitened_Cleaned"
    if(whitened_log_spectrum_bool.par==TRUE){
      if(remove_outliers_bool.par==TRUE & cleaned_log_spectrum_bool.par==TRUE){
        temp.index=3
      }
      else{
        temp.index=2
        temp.string<-"_Whitened"
      }
    }
    else if(!remove_outliers_bool.par & !whitened_log_spectrum_bool.par){
      temp.index=1
      temp.string<-"_Raw"
    }
    if(verbose.par==TRUE){
      cat("temp.index = ",temp.index,"\n")
    }
    temp.log_spectrum<-temp.log_spectrum_list[[temp.index]]
    #try({
    temp.log_mt_sa_ha_object.par<-mt_sa_ha.function(ts.par=temp.log_spectrum,NW.par=NW.par,jackknife.par=cepstral_jk_spectral_power_bool.par,
                                                    plot.par=cepstral_plot_spectral_power_bool.par,measured_quantity.par=cepstral_measured_quantity.par,
                                                    measured_units.par=cepstral_units.par,sampling_rate.par=temp.cepstral_sampling_rate,
                                                    F_test_threshold.par=temp.F_test_thresholds[temp.index],output.par=cepstral_output.par,
                                                    spectral_power_bool.par=cepstral_power_bool.par,jk_output.par=cepstral_output_jk_spectral_power.par,
                                                    ha_bool.par=cepstral_ha_bool.par,residual_bool.par=cepstral_residual_eigencoeffs_bool.par,
                                                    threshold_crossings_LB.par=threshold_crossings_LB.par,
                                                    new_directory.par=paste(cepstrum_new_directory.par,temp.string,"/",sep=""),
                                                    old_directory.par=old_directory.par,
                                                    cepstral_bool.par=cepstral_bool.par,verbose.par=cepstral_power.verbose_par)
    #},silent=T)
  }
  temp.zero_index=temp.M2-1
  temp.eigencoefficients<-temp.log_mt_sa_ha_object.par$out.eigencoeffs
  temp.slepian_functions<-temp.log_mt_sa_ha_object.par$out.slepian_functions
  temp.quefrencies_full<-temp.log_mt_sa_ha_object.par$out.frequencies_full
  temp.quefrencies<-temp.log_mt_sa_ha_object.par$out.frequencies
  temp.extracted_quefrequency_indices<-temp.log_mt_sa_ha_object.par$out.extracted_frequency_indices
  temp.quefrency_spacing=temp.log_mt_sa_ha_object.par$out.frequency_spacing
  temp.extracted_frequency_indices<-
    sort(unique(c(1,round(1/(temp.extracted_quefrequency_indices*sampling_period.par)/temp.sampling_rate*temp.M))))
  temp.num_extracted_frequencies=length(temp.extracted_frequency_indices)
  temp.extracted_frequency_indices[1]<-max(c(temp.extracted_frequency_indices[1],1))
  temp.extracted_frequency_indices[temp.num_extracted_frequencies]<-min(c(temp.extracted_frequency_indices[temp.num_extracted_frequencies],temp.M2))
  #Compute the harmonic coefficients.
  temp.significant_frequencies<-temp.log_mt_sa_ha_object.par$out.significant_frequencies
  temp.significant_frequency_indices<-round(temp.significant_frequencies*temp.M)
  temp.num_significant=length(temp.significant_frequencies)
  temp.significant_cyclic_frequencies=0
  temp.harmonic_coefficients=0
  if(temp.num_significant>0){
    temp.significant_frequency_indices<-temp.significant_frequency_indices[temp.significant_frequency_indices>0 & temp.significant_frequency_indices<=temp.M2]
    if(length(temp.significant_frequency_indices)>0){
      temp.num_significant=length(temp.significant_frequency_indices)
      temp.significant_frequencies<-temp.quefrencies[temp.significant_frequency_indices]
      temp.running_significant_frequency_indices<-which(temp.significant_frequencies>0)
      if(length(temp.running_significant_frequency_indices)>0){
        temp.significant_cyclic_frequencies<-1/(temp.significant_frequencies[temp.running_significant_frequency_indices])
        temp.significant_frequency_indices<-temp.significant_frequency_indices[temp.running_significant_frequency_indices]
        temp.harmonic_coefficients<-sapply(temp.zero_index+temp.significant_frequency_indices-1,harmonic_amplitude.function,temp.eigencoefficients,
                                           temp.slepian_functions)
      }
      else{
        temp.num_significant=0
        temp.significant_frequencies=0
        temp.significant_cyclic_frequencies=0
        temp.harmonic_coefficients=0
        temp.extracted_frequency_indices=1
      }
    }
    else{
      temp.num_significant=0
      temp.significant_frequencies=0
      temp.significant_cyclic_frequencies=0
      temp.harmonic_coefficients=0
      temp.extracted_frequency_indices=1
    }
  }
  else{
    temp.num_significant=0
    temp.significant_frequencies=0
    temp.significant_cyclic_frequencies=0
    temp.harmonic_coefficients=0
    temp.extracted_frequency_indices=1
  }
  if(verbose.par==TRUE){
    cat("Cepstral F-test threshold = ",temp.running_threshold,"\n")
    cat("All cepstral-analysis computations: ")
    toc()
  }
  temp.list<-list(out.extracted_frequency_indices=temp.extracted_frequency_indices,
                  out.significant_frequency_indices=temp.significant_frequency_indices,
                  out.harmonic_coefficients=temp.harmonic_coefficients,
                  out.significant_frequencies=temp.significant_frequencies,
                  out.all_indices=voltage_extracted_frequency_indices.par,
                  out.N_log=temp.N_log,
                  out.log_spectrum=temp.log_spectrum,
                  out.run_failure_parameter=temp.run_failure_parameter,
                  out.peak_frequencies=temp.peak_frequencies,
                  out.peak_areas=temp.peak_areas,
                  out.significant_cyclic_frequencies=temp.significant_cyclic_frequencies)
  return(temp.list)
}
























