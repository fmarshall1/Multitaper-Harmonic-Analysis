#Francois Marshall, Boston University
#Header file for RNG.
###################################################################################################################


MUA_LFP_comparison_Marshall_read_datasets.function<-function(directory_file_name.par="",
                                                             directory_file_name_MUA.par="",
                                                             directory_file_name_LFP.par="",
                                                             ts_parameters_file.par="",
                                                             time_window_index.par=1,record_size.par=1,
                                                             x_measurement.par="",y_measurement.par="",
                                                             time_units.par="",y_units.par="",
                                                             x_scale.par=1,y_scale.par=1,plot.par=FALSE,
                                                             working_directory_string.par="",header.par=TRUE,
                                                             output_bool.par=FALSE,step_size.par=1,
                                                             full_series_bool.par=FALSE,
                                                             start_window_time.par=0,
                                                             end_window_time.par=0,
                                                             base_time.par=0){
  #Raw time series.
  temp.TS_data_upload_text_decimation_object<-
    TS_data_upload_text_decimation.function(file_name.par=directory_file_name.par,ts_parameters_file.par=ts_parameters_file.par,
                                            time_window_index.par=time_window_index.par,record_size.par=record_size.par,
                                            x_measurement.par=x_measurement.par,y_measurement.par=y_measurement.par,
                                            time_units.par=time_units.par,y_units.par=y_units.par,
                                            pdf_title.par="Time_series.pdf",
                                            x_scale.par=x_scale.par,y_scale.par=y_scale.par,
                                            plot.par=plot.par,num_plotting.par=0,
                                            working_directory_string.par=working_directory_string.par,
                                            header.par=header.par,output_bool.par=output_bool.par,
                                            step_size.par=step_size.par)
  temp.time_sequence<-temp.TS_data_upload_text_decimation_object$out.times
  print(max(temp.time_sequence))
  temp.ts_values<-temp.TS_data_upload_text_decimation_object$out.ts
  temp.sampling_period=temp.TS_data_upload_text_decimation_object$out.sampling_period
  temp.sampling_rate=temp.TS_data_upload_text_decimation_object$out.sampling_rate
  temp.start_window_time=0
  temp.end_window_time=0
  if(full_series_bool.par==TRUE & is.na(start_window_time.par)==TRUE & is.na(end_window_time.par)==TRUE){
    temp.start_window_time=min(temp.time_sequence)
    temp.end_window_time=max(temp.time_sequence)
  } else{
    temp.start_window_time=start_window_time.par
    temp.end_window_time=end_window_time.par
    if(!is.na(start_window_time.par)){
      temp.ts_values<-temp.ts_values[temp.time_sequence>=start_window_time.par]
      temp.time_sequence<-temp.time_sequence[temp.time_sequence>=start_window_time.par]
    } else{
      temp.start_window_time=min(temp.time_sequence)
    }
    if(!is.na(end_window_time.par)){
      temp.ts_values<-temp.ts_values[temp.time_sequence<=end_window_time.par]
      temp.time_sequence<-temp.time_sequence[temp.time_sequence<=end_window_time.par]
    } else{
      temp.end_window_time=max(temp.time_sequence)
    }
  }
  temp.N=length(temp.ts_values)
  #Reconstructions of the low- and high-frequency demodulates obtained using the filter of Marshall-Thomson-Kramer.
  #For the Patient C5 / Electrode E1 / (-90,90]Hz ) stratum, e.g., the files are originally located in the text file,
  #" 2_Performance_Analysis/4_Nonstationary_Analysis/Patient_C5/Electrode_1/0_90_Hz/Filtered_Data/0_90_Hz_Demodulate.txt ",
  #while this file has itself been copied and pasted into the "MUA_Analysis/Data" directory.
  #Slepian MUA.
  temp.TS_data_upload_text_decimation_object<-
    TS_data_upload_text_decimation.function(file_name.par=directory_file_name_MUA.par,ts_parameters_file.par="",
                                            time_window_index.par=time_window_index.par,record_size.par=record_size.par,
                                            x_measurement.par=x_measurement.par,y_measurement.par=y_measurement.par,
                                            time_units.par=time_units.par,y_units.par=y_units.par,
                                            pdf_title.par="Time_series_Marshall_MUA.pdf",
                                            x_scale.par=x_scale.par,y_scale.par=y_scale.par,
                                            plot.par=plot.par,num_plotting.par=0,
                                            working_directory_string.par=working_directory_string.par,
                                            header.par=header.par,output_bool.par=output_bool.par,
                                            step_size.par=step_size.par)
  temp.time_sequence_Marshall_MUA<-base_time.par+temp.TS_data_upload_text_decimation_object$out.times
  temp.ts_values_Marshall_MUA<-temp.TS_data_upload_text_decimation_object$out.ts
  temp.N_Marshall_MUA=temp.TS_data_upload_text_decimation_object$out.N
  temp.sampling_period_Marshall_MUA=temp.TS_data_upload_text_decimation_object$out.sampling_period
  temp.sampling_rate_Marshall_MUA=temp.TS_data_upload_text_decimation_object$out.sampling_rate
  #Slepian LFP.
  temp.TS_data_upload_text_decimation_object<-
    TS_data_upload_text_decimation.function(file_name.par=directory_file_name_LFP.par,
                                            ts_parameters_file.par="",
                                            time_window_index.par=time_window_index.par,
                                            record_size.par=record_size.par,
                                            x_measurement.par=x_measurement.par,y_measurement.par=y_measurement.par,
                                            time_units.par=time_units.par,y_units.par=y_units.par,
                                            pdf_title.par="Time_series_Marshall_LFP.pdf",
                                            x_scale.par=x_scale.par,y_scale.par=y_scale.par,
                                            plot.par=plot.par,num_plotting.par=0,
                                            working_directory_string.par=working_directory_string.par,
                                            header.par=header.par,output_bool.par=output_bool.par,
                                            step_size.par=step_size.par)
  temp.time_sequence_Marshall_LFP<-base_time.par+temp.TS_data_upload_text_decimation_object$out.times
  temp.ts_values_Marshall_LFP<-temp.TS_data_upload_text_decimation_object$out.ts
  temp.N_Marshall_LFP=temp.TS_data_upload_text_decimation_object$out.N
  temp.sampling_period_Marshall_LFP=temp.TS_data_upload_text_decimation_object$out.sampling_period
  temp.sampling_rate_Marshall_LFP=temp.TS_data_upload_text_decimation_object$out.sampling_rate
  #Time alignment.
  if(temp.time_sequence_Marshall_MUA[1]<temp.time_sequence_Marshall_LFP[1]){
    temp.time_sequence_Marshall_MUA<-temp.time_sequence_Marshall_MUA+temp.time_sequence_Marshall_LFP[1]-temp.time_sequence_Marshall_MUA[1]
  }
  #Data from the selected time window.
  temp.time_window_indices<-which(temp.time_sequence>temp.start_window_time & temp.time_sequence<temp.end_window_time)
  temp.N_window=length(temp.time_window_indices)
  temp.window_times<-temp.time_sequence[temp.time_window_indices]
  temp.window_time_indices_Marshall_MUA<-
    which(temp.time_sequence_Marshall_MUA>temp.start_window_time & temp.time_sequence_Marshall_MUA<temp.end_window_time)
  temp.N_Marshall_window=length(temp.window_time_indices_Marshall_MUA)
  temp.window_MUA_Marshall_times<-temp.time_sequence_Marshall_MUA[temp.window_time_indices_Marshall_MUA]
  temp.window_time_indices_Marshall_LFP<-
    which(temp.time_sequence_Marshall_LFP>temp.start_window_time & temp.time_sequence_Marshall_LFP<temp.end_window_time)
  temp.N_Marshall_window=length(temp.window_time_indices_Marshall_LFP)
  temp.window_LFP_Marshall_times<-temp.time_sequence_Marshall_LFP[temp.window_time_indices_Marshall_LFP]
  temp.list<-list(out.time_sequence=temp.time_sequence,
                  out.ts_values=temp.ts_values,
                  out.sampling_period=temp.sampling_period,
                  out.sampling_rate=temp.sampling_rate,
                  out.N=temp.N,
                  out.time_sequence_Marshall_MUA=temp.time_sequence_Marshall_MUA,
                  out.ts_values_Marshall_MUA=temp.ts_values_Marshall_MUA,
                  out.sampling_period_Marshall_MUA=temp.sampling_period_Marshall_MUA,
                  out.sampling_rate_Marshall_MUA=temp.sampling_rate_Marshall_MUA,
                  out.N_Marshall_MUA=temp.N_Marshall_MUA,
                  out.time_sequence_Marshall_LFP=temp.time_sequence_Marshall_LFP,
                  out.ts_values_Marshall_LFP=temp.ts_values_Marshall_LFP,
                  out.sampling_period_Marshall_LFP=temp.sampling_period_Marshall_LFP,
                  out.sampling_rate_Marshall_LFP=temp.sampling_rate_Marshall_LFP,
                  out.N_Marshall_LFP=temp.N_Marshall_LFP,
                  out.start_window_time=temp.start_window_time,
                  out.end_window_time=temp.end_window_time,
                  out.window_times=temp.window_times,
                  out.time_window_indices=temp.time_window_indices,
                  out.N_window=temp.N_window,
                  out.window_MUA_Marshall_times=temp.window_MUA_Marshall_times,
                  out.window_time_indices_Marshall_MUA=temp.window_time_indices_Marshall_MUA,
                  out.N_Marshall_window=temp.N_Marshall_window,
                  out.window_MUA_Marshall_times=temp.window_MUA_Marshall_times,
                  out.N_Marshall_window=temp.N_Marshall_window,
                  out.window_LFP_Marshall_times=temp.window_LFP_Marshall_times,
                  out.window_time_indices_Marshall_LFP=temp.window_time_indices_Marshall_LFP)
  
  return(temp.list)
}



MUA_HFO_LFP_comparison_Marshall_filtering.function<-function(ts_values.par,
                                                             ts_values_Marshall_MUA.par,ts_values_Marshall_LFP.par,
                                                             bandpass_filter_strings_list.par,
                                                             bandpass_filter_lists_list.par,
                                                             output_bool.par=FALSE){
  temp.N=length(ts_values.par)
  #No whitening.
  temp.N_Marshall_MUA=length(ts_values_Marshall_MUA.par)
  temp.integrated_ts_values_Marshall_MUA<-
    c(ts_values_Marshall_MUA.par[1],ts_values_Marshall_MUA.par[2:temp.N_Marshall_MUA-1]+ts_values_Marshall_MUA.par[2:temp.N_Marshall_MUA])
  temp.MUA_not_differenced_filtered_series_list<-list()
  temp.HFO_not_differenced_filtered_series_list<-list()
  temp.LFP_not_differenced_filtered_series_list<-list()
  if(output_bool.par==TRUE){
    cat("MUA filtering\n")
  }
  temp.num_filters_MUA=length(bandpass_filter_strings_list.par[[1]])
  temp.filter_object_MUA_list<-bandpass_filter_lists_list.par[[1]]
  for(temp.j in 1:temp.num_filters_MUA){
    if(temp.j<temp.num_filters_MUA){
      temp.MUA_not_differenced_filtered_series_list[[temp.j]]<-filter(temp.filter_object_MUA_list[[temp.j]],ts_values.par)
    } else{
      temp.MUA_not_differenced_filtered_series_list[[temp.j]]<-temp.integrated_ts_values_Marshall_MUA
    }
  }
  if(output_bool.par==TRUE){
    cat("HFO filtering\n")
  }
  temp.num_filters_HFO=length(bandpass_filter_strings_list.par[[2]])
  temp.filter_object_HFO_list<-bandpass_filter_lists_list.par[[2]]
  for(temp.j in 1:temp.num_filters_HFO){
    temp.HFO_not_differenced_filtered_series_list[[temp.j]]<-filter(temp.filter_object_HFO_list[[temp.j]],ts_values.par)
  }
  if(output_bool.par==TRUE){
    cat("LFP filtering\n")
  }
  temp.num_filters_LFP=length(bandpass_filter_strings_list.par[[3]])
  temp.filter_object_LFP_list<-bandpass_filter_lists_list.par[[3]]
  for(temp.j in 1:temp.num_filters_LFP){
    if(temp.j<temp.num_filters_LFP){
      temp.LFP_not_differenced_filtered_series_list[[temp.j]]<-filter(temp.filter_object_LFP_list[[temp.j]],ts_values.par)
    } else{
      temp.LFP_not_differenced_filtered_series_list[[temp.j]]<-ts_values_Marshall_LFP.par
    }
  }
  temp.not_differenced_filtered_series_lists<-list(out.MUA_not_differenced_filtered_series_list=temp.MUA_not_differenced_filtered_series_list,
                                                   out.HFO_not_differenced_filtered_series_list=temp.HFO_not_differenced_filtered_series_list,
                                                   out.LFP_not_differenced_filtered_series_list=temp.LFP_not_differenced_filtered_series_list)
  #Whitening.
  temp.diffs<-c(0,ts_values.par[2:temp.N]-ts_values.par[2:temp.N-1])
  temp.MUA_differenced_filtered_series_list<-list()
  if(output_bool.par==TRUE){
    cat("MUA filtering\n")
  }
  for(temp.j in 1:temp.num_filters_MUA){
    if(temp.j<temp.num_filters_MUA){
      temp.MUA_differenced_filtered_series_list[[temp.j]]<-filter(temp.filter_object_MUA_list[[temp.j]],temp.diffs)
    } else{
      temp.MUA_differenced_filtered_series_list[[temp.j]]<-ts_values_Marshall_MUA.par
    }
  }
  #500Hz whitening.
  temp.500Hz_step_size=floor(temp.sampling_rate/500)
  temp.500Hzdiffs<-
    c(rep(0,temp.500Hz_step_size),ts_values.par[(temp.500Hz_step_size+1):temp.N]-ts_values.par[(temp.500Hz_step_size+1):temp.N-temp.500Hz_step_size])
  temp.500Hzdiffs_Slepian<-
    c(rep(0,temp.500Hz_step_size),ts_values_Marshall_MUA.par[(temp.500Hz_step_size+1):temp.N_Marshall_MUA]-
        ts_values_Marshall_MUA.par[(temp.500Hz_step_size+1):temp.N_Marshall_MUA-temp.500Hz_step_size])
  temp.MUA_500Hzdifferenced_filtered_series_list<-list()
  if(output_bool.par==TRUE){
    cat("MUA filtering\n")
  }
  for(temp.j in 1:temp.num_filters_MUA){
    if(temp.j<temp.num_filters_MUA){
      temp.MUA_500Hzdifferenced_filtered_series_list[[temp.j]]<-filter(temp.filter_object_MUA_list[[temp.j]],temp.500Hzdiffs)
    } else{
      temp.MUA_500Hzdifferenced_filtered_series_list[[temp.j]]<-temp.500Hzdiffs_Slepian
    }
  }
  temp.list<-list(out.not_differenced_filtered_series_lists=temp.not_differenced_filtered_series_lists,
                  out.MUA_differenced_filtered_series_list=temp.MUA_differenced_filtered_series_list,
                  out.MUA_500Hzdifferenced_filtered_series_list=temp.MUA_500Hzdifferenced_filtered_series_list)
  return(temp.list)
}



weiss_action_potential_detection.function<-function(temp.MUA_not_differenced_filtered_series.par,
                                                    time_sequence.par,
                                                    action_potential_threshold_level.par=2.5,
                                                    start_window_time.par=0,end_window_time.par=0){
  #Detect the action-potential events using the method of Weiss et al. (2013).
  temp.mean_signal<-mean(temp.MUA_not_differenced_filtered_series.par)
  temp.sd_signal<-sqrt(var(temp.MUA_not_differenced_filtered_series.par))
  temp.standardized_MUA_series<-(temp.mean_signal-temp.MUA_not_differenced_filtered_series.par)/temp.sd_signal
  temp.action_potential_time_indices<-which(temp.standardized_MUA_series>action_potential_threshold_level.par)
  temp.action_potential_times<-time_sequence.par[temp.action_potential_time_indices]
  temp.standardized_MUA_series_window<-temp.standardized_MUA_series[temp.action_potential_time_indices]
  temp.num_ap_times=length(temp.action_potential_times)
  temp.point_process_realization<-rep(0,temp.num_ap_times)
  for(temp.j in 2:temp.num_ap_times){
    temp.point_process_realization[temp.j]=temp.point_process_realization[temp.j-1]+abs(temp.standardized_MUA_series_window[temp.j])
  }
  temp.action_potential_times_window_indices<-
    which(temp.action_potential_times>start_window_time.par & temp.action_potential_times<end_window_time.par)
  temp.action_potential_times_window<-temp.action_potential_times[temp.action_potential_times_window_indices]
  temp.point_process_realization_window<-temp.point_process_realization[temp.action_potential_times_window_indices]
  temp.point_process_realization_window<-
    (temp.point_process_realization_window-min(temp.point_process_realization_window))/
    (max(temp.point_process_realization_window)-min(temp.point_process_realization_window))
  temp.list<-list(out.action_potential_times_window=temp.action_potential_times_window,
                  out.point_process_realization_window=temp.point_process_realization_window)
  return(temp.list)
}




standardized_squared_filtered_window.funcion<-function(window_times.par,time_window_indices.par,
                                                       filtered_series_list.par,
                                                       num_filters.par,
                                                       trial_frequency_bands_list.par,sampling_rate.par=1,
                                                       action_potential_times_window.par,point_process_realization_window.par,
                                                       first_time.par=0,
                                                       all_title_strings.par="",
                                                       abbreviated_time_units_string.par="",
                                                       time_units_string.par="",measure_units_string.par="",
                                                       x_scale.par="",
                                                       pdf_title.par="",
                                                       window_times_filtered.par=NA,time_window_indices_filtered.par=NA,
                                                       plot_bool.par=FALSE){
  temp.total_num_filters=length(filtered_series_list.par)
  temp.window_times_list<-list()
  temp.squared_filtered_series_list<-list()
  temp.running_time_window_indices<-c()
  for(temp.j in 1:temp.total_num_filters){
    if(!is.na(window_times_filtered.par)){
      if(temp.j<=num_filters.par){
        temp.window_times_list[[temp.j]]<-window_times.par
        temp.running_time_window_indices<-time_window_indices.par
      } else{
        temp.window_times_list[[temp.j]]<-window_times_filtered.par
        temp.running_time_window_indices<-time_window_indices_filtered.par
      }
    } else{
      temp.window_times_list[[temp.j]]<-window_times.par
      temp.running_time_window_indices<-time_window_indices.par
    }
    temp.window_ordinates<-filtered_series_list.par[[temp.j]][temp.running_time_window_indices]
    temp.window_squared_ordinates<-temp.window_ordinates^2
    temp.squared_filtered_series_list[[temp.j]]<-
      (temp.window_squared_ordinates-min(temp.window_squared_ordinates))/(max(temp.window_squared_ordinates)-min(temp.window_squared_ordinates))
  }
  #Downsampling.
  temp.record_sizes=rep(0,temp.total_num_filters)
  for(temp.j in 1:temp.total_num_filters){
    temp.step_size=floor(0.5*sampling_rate.par/(trial_frequency_bands_list.par[[temp.j]][2]-trial_frequency_bands_list.par[[temp.j]][1]))
    temp.index_sequence_j<-c()
    if(!is.na(window_times_filtered.par)){
      if(temp.j<temp.total_num_filters){
        temp.N_window=length(time_window_indices.par)
        temp.index_sequence_j<-seq(from=1,to=temp.N_window,by=temp.step_size)
      } else{
        temp.N_Marshall_window=length(time_window_indices_filtered.par)
        temp.index_sequence_j<-seq(from=1,to=temp.N_Marshall_window,by=temp.step_size)
      }
    } else{
      temp.N_window=length(time_window_indices.par)
      temp.index_sequence_j<-seq(from=1,to=temp.N_window,by=temp.step_size)
    }
    temp.window_times_list[[temp.j]]<-temp.window_times_list[[temp.j]][temp.index_sequence_j]-first_time.par
    temp.squared_filtered_series_list[[temp.j]]<-temp.squared_filtered_series_list[[temp.j]][temp.index_sequence_j]
    temp.record_sizes[temp.j]=length(temp.squared_filtered_series_list[[temp.j]])
  }
  temp.min_record_size=min(temp.record_sizes)
  temp.window_times_list<-list.append(temp.window_times_list,action_potential_times_window.par-first_time.par)
  temp.squared_filtered_series_list<-list.append(temp.squared_filtered_series_list,point_process_realization_window.par)
  #Plotting.
  if(plot_bool.par==TRUE){
    temp.first_time=round_general.function(first_time.par*x_scale.par)
    multipage_plot_comparison.function(x_plotting_list.par=temp.window_times_list,
                                       y_plotting_list.par=temp.squared_filtered_series_list,
                                       x_plotting_list2.par=NA,y_plotting_list2.par=NA,
                                       bounds_all.par=NA,
                                       x_label.par=paste("Time, in ",abbreviated_time_units_string.par," since ",
                                                         temp.first_time," ",time_units_string.par,sep=""),
                                       y_label.par=paste("Squared units of ",measure_units_string.par,", normalized to [0,1]",sep=""),
                                       title_strings.par=all_title_strings.par,
                                       pdf_title.par=paste(pdf_title.par,".pdf",sep=""),
                                       no_comparison_bool.par=FALSE,
                                       num_samples.par=min(temp.min_record_size,5e3),shade_intervals.par=NA)
  }
  temp.list<-list(out.window_times_list=temp.window_times_list,
                  out.squared_filtered_series_list=temp.squared_filtered_series_list,
                  out.min_record_size=temp.min_record_size)
  return(temp.list)
}


rhythm_comparison_Marshall_standardization.function<-function(window_times.par,time_window_indices.par,
                                                              filtered_series_lists.par,num_filter_objects_vector.par,
                                                              trial_frequency_bands_list.par,sampling_rate.par=1,
                                                              action_potential_times_window.par,point_process_realization_window.par,
                                                              bandpass_filter_strings_list.par,
                                                              cumulative_ordinate_string.par="",
                                                              first_time.par=0,
                                                              abbreviated_time_units_string.par="",
                                                              time_units_string.par="",measure_units_string.par="",x_scale.par="",
                                                              pdf_title_vector.par="",
                                                              window_Marshall_times_list.par,window_time_indices_Marshall_list.par,
                                                              plot_bool.par=FALSE){
  temp.num_rhythms=length(window_Marshall_times_list.par)
  temp.window_times_lists<-list()
  temp.filtered_absolute_series_lists<-list()
  temp.min_record_sizes<-rep(0,temp.num_rhythms)
  for(temp.j in 1:temp.num_rhythms){
    temp.all_title_strings<-c(bandpass_filter_strings_list.par[[temp.j]],cumulative_ordinate_string.par)
    temp.standardized_squared_filtered_window_object<-
      standardized_squared_filtered_window.funcion(window_times.par=window_times.par,
                                                   time_window_indices.par=time_window_indices.par,
                                                   filtered_series_list.par=filtered_series_lists.par[[temp.j]],
                                                   trial_frequency_bands_list.par=trial_frequency_bands_list.par[[temp.j]],
                                                   sampling_rate.par=sampling_rate.par,
                                                   action_potential_times_window.par=action_potential_times_window.par,
                                                   point_process_realization_window.par=point_process_realization_window.par,
                                                   num_filters.par=num_filter_objects_vector.par[temp.j],
                                                   first_time.par=first_time.par,
                                                   all_title_strings.par=temp.all_title_strings,
                                                   abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                                   time_units_string.par=time_units_string.par,
                                                   measure_units_string.par=measure_units_string.par,x_scale.par=x_scale.par,
                                                   pdf_title.par=pdf_title_vector.par[[temp.j]],
                                                   window_times_filtered.par=window_Marshall_times_list.par[[temp.j]],
                                                   time_window_indices_filtered.par=window_time_indices_Marshall_list.par[[temp.j]],
                                                   plot_bool.par=plot_bool.par)
    temp.window_times_lists[[temp.j]]<-temp.standardized_squared_filtered_window_object$out.window_times_list
    temp.filtered_absolute_series_lists[[temp.j]]<-temp.standardized_squared_filtered_window_object$out.squared_filtered_series_list
    temp.min_record_sizes[temp.j]=temp.standardized_squared_filtered_window_object$out.min_record_size
  }
  temp.list<-list(out.window_times_lists=temp.window_times_lists,
                  out.filtered_absolute_series_lists=temp.filtered_absolute_series_lists,
                  out.min_record_sizes=temp.min_record_sizes)
  return(temp.list)
}






MUA_HFO_LFP_peak_trace_visual_comparison.function<-function(temp.MUA_not_differenced_filtered_series.par,time_sequence.par,
                                                            action_potential_threshold_level.par,
                                                            start_window_time.par,end_window_time.par,
                                                            window_times.par,time_window_indices.par,filtered_series_lists.par,
                                                            num_filter_objects_vector.par,trial_frequency_bands_list.par,sampling_rate.par,
                                                            bandpass_filter_strings_list.par,cumulative_ordinate_string.par="",
                                                            abbreviated_time_units_string.par="",time_units_string.par="",
                                                            measure_units_string.par="",x_scale.par=1,
                                                            window_MUA_Marshall_times.par,window_LFP_Marshall_times.par,
                                                            window_time_indices_Marshall_MUA.par,window_time_indices_Marshall_LFP.par,
                                                            differenced_filtered_series_list.par,MUA_500Hzdifferenced_filtered_series_list.par,
                                                            plot_bool.par=TRUE){
  #Action-potential identification for a single window.
  temp.weiss_action_potential_detection_object<-
    weiss_action_potential_detection.function(temp.MUA_not_differenced_filtered_series.par=temp.MUA_not_differenced_filtered_series.par,
                                              time_sequence.par=time_sequence.par,
                                              action_potential_threshold_level.par=action_potential_threshold_level.par,
                                              start_window_time.par=start_window_time.par,end_window_time.par=end_window_time.par)
  temp.action_potential_times_window<-temp.weiss_action_potential_detection_object$out.action_potential_times_window
  temp.point_process_realization_window<-temp.weiss_action_potential_detection_object$out.point_process_realization_window
  #Absolute values.
  temp.cumulative_ordinate_string<-paste("Cumulative absolute standardized ",measure_quantity_string.lower_case,
                                         "\nMUA [",trial_frequency_bands_MUA.par[[1]][1],",",trial_frequency_bands_MUA.par[[1]][1],"]",
                                         abbreviated_frequency_units.string,"\nFIR",filter_orders_MUA.par[3],", ",
                                         reference_paper_strings_MUA.par[3],sep="")
  temp.window_Marshall_times_list<-list(window_MUA_Marshall_times.par,
                                        NA,
                                        window_LFP_Marshall_times.par)
  temp.window_time_indices_Marshall_list<-list(window_time_indices_Marshall_MUA.par,
                                               NA,
                                               window_time_indices_Marshall_LFP.par)
  temp.pdf_title_vector<-c("MUA_Squared_Values_Normalized",
                           "HFO_Squared_Values_Normalized",
                           "LFP_Squared_Values_Normalized")
  temp.rhythm_comparison_Marshall_standardization_object<-
    rhythm_comparison_Marshall_standardization.function(window_times.par=window_times.par,time_window_indices.par=time_window_indices.par,
                                                        filtered_series_lists.par=filtered_series_lists.par,
                                                        num_filter_objects_vector.par=num_filter_objects_vector.par,
                                                        trial_frequency_bands_list.par=trial_frequency_bands_list.par,
                                                        sampling_rate.par=sampling_rate.par,
                                                        action_potential_times_window.par=temp.action_potential_times_window,
                                                        point_process_realization_window.par=temp.point_process_realization_window,
                                                        bandpass_filter_strings_list.par=bandpass_filter_strings_list.par,
                                                        cumulative_ordinate_string.par=cumulative_ordinate_string.par,
                                                        first_time.par=time_sequence.par[1],
                                                        abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                                        time_units_string.par=time_units_string.par,
                                                        measure_units_string.par=measure_units_string.par,
                                                        x_scale.par=x_scale.par,
                                                        pdf_title_vector.par=temp.pdf_title_vector,
                                                        window_Marshall_times_list.par=temp.window_Marshall_times_list,
                                                        window_time_indices_Marshall_list.par=temp.window_time_indices_Marshall_list,
                                                        plot_bool.par=TRUE)
  temp.window_times_no_diff_lists<-temp.rhythm_comparison_Marshall_standardization_object$out.window_times_lists
  temp.normalized_squared_filtered_series_no_diff_lists<-
    temp.rhythm_comparison_Marshall_standardization_object$out.filtered_absolute_series_lists
  temp.min_record_sizes<-temp.rhythm_comparison_Marshall_standardization_object$out.min_record_sizes
  #Differenced MUA series.
  temp.window_Marshall_times_list<-list(window_MUA_Marshall_times.par,
                                        window_MUA_Marshall_times.par)
  temp.window_time_indices_Marshall_list<-list(window_time_indices_Marshall_MUA.par,
                                               window_time_indices_Marshall_MUA.par)
  temp.pdf_title_vector<-c("Differenced_MUA_Squared_Values_Normalized",
                           "500Hzdifferenced_MUA_Squared_Values_Normalized")
  temp.rhythm_comparison_Marshall_standardization_object<-
    rhythm_comparison_Marshall_standardization.function(window_times.par=window_times.par,time_window_indices.par=time_window_indices.par,
                                                        filtered_series_lists.par=list(differenced_filtered_series_list.par,
                                                                                       MUA_500Hzdifferenced_filtered_series_list.par),
                                                        num_filter_objects_vector.par=c(num_filter_objects_vector.par[1],
                                                                                        num_filter_objects_vector.par[1]),
                                                        trial_frequency_bands_list.par=list(trial_frequency_bands_list.par[[1]],
                                                                                            trial_frequency_bands_list.par[[1]]),
                                                        sampling_rate.par=sampling_rate.par,
                                                        action_potential_times_window.par=temp.action_potential_times_window,
                                                        point_process_realization_window.par=temp.point_process_realization_window,
                                                        bandpass_filter_strings_list.par=list(bandpass_filter_strings_list.par[[1]],
                                                                                              bandpass_filter_strings_list.par[[1]]),
                                                        cumulative_ordinate_string.par=cumulative_ordinate_string.par,
                                                        first_time.par=time_sequence.par[1],
                                                        abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                                        time_units_string.par=time_units_string.par,
                                                        measure_units_string.par=measure_units_string.par,
                                                        x_scale.par=x_scale.par,
                                                        pdf_title_vector.par=temp.pdf_title_vector,
                                                        window_Marshall_times_list.par=temp.window_Marshall_times_list,
                                                        window_time_indices_Marshall_list.par=temp.window_time_indices_Marshall_list,
                                                        plot_bool.par=TRUE)
  temp.window_times_diff_lists<-temp.rhythm_comparison_Marshall_standardization_object$out.window_times_lists
  temp.normalized_squared_filtered_series_diff_lists<-
    temp.rhythm_comparison_Marshall_standardization_object$out.filtered_absolute_series_lists
  temp.list<-list(out.action_potential_times_window=temp.action_potential_times_window,
                  out.point_process_realization_window=temp.point_process_realization_window,
                  out.window_times_no_diff_lists=temp.window_times_no_diff_lists,
                  out.normalized_squared_filtered_series_no_diff_lists=temp.normalized_squared_filtered_series_no_diff_lists,
                  out.window_times_diff_lists=temp.window_times_diff_lists,
                  out.normalized_squared_filtered_series_diff_lists=temp.normalized_squared_filtered_series_diff_lists,
                  out.min_record_sizes=temp.min_record_sizes)
  return(temp.list)
}



partitioned_ISI_series.function<-function(firing_sections_times_list.par,
                                          time_sequence_Marshall_MUA.par,
                                          time_sequence_Marshall_LFP.par,
                                          abbreviated_time_units_string.par="",
                                          time_units_string.par="",
                                          plot_bool.par=FALSE){
  temp.num_trial_sections=length(firing_sections_times_list.par)
  temp.ISI_times_list<-list()
  temp.ISI_series_list<-list()
  temp.ISI_local_maxima_times_list<-list()
  temp.ISI_local_maxima_ordinates_list<-list()
  for(temp.j in 1:temp.num_trial_sections){
    temp.section_series_j<-firing_sections_times_list.par[[temp.j]]
    temp.size_j=length(temp.section_series_j)
    temp.ISI_series_j<-c()
    if(temp.size_j>1){
      temp.ISI_times_j<-temp.section_series_j[2:temp.size_j]
      temp.ISI_series_j<-temp.section_series_j[2:temp.size_j]-temp.section_series_j[2:temp.size_j-1]
    } else{
      temp.ISI_times_j<-temp.section_series_j
      temp.ISI_series_j<-temp.section_series_j
    }
    temp.ISI_times_list[[temp.j]]<-temp.ISI_times_j
    temp.ISI_series_list[[temp.j]]<-temp.ISI_series_j
    temp.size_j=length(temp.ISI_times_j)
    temp.buffer_times_list_j<-list()
    temp.buffer_ordinates_list_j<-list()
    temp.counter_j=1
    for(temp.k in 1:temp.size_j){
      temp.bool_k=FALSE
      if(temp.size_j>1){
        if(temp.k==1){
          if(temp.ISI_series_j[temp.k]>temp.ISI_series_j[temp.k+1]){
            temp.bool_k=TRUE
          }
        } else if(temp.k==temp.size_j){
          if(temp.ISI_series_j[temp.k]>temp.ISI_series_j[temp.k-1]){
            temp.bool_k=TRUE
          }
        } else{
          if(temp.ISI_series_j[temp.k]>temp.ISI_series_j[temp.k-1] & temp.ISI_series_j[temp.k]>temp.ISI_series_j[temp.k+1]){
            temp.bool_k=TRUE
          }
        }
        if(temp.bool_k==TRUE){
          temp.buffer_times_list_j[[temp.counter_j]]<-temp.ISI_times_j[temp.k]
          temp.buffer_ordinates_list_j[[temp.counter_j]]<-temp.ISI_series_j[temp.k]
          temp.counter_j=temp.counter_j+1
        }
      } else{
        temp.buffer_times_list_j[[temp.counter_j]]<-temp.ISI_times_j[temp.k]
        temp.buffer_ordinates_list_j[[temp.counter_j]]<-temp.ISI_series_j[temp.k]
        temp.counter_j=temp.counter_j+1
      }
    }
    temp.buffer_times_vector_j<-unlist(temp.buffer_times_list_j)
    temp.buffer_ordinates_vector_j<-unlist(temp.buffer_ordinates_list_j)
    temp.indices_j<-c()
    if(temp.size_j>1){
      temp.indices_j<-which(temp.buffer_ordinates_vector_j>median(temp.buffer_ordinates_vector_j))
      if(!length(temp.indices_j)){
        temp.indices_j=1
      }
    } else{
      temp.indices_j=1
    }
    temp.buffer_times_vector_j<-temp.buffer_times_vector_j[temp.indices_j]
    temp.buffer_ordinates_vector_j<-temp.buffer_ordinates_vector_j[temp.indices_j]
    temp.ISI_local_maxima_times_list[[temp.j]]<-temp.buffer_times_vector_j
    temp.ISI_local_maxima_ordinates_list[[temp.j]]<-temp.buffer_ordinates_vector_j
  }
  if(plot_bool.par==TRUE){
    multipage_plot_comparison.function(x_plotting_list.par=temp.ISI_local_maxima_times_list,
                                       y_plotting_list.par=temp.ISI_local_maxima_ordinates_list,
                                       x_plotting_list2.par=temp.ISI_times_list,
                                       y_plotting_list2.par=temp.ISI_series_list,
                                       x_label.par=paste("Time, in ",abbreviated_time_units_string.par," since ",
                                                         round_general.function(time_sequence_Marshall_MUA.par[1])," ",time_units_string.par,sep=""),
                                       y_label.par=paste("Inter-spike interval, in ",abbreviated_time_units_string.par,sep=""),
                                       types.par=c("p","h"),
                                       no_comparison_bool.par=TRUE,
                                       pdf_title.par="ISI_Section_Series.pdf")
  }
  #Generate the CDF-plots.
  temp.ISI_CDF_list<-list()
  temp.ISI_sorted_series_list<-list()
  for(temp.j in 1:temp.num_trial_sections){
    temp.section_ISI_series_j<-temp.ISI_series_list[[temp.j]]
    temp.ISI_sorted_series_list[[temp.j]]<-sort(temp.section_ISI_series_j)
    temp.size_j=length(temp.section_ISI_series_j)
    temp.CDF_j<-rep(0,temp.size_j)
    if(temp.size_j>1){
      for(temp.k in 1:(temp.size_j-1)){
        temp.CDF_j[temp.k+1]=temp.ISI_sorted_series_list[[temp.j]][temp.k+1]+temp.CDF_j[temp.k]
      }
    } else{
      temp.CDF_j[1]=temp.CDF_j[1]
    }
    temp.ISI_CDF_list[[temp.j]]<-temp.CDF_j
    temp.lm_object<-lm(temp.CDF_j~temp.ISI_sorted_series_list[[temp.j]])
    temp.coefficients_j<-temp.lm_object$coefficients
    temp.waiting_time_j=1/temp.coefficients_j
  }
  if(plot_bool.par==TRUE){
    multipage_plot_comparison.function(x_plotting_list.par=temp.ISI_sorted_series_list,
                                       y_plotting_list.par=temp.ISI_CDF_list,
                                       x_label.par=paste("Inter-spike interval, in ",abbreviated_time_units_string.par,sep=""),
                                       y_label.par=paste("Cumulative inter-spike interval, in ",abbreviated_time_units_string.par,sep=""),
                                       types.par=c("p","p"),
                                       no_comparison_bool.par=TRUE,
                                       pdf_title.par="ISI_Section_CDFs.pdf")
  }
  temp.list<-list(out.ISI_local_maxima_times_list=temp.ISI_local_maxima_times_list,
                  out.ISI_local_maxima_ordinates_list=temp.ISI_local_maxima_ordinates_list,
                  out.ISI_times_list=temp.ISI_times_list,
                  out.ISI_series_list=temp.ISI_series_list)
  return(temp.list)
}




quiescence_burst_bounds.function<-function(ISI_local_maxima_ordinates_list.par,
                                           num_breaks.par=10,
                                           abbreviated_time_units_string.par=""){
  temp.quiescence_bounds_list<-list()
  temp.burst_bounds_list<-list()
  temp.num_trial_sections=length(ISI_local_maxima_ordinates_list.par)
  pdf("ISI_Section_Histograms.pdf",width=8,height=6)
  par(mgp=c(2,0.5,0))
  for(temp.j in 1:temp.num_trial_sections){
    temp.section_ISI_series_j<-ISI_local_maxima_ordinates_list.par[[temp.j]]
    temp.h_j<-hist(temp.section_ISI_series_j,breaks=num_breaks.par,probability=TRUE,plot=FALSE)
    temp.ISI_bin_edge_values<-temp.h_j$breaks
    temp.num_bin_edges=length(temp.ISI_bin_edge_values)
    temp.plotting_heights<-c(temp.h_j$counts/sum(temp.h_j$counts)/(temp.ISI_bin_edge_values[2]-temp.ISI_bin_edge_values[1]),0)
    temp.num_heights=length(temp.plotting_heights)
    temp.sorted_heights<-unique(sort(temp.plotting_heights))
    temp.num_unique_heights=length(temp.sorted_heights)
    temp.penultimate_sorted_height<-temp.sorted_heights[temp.num_unique_heights-1]
    temp.last_sorted_height<-temp.sorted_heights[temp.num_unique_heights]
    temp.min_penultimate_peak_index=min(which(temp.plotting_heights==temp.penultimate_sorted_height))
    temp.min_last_peak_index=min(which(temp.plotting_heights==temp.last_sorted_height))
    if(temp.min_penultimate_peak_index<temp.min_last_peak_index){
      temp.quiescent_height=temp.penultimate_sorted_height
      temp.burst_height=temp.last_sorted_height
    } else{
      temp.quiescent_height=temp.last_sorted_height
      temp.burst_height=temp.penultimate_sorted_height
    }
    temp.quiescence_min_optimal_edge_index_left=min(which(temp.plotting_heights==temp.quiescent_height))
    temp.quiescence_max_optimal_edge_index_right=0
    if(temp.quiescence_min_optimal_edge_index_left<temp.num_heights){
      temp.quiescence_max_optimal_edge_index_right=temp.quiescence_min_optimal_edge_index_left+1
    } else{
      temp.quiescence_max_optimal_edge_index_right=temp.quiescence_min_optimal_edge_index_left
    }
    temp.burst_min_optimal_edge_index_left=min(which(temp.plotting_heights==temp.burst_height))
    temp.burst_min_optimal_edge_index_right=0
    if(temp.burst_min_optimal_edge_index_left<temp.num_heights){
      temp.burst_min_optimal_edge_index_right=temp.burst_min_optimal_edge_index_left+1
    } else{
      temp.burst_min_optimal_edge_index_right=temp.burst_min_optimal_edge_index_left
    }
    temp.quiescence_bounds_list[[temp.j]]<-
      temp.ISI_bin_edge_values[c(temp.quiescence_min_optimal_edge_index_left,temp.quiescence_max_optimal_edge_index_right)]
    temp.burst_bounds_list[[temp.j]]<-
      temp.ISI_bin_edge_values[c(temp.burst_min_optimal_edge_index_left,temp.burst_min_optimal_edge_index_right)]
    temp.lower_ISI_bin_value=0
    temp.upper_ISI_bin_value=max(temp.ISI_bin_edge_values)
    temp.lower_height=0
    temp.upper_height=max(temp.plotting_heights)
    plot(0,0,xlab=paste("Inter-spike interval, in ",abbreviated_time_units_string.par,sep=""),
         ylab=paste("Occurrences per ",abbreviated_time_units_string.par,sep=""),main="",
         xlim=c(temp.lower_ISI_bin_value,temp.upper_ISI_bin_value),ylim=c(temp.lower_height,temp.upper_height),
         pch=".",lab=c(10,10,7))
    grid()
    minor.tick(10,10)
    lines(temp.ISI_bin_edge_values,temp.plotting_heights,main="",type="s")
  }
  dev.off()
  temp.list<-list(out.quiescence_bounds_list=temp.quiescence_bounds_list,
                  out.burst_bounds_list=temp.burst_bounds_list)
  return(temp.list)
}




ISI_classification.function<-function(quiescence_bounds_list.par,burst_bounds_list.par,
                                      ISI_times_list.par,ISI_series_list.par,
                                      firing_sections_times_list.par,
                                      firing_sections_ordinates_list.par,
                                      LFP_window_times_list.par,LFP_not_differenced_filtered_absolute_series_list.par,
                                      time_sequence_Marshall_MUA.par,time_sequence_Marshall_LFP.par,
                                      num_breaks.par=10,
                                      abbreviated_time_units_string.par="",time_units_string.par="",
                                      plot_bool.par=FALSE){
  temp.num_trial_sections=length(quiescence_bounds_list.par)
  temp.quiescence_min_local_max_times_list<-list()
  temp.quiescence_min_local_max_ordinates_list<-list()
  temp.burst_min_local_max_times_list<-list()
  temp.burst_min_local_max_ordinates_list<-list()
  temp.quiescence_min_times_list<-list()
  temp.quiescence_min_ordinates_list<-list()
  temp.burst_min_times_list<-list()
  temp.burst_min_ordinates_list<-list()
  for(temp.j in 1:temp.num_trial_sections){
    temp.quiescence_bounds_j<-quiescence_bounds_list.par[[temp.j]]
    temp.burst_bounds_j<-burst_bounds_list.par[[temp.j]]
    temp.ISI_local_maxima_times_j<-ISI_times_list.par[[temp.j]]
    temp.ISI_local_maxima_ordinates_j<-ISI_series_list.par[[temp.j]]
    temp.quiescence_min_local_max_indices_j<-1:length(temp.ISI_local_maxima_ordinates_j)
      #which(temp.ISI_local_maxima_ordinates_j>=temp.quiescence_bounds_j[1] & temp.ISI_local_maxima_ordinates_j<=temp.quiescence_bounds_j[2])
    temp.burst_min_local_max_indices_j<-
      which(temp.ISI_local_maxima_ordinates_j>=temp.burst_bounds_j[1] & temp.ISI_local_maxima_ordinates_j<=temp.burst_bounds_j[2])
    if(!length(temp.quiescence_min_local_max_indices_j)){
      temp.diffs_vector<-abs(temp.ISI_local_maxima_ordinates_j-temp.quiescence_bounds_j[2])
      temp.min_diff=min(temp.diffs_vector)
      temp.optimal_diff_index=min(which(temp.diffs_vector==temp.min_diff))
      temp.quiescence_min_local_max_indices_j<-temp.optimal_diff_index
    }
    if(!length(temp.burst_min_local_max_indices_j)){
      temp.diffs_vector<-abs(temp.ISI_local_maxima_ordinates_j-temp.burst_bounds_j[1])
      temp.min_diff=min(temp.diffs_vector)
      temp.optimal_diff_index=min(which(temp.diffs_vector==temp.min_diff))
      temp.burst_min_local_max_indices_j<-temp.optimal_diff_index
    }
    temp.quiescence_min_local_max_times_j<-temp.ISI_local_maxima_times_j[temp.quiescence_min_local_max_indices_j]
    temp.quiescence_min_local_max_ordinates_j<-temp.ISI_local_maxima_ordinates_j[temp.quiescence_min_local_max_indices_j]
    temp.quiescence_min_local_max_times_list[[temp.j]]<-temp.quiescence_min_local_max_times_j
    temp.quiescence_min_local_max_ordinates_list[[temp.j]]<-temp.quiescence_min_local_max_ordinates_j
    temp.burst_min_local_max_times_j<-temp.ISI_local_maxima_times_j[temp.burst_min_local_max_indices_j]
    temp.burst_min_local_max_ordinates_j<-temp.ISI_local_maxima_ordinates_j[temp.burst_min_local_max_indices_j]
    temp.burst_min_local_max_times_list[[temp.j]]<-temp.burst_min_local_max_times_j
    temp.burst_min_local_max_ordinates_list[[temp.j]]<-temp.burst_min_local_max_ordinates_j
    #Identify the peaks where the burst and quiescent intervals are situated in global time.
    temp.firing_sections_times_j<-firing_sections_times_list.par[[temp.j]]
    temp.firing_sections_ordinates_j<-firing_sections_ordinates_list.par[[temp.j]]
    temp.size_j=length(temp.firing_sections_times_j)
    temp.quiescence_min_local_max_indices_j<-temp.quiescence_min_local_max_indices_j[temp.quiescence_min_local_max_indices_j<=temp.size_j]
    temp.quiescence_min_ordinates_j<-c()
    if(temp.size_j>1){
      temp.quiescence_min_times_j<-temp.firing_sections_times_j[temp.quiescence_min_local_max_indices_j+1]
      temp.quiescence_min_ordinates_j<-temp.firing_sections_ordinates_j[temp.quiescence_min_local_max_indices_j+1]
    } else{
      temp.quiescence_min_times_j<-temp.firing_sections_times_j[temp.quiescence_min_local_max_indices_j]
      temp.quiescence_min_ordinates_j<-temp.firing_sections_ordinates_j[temp.quiescence_min_local_max_indices_j]
    }
    temp.burst_min_local_max_indices_j<-temp.burst_min_local_max_indices_j[temp.burst_min_local_max_indices_j<=temp.size_j]
    temp.burst_min_times_j<-c()
    temp.burst_min_ordinates_j<-c()
    if(temp.size_j>1){
      temp.burst_min_times_j<-temp.firing_sections_times_j[temp.burst_min_local_max_indices_j+1]
      temp.burst_min_ordinates_j<-temp.firing_sections_ordinates_j[temp.burst_min_local_max_indices_j+1]
    } else{
      temp.burst_min_times_j<-temp.firing_sections_times_j[temp.burst_min_local_max_indices_j]
      temp.burst_min_ordinates_j<-temp.firing_sections_ordinates_j[temp.burst_min_local_max_indices_j]
    }
    temp.quiescence_min_times_list[[temp.j]]<-temp.quiescence_min_times_j
    temp.quiescence_min_ordinates_list[[temp.j]]<-temp.quiescence_min_ordinates_j
    temp.burst_min_times_list[[temp.j]]<-temp.burst_min_times_j
    temp.burst_min_ordinates_list[[temp.j]]<-temp.burst_min_ordinates_j
  }
  if(plot_bool.par==TRUE){
    multipage_plot_comparison.function(x_plotting_list.par=temp.quiescence_min_local_max_times_list,
                                       y_plotting_list.par=temp.quiescence_min_local_max_ordinates_list,
                                       x_plotting_list2.par=temp.burst_min_local_max_times_list,
                                       y_plotting_list2.par=temp.burst_min_local_max_ordinates_list,
                                       bounds_all.par=c(min(min(unlist(temp.quiescence_min_local_max_ordinates_list)),
                                                            min(unlist(temp.burst_min_local_max_ordinates_list))),
                                                        max(max(unlist(temp.quiescence_min_local_max_ordinates_list)),
                                                            max(unlist(temp.burst_min_local_max_ordinates_list)))),
                                       x_label.par=paste("Time, in ",abbreviated_time_units_string.par,
                                                         " since ",round_general.function(time_sequence_Marshall_MUA.par[1])," ",time_units_string.par,sep=""),
                                       y_label.par=paste("Inter-spike interval, in ",abbreviated_time_units_string.par,sep=""),
                                       types.par=c("h","h"),
                                       no_comparison_bool.par=TRUE,
                                       pdf_title.par="ISI_Section_Bursts_and_Quiescence_Plot.pdf")
    multipage_plot_comparison.function(x_plotting_list.par=temp.quiescence_min_times_list,
                                       y_plotting_list.par=temp.quiescence_min_ordinates_list,
                                       x_plotting_list2.par=temp.burst_min_local_max_times_list,
                                       y_plotting_list2.par=temp.burst_min_ordinates_list,
                                       bounds_all.par=c(min(min(unlist(temp.quiescence_min_ordinates_list)),
                                                            min(unlist(temp.burst_min_ordinates_list))),
                                                        max(max(unlist(temp.quiescence_min_ordinates_list)),
                                                            max(unlist(temp.burst_min_ordinates_list)))),
                                       x_label.par=paste("Time, in ",abbreviated_time_units_string.par," since ",
                                                         round_general.function(time_sequence_Marshall_MUA.par[1])," ",time_units_string.par,sep=""),
                                       y_label.par="Normalized units",
                                       types.par=c("h","h"),
                                       no_comparison_bool.par=TRUE,
                                       pdf_title.par="500Hzdifferenced_MUA_Squared_Values_Normalized_Classes_Section_Bursts_and_Quiescence_Plot.pdf")
  }
  temp.LFP_times_vector<-LFP_window_times_list.par[[2]]
  temp.LFP_series<-LFP_not_differenced_filtered_absolute_series_list.par[[2]]
  temp.all_quiescence_burst_min_times_list<-unlist(temp.quiescence_min_times_list)#c(unlist(temp.quiescence_min_times_list),unlist(temp.burst_min_times_list))
  temp.all_quiescence_burst_min_ordinates_list<-unlist(temp.quiescence_min_ordinates_list)#c(unlist(temp.quiescence_min_ordinates_list),unlist(temp.burst_min_ordinates_list))
  if(plot_bool.par==TRUE){
    plot.graph(x_list.par=list(temp.LFP_times_vector,temp.all_quiescence_burst_min_times_list),
               y_list.par=list(temp.LFP_series,temp.all_quiescence_burst_min_ordinates_list),
               x_label.par=paste("Time, in ",abbreviated_time_units_string.par," since ",
                                 round_general.function(min(time_sequence_Marshall_LFP.par[1],time_sequence_Marshall_MUA.par[1])),
                                 " ",time_units_string.par,sep=""),
               y_label.par="Normalized units",
               type.par=c("l","h"),
               col.par=c(1,2),
               pdf_title.par="LFP_Quiescent_MUA_Overlay.pdf")
  }
  temp.min_LFP=min(temp.LFP_series)
  temp.max_LFP=max(temp.LFP_series)
  temp.LFP_comparison_times_list<-list()
  temp.LFP_comparison_ordinates_list<-list()
  for(temp.j in 1:temp.num_trial_sections){
    temp.min_time_j=min(temp.quiescence_min_times_list[[temp.j]])
    temp.max_time_j=max(temp.quiescence_min_times_list[[temp.j]])
    temp.window_indices_j<-which(temp.LFP_times_vector>=temp.min_time_j & temp.LFP_times_vector<temp.max_time_j)
    if(!length(temp.window_indices_j)){
      temp.diffs<-abs(temp.LFP_times_vector-temp.max_time_j)
      temp.min_diff=min(temp.diffs)
      temp.window_indices_j=min(which(temp.diffs==temp.min_diff))
    }
    temp.LFP_comparison_times_list[[temp.j]]<-temp.LFP_times_vector[temp.window_indices_j]
    temp.LFP_comparison_ordinates_list[[temp.j]]<-temp.LFP_series[temp.window_indices_j]
  }
  temp.quiescence_all_times_list<-list()
  temp.raster_heights_list<-list()
  for(temp.j in 1:temp.num_trial_sections){
    temp.quiescence_min_times_j<-temp.quiescence_min_times_list[[temp.j]]
    temp.quiescence_all_times_list[[temp.j]]<-sort(c(temp.quiescence_min_times_j-temp.quiescence_min_ordinates_list[[temp.j]],temp.quiescence_min_times_j))
    temp.size_j=length(temp.quiescence_all_times_list[[temp.j]])
    temp.raster_heights_list[[temp.j]]<-(-0.1)*rep(temp.max_LFP,temp.size_j)
  }
  if(plot_bool.par==TRUE){
    multipage_plot_comparison.function(x_plotting_list.par=temp.quiescence_all_times_list,
                                       y_plotting_list.par=temp.raster_heights_list,
                                       x_plotting_list2.par=temp.LFP_comparison_times_list,
                                       y_plotting_list2.par=temp.LFP_comparison_ordinates_list,
                                       bounds_all.par=c(min(min(unlist(temp.LFP_comparison_ordinates_list)),
                                                            min(unlist(temp.raster_heights_list))),
                                                        max(max(unlist(temp.LFP_comparison_ordinates_list)),
                                                            max(unlist(temp.raster_heights_list)))),
                                       x_label.par=paste("Time, in ",abbreviated_time_units_string.par," since ",
                                                         round_general.function(time_sequence_Marshall_LFP.par[1]),
                                                         " ",time_units_string.par,sep=""),
                                       y_label.par="Normalized units",
                                       types.par=c("h","l"),
                                       no_comparison_bool.par=TRUE,
                                       pdf_title.par="LFP_vs_Quiescent_MUA_Section_Overlays.pdf")
  }
  temp.list<-list(out.LFP_times_vector=temp.LFP_times_vector,
                  out.LFP_series=temp.LFP_series,
                  out.all_quiescence_burst_min_times_list=temp.all_quiescence_burst_min_times_list,
                  out.all_quiescence_burst_min_ordinates_list=temp.all_quiescence_burst_min_ordinates_list,
                  #Section plots
                  out.quiescence_all_times_list=temp.quiescence_all_times_list,
                  out.raster_heights_list=temp.raster_heights_list,
                  out.LFP_comparison_times_list=temp.LFP_comparison_times_list,
                  out.LFP_comparison_ordinates_list=temp.LFP_comparison_ordinates_list)
  return(temp.list)
}





ISI_TS_partition_classification.function<-function(firing_sections_times_list.par,
                                                   time_sequence_Marshall_MUA.par,time_sequence_Marshall_LFP.par,
                                                   firing_sections_ordinates_list.par,
                                                   LFP_window_times_list.par,LFP_not_differenced_filtered_absolute_series_list.par,
                                                   num_breaks.par=10,
                                                   abbreviated_time_units_string.par="",time_units_string.par="",
                                                   plot_bool.par=TRUE){
  #For each section of the partitioned series, compute the corresponding series of ISI.
  temp.partitioned_ISI_series_object<-
    partitioned_ISI_series.function(firing_sections_times_list.par=firing_sections_times_list.par,
                                    time_sequence_Marshall_MUA.par=time_sequence_Marshall_MUA.par,
                                    time_sequence_Marshall_LFP.par=temp.time_sequence_Marshall_LFP,
                                    abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                    time_units_string.par=time_units_string.par,
                                    plot_bool.par=plot_bool.par)
  temp.ISI_local_maxima_ordinates_list<-temp.partitioned_ISI_series_object$out.ISI_local_maxima_ordinates_list
  temp.ISI_times_list<-temp.partitioned_ISI_series_object$out.ISI_times_list
  temp.ISI_series_list<-temp.partitioned_ISI_series_object$out.ISI_series_list
  #Determine the ISI bounds of the quiescent and burst firing activity
  temp.quiescence_burst_bounds_object<-
    quiescence_burst_bounds.function(ISI_local_maxima_ordinates_list.par=temp.ISI_local_maxima_ordinates_list,
                                     num_breaks.par=num_breaks.par,
                                     abbreviated_time_units_string.par=abbreviated_time_units_string.par)
  temp.quiescence_bounds_list<-temp.quiescence_burst_bounds_object$out.quiescence_bounds_list
  temp.burst_bounds_list<-temp.quiescence_burst_bounds_object$out.burst_bounds_list
  #Revert to the original time-domain space to see the results of the classification.
  temp.ISI_classification_object<-
    ISI_classification.function(quiescence_bounds_list.par=temp.quiescence_bounds_list,
                                burst_bounds_list.par=temp.burst_bounds_list,
                                ISI_times_list.par=temp.ISI_times_list,
                                ISI_series_list.par=temp.ISI_series_list,
                                firing_sections_times_list.par=firing_sections_times_list.par,
                                firing_sections_ordinates_list.par=firing_sections_ordinates_list.par,
                                LFP_window_times_list.par=LFP_window_times_list.par,
                                LFP_not_differenced_filtered_absolute_series_list.par=LFP_not_differenced_filtered_absolute_series_list.par,
                                time_sequence_Marshall_MUA.par=time_sequence_Marshall_MUA.par,
                                time_sequence_Marshall_LFP.par=time_sequence_Marshall_LFP.par,
                                num_breaks.par=num_breaks.par,
                                abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                time_units_string.par=time_units_string.par,
                                plot_bool.par=plot_bool.par)
  temp.LFP_times_vector<-temp.ISI_classification_object$out.LFP_times_vector
  temp.LFP_series<-temp.ISI_classification_object$out.LFP_series
  temp.all_quiescence_burst_min_times_vector<-temp.ISI_classification_object$out.all_quiescence_burst_min_times_list
  temp.all_quiescence_burst_min_ordinates_vector<-temp.ISI_classification_object$out.all_quiescence_burst_min_ordinates_list
  temp.list<-list(out.LFP_times_vector=temp.LFP_times_vector,
                  out.LFP_series=temp.LFP_series,
                  out.all_quiescence_burst_min_times_vector=temp.all_quiescence_burst_min_times_vector,
                  out.all_quiescence_burst_min_ordinates_vector=temp.all_quiescence_burst_min_ordinates_vector)
  return(temp.list)
}




PC_component_ISI_analysis.function<-function(filter_index.par,
                                             pc_demodulate_components_times_list.par,
                                             pc_demodulate_components_ordinates_list.par,
                                             time_sequence_Marshall_MUA.par,time_sequence_Marshall_LFP.par,
                                             LFP_window_times_list.par,LFP_not_differenced_filtered_absolute_series_list.par,
                                             num_trial_sections.par=10,num_breaks.par=10,
                                             reference_paper_identifier_strings_MUA.par="",MUA_directory_string_j.par="",
                                             measure_units_string.par="",abbreviated_time_units_string.par="",
                                             time_units_string.par="",
                                             output_bool.par=FALSE,plot_bool.par=TRUE){
  #Segment the analysis further for the two PC-components.
  temp.pc_strings<-c("High_Variance_Component","Low_Variance_Component")
  temp.pc_plotting_strings<-c("High variance","Low variance")
  temp.raster_legend_strings_vector<-rep("",2)
  temp.filter_raster_times_section_list<-list()
  temp.filter_raster_ordinates_section_list<-list()
  for(temp.pc_index in 1:2){
    if(output_bool.par==TRUE){
      cat(temp.pc_index," out of 2\n")
    }
    temp.raster_legend_strings_vector[temp.pc_index]<-
      paste(reference_paper_identifier_strings_MUA.par[filter_index.par],", ",temp.pc_plotting_strings[temp.pc_index],sep="")
    temp.directory_string_j_pc_index<-temp.pc_strings[temp.pc_index]
    dir.create(temp.directory_string_j_pc_index,showWarnings=FALSE)
    temp.MUA_directory_string_j_pc_index<-paste(MUA_directory_string_j.par,"/",temp.directory_string_j_pc_index,sep="")
    setwd(temp.MUA_directory_string_j_pc_index)
    #Partition the time series.
    temp.partitioned_series_object<-
      partitioned_series.function(plotting_x1.par=pc_demodulate_components_times_list.par[[temp.pc_index]],
                                  plotting_y1.par=pc_demodulate_components_ordinates_list.par[[temp.pc_index]],
                                  time_sequence_Marshall_MUA.par=time_sequence_Marshall_MUA.par,
                                  num_trial_sections.par=num_trial_sections.par,
                                  measure_units_string.par=measure_units_string.par,
                                  abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                  time_units_string.par=time_units_string.par,
                                  pdf_title.par="Spike_Section_Series.pdf",
                                  plot_bool.par=plot_bool.par)
    temp.firing_sections_times_list<-temp.partitioned_series_object$out.firing_sections_times_list
    temp.firing_sections_ordinates_list<-temp.partitioned_series_object$out.firing_sections_ordinates_list
    #Full ISI-classification analysis for each section of the above partitioned series.
    temp.ISI_TS_partition_classification_object<-
      ISI_TS_partition_classification.function(firing_sections_times_list.par=temp.firing_sections_times_list,
                                               time_sequence_Marshall_MUA.par=time_sequence_Marshall_MUA.par,
                                               time_sequence_Marshall_LFP.par=time_sequence_Marshall_LFP.par,
                                               firing_sections_ordinates_list.par=temp.firing_sections_ordinates_list,
                                               LFP_window_times_list.par=LFP_window_times_list.par,
                                               LFP_not_differenced_filtered_absolute_series_list.par=
                                                 LFP_not_differenced_filtered_absolute_series_list.par,
                                               num_breaks.par=num_breaks.par,
                                               abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                               time_units_string.par=time_units_string.par,
                                               plot_bool.par=plot_bool.par)
    temp.LFP_times_vector<-temp.ISI_TS_partition_classification_object$out.LFP_times_vector
    temp.LFP_series<-temp.ISI_TS_partition_classification_object$out.LFP_series
    temp.all_quiescence_burst_min_times_vector<-temp.ISI_TS_partition_classification_object$out.all_quiescence_burst_min_times_vector
    temp.all_quiescence_burst_min_ordinates_vector<-temp.ISI_TS_partition_classification_object$out.all_quiescence_burst_min_ordinates_vector
    #Update the lists in the pc-component for loop.
    temp.filter_raster_times_section_list[[temp.pc_index]]<-temp.all_quiescence_burst_min_times_vector
    temp.num_all_quiescence_min_times=length(temp.all_quiescence_burst_min_times_vector)
    temp.filter_raster_ordinates_section_list[[temp.pc_index]]<-
      rep((-1)*((filter_index.par-1)*2+temp.pc_index),temp.num_all_quiescence_min_times)
    
    setwd(MUA_directory_string_j.par)
  } #End for loop.
  temp.list<-list(out.raster_legend_strings_vector=temp.raster_legend_strings_vector,
                  out.LFP_times_vector=temp.LFP_times_vector,
                  out.LFP_series=temp.LFP_series,
                  out.filter_raster_times_section_list=temp.filter_raster_times_section_list,
                  out.filter_raster_ordinates_section_list=temp.filter_raster_ordinates_section_list)
  return(temp.list)
}






MUA_spike_identification.function<-function(window_times_diff_lists.par,
                                            normalized_squared_filtered_series_diff_lists.par,
                                            time_sequence_Marshall_MUA.par,time_sequence_Marshall_LFP.par,
                                            window_times_no_diff_lists.par,normalized_squared_filtered_series_no_diff_lists.par,
                                            diff_index.par=1,num_trial_sections.par=1,
                                            min_record_sizes_MUA.par=1,
                                            num_breaks.par=10,
                                            pc_outlier_threshold_quantile.par=5,scale.par=5,
                                            reference_paper_identifier_strings_MUA.par="",
                                            MUA_classification_directory_string.par="",
                                            abbreviated_time_units_string.par="",
                                            time_units_string.par="",measure_units_string.par="",
                                            output_bool.par=FALSE,
                                            plot_bool.par=FALSE){
  #Initialize the relevant output objects.
  temp.all_raster_legend_strings_vector<-c()
  temp.filter_raster_times_list<-list()
  temp.filter_raster_ordinates_list<-list()
  temp.num_filters=length(window_times_diff_lists.par[[diff_index.par]])-1
  for(temp.filter_index in 1:temp.num_filters){
    if(output_bool.par==TRUE){
      cat(temp.filter_index," out of 4\n")
    }
    temp.directory_string_filter_index<-paste(reference_paper_identifier_strings_MUA.par[temp.filter_index],sep="")
    dir.create(temp.directory_string_filter_index,showWarnings=FALSE)
    temp.MUA_directory_string_j<-paste(MUA_classification_directory_string.par,"/",temp.directory_string_filter_index,sep="")
    setwd(temp.MUA_directory_string_j)
    #PCA-preprocessing to identify low- and high-variance demodulate time samples.
    temp.two_class_PCA_identification_object<-
      two_class_PCA_identification.function(MUA_window_times_vector.par=window_times_diff_lists.par[[diff_index.par]][[temp.filter_index]],
                                            MUA_window_ordinates_500_vector.par=
                                              normalized_squared_filtered_series_diff_lists.par[[diff_index.par]][[temp.filter_index]],
                                            time_sequence_Marshall_MUA.par=time_sequence_Marshall_MUA.par,
                                            abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                            time_units_string.par=time_units_string.par,
                                            units_string.par=measure_units_string.par,
                                            min_record_size_MUA.par=min_record_sizes_MUA.par[1],
                                            pc_outlier_threshold_quantile.par=pc_outlier_threshold_quantile.par,
                                            scale.par=scale.par,
                                            working_directory_string.par=temp.MUA_directory_string_j,
                                            plot_bool.par=plot_bool.par)
    temp.pc_demodulate_components_times_list<-list(high_variance_times=temp.two_class_PCA_identification_object$out.plotting_x1,
                                                   low_variance_times=temp.two_class_PCA_identification_object$out.plotting_x2)
    temp.pc_demodulate_components_ordinates_list<-list(high_variance_ordinates=temp.two_class_PCA_identification_object$out.plotting_y1,
                                                       low_variance_ordinates=temp.two_class_PCA_identification_object$out.plotting_y2)
    #Identify the ISI modes for each PC-component.
    temp.PC_component_ISI_analysis_object<-
      PC_component_ISI_analysis.function(filter_index.par=temp.filter_index,
                                         pc_demodulate_components_times_list.par=temp.pc_demodulate_components_times_list,
                                         pc_demodulate_components_ordinates_list.par=temp.pc_demodulate_components_ordinates_list,
                                         time_sequence_Marshall_MUA.par=time_sequence_Marshall_MUA.par,
                                         time_sequence_Marshall_LFP.par=time_sequence_Marshall_LFP.par,
                                         LFP_window_times_list.par=window_times_no_diff_lists.par[[3]],
                                         LFP_not_differenced_filtered_absolute_series_list.par=
                                           normalized_squared_filtered_series_no_diff_lists.par[[3]],
                                         num_trial_sections.par=num_trial_sections.par,num_breaks.par=num_breaks.par,
                                         reference_paper_identifier_strings_MUA.par=reference_paper_identifier_strings_MUA.par,
                                         MUA_directory_string_j.par=temp.MUA_directory_string_j,
                                         measure_units_string.par=measure_units_string.par,
                                         abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                         time_units_string.par=time_units_string.par,
                                         output_bool.par=output_bool.par)
    temp.raster_legend_strings_vector<-temp.PC_component_ISI_analysis_object$out.raster_legend_strings_vector
    temp.LFP_times_vector<-temp.PC_component_ISI_analysis_object$out.LFP_times_vector
    temp.LFP_series<-temp.PC_component_ISI_analysis_object$out.LFP_series
    temp.filter_raster_times_section_list<-temp.PC_component_ISI_analysis_object$out.filter_raster_times_section_list
    temp.filter_raster_ordinates_section_list<-temp.PC_component_ISI_analysis_object$out.filter_raster_ordinates_section_list
    temp.all_raster_legend_strings_vector[(temp.filter_index-1)*2+1:2]<-temp.raster_legend_strings_vector
    for(temp.pc_index in 1:2){
      temp.filter_raster_times_list[[(temp.filter_index-1)*2+temp.pc_index]]<-temp.filter_raster_times_section_list[[temp.pc_index]]
      temp.filter_raster_ordinates_list[[(temp.filter_index-1)*2+temp.pc_index]]<-temp.filter_raster_ordinates_section_list[[temp.pc_index]]
    }
    setwd(MUA_classification_directory_string.par)
  }#End for loop.
  temp.list<-list(out.all_raster_legend_strings_vector=temp.all_raster_legend_strings_vector,
                  out.filter_raster_times_list=temp.filter_raster_times_list,
                  out.filter_raster_ordinates_list=temp.filter_raster_ordinates_list,
                  out.LFP_times_vector=temp.LFP_times_vector,
                  out.LFP_series=temp.LFP_series)
  return(temp.list)
}





raster_summary.function<-function(filter_raster_times_list.par,filter_raster_ordinates_list.par,
                                  action_potential_times_window.par,
                                  LFP_times_vector.par,LFP_series.par,
                                  num_test_sections.par,time_sequence.par,
                                  all_raster_legend_strings_vector.par,diff_bool_directory_string.par,
                                  first_time.par=0,
                                  abbreviated_time_units_string.par="",time_units_string.par="",
                                  measure_quantity_string.par=""){
  temp.num_list_elements=length(filter_raster_times_list.par)
  temp.num_weiss_AP_event_times=length(action_potential_times_window.par)
  temp.plotting_legend_strings_vector<-c(all_raster_legend_strings_vector.par,"Weiss AP-detection method","LFP")
  temp.x_plotting_list<-list.append(filter_raster_times_list.par,action_potential_times_window.par-time_sequence.par[1],LFP_times_vector.par)
  temp.y_plotting_list<-list.append(filter_raster_ordinates_list.par,rep((-1)*temp.num_list_elements-1,temp.num_weiss_AP_event_times),LFP_series.par)
  temp.num_augmented_list_elements=length(temp.x_plotting_list)
  temp.min_time_all_list_elements=min(unlist(temp.x_plotting_list))
  temp.max_time_all_list_elements=max(unlist(temp.x_plotting_list))
  temp.record_duration_all_list_elements=temp.max_time_all_list_elements-temp.min_time_all_list_elements
  temp.section_length=temp.record_duration_all_list_elements/num_test_sections.par
  temp.all_spike_time_lists<-list()
  temp.LFP_time_list<-list()
  temp.LFP_ordinate_list<-list()
  for(temp.j in 1:num_test_sections.par){
    temp.bounds_j<-temp.min_time_all_list_elements+(temp.j-1)*temp.section_length+c(0,temp.section_length)
    temp.min_j=temp.bounds_j[1]
    temp.max_j=temp.bounds_j[2]
    temp.LFP_vector_j<-
      temp.y_plotting_list[[temp.num_augmented_list_elements]][temp.x_plotting_list[[temp.num_augmented_list_elements]]>=temp.min_j &
                                                                 temp.x_plotting_list[[temp.num_augmented_list_elements]]<temp.max_j]
    temp.min_ordinate_LFP_j=min(temp.LFP_vector_j)
    temp.max_ordinate_LFP_j=max(temp.LFP_vector_j)
    temp.ordinate_range_j=temp.max_ordinate_LFP_j-temp.min_ordinate_LFP_j
    temp.x_plotting_list_j<-list()
    temp.y_plotting_list_j<-list()
    for(temp.k in 1:temp.num_augmented_list_elements){
      temp.x_vector_k<-temp.x_plotting_list[[temp.k]]
      temp.y_vector_k<-temp.y_plotting_list[[temp.k]]
      temp.x_plotting_list_j[[temp.k]]<-temp.x_vector_k[temp.x_vector_k>=temp.min_j & temp.x_vector_k<temp.max_j]
      temp.y_plotting_list_j[[temp.k]]<-temp.y_vector_k[temp.x_vector_k>=temp.min_j & temp.x_vector_k<temp.max_j]
      if(temp.k<temp.num_augmented_list_elements){
        temp.y_plotting_list_j[[temp.k]]<-temp.y_plotting_list_j[[temp.k]]*temp.ordinate_range_j/(temp.num_augmented_list_elements-1)
      }
    }
    temp.all_spike_time_lists[[temp.j]]<-temp.x_plotting_list_j[1:(temp.num_augmented_list_elements-1)]
    temp.LFP_time_list[[temp.j]]<-temp.x_plotting_list_j[[temp.num_augmented_list_elements]]
    temp.LFP_ordinate_list[[temp.j]]<-temp.y_plotting_list_j[[temp.num_augmented_list_elements]]
    plot.graph(x_list.par=temp.x_plotting_list_j,y_list.par=temp.y_plotting_list_j,
               plotting_UB_x.par=temp.min_j+2*temp.section_length,
               x_label.par=paste("Time, in ",abbreviated_time_units_string.par," since ",first_time.par," ",time_units_string.par,sep=""),
               y_label.par=paste("Squared ",measure_quantity_string.par,", normalized to [0,1]",sep=""),
               type.par=c(rep("p",temp.num_list_elements+1),"l"),
               pch.par=c(rep(3,temp.num_list_elements+1),NA),
               cex.par=c(rep(1,temp.num_list_elements+1),NA),
               col.par=c(1:(temp.num_list_elements+1),1),
               legend_labels.par=temp.plotting_legend_strings_vector,
               pdf_title.par=paste("Raster_Comparison_Section_",temp.j,".pdf",sep=""))
  } #End for loop.
  setwd(diff_bool_directory_string.par)
  temp.list<-list(out.all_spike_time_lists=temp.all_spike_time_lists,
                  out.LFP_time_list=temp.LFP_time_list,
                  out.LFP_ordinate_list=temp.LFP_ordinate_list,
                  out.plotting_legend_strings_vector=temp.plotting_legend_strings_vector,
                  out.num_augmented_list_elements=temp.num_augmented_list_elements)
  return(temp.list)
}




MUA_spike_identification_and_results.function<-function(window_times_diff_lists.par,
                                                        normalized_squared_filtered_series_diff_lists.par,
                                                        time_sequence_Marshall_MUA.par,
                                                        time_sequence_Marshall_LFP.par,
                                                        window_times_no_diff_lists.par,
                                                        normalized_squared_filtered_series_no_diff_lists.par,
                                                        action_potential_times_window.par,
                                                        diff_index.par,num_trial_sections.par,
                                                        min_record_sizes_MUA.par,
                                                        time_sequence.par,
                                                        num_breaks.par=10,num_test_sections.par,
                                                        pc_outlier_threshold_quantile.par=5,scale.par=5,
                                                        reference_paper_identifier_strings_MUA.par="",
                                                        MUA_classification_directory_string.par="",
                                                        first_time.par=0,
                                                        abbreviated_time_units_string.par="",
                                                        time_units_string.par="",measure_units_string.par="",
                                                        measure_quantity_string.par="",
                                                        diff_bool_directory_string.par="",
                                                        display_raster_results_bool.par=FALSE,
                                                        output_bool.par=FALSE,
                                                        plot_bool.par=FALSE){
  #Identify the MUA spikes.
  temp.MUA_spike_identification_object<-
    MUA_spike_identification.function(window_times_diff_lists.par=window_times_diff_lists.par,
                                      normalized_squared_filtered_series_diff_lists.par=normalized_squared_filtered_series_diff_lists.par,
                                      time_sequence_Marshall_MUA.par=time_sequence_Marshall_MUA.par,
                                      time_sequence_Marshall_LFP.par=time_sequence_Marshall_LFP.par,
                                      window_times_no_diff_lists.par=window_times_no_diff_lists.par,
                                      normalized_squared_filtered_series_no_diff_lists.par=normalized_squared_filtered_series_no_diff_lists.par,
                                      diff_index.par=diff_index.par,num_trial_sections.par=num_trial_sections.par,
                                      min_record_sizes_MUA.par=min_record_sizes_MUA.par,
                                      num_breaks.par=num_breaks.par,
                                      pc_outlier_threshold_quantile.par=pc_outlier_threshold_quantile.par,scale.par=scale.par,
                                      reference_paper_identifier_strings_MUA.par=reference_paper_identifier_strings_MUA.par,
                                      MUA_classification_directory_string.par=MUA_classification_directory_string.par,
                                      abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                      time_units_string.par=time_units_string.par,measure_units_string.par=measure_units_string.par,
                                      output_bool.par=output_bool.par,
                                      plot_bool.par=plot_bool.par)
  temp.all_raster_legend_strings_vector<-temp.MUA_spike_identification_object$out.all_raster_legend_strings_vector
  temp.filter_raster_times_list<-temp.MUA_spike_identification_object$out.filter_raster_times_list
  temp.filter_raster_ordinates_list<-temp.MUA_spike_identification_object$out.filter_raster_ordinates_list
  temp.LFP_times_vector<-temp.MUA_spike_identification_object$out.LFP_times_vector
  temp.LFP_series<-temp.MUA_spike_identification_object$out.LFP_series
  #Return to the original working directory before starting the next iteration.
  setwd(diff_bool_directory_string.par)
  temp.plotting_legend_strings_vector<-""
  if(display_raster_results_bool.par==TRUE){
    #Raster summary results.
    dir.create(temp.raster_summary_directory_string,showWarnings=FALSE)
    temp.MUA_raster_summary_directory_string<-paste(diff_bool_directory_string.par,"/",temp.raster_summary_directory_string,sep="")
    setwd(temp.MUA_raster_summary_directory_string)
    temp.raster_summary_object<-raster_summary.function(filter_raster_times_list.par=temp.filter_raster_times_list,
                                                        filter_raster_ordinates_list.par=temp.filter_raster_ordinates_list,
                                                        action_potential_times_window.par=action_potential_times_window.par,
                                                        LFP_times_vector.par=temp.LFP_times_vector,
                                                        LFP_series.par=temp.LFP_series,
                                                        num_test_sections.par=num_test_sections.par,
                                                        time_sequence.par=time_sequence.par,
                                                        all_raster_legend_strings_vector.par=temp.all_raster_legend_strings_vector,
                                                        diff_bool_directory_string.par=diff_bool_directory_string.par,
                                                        first_time.par=first_time.par,
                                                        abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                                        time_units_string.par=time_units_string.par,
                                                        measure_quantity_string.par=measure_quantity_string.par)
    temp.all_spike_time_lists<-temp.raster_summary_object$out.all_spike_time_lists
    temp.LFP_time_list<-temp.raster_summary_object$out.LFP_time_list
    temp.LFP_ordinate_list<-temp.raster_summary_object$out.LFP_ordinate_list
    temp.plotting_legend_strings_vector<-temp.raster_summary_object$out.plotting_legend_strings_vector
    temp.num_augmented_list_elements=temp.raster_summary_object$out.num_augmented_list_elements
  }
  temp.list<-list(out.LFP_times_vector=temp.LFP_times_vector,
                  out.LFP_series=temp.LFP_series,
                  out.all_spike_time_lists=temp.all_spike_time_lists,
                  out.LFP_time_list=temp.LFP_time_list,
                  out.LFP_ordinate_list=temp.LFP_ordinate_list,
                  out.plotting_legend_strings_vector=temp.plotting_legend_strings_vector,
                  out.num_augmented_list_elements=temp.num_augmented_list_elements)
  return(temp.list)
}





occupancy_normalized_peak_analysis.function<-function(all_spike_time_lists.par,
                                                      LFP_time_list.par,LFP_ordinate_list.par,
                                                      num_test_sections.par,
                                                      num_LFP_ordinate_breaks.par,
                                                      num_augmented_list_elements.par,
                                                      plotting_legend_strings_vector.par="",
                                                      point_process_glm_directory_string.par="",
                                                      abbreviated_time_units_string.par=""){
  temp.MUA_rate_vs_LFP_ordinate_directory_string<-"MUA_Peak_Rate_vs_LFP_Ordinate"
  dir.create(temp.MUA_rate_vs_LFP_ordinate_directory_string,showWarnings=FALSE)
  temp.glm_MUA_rate_vs_LFP_ordinate_directory_string<-paste(point_process_glm_directory_string.par,"/",temp.MUA_rate_vs_LFP_ordinate_directory_string,sep="")
  setwd(temp.glm_MUA_rate_vs_LFP_ordinate_directory_string)
  temp.all_peak_histogram_abscissa_lists<-list()
  temp.all_peak_histogram_ordinates_lists<-list()
  temp.all_LFP_spike_times_lists<-list()
  temp.all_spike_LFP_ordinates_lists<-list()
  for(temp.j in 1:temp.num_test_sections){
    temp.spike_time_list_j<-all_spike_time_lists.par[[temp.j]]
    temp.LFP_time_vector_j<-LFP_time_list.par[[temp.j]]
    temp.LFP_ordinate_vector_j<-LFP_ordinate_list.par[[temp.j]]
    temp.min_LFP_ordinate_j=min(temp.LFP_ordinate_vector_j)
    temp.max_LFP_ordinate_j=max(temp.LFP_ordinate_vector_j)
    temp.range_LFP_ordinate_j=temp.max_LFP_ordinate_j-temp.min_LFP_ordinate_j
    temp.bin_size_LFP_ordinate_j=temp.range_LFP_ordinate_j/num_LFP_ordinate_breaks.par
    temp.peak_histogram_abscissa_list<-list()
    temp.peak_histogram_ordinates_list<-list()
    temp.spike_LFP_ordinates_list_j<-list()
    temp.LFP_spike_times_list_j<-list()
    pdf(paste("LFP_Ordinate_Histograms_Section_",temp.j,".pdf",sep=""),width=8,height=6)
    par(mgp=c(2,0.5,0))
    for(temp.k in 1:(num_augmented_list_elements.par-1)){
      temp.spike_time_vector_jk<-temp.spike_time_list_j[[temp.k]]
      temp.num_spike_times_jk=length(temp.spike_time_vector_jk)
      temp.rates_vector_jk<-rep(0,num_LFP_ordinate_breaks.par)
      temp.LFP_ordinate_bin_edge_values_jk<-temp.rates_vector_jk
      temp.LFP_spike_times_jk_list<-list()
      temp.spike_LFP_ordinates_jk_list<-list()
      if(!temp.num_spike_times_jk){
        temp.LFP_ordinate_bin_edge_values_jk[[1]]<-0
        temp.spike_LFP_ordinates_jk_list[[1]]<-0
      } else{
        temp.counter=1
        for(temp.l in 1:num_LFP_ordinate_breaks.par){
          temp.min_ordinate_jl=temp.min_LFP_ordinate_j+(temp.l-1)*temp.bin_size_LFP_ordinate_j
          temp.max_ordinate_jl=temp.min_ordinate_jl+temp.bin_size_LFP_ordinate_j
          temp.LFP_ordinate_bin_edge_values_jk[temp.l]=temp.max_ordinate_jl
          temp.indices_jkl<-which(temp.LFP_ordinate_vector_j>=temp.min_ordinate_jl & temp.LFP_ordinate_vector_j<temp.max_ordinate_jl)
          temp.times_jkl<-temp.LFP_time_vector_j[temp.indices_jkl]
          temp.interspike_duration_jkl=max(temp.times_jkl)-min(temp.times_jkl)
          temp.num_times_jkl=length(temp.times_jkl)
          if(temp.num_times_jkl>1){
            for(temp.u in 1:(temp.num_times_jkl-1)){
              if(temp.u%%2!=0){
                temp.min_time_jkl=temp.times_jkl[temp.u]
                temp.max_time_jkl=temp.times_jkl[temp.u+1]
                temp.bin_indices_jklu<-which(temp.spike_time_vector_jk>=temp.min_time_jkl & temp.spike_time_vector_jk<temp.max_time_jkl)
                if(length(temp.bin_indices_jklu)>0){
                  temp.spike_times_jklu=temp.spike_time_vector_jk[temp.bin_indices_jklu]
                  temp.interspike_duration_jklu=max(temp.spike_times_jklu)-min(temp.spike_times_jklu)
                  if(temp.interspike_duration_jklu>0){
                    temp.rates_vector_jk[temp.l]=
                      temp.rates_vector_jk[temp.l]+length(temp.bin_indices_jklu)/temp.interspike_duration_jklu
                  }
                  temp.LFP_spike_times_jk_list[[temp.counter]]<-temp.spike_times_jklu
                  temp.num_spike_times_jklu=length(temp.spike_times_jklu)
                  temp.spike_LFP_ordinates_vector_jklu<-rep(temp.rates_vector_jk[temp.l],temp.num_spike_times_jklu)
                  temp.spike_LFP_ordinates_jk_list[[temp.counter]]<-temp.spike_LFP_ordinates_vector_jklu
                  temp.counter=temp.counter+1
                } else{
                  temp.LFP_spike_times_jk_list[[temp.counter]]<-0
                  temp.spike_LFP_ordinates_jk_list[[temp.counter]]<-0
                  temp.counter=temp.counter+1
                }
              }
            }
          } else{
            temp.LFP_spike_times_jk_list[[temp.counter]]<-0
            temp.spike_LFP_ordinates_jk_list[[temp.counter]]<-0
            temp.counter=temp.counter+1
          }
        }
        temp.LFP_spike_times_vector_jk<-unlist(temp.LFP_spike_times_jk_list)
        temp.spike_LFP_ordinates_vector_jk<-unlist(temp.spike_LFP_ordinates_jk_list)
        if(is.null(temp.LFP_spike_times_vector_jk)==TRUE || is.null(temp.spike_LFP_ordinates_vector_jk)==TRUE){
          temp.LFP_spike_times_vector_jk<-0
          temp.spike_LFP_ordinates_vector_jk<-0
        }
        temp.spike_LFP_ordinates_list_j[[temp.k]]<-temp.spike_LFP_ordinates_vector_jk[order(temp.LFP_spike_times_vector_jk)]
        temp.LFP_spike_times_list_j[[temp.k]]<-sort(temp.LFP_spike_times_vector_jk)
        temp.num_bin_edges=length(temp.rates_vector_jk)
        temp.num_zeros=length(which(temp.rates_vector_jk==0))
        temp.plotting_x_vector0<-temp.LFP_ordinate_bin_edge_values_jk
        temp.plotting_y_vector0<-temp.rates_vector_jk
        temp.plotting_x_vector<-temp.plotting_x_vector0
        temp.plotting_y_vector<-temp.plotting_y_vector0
        temp.nonzero_y_indices=length(which(temp.plotting_y_vector0!=0))
        if(length(temp.nonzero_y_indices)>1){
          temp.kernel_object<-
            ksmooth(temp.plotting_x_vector0,temp.plotting_y_vector0,"normal",bandwidth=4*(temp.plotting_x_vector0[2]-temp.plotting_x_vector0[1]))
          temp.plotting_x_vector<-temp.kernel_object$x
          temp.plotting_y_vector<-temp.kernel_object$y
        }
        temp.peak_histogram_abscissa_list[[temp.k]]<-temp.plotting_x_vector
        temp.peak_histogram_ordinates_list[[temp.k]]<-temp.plotting_y_vector
        temp.lower_LFP_ordinate_bin_value=0
        temp.upper_LFP_ordinate_bin_value=max(temp.plotting_x_vector)
        temp.lower_height=min(min(temp.plotting_y_vector0),min(temp.plotting_y_vector))
        temp.upper_height=max(max(temp.plotting_y_vector0),max(temp.plotting_y_vector))
        plot(0,0,xlab=paste("LFP squared-peak ",measure_quantity_string.lower_case,", normalized to [0,1]",sep=""),
             ylab=paste("Occupancy-normalized MUA squared-peak count\ncounts per ",abbreviated_time_units_string.par,sep=""),
             main=plotting_legend_strings_vector.par[temp.k],
             xlim=c(temp.lower_LFP_ordinate_bin_value,temp.upper_LFP_ordinate_bin_value),ylim=c(temp.lower_height,temp.upper_height),
             pch=".",lab=c(10,10,7))
        grid()
        minor.tick(10,10)
        lines(temp.plotting_x_vector0,temp.plotting_y_vector0,type="s",lwd=2)
        lines(temp.plotting_x_vector,temp.plotting_y_vector,col=2)
      }
    }
    dev.off()
    temp.all_peak_histogram_abscissa_lists[[temp.j]]<-temp.peak_histogram_abscissa_list
    temp.all_peak_histogram_ordinates_lists[[temp.j]]<-temp.peak_histogram_ordinates_list
    temp.all_LFP_spike_times_lists[[temp.j]]<-temp.LFP_spike_times_list_j
    temp.all_spike_LFP_ordinates_lists[[temp.j]]<-temp.spike_LFP_ordinates_list_j
  }
  setwd(point_process_glm_directory_string.par)
  temp.list<-list(out.all_peak_histogram_abscissa_lists=temp.all_peak_histogram_abscissa_lists,
                  out.all_peak_histogram_ordinates_lists=temp.all_peak_histogram_ordinates_lists,
                  out.all_LFP_spike_times_lists=temp.all_LFP_spike_times_lists,
                  out.all_spike_LFP_ordinates_lists=temp.all_spike_LFP_ordinates_lists)
  return(temp.list)
}






cumulative_residual_analysis_single_stratum.function<-function(LFP_time_list.par,LFP_ordinate_list.par,
                                                               all_peak_histogram_abscissa_lists.par,all_peak_histogram_ordinates_lists.par,
                                                               all_LFP_spike_times_lists.par,all_spike_LFP_ordinates_lists.par,
                                                               all_spike_time_lists.par,
                                                               num_augmented_list_elements.par,
                                                               plotting_legend_strings_vector.par="",
                                                               point_process_glm_directory_string.par="",
                                                               first_time.par=0,
                                                               abbreviated_time_units_string.par="",
                                                               time_units_string.par="",
                                                               output_bool.par=FALSE,
                                                               plot_bool.par=FALSE){
  temp.cumulative_residual_histogram_diagnostics_directory_string<-"Cumulative_Residual_Histogram_Diagnostics"
  dir.create(temp.cumulative_residual_histogram_diagnostics_directory_string,showWarnings=FALSE)
  temp.glm_cumulative_residual_histogram_diagnostics_directory_string<-
    paste(point_process_glm_directory_string.par,"/",temp.cumulative_residual_histogram_diagnostics_directory_string,sep="")
  setwd(temp.glm_cumulative_residual_histogram_diagnostics_directory_string)
  temp.all_spike_density_ordinates_lists<-list()
  temp.all_spike_density_abscissa_lists<-list()
  temp.boxplot_lists<-list()
  temp.boxplot_extrema_lists<-list()
  temp.boxplot_firing_rate_lists<-list()
  temp.boxplot_firing_rate_extrema_lists<-list()
  for(temp.j in 1:temp.num_test_sections){
    temp.LFP_time_vector_j<-LFP_time_list.par[[temp.j]]
    temp.LFP_ordinate_vector_j<-LFP_ordinate_list.par[[temp.j]]
    temp.peak_histogram_abscissa_list_j<-all_peak_histogram_abscissa_lists.par[[temp.j]]
    temp.peak_histogram_ordinates_list_j<-all_peak_histogram_ordinates_lists.par[[temp.j]]
    temp.LFP_spike_times_list_j<-all_LFP_spike_times_lists.par[[temp.j]]
    temp.spike_LFP_ordinates_list_j<-all_spike_LFP_ordinates_lists.par[[temp.j]]
    temp.spike_time_list_j<-all_spike_time_lists.par[[temp.j]]
    temp.cumulative_MUA_event_counts_list_j<-list()
    temp.spike_density_indices_list_j<-list()
    temp.spike_density_ordinates_list_j<-list()
    temp.spike_density_abscissa_list_j<-list()
    temp.boxplot_list_j<-list()
    temp.boxplot_extrema_matrix_j<-matrix(0,nrow=num_augmented_list_elements.par-1,ncol=2)
    temp.boxplot_firing_rate_list_j<-list()
    temp.boxplot_firing_rate_extrema_matrix_j<-matrix(0,nrow=num_augmented_list_elements.par-1,ncol=2)
    if(plot_bool.par==TRUE){
      pdf(paste("Cumulative_Residual_Histogram_Diagnostics_Section_",temp.j,".pdf",sep=""),width=8,height=6)
      par(mgp=c(2,0.5,0))
    }
    for(temp.k in 1:(num_augmented_list_elements.par-1)){
      if(output_bool.par==TRUE){
        cat(temp.k," out of ",(num_augmented_list_elements.par-1),"\n")
      }
      temp.peak_histogram_abscissa_vector_jk<-temp.peak_histogram_abscissa_list_j[[temp.k]]
      temp.peak_histogram_ordinates_vector_jk<-temp.peak_histogram_ordinates_list_j[[temp.k]]
      temp.spike_LFP_ordinates_vector_jk<-temp.spike_LFP_ordinates_list_j[[temp.k]]
      temp.LFP_spike_times_vector_jk<-temp.LFP_spike_times_list_j[[temp.k]]
      temp.spike_time_vector_jk<-temp.spike_time_list_j[[temp.k]]
      if(is.null(temp.spike_LFP_ordinates_vector_jk)==TRUE || is.null(temp.LFP_spike_times_vector_jk)){
        temp.spike_LFP_ordinates_vector_jk=as.vector(0)
        temp.LFP_spike_times_vector_jk=as.vector(0)
      }
      if(length(unique(temp.spike_LFP_ordinates_vector_jk))>1 || length(unique(temp.LFP_spike_times_vector_jk))>1){
        temp.spike_LFP_ordinates_buffer_list_jk<-list()
        temp.LFP_spike_times_buffer_list_jk<-list()
        temp.counter=1
        for(temp.l in 1:length(temp.LFP_spike_times_vector_jk)){
          if(!(!temp.spike_LFP_ordinates_vector_jk[temp.l] & !temp.LFP_spike_times_vector_jk[temp.l])){
            temp.spike_LFP_ordinates_buffer_list_jk[[temp.counter]]=temp.spike_LFP_ordinates_vector_jk[temp.l]
            temp.LFP_spike_times_buffer_list_jk[[temp.counter]]<-temp.LFP_spike_times_vector_jk[temp.l]
            temp.counter=temp.counter+1
          }
        }
        temp.spike_LFP_ordinates_vector_jk<-unlist(temp.spike_LFP_ordinates_buffer_list_jk)
        temp.LFP_spike_times_vector_jk<-unlist(temp.LFP_spike_times_buffer_list_jk)
      }
      temp.empirical_percentiles<-plotting.sampled_vector(temp.spike_LFP_ordinates_vector_jk)
      temp.nominal_percentiles<-plotting.sampled_vector(temp.LFP_spike_times_vector_jk)
      temp.LFP_time_vector_jk<-as.vector(0)
      temp.lambda_vector_jk=as.vector(0)
      temp.spike_density_ordinates<-rep(0,length(temp.LFP_time_vector_jk))
      temp.spike_density_abscissa<-temp.LFP_time_vector_jk
      temp.model_residual_counts<-c(0)
      temp.model_residual_times<-temp.spike_time_vector_jk[1]
      temp.model_rescaled_times<-c(0)
      if(length(unique(temp.empirical_percentiles))>1 || length(unique(temp.nominal_percentiles))>1){
        temp.min_time_jk=min(temp.nominal_percentiles)
        temp.max_time_jk=max(temp.nominal_percentiles)
        temp.section_k_indices<-which(temp.LFP_time_vector_j>=temp.min_time_jk & temp.LFP_time_vector_j<temp.max_time_jk)
        if(length(temp.section_k_indices)>0){
          temp.LFP_time_vector_jk<-temp.LFP_time_vector_j[temp.section_k_indices]
          temp.LFP_ordinate_vector_jk<-temp.LFP_ordinate_vector_j[temp.section_k_indices]
          temp.LFP_time_vector_jk<-plotting.sampled_vector(temp.LFP_time_vector_jk)
          temp.LFP_ordinate_vector_jk<-plotting.sampled_vector(temp.LFP_ordinate_vector_jk)
          temp.num_LFP_ordinates_jk=length(temp.LFP_ordinate_vector_jk)
          temp.lambda_vector_jk<-rep(0,temp.num_LFP_ordinates_jk)
          for(temp.l in 1:temp.num_LFP_ordinates_jk){
            temp.diffs<-abs(temp.peak_histogram_abscissa_vector_jk-temp.LFP_ordinate_vector_jk[temp.l])
            temp.min_diff=min(temp.diffs)
            temp.optimal_index=min(which(temp.diffs==temp.min_diff))
            temp.lambda_vector_jk[temp.l]=temp.peak_histogram_ordinates_vector_jk[temp.optimal_index]
          }
        }
      }
      if(length(unique(temp.empirical_percentiles))>1 || length(unique(temp.nominal_percentiles))>1){
        temp.h_jk<-hist(temp.spike_time_vector_jk,breaks=50,probability=TRUE,plot=FALSE)
        temp.bin_edge_values<-temp.h_jk$breaks
        temp.bin_width=temp.bin_edge_values[2]-temp.bin_edge_values[1]
        temp.num_bin_edges=length(temp.bin_edge_values)
        temp.counts_vector_jk<-temp.h_jk$counts
        temp.num_LFP_vector<-c()
        temp.plotting_times_list<-list()
        temp.plotting_ordinates_list<-list()
        temp.plotting_indices_list<-list()
        temp.plotting_fit_times_list<-list()
        temp.plotting_fit_ordinates_list<-list()
        temp.counter=1
        for(temp.u in 1:(temp.num_bin_edges-1)){
          #if(temp.counts_vector_jk[temp.u]>0){
            temp.indices_jku<-which(temp.LFP_time_vector_jk>=temp.bin_edge_values[temp.u] & temp.LFP_time_vector_jk<temp.bin_edge_values[temp.u+1])
            if(length(temp.indices_jku)>0){
              temp.section_times_jku<-temp.LFP_time_vector_jk[temp.indices_jku]
              temp.section_lambdas_jku<-temp.lambda_vector_jk[temp.indices_jku]
              #temp.kernel_object<-
              #  ksmooth(temp.section_times_jku,temp.section_lambdas_jku,"normal",bandwidth=2*(temp.section_times_jku[2]-temp.section_times_jku[1]),
              #          n.points=length(temp.indices_jku))
              #temp.section_fit_times_jku<-temp.kernel_object$x
              #temp.section_fit_lambdas_jku<-temp.kernel_object$y
              #temp.section_fit_lambdas_jku[is.na(temp.section_fit_lambdas_jku)==TRUE]<-0
              temp.section_fit_times_jku<-temp.LFP_time_vector_jk[temp.indices_jku]
              temp.section_fit_lambdas_jku<-temp.section_lambdas_jku
              temp.plotting_times_list[[temp.counter]]<-temp.LFP_time_vector_jk[temp.indices_jku]
              temp.plotting_ordinates_list[[temp.counter]]<-temp.section_lambdas_jku
              temp.plotting_fit_times_list[[temp.counter]]<-temp.section_fit_times_jku
              temp.plotting_fit_ordinates_list[[temp.counter]]<-temp.section_fit_lambdas_jku
              temp.plotting_indices_list[[temp.counter]]<-temp.indices_jku
              temp.counter=temp.counter+1
              temp.num_residual_counts=length(temp.model_residual_counts)
              temp.model_residual_times<-c(temp.model_residual_times,temp.bin_edge_values[temp.u])
              #if(temp.counts_vector_jk[temp.u]>0){
                temp.model_residual_counts<-c(temp.model_residual_counts,
                                              temp.counts_vector_jk[temp.u]-
                                                sum(temp.section_fit_lambdas_jku)*temp.sampling_period_Marshall_LFP)
              #} else{
              #  temp.model_residual_counts<-c(temp.model_residual_counts,0)
              #}
              #temp.positive_model_residual_counts<-temp.model_residual_counts[temp.model_residual_counts>0]
              #if(length(temp.positive_model_residual_counts)>0){
              #  temp.model_residual_counts[temp.model_residual_counts>0]<-10*log10(temp.positive_model_residual_counts)
              #}
            }
          #}
        }
        temp.all_plotting_indices_vector<-unlist(temp.plotting_indices_list)
        temp.all_plotting_times_vector<-unlist(temp.plotting_times_list)
        if(!is.null(temp.all_plotting_times_vector)){
          temp.all_plotting_ordinates_vector<-unlist(temp.plotting_ordinates_list)
          temp.lambda_vector_jk<-temp.all_plotting_ordinates_vector[order(temp.all_plotting_times_vector)]
          temp.LFP_time_vector_jk<-sort(temp.all_plotting_times_vector)
        }
        temp.all_plotting_times_vector<-unlist(temp.plotting_fit_times_list)
        if(!is.null(temp.all_plotting_times_vector)){
          temp.all_plotting_ordinates_vector<-unlist(temp.plotting_fit_ordinates_list)
          temp.spike_density_ordinates[temp.all_plotting_indices_vector]<-temp.all_plotting_ordinates_vector#[order(temp.all_plotting_times_vector)]
          temp.spike_density_abscissa[temp.all_plotting_indices_vector]<-temp.all_plotting_times_vector#<-sort(temp.all_plotting_times_vector)
        }
        temp.spike_density_ordinates[is.na(temp.spike_density_ordinates)==TRUE]<-0
      }
      #Store the spike-density information.
      temp.spike_density_ordinates_list_j[[temp.k]]<-temp.spike_density_ordinates
      temp.spike_density_abscissa_list_j[[temp.k]]<-temp.spike_density_abscissa
      #Boxplots.
      #Cumulative residuals.
      #temp.boxplot_object<-c()
      #if(length(temp.model_residual_counts[temp.model_residual_counts>0])>0){
      #  temp.boxplot_object<-boxplot(temp.model_residual_counts[temp.model_residual_counts>0],plot=FALSE)
      #} else{
        temp.boxplot_object<-boxplot(temp.model_residual_counts,plot=FALSE)
      #}
      #extreme of the lower whisker, the lower hinge, the median, the upper hinge and the extreme of the upper whisker
      temp.boxplot_stats<-temp.boxplot_object$stats
      temp.boxplot_list_j[[temp.k]]<-temp.boxplot_stats
      temp.boxplot_extrema_matrix_j[temp.k,1]=temp.boxplot_stats[1]
      temp.boxplot_extrema_matrix_j[temp.k,2]=temp.boxplot_stats[5]
      #Firing rate.
      temp.boxplot_object<-boxplot(temp.lambda_vector_jk,plot=FALSE)
      #extreme of the lower whisker, the lower hinge, the median, the upper hinge and the extreme of the upper whisker
      temp.boxplot_stats<-temp.boxplot_object$stats
      temp.boxplot_firing_rate_list_j[[temp.k]]<-temp.boxplot_stats
      temp.boxplot_firing_rate_extrema_matrix_j[temp.k,1]=temp.boxplot_stats[1]
      temp.boxplot_firing_rate_extrema_matrix_j[temp.k,2]=temp.boxplot_stats[5]
      if(plot_bool.par==TRUE){
        temp.min_x=0
        temp.max_x=0
        temp.min_y=0
        temp.max_y=0
        if(length(unique(temp.model_residual_times))>1 || length(unique(temp.model_residual_counts))>1){
          temp.min_x=min(temp.model_residual_times)
          temp.max_x=max(temp.model_residual_times)
          temp.min_y=min(temp.model_residual_counts)
          temp.max_y=max(temp.model_residual_counts)
        }
        plot(0,0,xlab=paste("Time, in ",abbreviated_time_units_string.par," since ",first_time.par," ",time_units_string.par,sep=""),
             ylab="Residual count",
             main=plotting_legend_strings_vector.par[temp.k],
             xlim=c(temp.min_x,temp.max_x),ylim=c(temp.min_y,temp.max_y),
             pch=".",lab=c(10,10,7))
        grid()
        minor.tick(10,10)
        lines(temp.model_residual_times,temp.model_residual_counts,type="s")
      }
    }
    if(plot_bool.par==TRUE){
      dev.off()
    }
    temp.all_spike_density_ordinates_lists[[temp.j]]<-temp.spike_density_ordinates_list_j
    temp.all_spike_density_abscissa_lists[[temp.j]]<-temp.spike_density_abscissa_list_j
    temp.boxplot_lists[[temp.j]]<-temp.boxplot_list_j
    temp.boxplot_extrema_lists[[temp.j]]<-temp.boxplot_extrema_matrix_j
    temp.boxplot_firing_rate_lists[[temp.j]]<-temp.boxplot_firing_rate_list_j
    temp.boxplot_firing_rate_extrema_lists[[temp.j]]<-temp.boxplot_firing_rate_extrema_matrix_j
  }#end loop
  temp.num_rows=1
  for(temp.j in 1:temp.num_test_sections){
    temp.spike_density_ordinates_list_j<-temp.all_spike_density_ordinates_lists[[temp.j]]
    if(temp.j==1){
      temp.num_rows=length(temp.spike_density_abscissa_list_j)
    }
    for(temp.k in 1:temp.num_rows){
      temp.ordinates_jk<-temp.spike_density_ordinates_list_j[[temp.k]]
      temp.unique_ordinates_j<-unique(temp.ordinates_jk)
      for(temp.u in 1:length(temp.unique_ordinates_j)){
        temp.indices_u<-which(temp.ordinates_jk==temp.unique_ordinates_j[temp.u])
        if(length(temp.indices_u)>(0.1*length(temp.ordinates_jk))){
          temp.ordinates_jk[temp.indices_u]<-0
        }
      }
      temp.spike_density_ordinates_list_j[[temp.k]]<-temp.ordinates_jk
    }
    temp.all_spike_density_ordinates_lists[[temp.j]]<-temp.spike_density_ordinates_list_j
  }
  setwd(point_process_glm_directory_string.par)
  temp.list<-list(out.all_spike_density_ordinates_lists=temp.all_spike_density_ordinates_lists,
                  out.all_spike_density_abscissa_lists=temp.all_spike_density_abscissa_lists,
                  out.boxplot_lists=temp.boxplot_lists,
                  out.boxplot_extrema_lists=temp.boxplot_extrema_lists,
                  out.boxplot_firing_rate_lists=temp.boxplot_firing_rate_lists,
                  out.boxplot_firing_rate_extrema_lists=temp.boxplot_firing_rate_extrema_lists,
                  out.model_residual_times=temp.model_residual_times,
                  out.model_residual_counts=temp.model_residual_counts)
  return(temp.list)
}





cumulative_residuals_boxplots.function<-function(boxplot_extrema_lists.par,boxplot_firing_rate_lists.par,
                                                 LFP_time_list.par,LFP_ordinate_list.par,
                                                 model_residual_times.par,model_residual_counts.par,
                                                 num_test_sections.par,num_augmented_list_elements.par,
                                                 abbreviated_time_units_string.par="",
                                                 first_time.par=0,
                                                 time_units_string.par=""){
  temp.boxplot_minima<-rep(0,num_test_sections.par)
  temp.boxplot_maxima<-temp.boxplot_minima
  for(temp.j in 1:num_test_sections.par){
    temp.boxplot_extrema_matrix_j<-boxplot_extrema_lists.par[[temp.j]]
    temp.boxplot_minima[temp.j]=min(temp.boxplot_extrema_matrix_j[,1])
    temp.boxplot_maxima[temp.j]=max(temp.boxplot_extrema_matrix_j[,2])
  }
  temp.boxplot_global_min=min(temp.boxplot_minima)
  temp.boxplot_global_max=max(temp.boxplot_maxima)
  temp.boxplot_global_range=temp.boxplot_global_max-temp.boxplot_global_min
  temp.LFP_global_min=min(unlist(LFP_ordinate_list.par))
  temp.LFP_global_max=max(unlist(LFP_ordinate_list.par))
  temp.min_x=min(unlist(LFP_time_list.par))
  temp.max_x=max(unlist(LFP_time_list.par))
  temp.min_y=-(num_augmented_list_elements.par-1)
  temp.max_y=1
  pdf(paste("LFP_MUA_Cumulative_Residual_Boxplots_Overlay.pdf",sep=""),width=8,height=6)
  par(mgp=c(2,0.5,0))
  plot(0,0,xlab=paste("Time, in ",abbreviated_time_units_string.par," since ",
                      first_time.par," ",time_units_string.par,sep=""),
       ylab="",
       main="Cumulative residual peak count:\nRange: Light - low, Dark - high",
       xlim=c(temp.min_x,temp.max_x),ylim=c(temp.min_y,temp.max_y),
       pch=".",lab=c(10,10,7),yaxt="n")
  temp.plotting_indices<-1:num_augmented_list_elements.par
  temp.plotting_indices<-rev(temp.plotting_indices)-num_augmented_list_elements.par
  axis(side=2,at=temp.plotting_indices,labels=c("",1:(num_augmented_list_elements.par-1)))
  grid()
  minor.tick(10,10)
  for(temp.j in 1:num_test_sections.par){
    temp.LFP_time_vector_j<-LFP_time_list.par[[temp.j]]
    temp.LFP_ordinate_vector_j<-LFP_ordinate_list.par[[temp.j]]
    temp.LFP_ordinate_vector_j<-temp.LFP_global_min+
      (temp.LFP_ordinate_vector_j-temp.LFP_global_min)/(temp.LFP_global_max-temp.LFP_global_min)
    temp.boxplot_extrema_matrix_j<-boxplot_extrema_lists.par[[temp.j]]
    temp.boxplot_range_j=temp.boxplot_maxima[temp.j]-temp.boxplot_minima[temp.j]
    temp.central_time_j=(min(temp.LFP_time_vector_j)+max(temp.LFP_time_vector_j))/2
    abline(v=min(temp.LFP_time_vector_j))
    abline(v=temp.central_time_j,col="grey80")
    lines(temp.LFP_time_vector_j,temp.LFP_ordinate_vector_j)
    temp.LFP_min_j=min(temp.LFP_time_vector_j)
    temp.LFP_max_j=max(temp.LFP_time_vector_j)
    temp.LFP_range_j=temp.LFP_max_j-temp.LFP_min_j
    temp.boxplot_list_j<-boxplot_firing_rate_lists.par[[temp.j]]
    temp.global_min_j<-min(unlist(temp.boxplot_list_j))
    temp.global_max_j<-max(unlist(temp.boxplot_list_j))
    temp.abs_global_min_j=abs(temp.global_min_j)
    temp.abs_global_max_j=abs(temp.global_max_j)
    if(temp.abs_global_min_j<temp.abs_global_max_j){
      temp.global_min_j=temp.global_min_j-(temp.abs_global_max_j-temp.abs_global_min_j)
    }
    else if(temp.abs_global_min_j>temp.abs_global_max_j){
      temp.global_max_j=temp.global_max_j+(temp.abs_global_min_j-temp.abs_global_max_j)
    }
    temp.global_range_j<-temp.global_max_j-temp.global_min_j
    for(temp.k in 1:(num_augmented_list_elements.par-1)){
      #extreme of the lower whisker, the lower hinge, the median, the upper hinge and the extreme of the upper whisker
      temp.boxplot_object_jk<-temp.boxplot_list_j[[temp.k]]
      temp.min_global_jk=min(temp.boxplot_object_jk)
      temp.max_global_jk=max(temp.boxplot_object_jk)
      temp.range_global_jk=temp.max_global_jk-temp.min_global_jk
      temp.shifted_boxplot_values_global_jk<-c()
      if(temp.global_range_j>0){
        temp.shifted_boxplot_values_global_jk<-(temp.boxplot_object_jk-temp.min_global_jk)*temp.range_global_jk/temp.global_range_j+temp.min_global_jk
      } else{
        temp.shifted_boxplot_values_global_jk<-temp.boxplot_object_jk
      }
      temp.min_jk=min(temp.shifted_boxplot_values_global_jk)
      temp.max_jk=max(temp.shifted_boxplot_values_global_jk)
      temp.range_jk=temp.max_jk-temp.min_jk
      if(temp.range_jk>0){
        temp.boxplot_object_jk<-(temp.shifted_boxplot_values_global_jk-temp.range_jk/2)*temp.LFP_range_j/temp.range_jk+temp.LFP_min_j+temp.LFP_range_j/2
      } else{
        temp.boxplot_object_jk<-temp.shifted_boxplot_values_global_jk
      }
      
      #temp.range_value=temp.boxplot_object_jk[5]-temp.boxplot_object_jk[1]
      #temp.mid_point=temp.boxplot_object_jk[1]+(temp.boxplot_object_jk[5]-temp.boxplot_object_jk[1])/2
      #temp.diffs<-c(temp.boxplot_object_jk[1]-temp.mid_point,temp.boxplot_object_jk[5]-temp.mid_point)
      #temp.abs_diffs<-abs(temp.diffs)
      #temp.max_abs_value=max(temp.abs_diffs)
      #temp.optimal_diff=temp.diffs[min(which(temp.abs_diffs==temp.max_abs_value))]
      #temp.shifted_boxplot_values_j<-temp.boxplot_object_jk-temp.optimal_diff
      #temp.boxplot_object_jk<-temp.central_time_j+temp.shifted_boxplot_values_j
      #if(temp.max_abs_value>0){
      #  temp.boxplot_object_jk<-temp.central_time_j+
      #    temp.shifted_boxplot_values_j*
      #    (max(temp.LFP_time_vector_j)-min(temp.LFP_time_vector_j))/(2*temp.max_abs_value)
      #}
      #cat("temp.boxplot_object_jk\n")
      #print(head(temp.boxplot_object_jk))
      #Whiskers.
      segments(x0=temp.boxplot_object_jk[1],y0=-temp.k,x1=temp.boxplot_object_jk[5],y1=-temp.k)
      lines(c(temp.boxplot_object_jk[1],temp.boxplot_object_jk[5]),c(-temp.k,-temp.k),type="p",pch=".",cex=3)
      #Box.
      temp.running_mycol=1
      if(temp.boxplot_minima[temp.j]!=temp.boxplot_maxima[temp.j]){
        temp.alpha_level=100-(temp.boxplot_extrema_matrix_j[temp.k,2]-temp.boxplot_minima[temp.j])/temp.boxplot_range_j*100
        if(temp.alpha_level>=0 & temp.alpha_level<=100){
          temp.running_mycol<-
            t_col(temp.running_mycol,perc=temp.alpha_level,
                  name=paste("lt.",temp.j,",",temp.k,sep=""))
        }
      }
      rect(xleft=temp.boxplot_object_jk[2],ybottom=-temp.k-0.2,xright=temp.boxplot_object_jk[4],ytop=-temp.k+0.2,
           col=temp.running_mycol,border=par("fg"),lty=NULL,lwd=par("lwd"),xpd=FALSE)
      #Median.
      segments(x0=temp.boxplot_object_jk[3],y0=-temp.k-0.2,x1=temp.boxplot_object_jk[3],y1=-temp.k+0.2,lwd=2)
    }
  }
  dev.off()
}







cumulative_residual_analysis_single_stratum_model_diagnostic.function<-
  function(LFP_time_list.par,LFP_ordinate_list.par,
           all_peak_histogram_abscissa_lists.par,all_peak_histogram_ordinates_lists.par,
           all_LFP_spike_times_lists.par,all_spike_LFP_ordinates_lists.par,all_spike_time_lists.par,
           num_test_sections.par,num_augmented_list_elements.par,
           plotting_legend_strings_vector.par,point_process_glm_directory_string.par,
           first_time.par=0,
           abbreviated_time_units_string.par="",
           time_units_string.par="",
           output_bool.par=FALSE,
           plot_bool.par=FALSE){
    temp.cumulative_residual_analysis_single_stratum_object<-
      cumulative_residual_analysis_single_stratum.function(LFP_time_list.par=LFP_time_list.par,
                                                           LFP_ordinate_list.par=LFP_ordinate_list.par,
                                                           all_peak_histogram_abscissa_lists.par=all_peak_histogram_abscissa_lists.par,
                                                           all_peak_histogram_ordinates_lists.par=all_peak_histogram_ordinates_lists.par,
                                                           all_LFP_spike_times_lists.par=all_LFP_spike_times_lists.par,
                                                           all_spike_LFP_ordinates_lists.par=all_spike_LFP_ordinates_lists.par,
                                                           all_spike_time_lists.par=all_spike_time_lists.par,
                                                           num_augmented_list_elements.par=num_augmented_list_elements.par,
                                                           plotting_legend_strings_vector.par=plotting_legend_strings_vector.par,
                                                           point_process_glm_directory_string.par=point_process_glm_directory_string.par,
                                                           first_time.par=first_time.par,
                                                           abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                                           time_units_string.par=time_units_string.par,
                                                           output_bool.par=output_bool.par,
                                                           plot_bool.par=plot_bool.par)
    temp.all_spike_density_ordinates_lists<-temp.cumulative_residual_analysis_single_stratum_object$out.all_spike_density_ordinates_lists
    temp.all_spike_density_abscissa_lists<-temp.cumulative_residual_analysis_single_stratum_object$out.all_spike_density_abscissa_lists
    temp.boxplot_lists<-temp.cumulative_residual_analysis_single_stratum_object$out.boxplot_lists
    temp.boxplot_extrema_lists<-temp.cumulative_residual_analysis_single_stratum_object$out.boxplot_extrema_lists
    temp.boxplot_firing_rate_lists<-temp.cumulative_residual_analysis_single_stratum_object$out.boxplot_firing_rate_lists
    temp.boxplot_firing_rate_extrema_lists<-temp.cumulative_residual_analysis_single_stratum_object$out.boxplot_firing_rate_extrema_lists
    temp.model_residual_times<-temp.cumulative_residual_analysis_single_stratum_object$out.model_residual_times
    temp.model_residual_counts<-temp.cumulative_residual_analysis_single_stratum_object$out.model_residual_counts
    #Cumulative residuals boxplots.
    temp.cumulative_residuals_boxplots_object<-
      cumulative_residuals_boxplots.function(boxplot_extrema_lists.par=temp.boxplot_extrema_lists,
                                             boxplot_firing_rate_lists.par=temp.boxplot_firing_rate_lists,
                                             LFP_time_list.par=LFP_time_list.par,
                                             LFP_ordinate_list.par=LFP_ordinate_list.par,
                                             model_residual_times.par=temp.model_residual_times,
                                             model_residual_counts.par=temp.model_residual_counts,
                                             num_test_sections.par=num_test_sections.par,
                                             num_augmented_list_elements.par=num_augmented_list_elements.par,
                                             abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                             first_time.par=first_time.par,
                                             time_units_string.par=time_units_string.par)
    temp.list<-list(out.all_spike_density_ordinates_lists=temp.all_spike_density_ordinates_lists,
                    out.all_spike_density_abscissa_lists=temp.all_spike_density_abscissa_lists,
                    out.boxplot_lists=temp.boxplot_lists,
                    out.boxplot_extrema_lists=temp.boxplot_extrema_lists,
                    out.boxplot_firing_rate_lists=temp.boxplot_firing_rate_lists,
                    out.boxplot_firing_rate_extrema_lists=temp.boxplot_firing_rate_extrema_lists,
                    out.model_residual_times=temp.model_residual_times,
                    out.model_residual_counts=temp.model_residual_counts)
    return(temp.list)
  }





peak_rate_boxplots.function<-function(boxplot_firing_rate_extrema_lists.par,boxplot_firing_rate_lists.par,
                                      LFP_time_list.par,LFP_ordinate_list.par,
                                      model_residual_times.par,model_residual_counts.par,
                                      num_test_sections.par,num_augmented_list_elements.par,
                                      abbreviated_time_units_string.par="",
                                      first_time.par=0,time_units_string.par=""){
  #Peak-rate boxplots.
  temp.boxplot_minima<-rep(0,num_test_sections.par)
  temp.boxplot_maxima<-temp.boxplot_minima
  for(temp.j in 1:num_test_sections.par){
    temp.boxplot_extrema_matrix_j<-boxplot_firing_rate_extrema_lists.par[[temp.j]]
    temp.boxplot_minima[temp.j]=min(temp.boxplot_extrema_matrix_j[,1])
    temp.boxplot_maxima[temp.j]=max(temp.boxplot_extrema_matrix_j[,2])
  }
  temp.LFP_global_min=min(unlist(LFP_ordinate_list.par))
  temp.LFP_global_max=max(unlist(LFP_ordinate_list.par))
  temp.min_x=min(unlist(LFP_time_list.par))
  temp.max_x=max(unlist(LFP_time_list.par))
  temp.min_y=-(num_augmented_list_elements.par-1)
  temp.max_y=1
  pdf(paste("LFP_MUA_Firing_Rate_Boxplots_Overlay.pdf",sep=""),width=8,height=6)
  par(mgp=c(2,0.5,0))
  plot(0,0,xlab=paste("Time, in ",abbreviated_time_units_string.par," since ",
                      first_time.par," ",time_units_string.par,sep=""),
       ylab="",
       main=paste("Peaks per ",abbreviated_time_units_string.par," (square-root value)\nPeak rate: Light - low, Dark - high",sep=""),
       xlim=c(temp.min_x,temp.max_x),ylim=c(temp.min_y,temp.max_y),
       pch=".",lab=c(10,10,7),yaxt="n")
  temp.plotting_indices<-1:num_augmented_list_elements.par
  temp.plotting_indices<-rev(temp.plotting_indices)-num_augmented_list_elements.par
  axis(side=2,at=temp.plotting_indices,labels=c("",1:(num_augmented_list_elements.par-1)))
  grid()
  minor.tick(10,10)
  for(temp.j in 1:num_test_sections.par){
    temp.LFP_time_vector_j<-LFP_time_list.par[[temp.j]]
    temp.LFP_ordinate_vector_j<-LFP_ordinate_list.par[[temp.j]]
    temp.LFP_ordinate_vector_j<-temp.LFP_global_min+
      (temp.LFP_ordinate_vector_j-temp.LFP_global_min)/(temp.LFP_global_max-temp.LFP_global_min)
    temp.boxplot_extrema_matrix_j<-boxplot_firing_rate_extrema_lists.par[[temp.j]]
    temp.boxplot_range_j=temp.boxplot_maxima[temp.j]-temp.boxplot_minima[temp.j]
    abline(v=min(temp.LFP_time_vector_j))
    lines(temp.LFP_time_vector_j,temp.LFP_ordinate_vector_j)
    temp.boxplot_list_j<-boxplot_firing_rate_lists.par[[temp.j]]
    temp.min_values_j<-sqrt(temp.boxplot_extrema_matrix_j[,1])
    temp.max_values_j<-sqrt(temp.boxplot_extrema_matrix_j[,2])
    temp.boxplot_global_min_j=min(temp.min_values_j)
    temp.boxplot_global_max_j=max(temp.max_values_j)
    temp.boxplot_global_range_j=temp.boxplot_global_max_j-temp.boxplot_global_min_j
    for(temp.k in 1:(num_augmented_list_elements.par-1)){
      #extreme of the lower whisker, the lower hinge, the median, the upper hinge and the extreme of the upper whisker
      temp.boxplot_object_jk<-temp.boxplot_list_j[[temp.k]]
      temp.boxplot_object_jk<-sqrt(temp.boxplot_object_jk)
      temp.shifted_boxplot_values_j<-temp.boxplot_object_jk-temp.boxplot_global_min_j
      temp.boxplot_object_jk<-min(temp.LFP_time_vector_j)+temp.shifted_boxplot_values_j
      if(temp.boxplot_global_range_j>0){
        temp.boxplot_object_jk<-min(temp.LFP_time_vector_j)+
          temp.shifted_boxplot_values_j*
          (max(temp.LFP_time_vector_j)-min(temp.LFP_time_vector_j))/temp.boxplot_global_range_j
      }
      #Whiskers.
      segments(x0=temp.boxplot_object_jk[1],y0=-temp.k,x1=temp.boxplot_object_jk[5],y1=-temp.k)
      lines(c(temp.boxplot_object_jk[1],temp.boxplot_object_jk[5]),c(-temp.k,-temp.k),type="p",pch=".",cex=3)
      #Box.
      temp.running_mycol=1
      if(temp.boxplot_minima[temp.j]!=temp.boxplot_maxima[temp.j]){
        temp.running_mycol<-
          t_col(temp.running_mycol,perc=100-(temp.boxplot_extrema_matrix_j[temp.k,2]-temp.boxplot_minima[temp.j])/temp.boxplot_range_j*100,
                name=paste("lt.",temp.j,",",temp.k,sep=""))
      }
      rect(xleft=temp.boxplot_object_jk[2],ybottom=-temp.k-0.2,xright=temp.boxplot_object_jk[4],ytop=-temp.k+0.2,
           col=temp.running_mycol,border=par("fg"),lty=NULL,lwd=par("lwd"),xpd=FALSE)
      #Median.
      segments(x0=temp.boxplot_object_jk[3],y0=-temp.k-0.2,x1=temp.boxplot_object_jk[3],y1=-temp.k+0.2,lwd=2)
    }
  }
  dev.off()
}




point_process_diagnostics_all_models.function<-function(LFP_time_list.par,LFP_ordinate_list.par,
                                                        all_peak_histogram_abscissa_lists.par,all_peak_histogram_ordinates_lists.par,
                                                        all_LFP_spike_times_lists.par,all_spike_LFP_ordinates_lists.par,
                                                        all_spike_time_lists.par,
                                                        num_test_sections.par,num_augmented_list_elements.par,
                                                        plotting_legend_strings_vector.par,point_process_glm_directory_string.par,
                                                        first_time.par=0,
                                                        abbreviated_time_units_string.par="",
                                                        time_units_string.par="",
                                                        output_bool.par=FALSE,plot_bool.par=FALSE){
  #Cumulative-residual diagnostic analysis.
  temp.cumulative_residual_analysis_single_stratum_model_diagnostic_object<-
    cumulative_residual_analysis_single_stratum_model_diagnostic.function(LFP_time_list.par=LFP_time_list.par,
                                                                          LFP_ordinate_list.par=LFP_ordinate_list.par,
                                                                          all_peak_histogram_abscissa_lists.par=all_peak_histogram_abscissa_lists.par,
                                                                          all_peak_histogram_ordinates_lists.par=all_peak_histogram_ordinates_lists.par,
                                                                          all_LFP_spike_times_lists.par=all_LFP_spike_times_lists.par,
                                                                          all_spike_LFP_ordinates_lists.par=all_spike_LFP_ordinates_lists.par,
                                                                          all_spike_time_lists.par=all_spike_time_lists.par,
                                                                          num_test_sections.par=num_test_sections.par,
                                                                          num_augmented_list_elements.par=num_augmented_list_elements.par,
                                                                          plotting_legend_strings_vector.par=plotting_legend_strings_vector.par,
                                                                          point_process_glm_directory_string.par=point_process_glm_directory_string.par,
                                                                          first_time.par=first_time.par,
                                                                          abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                                                          time_units_string.par=time_units_string.par,
                                                                          output_bool.par=output_bool.par,
                                                                          plot_bool.par=plot_bool.par)
  temp.all_spike_density_ordinates_lists<-temp.cumulative_residual_analysis_single_stratum_model_diagnostic_object$out.all_spike_density_ordinates_lists
  temp.all_spike_density_abscissa_lists<-temp.cumulative_residual_analysis_single_stratum_model_diagnostic_object$out.all_spike_density_abscissa_lists
  temp.boxplot_lists<-temp.cumulative_residual_analysis_single_stratum_model_diagnostic_object$out.boxplot_lists
  temp.boxplot_extrema_lists<-temp.cumulative_residual_analysis_single_stratum_model_diagnostic_object$out.boxplot_extrema_lists
  temp.boxplot_firing_rate_lists<-temp.cumulative_residual_analysis_single_stratum_model_diagnostic_object$out.boxplot_firing_rate_lists
  temp.boxplot_firing_rate_extrema_lists<-temp.cumulative_residual_analysis_single_stratum_model_diagnostic_object$out.boxplot_firing_rate_extrema_lists
  temp.model_residual_times<-temp.cumulative_residual_analysis_single_stratum_model_diagnostic_object$out.model_residual_times
  temp.model_residual_counts<-temp.cumulative_residual_analysis_single_stratum_model_diagnostic_object$out.model_residual_counts
  #Peak-rate diagnostic analysis.
  temp.peak_rate_boxplots_object<-
    peak_rate_boxplots.function(boxplot_firing_rate_extrema_lists.par=temp.boxplot_firing_rate_extrema_lists,
                                boxplot_firing_rate_lists.par=temp.boxplot_firing_rate_lists,
                                LFP_time_list.par=LFP_time_list.par,
                                LFP_ordinate_list.par=LFP_ordinate_list.par,
                                num_test_sections.par=num_test_sections.par,
                                num_augmented_list_elements.par=num_augmented_list_elements.par,
                                model_residual_times.par=temp.model_residual_times,
                                model_residual_counts.par=temp.model_residual_counts,
                                first_time.par=first_time.par,
                                abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                time_units_string.par=time_units_string.par)
  temp.list<-list(out.all_spike_density_ordinates_lists=temp.all_spike_density_ordinates_lists,
                  out.all_spike_density_abscissa_lists=temp.all_spike_density_abscissa_lists,
                  out.boxplot_lists=temp.boxplot_lists,
                  out.boxplot_extrema_lists=temp.boxplot_extrema_lists,
                  out.boxplot_firing_rate_lists=temp.boxplot_firing_rate_lists,
                  out.boxplot_firing_rate_extrema_lists=temp.boxplot_firing_rate_extrema_lists,
                  out.model_residual_times=temp.model_residual_times,
                  out.model_residual_counts=temp.model_residual_counts)
  return(temp.list)
}






#Final firing-rate boxplots.
peak_rates_final_model.function<-function(LFP_time_list.par,LFP_ordinate_list.par,
                                          boxplot_firing_rate_extrema_lists.par,boxplot_firing_rate_lists.par,
                                          all_spike_density_abscissa_lists.par,all_spike_density_ordinates_lists.par,
                                          num_test_sections.par,
                                          start_section_index.par=1,
                                          abbreviated_time_units_string.par="",
                                          measure_quantity.par="",measure_quantity_upper_case.string="",
                                          measure_units.par="",
                                          first_time.par=0,time_units_string.par="",
                                          model_index.par=1,final_model_index.par=1,
                                          all_raster_legend_strings_vector.par){
  temp.boxplot_minima<-rep(0,num_test_sections.par-start_section_index.par+1)
  temp.boxplot_maxima<-temp.boxplot_minima
  temp.spike_density_minima<-temp.boxplot_minima
  temp.spike_density_maxima<-temp.boxplot_minima
  temp.LFP_min_times_vector<-temp.boxplot_minima
  temp.num_rows=0
  for(temp.j in start_section_index.par:num_test_sections.par){
    temp.LFP_min_times_vector[temp.j-start_section_index.par+1]=min(LFP_time_list.par[[temp.j]])
    temp.boxplot_extrema_matrix_j<-boxplot_firing_rate_extrema_lists.par[[temp.j]]
    if(temp.j==1){
      temp.num_rows=nrow(temp.boxplot_extrema_matrix_j)
    }
    temp.boxplot_minima[temp.j-start_section_index.par+1]=min(temp.boxplot_extrema_matrix_j[c(temp.num_rows,temp.num_rows-rev(c(model_index.par+2-1))),1])
    temp.boxplot_maxima[temp.j-start_section_index.par+1]=max(temp.boxplot_extrema_matrix_j[c(temp.num_rows,temp.num_rows-rev(c(model_index.par+2-1))),2])
    temp.spike_density_ordinates_list_j<-all_spike_density_ordinates_lists.par[[temp.j]]
    temp.root_spiking_density_Marshall_high_variance<-temp.spike_density_ordinates_list_j[[c(temp.num_rows-rev(c(model_index.par+2-1)))]]
    temp.root_spiking_density_Marshall_low_variance<-temp.spike_density_ordinates_list_j[[c(temp.num_rows)]]
    temp.root_spiking_density_Marshall_high_variance<-sqrt(temp.root_spiking_density_Marshall_high_variance)
    temp.root_spiking_density_Marshall_low_variance<-sqrt(temp.root_spiking_density_Marshall_low_variance)
    temp.spike_density_minima[temp.j-start_section_index.par+1]=
      min(min(temp.root_spiking_density_Marshall_high_variance),min(temp.root_spiking_density_Marshall_low_variance))
    temp.spike_density_maxima[temp.j-start_section_index.par+1]=
      max(max(temp.root_spiking_density_Marshall_high_variance),max(temp.root_spiking_density_Marshall_low_variance))
  }
  temp.global_boxplot_minimum=min(temp.boxplot_minima)
  temp.global_boxplot_maximum=max(temp.boxplot_minima)
  temp.boxplot_global_range=temp.global_boxplot_maximum-temp.global_boxplot_minimum
  temp.global_spike_density_minimum=min(temp.spike_density_minima)
  temp.global_spike_density_maximum=max(temp.spike_density_maxima)
  temp.spike_density_global_range=temp.global_spike_density_maximum-temp.global_spike_density_minimum
  temp.LFP_global_min_time=min(temp.LFP_min_times_vector)
  temp.plotting_all_LFP_ordinates<-unlist(LFP_ordinate_list.par)
  temp.LFP_global_min=min(temp.plotting_all_LFP_ordinates)
  temp.LFP_global_max=max(temp.plotting_all_LFP_ordinates)
  temp.plotting_legend_strings_vector<-c(all_raster_legend_strings_vector.par,"Weiss AP-detection method","LFP")
  temp.num_plotting_legend_strings=length(temp.plotting_legend_strings_vector)
  temp.plotting_final_model_string<-temp.plotting_legend_strings_vector[length(temp.plotting_legend_strings_vector)-c(6+final_model_index.par-1)+1]
  temp.min_x=temp.LFP_global_min_time
  temp.max_x=max(unlist(LFP_time_list.par))
  temp.min_y=-2.2#-(temp.num_augmented_list_elements-1)
  temp.max_y=3
  pdf(paste("LFP_MUA_Firing_Rate_Boxplots_Overlay_Marshall.pdf",sep=""),width=8,height=6)
  par(mgp=c(2,0.5,0))
  plot(0,0,xlab=paste("Time, in ",abbreviated_time_units_string.par," since ",
                      first_time.par," ",time_units_string.par,sep=""),
       ylab="",
       main=paste("Squared ",measure_quantity_upper_case.string,", [0,1]-normalized / Peaks per ",
                  abbreviated_time_units_string.par," (square-root value)",sep=""),
       xlim=c(temp.min_x,temp.max_x),ylim=c(temp.min_y,temp.max_y),
       pch=".",lab=c(10,10,7),yaxt="n")
  temp.plotting_indices<-rev(1:5)-2
  temp.plotting_indices[1:3]<-temp.plotting_indices[1:3]-0.5
  temp.plotting_indices[4:5]<-temp.plotting_indices[4:5]-1
  axis(side=2,at=temp.plotting_indices,labels=c("LFP","HV","Weiss_AP","HV","Weiss_AP"))
  axis(side=4,at=3,labels=round_general.function(temp.LFP_global_max,1))
  axis(side=4,at=2,
       labels=paste(round_general.function(temp.global_spike_density_maximum,1),sep=""))
  axis(side=4,at=1,
       labels=paste(round_general.function(temp.global_spike_density_maximum,1),sep=""))
  axis(side=4,at=0,
       labels=paste(round_general.function(temp.global_spike_density_minimum,1),sep=""))
  grid()
  minor.tick(10,10)
  for(temp.j in start_section_index.par:num_test_sections.par){
    temp.spike_density_ordinates_list_j<-all_spike_density_ordinates_lists.par[[temp.j]]
    temp.spike_density_abscissa_list_j<-all_spike_density_abscissa_lists.par[[temp.j]]
    temp.LFP_time_vector_j<-LFP_time_list.par[[temp.j]]
    temp.LFP_ordinate_vector_j<-LFP_ordinate_list.par[[temp.j]]
    temp.LFP_ordinate_vector_j<-(temp.LFP_ordinate_vector_j-temp.LFP_global_min)/(temp.LFP_global_max-temp.LFP_global_min)
    temp.boxplot_extrema_matrix_j<-boxplot_firing_rate_extrema_lists.par[[temp.j]]
    temp.boxplot_range_j=temp.boxplot_maxima[temp.j]-temp.boxplot_minima[temp.j]
    abline(v=min(temp.LFP_time_vector_j))
    abline(h=3:6-3,col="grey75")
    abline(h=1:2-2.5,col="grey75")
    lines(temp.LFP_time_vector_j,temp.LFP_ordinate_vector_j+2)
    temp.boxplot_list_j<-boxplot_firing_rate_lists.par[[temp.j]]
    temp.min_values_j=min(temp.boxplot_extrema_matrix_j[c(temp.num_rows,temp.num_rows-rev(c(model_index.par+2-1))),1])
    temp.max_values_j=max(temp.boxplot_extrema_matrix_j[c(temp.num_rows,temp.num_rows-rev(c(model_index.par+2-1))),2])
    temp.min_values_j<-sqrt(temp.min_values_j)
    temp.max_values_j<-sqrt(temp.max_values_j)
    temp.boxplot_global_min_j=min(temp.min_values_j)
    temp.boxplot_global_max_j=max(temp.max_values_j)
    temp.boxplot_global_range_j=temp.boxplot_global_max_j-temp.boxplot_global_min_j
    temp.counter=1
    for(temp.k in c(temp.num_rows,temp.num_rows-rev(c(model_index.par+2-1)))){
      temp.spike_density_ordinates_vector_jk<-sqrt(temp.spike_density_ordinates_list_j[[temp.k]])
      temp.spike_density_abscissa_vector_jk<-temp.spike_density_abscissa_list_j[[temp.k]]
      temp.spike_density_ordinates_vector_jk<-
        (temp.spike_density_ordinates_vector_jk-temp.global_spike_density_minimum)/
        (temp.global_spike_density_maximum-temp.global_spike_density_minimum)
      lines(temp.spike_density_abscissa_vector_jk,temp.spike_density_ordinates_vector_jk+temp.counter-1,cex=0.25)
      #extreme of the lower whisker, the lower hinge, the median, the upper hinge and the extreme of the upper whisker
      temp.boxplot_object_jk<-temp.boxplot_list_j[[temp.k]]
      temp.boxplot_object_jk<-sqrt(temp.boxplot_object_jk)
      temp.shifted_boxplot_values_j<-temp.boxplot_object_jk-temp.boxplot_global_min_j
      temp.boxplot_object_jk<-min(temp.LFP_time_vector_j)+temp.shifted_boxplot_values_j
      if(temp.boxplot_global_range_j>0){
        temp.boxplot_object_jk<-min(temp.LFP_time_vector_j)+
          temp.shifted_boxplot_values_j*
          (max(temp.LFP_time_vector_j)-min(temp.LFP_time_vector_j))/temp.boxplot_global_range_j
      }
      #Whiskers.
      segments(x0=temp.boxplot_object_jk[1],y0=+temp.counter-3,x1=temp.boxplot_object_jk[5],y1=+temp.counter-3)
      lines(c(temp.boxplot_object_jk[1],temp.boxplot_object_jk[5]),c(+temp.counter-3,+temp.counter-3),type="p",pch=".",cex=3)
      #Colour shading indicates the level of the k'th PC-component firing rate the relative to the minimum and maximum firing rates over PC-components.
      temp.running_mycol=1
      if(temp.boxplot_minima[temp.j-start_section_index.par+1]!=temp.boxplot_maxima[temp.j-start_section_index.par+1]){
        temp.alpha_level=(temp.boxplot_extrema_matrix_j[temp.k,2]-temp.boxplot_minima[temp.j-start_section_index.par+1])/temp.boxplot_range_j*100
        if(temp.alpha_level>=0 & temp.alpha_level<=100){
          temp.running_mycol<-
            t_col(temp.running_mycol,perc=temp.alpha_level,
                  name=paste("lt.",temp.j-start_section_index.par+1,",",temp.k,sep=""))
        }
      }
      rect(xleft=temp.boxplot_object_jk[2],ybottom=+temp.counter-3-0.2,xright=temp.boxplot_object_jk[4],ytop=+temp.counter-3+0.2,
           border=par("fg"),lty=NULL,lwd=par("lwd"),xpd=FALSE)
      #Median.
      segments(x0=temp.boxplot_object_jk[3],y0=+temp.counter-3,x1=temp.boxplot_object_jk[3],y1=+temp.counter-3,lwd=2)
      temp.counter=temp.counter+1
    }
  }
  dev.off()
}





#Final firing-rate boxplots.
peak_rates_final_model_quantiles.function<-function(LFP_time_list.par,LFP_ordinate_list.par,
                                                    boxplot_firing_rate_extrema_lists.par,boxplot_firing_rate_lists.par,
                                                    all_spike_density_abscissa_lists.par,all_spike_density_ordinates_lists.par,
                                                    num_test_sections.par,
                                                    start_section_index.par=1,
                                                    all_raster_legend_strings_vector.par,
                                                    abbreviated_time_units_string.par="",
                                                    measure_quantity_upper_case.string="",
                                                    measure_units.par="",
                                                    first_time.par=0,time_units_string.par="",
                                                    final_model_index.par=1){
  temp.plotting_legend_strings_vector<-c(all_raster_legend_strings_vector.par,"Weiss AP-detection method","LFP")
  temp.LFP_global_min_time=min(unlist(LFP_time_list.par))
  temp.plotting_all_LFP_ordinates<-unlist(LFP_ordinate_list.par)
  temp.LFP_global_min=min(temp.plotting_all_LFP_ordinates)
  temp.LFP_global_max=max(temp.plotting_all_LFP_ordinates)
  temp.num_rows=0
  pdf(paste("LFP_MUA_Firing_Rate_Model_Uncertainty_Marshall.pdf",sep=""),width=8,height=6)
  par(mgp=c(2,0.5,0))
  for(temp.j in start_section_index.par:num_test_sections.par){
    temp.boxplot_extrema_matrix_j<-boxplot_firing_rate_extrema_lists.par[[temp.j]]
    if(temp.j==1){
      temp.num_rows=nrow(temp.boxplot_extrema_matrix_j)
    }
    temp.spike_density_ordinates_list_j<-all_spike_density_ordinates_lists.par[[temp.j]]
    temp.spike_density_abscissa_list_j<-all_spike_density_abscissa_lists.par[[temp.j]]
    temp.num_LFP_j=length(temp.spike_density_ordinates_list_j[[1]])
    for(temp.k in 2:(temp.num_rows-1)){
      temp.num_LFP_jk=length(temp.spike_density_ordinates_list_j[[temp.k]])
      if(temp.num_LFP_jk>temp.num_LFP_j){
        temp.num_LFP_j=temp.num_LFP_jk
      }
    }
    temp.indices_j<-1:(temp.num_rows-1)
    temp.medians_j<-rep(NA,temp.num_rows-1)
    for(temp.k in temp.indices_j){
      temp.spike_density_ordinates_vector_jk<-temp.spike_density_ordinates_list_j[[temp.k]]
      if(length(temp.spike_density_ordinates_vector_jk)>1){
        if(length(which(temp.spike_density_ordinates_vector_jk>0))>1){
          temp.medians_j[temp.k]<-median(temp.spike_density_ordinates_vector_jk)
        }
      }
    }
    temp.applicable_indices_j<-which(is.na(temp.medians_j)==FALSE)
    temp.applicable_medians_j<-temp.medians_j[temp.applicable_indices_j]
    temp.ordered_indices_j<-temp.applicable_indices_j[order(temp.applicable_medians_j)]
    temp.num_ordered_indices_j=length(temp.ordered_indices_j)
    temp.applicable_lower_quartile_index=min(max(1,round(temp.num_ordered_indices_j/4)),temp.num_ordered_indices_j)
    temp.applicable_median_index=min(max(1,round(temp.num_ordered_indices_j/2)),temp.num_ordered_indices_j)
    temp.applicable_upper_quartile_index=min(max(1,round(temp.num_ordered_indices_j*3/4)),temp.num_ordered_indices_j)
    temp.lower_quartile_index<-temp.ordered_indices_j[temp.applicable_lower_quartile_index]
    temp.median_quartile_index<-temp.ordered_indices_j[temp.applicable_median_index]
    temp.upper_quartile_index<-temp.ordered_indices_j[temp.applicable_upper_quartile_index]
    temp.quantile_signals_times_list_j<-list()
    temp.quantile_signals_list_j<-list()
    temp.quantile_signals_times_list_j[[1]]<-temp.spike_density_abscissa_list_j[[temp.lower_quartile_index]]
    temp.quantile_signals_list_j[[1]]<-temp.spike_density_ordinates_list_j[[temp.lower_quartile_index]]
    temp.quantile_signals_times_list_j[[2]]<-temp.spike_density_abscissa_list_j[[temp.median_quartile_index]]
    temp.quantile_signals_list_j[[2]]<-temp.spike_density_ordinates_list_j[[temp.median_quartile_index]]
    temp.quantile_signals_times_list_j[[3]]<-temp.spike_density_abscissa_list_j[[temp.upper_quartile_index]]
    temp.quantile_signals_list_j[[3]]<-temp.spike_density_ordinates_list_j[[temp.upper_quartile_index]]
    temp.all_spike_density_ordinates_vector_j<-temp.spike_density_ordinates_list_j[[temp.num_rows-2]]
    temp.all_quantile_signals_vector_j<-unlist(temp.quantile_signals_list_j)
    temp.global_spike_density_minimum_j=min(c(min(temp.all_quantile_signals_vector_j[temp.all_quantile_signals_vector_j>0]),
                                               min(temp.all_spike_density_ordinates_vector_j)))
    temp.global_spike_density_maximum_j=max(c(max(temp.all_quantile_signals_vector_j[temp.all_quantile_signals_vector_j>0]),
                                               max(temp.all_spike_density_ordinates_vector_j)))
    temp.spike_density_global_range_j=temp.global_spike_density_maximum_j-temp.global_spike_density_minimum_j
    temp.min_x=min(LFP_time_list.par[[temp.j]])
    temp.max_x=temp.min_x+2*(max(LFP_time_list.par[[temp.j]])-temp.min_x)
    temp.min_y=0
    temp.max_y=4
    plot(0,0,xlab=paste("Time, in ",abbreviated_time_units_string.par," since ",
                        first_time.par," ",time_units_string.par,sep=""),
         ylab=paste("Peaks per ",abbreviated_time_units_string.par," (square-root value) / Squared ",
                    measure_quantity_upper_case.string,", [0,1]-normalized",sep=""),
         main="",
         xlim=c(temp.min_x,temp.max_x),ylim=c(temp.min_y,temp.max_y),
         pch=".",lab=c(10,10,7),yaxt="n")
    grid()
    minor.tick(10,10)
    temp.LFP_time_vector_j<-LFP_time_list.par[[temp.j]]
    temp.LFP_ordinate_vector_j<-LFP_ordinate_list.par[[temp.j]]
    temp.LFP_ordinate_vector_j<-(temp.LFP_ordinate_vector_j-temp.LFP_global_min)/(temp.LFP_global_max-temp.LFP_global_min)
    #abline(v=min(temp.LFP_time_vector_j))
    abline(h=1:4-1,col="grey75")
    lines(temp.LFP_time_vector_j,temp.LFP_ordinate_vector_j+3)
    #Lower quartile.
    temp.lower_quartile_times_vector<-temp.quantile_signals_times_list_j[[1]]
    temp.lower_quartile_vector<-temp.quantile_signals_list_j[[1]]
    #temp.lower_quartile_vector[temp.lower_quartile_vector>0]<-
    #  10*log10(temp.lower_quartile_vector[temp.lower_quartile_vector>0])
    #temp.lower_quartile_vector[temp.lower_quartile_vector==0]<-
    #  min(which(temp.lower_quartile_vector>0))-12
    temp.lower_quartile_vector<-
      (temp.lower_quartile_vector-temp.global_spike_density_minimum_j)/temp.spike_density_global_range_j
    temp.lower_quartile_times<-temp.lower_quartile_times_vector
    temp.lower_quartile_ordinates<-temp.lower_quartile_vector+1
    #for(temp.l in 1:length(temp.upper_quartile_ordinates)){
    #  segments(x0=temp.upper_quartile_times[temp.l],y0=1,
    #           x1=temp.upper_quartile_times[temp.l],y1=temp.upper_quartile_ordinates[temp.l],
    #           col="grey75")
    #}
    lines(temp.lower_quartile_times,temp.lower_quartile_ordinates,type="o",pch=".",cex=3,col="grey50")
    #Upper quartile.
    temp.upper_quartile_times_vector<-temp.quantile_signals_times_list_j[[3]]
    temp.upper_quartile_vector<-temp.quantile_signals_list_j[[3]]
    #temp.upper_quartile_vector[temp.upper_quartile_vector>0]<-
    #  10*log10(temp.upper_quartile_vector[temp.upper_quartile_vector>0])
    #temp.upper_quartile_vector[temp.upper_quartile_vector==0]<-
    #  min(which(temp.upper_quartile_vector>0))-12
    temp.upper_quartile_vector<-
      (temp.upper_quartile_vector-temp.global_spike_density_minimum_j)/temp.spike_density_global_range_j
    temp.upper_quartile_times<-temp.upper_quartile_times_vector
    temp.upper_quartile_ordinates<-temp.upper_quartile_vector+1
    #for(temp.l in 1:length(temp.upper_quartile_ordinates)){
    #  segments(x0=temp.upper_quartile_times[temp.l],y0=1,
    #           x1=temp.upper_quartile_times[temp.l],y1=temp.upper_quartile_ordinates[temp.l],
    #           col="grey75")
    #}
    lines(temp.upper_quartile_times,temp.upper_quartile_ordinates,type="o",pch=".",cex=3,col="grey50")
    #Median.
    temp.median_times_vector<-temp.quantile_signals_times_list_j[[2]]
    temp.median_vector<-temp.quantile_signals_list_j[[2]]
    #temp.median_vector[temp.median_vector>0]<-
    #  10*log10(temp.median_vector[temp.median_vector>0])
    #temp.median_vector[temp.median_vector==0]<-
    #  min(which(temp.median_vector>0))-12
    temp.median_vector<-
      (temp.median_vector-temp.global_spike_density_minimum_j)/temp.spike_density_global_range_j
    temp.median_times<-temp.median_times_vector
    temp.median_ordinates<-temp.median_vector+1
    lines(temp.median_times,temp.median_ordinates,type="o",pch=".",lty=2,cex=3,col=2)
    #Final model.
    temp.spike_density_abscissa_vector_jk<-temp.spike_density_abscissa_list_j[[temp.num_rows-final_model_index.par-1]]
    temp.spike_density_ordinates_vector_jk<-temp.spike_density_ordinates_list_j[[temp.num_rows-final_model_index.par-1]]
    #temp.spike_density_ordinates_vector_jk[temp.spike_density_ordinates_vector_jk>0]<-
    #  10*log10(temp.spike_density_ordinates_vector_jk[temp.spike_density_ordinates_vector_jk>0])
    #temp.spike_density_ordinates_vector_jk[temp.spike_density_ordinates_vector_jk==0]<-
    #  min(which(temp.spike_density_ordinates_vector_jk>0))-12
    temp.max_spike_density_ordinates_vector_jk=max(temp.spike_density_ordinates_vector_jk)
    temp.spike_density_ordinates_vector_jk<-
      (temp.spike_density_ordinates_vector_jk-min(temp.spike_density_ordinates_vector_jk))/
      (max(temp.spike_density_ordinates_vector_jk)-min(temp.spike_density_ordinates_vector_jk))
    temp.marshall_times<-temp.spike_density_abscissa_vector_jk
    temp.marshall_ordinates<-temp.spike_density_ordinates_vector_jk+2
    #for(temp.l in 1:length(temp.marshall_ordinates)){
    #  segments(x0=temp.marshall_times[temp.l],y0=1,
    #           x1=temp.marshall_times[temp.l],y1=temp.marshall_ordinates[temp.l])
    #}
    lines(temp.marshall_times,temp.marshall_ordinates,type="o",pch=".",cex=3)
    #Weiss benchmark.
    temp.benchmark_vector<-temp.spike_density_ordinates_list_j[[temp.num_rows]]
    #temp.benchmark_vector[temp.benchmark_vector>0]<-
    #  10*log10(temp.benchmark_vector[temp.benchmark_vector>0])
    #temp.benchmark_vector[temp.benchmark_vector==0]<-
    #  min(which(temp.benchmark_vector>0))-12
    temp.min_benchmark_vector=min(temp.benchmark_vector)
    temp.max_benchmark_vector=max(temp.benchmark_vector)
    temp.benchmark_vector<-
      (temp.benchmark_vector-min(temp.benchmark_vector))/(max(temp.benchmark_vector)-min(temp.benchmark_vector))
    temp.weiss_times<-temp.spike_density_abscissa_list_j[[temp.num_rows]]
    temp.weiss_ordinates<-temp.benchmark_vector
    #for(temp.l in 1:length(temp.weiss_ordinates)){
    #  segments(x0=temp.weiss_times[temp.l],y0=0,
    #           x1=temp.weiss_times[temp.l],y1=temp.weiss_ordinates[temp.l],
    #           col=4)
    #}
    lines(temp.weiss_times,temp.weiss_ordinates,type="o",pch=".",cex=3,col=4)
    axis(side=2,at=4,labels=round_general.function(temp.LFP_global_max,1))
    if(!is.nan(temp.max_spike_density_ordinates_vector_jk)){
      axis(side=2,at=3,
           labels=paste(round_general.function(temp.max_spike_density_ordinates_vector_jk,1),sep=""))
    }
    axis(side=2,at=2,
         labels=paste(round_general.function(temp.global_spike_density_maximum_j,1),sep=""))
    axis(side=2,at=1,
         labels=paste(round_general.function(temp.max_benchmark_vector,1),sep=""))
    axis(side=2,at=0,
         labels=paste(round_general.function(temp.min_benchmark_vector,1),sep=""))
    legend.function(c(temp.LFP_time_vector_j,temp.lower_quartile_times,temp.upper_quartile_times,temp.median_times,temp.marshall_times,temp.weiss_times),
                    c(temp.LFP_ordinate_vector_j,temp.lower_quartile_ordinates,temp.upper_quartile_ordinates,temp.median_ordinates,temp.marshall_ordinates,
                      temp.weiss_ordinates),
                    title.par="",
                    labels.par=c(temp.plotting_legend_strings_vector[length(temp.plotting_legend_strings_vector)-c(1,6+final_model_index.par-1)+1],
                                 "Lower/upper quartiles","Median",
                                 temp.plotting_legend_strings_vector[length(temp.plotting_legend_strings_vector)-1]),
                    lty.par=c(1,1,1,2,1),legend_plot_bool.par=TRUE,col.par=c(1,1,"grey50",2,4),lwd.par=rep(2,5))
  }
  dev.off()
}








point_process_analysis.function<-function(all_spike_time_lists.par,
                                          LFP_time_list.par,LFP_ordinate_list.par,
                                          num_test_sections.par,num_LFP_ordinate_breaks.par,num_augmented_list_elements.par,
                                          plotting_legend_strings_vector.par,
                                          all_raster_legend_strings_vector.par,
                                          diff_bool_directory_string.par="",
                                          abbreviated_time_units_string.par="",
                                          measure_quantity.par="",measure_quantity_upper_case.string="",
                                          measure_units.par="",
                                          first_time.par=0,
                                          time_units_string.par="",
                                          model_index.par=1,
                                          final_model_index.par=1){
  temp.point_process_directory_string<-"Point_Process_GLM_Modelling"
  dir.create(temp.point_process_directory_string,showWarnings=FALSE)
  temp.point_process_glm_directory_string<-paste(diff_bool_directory_string.par,"/",temp.point_process_directory_string,sep="")
  setwd(temp.point_process_glm_directory_string)
  #Smoothed histogram curves for MUA occupancy vs. firing rate.
  temp.occupancy_normalized_peak_analysis_object<-
    occupancy_normalized_peak_analysis.function(all_spike_time_lists.par=all_spike_time_lists.par,
                                                LFP_time_list.par=LFP_time_list.par,
                                                LFP_ordinate_list.par=LFP_ordinate_list.par,
                                                num_test_sections.par=num_test_sections.par,
                                                num_LFP_ordinate_breaks.par=num_LFP_ordinate_breaks.par,
                                                num_augmented_list_elements.par=num_augmented_list_elements.par,
                                                plotting_legend_strings_vector.par=plotting_legend_strings_vector.par,
                                                point_process_glm_directory_string.par=temp.point_process_glm_directory_string,
                                                abbreviated_time_units_string.par=abbreviated_time_units_string.par)
  temp.all_peak_histogram_abscissa_lists<-temp.occupancy_normalized_peak_analysis_object$out.all_peak_histogram_abscissa_lists
  temp.all_peak_histogram_ordinates_lists<-temp.occupancy_normalized_peak_analysis_object$out.all_peak_histogram_ordinates_lists
  temp.all_LFP_spike_times_lists<-temp.occupancy_normalized_peak_analysis_object$out.all_LFP_spike_times_lists
  temp.all_spike_LFP_ordinates_lists<-temp.occupancy_normalized_peak_analysis_object$out.all_spike_LFP_ordinates_lists
  #Point-process diagnostics, all models.
  temp.point_process_diagnostics_all_models_object<-
    point_process_diagnostics_all_models.function(LFP_time_list.par=LFP_time_list.par,
                                                  LFP_ordinate_list.par=LFP_ordinate_list.par,
                                                  all_peak_histogram_abscissa_lists.par=temp.all_peak_histogram_abscissa_lists,
                                                  all_peak_histogram_ordinates_lists.par=temp.all_peak_histogram_ordinates_lists,
                                                  all_LFP_spike_times_lists.par=temp.all_LFP_spike_times_lists,
                                                  all_spike_LFP_ordinates_lists.par=temp.all_spike_LFP_ordinates_lists,
                                                  all_spike_time_lists.par=all_spike_time_lists.par,
                                                  num_test_sections.par=num_test_sections.par,
                                                  num_augmented_list_elements.par=num_augmented_list_elements.par,
                                                  plotting_legend_strings_vector.par=plotting_legend_strings_vector.par,
                                                  point_process_glm_directory_string.par=temp.point_process_glm_directory_string,
                                                  first_time.par=first_time.par,
                                                  abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                                  time_units_string.par=time_units_string.par,
                                                  output_bool.par=TRUE,
                                                  plot_bool.par=TRUE)
  temp.boxplot_firing_rate_lists<-temp.point_process_diagnostics_all_models_object$out.boxplot_firing_rate_lists
  temp.boxplot_firing_rate_extrema_lists<-temp.point_process_diagnostics_all_models_object$out.boxplot_firing_rate_extrema_lists
  temp.all_spike_density_ordinates_lists<-temp.point_process_diagnostics_all_models_object$out.all_spike_density_ordinates_lists
  temp.all_spike_density_abscissa_lists<-temp.point_process_diagnostics_all_models_object$out.all_spike_density_abscissa_lists
  #Peak rates, final model.
  temp.peak_rates_final_model_object<-
    peak_rates_final_model.function(LFP_time_list.par=LFP_time_list.par,
                                    boxplot_firing_rate_extrema_lists.par=temp.boxplot_firing_rate_extrema_lists,
                                    boxplot_firing_rate_lists.par=temp.boxplot_firing_rate_lists,
                                    LFP_ordinate_list.par=LFP_ordinate_list.par,
                                    all_spike_density_abscissa_lists.par=temp.all_spike_density_abscissa_lists,
                                    all_spike_density_ordinates_lists.par=temp.all_spike_density_ordinates_lists,
                                    num_test_sections.par=num_test_sections.par,
                                    start_section_index.par=temp.start_section_index,
                                    abbreviated_time_units_string.par=abbreviated_time_units.string,
                                    measure_quantity.par=measure_quantity.par,
                                    measure_quantity_upper_case.string=measure_quantity_upper_case.string,
                                    measure_units.par=measure_units.par,
                                    first_time.par=first_time.par,time_units_string.par=time_units_string.par,
                                    model_index.par=model_index.par,final_model_index.par=final_model_index.par,
                                    all_raster_legend_strings_vector.par=all_raster_legend_strings_vector.par)
  #Peak rates, final model with model uncertainty.
  temp.peak_rates_final_model_quantiles_object<-
    peak_rates_final_model_quantiles.function(LFP_time_list.par=LFP_time_list.par,
                                              boxplot_firing_rate_extrema_lists.par=temp.boxplot_firing_rate_extrema_lists,
                                              boxplot_firing_rate_lists.par=temp.boxplot_firing_rate_lists,
                                              LFP_ordinate_list.par=LFP_ordinate_list.par,
                                              all_spike_density_abscissa_lists.par=temp.all_spike_density_abscissa_lists,
                                              all_spike_density_ordinates_lists.par=temp.all_spike_density_ordinates_lists,
                                              num_test_sections.par=num_test_sections.par,
                                              start_section_index.par=temp.start_section_index,
                                              all_raster_legend_strings_vector.par=all_raster_legend_strings_vector.par,
                                              abbreviated_time_units_string.par=abbreviated_time_units.string,
                                              measure_quantity_upper_case.string=measure_quantity_upper_case.string,
                                              measure_units.par=measure_units.par,
                                              first_time.par=first_time.par,time_units_string.par=time_units_string.par,
                                              final_model_index.par=final_model_index.par)
  setwd(diff_bool_directory_string.par)
}









MUA_spike_identification_500Hz_diff_bool.function<-function(full_series_diff_index.par,
                                                            window_times_full_series_diff_lists.par,filtered_diff_series_bool_list.par,
                                                            window_times_no_diff_lists.par,normalized_squared_filtered_series_no_diff_lists.par,
                                                            action_potential_times_window.par,
                                                            min_record_sizes.par,time_sequence.par,
                                                            num_trial_sections.par,num_breaks.par,num_test_sections.par,
                                                            num_LFP_ordinate_breaks.par,
                                                            pc_outlier_threshold_quantile.par=5,scale.par=5,
                                                            reference_paper_identifier_strings_MUA.par,
                                                            abbreviated_time_units_string.par="",
                                                            time_units_string.par="",measure_units_string.par="",
                                                            measure_quantity_string.par="",measure_quantity_upper_case.string="",
                                                            diff_bool_directory_string.par="",
                                                            display_raster_results_bool.par=FALSE,output_bool.par=FALSE,plot_bool.par=FALSE,
                                                            model_indices.par=c(1,1,1,1),
                                                            final_model_indices.par=c(1,1,1,1)){
  temp.500Hz_diff_bools_string<-c("No_500Hz_diff","500Hz_diff")
  for(temp.diff_index in 1:2){
    dir.create(temp.500Hz_diff_bools_string[temp.diff_index],showWarnings=FALSE)
    temp.500Hz_diff_bool_directory_string<-paste(diff_bool_directory_string.par,"/",temp.500Hz_diff_bools_string[temp.diff_index],sep="")
    setwd(temp.500Hz_diff_bool_directory_string)
    #Peak classification.
    temp.MUA_spike_identification_and_results_object<-
      MUA_spike_identification_and_results.function(window_times_diff_lists.par=
                                                      window_times_full_series_diff_lists.par[[temp.full_series_diff_index]],
                                                    normalized_squared_filtered_series_diff_lists.par=
                                                      filtered_diff_series_bool_list.par[[temp.full_series_diff_index]],
                                                    time_sequence_Marshall_MUA.par=temp.time_sequence_Marshall_MUA,
                                                    time_sequence_Marshall_LFP.par=temp.time_sequence_Marshall_LFP,
                                                    window_times_no_diff_lists.par=window_times_no_diff_lists.par,
                                                    normalized_squared_filtered_series_no_diff_lists.par=
                                                      normalized_squared_filtered_series_no_diff_lists.par,
                                                    action_potential_times_window.par=action_potential_times_window.par,
                                                    diff_index.par=temp.diff_index,num_trial_sections.par=num_trial_sections.par,
                                                    min_record_sizes_MUA.par=min_record_sizes.par[1],
                                                    time_sequence.par=time_sequence.par,
                                                    num_breaks.par=num_breaks.par,
                                                    num_test_sections.par=num_test_sections.par,
                                                    pc_outlier_threshold_quantile.par=pc_outlier_threshold_quantile.par,
                                                    scale.par=scale.par,
                                                    reference_paper_identifier_strings_MUA.par=reference_paper_identifier_strings_MUA.par,
                                                    MUA_classification_directory_string.par=temp.500Hz_diff_bool_directory_string,
                                                    first_time.par=time_sequence.par[1],
                                                    abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                                    time_units_string.par=time_units_string.par,measure_units_string.par=measure_units_string.par,
                                                    measure_quantity_string.par=measure_quantity_string.par,
                                                    diff_bool_directory_string.par=temp.500Hz_diff_bool_directory_string,
                                                    display_raster_results_bool.par=display_raster_results_bool.par,
                                                    output_bool.par=output_bool.par,
                                                    plot_bool.par=plot_bool.par)
    temp.LFP_times_vector<-temp.MUA_spike_identification_and_results_object$out.LFP_times_vector
    temp.LFP_series<-temp.MUA_spike_identification_and_results_object$out.LFP_series
    temp.all_spike_time_lists<-temp.MUA_spike_identification_and_results_object$out.all_spike_time_lists
    temp.LFP_time_list<-temp.MUA_spike_identification_and_results_object$out.LFP_time_list
    temp.LFP_ordinate_list<-temp.MUA_spike_identification_and_results_object$out.LFP_ordinate_list
    temp.plotting_legend_strings_vector<-temp.MUA_spike_identification_and_results_object$out.plotting_legend_strings_vector
    temp.num_augmented_list_elements=temp.MUA_spike_identification_and_results_object$out.num_augmented_list_elements
    #Full point-process analysis.
    temp.point_process_analysis_object<-
      point_process_analysis.function(all_spike_time_lists.par=temp.all_spike_time_lists,
                                      LFP_time_list.par=temp.LFP_time_list,
                                      LFP_ordinate_list.par=temp.LFP_ordinate_list,
                                      num_test_sections.par=num_test_sections.par,
                                      num_LFP_ordinate_breaks.par=num_LFP_ordinate_breaks.par,
                                      num_augmented_list_elements.par=temp.num_augmented_list_elements,
                                      plotting_legend_strings_vector.par=temp.plotting_legend_strings_vector,
                                      all_raster_legend_strings_vector.par=temp.plotting_legend_strings_vector,
                                      diff_bool_directory_string.par=temp.500Hz_diff_bool_directory_string,
                                      abbreviated_time_units_string.par=abbreviated_time_units_string.par,
                                      measure_quantity.par=measure_quantity_string.par,
                                      measure_quantity_upper_case.string=measure_quantity_upper_case.string,
                                      measure_units.par=measure_units_string.par,
                                      first_time.par=time_sequence.par[1],
                                      time_units_string.par=time_units_string.par,
                                      model_index.par=model_indices.par[(full_series_diff_index.par-1)*2+temp.diff_index],
                                      final_model_index.par=final_model_indices.par[(full_series_diff_index.par-1)*2+temp.diff_index])
    setwd(diff_bool_directory_string.par)
  }#End 500Hz-diff bool for loop.
}






