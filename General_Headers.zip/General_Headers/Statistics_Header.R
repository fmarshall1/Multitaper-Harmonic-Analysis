#Francois Marshall, Boston University
#Header file for statistics functions.
###################################################################################################################

#General math.

quadratic_formula_roots.function<-function(quadratic_coefficients.par){
  temp.roots_vector<-rep(0,2)
  temp.roots_vector[1]=
    ((-1)*quadratic_coefficients.par[2]-
       sqrt(quadratic_coefficients.par[2]^2-4*quadratic_coefficients.par[1]*quadratic_coefficients.par[3]))/
    2/quadratic_coefficients.par[1]
  temp.roots_vector[2]=
    ((-1)*quadratic_coefficients.par[2]+
       sqrt(quadratic_coefficients.par[2]^2-4*quadratic_coefficients.par[1]*quadratic_coefficients.par[3]))/
    2/quadratic_coefficients.par[1]
  return(temp.roots_vector)
}

running.sum<-function(end.par,sequence.par){
  temp.sum=0
  if(end.par==1){
    temp.sum=sequence.par[1]
  }
  else{
    temp.sum=sum(sequence.par[1:end.par])
  }
  return(temp.sum)
}

second_difference.function<-function(abscissa.par,function_values.par,measured_quantity.par="Measured quantity",measured_units.par="units",
                                     pdf_title.par="",plot.par=FALSE){
  #First differences.
  temp.num_values=length(function_values.par)
  temp.first_differences<-function_values.par[2:temp.num_values]-function_values.par[2:temp.num_values-1]
  temp.num_first_diffs=length(temp.first_differences)
  #Second differences.
  temp.second_differences<-temp.first_differences[2:temp.num_first_diffs]-temp.first_differences[2:temp.num_first_diffs-1]
  temp.truncated_abscissa<-abscissa.par[3:temp.num_values]
  temp.plotting_abscissa<-list(temp.truncated_abscissa)
  temp.plotting_second_diffs<-list(temp.second_differences)
  if(plot.par==TRUE){
    plot.graph(temp.plotting_abscissa,temp.plotting_second_diffs,x_label.par=paste(measured_quantity.par,", in ",measured_units.par,sep=""),
               y_label.par=paste("Frequency, second difference, in inverse ",measured_units.par,sep=""),
               pdf_title.par=pdf_title.par,horizontal_line.par=0)
  }
  temp.list<-list(out.truncated_abscissa=temp.truncated_abscissa,
                  out.second_differences=temp.second_differences)
  return(temp.list)
}


local_maxima_second_derivative_test.function<-function(abscissa.par,function_values.par,measured_quantity.par="Measured quantity",
                                                       measured_units.par="units",pdf_title.par="",histogram_bin_width.par=0,
                                                       zero_crossing_threshold.par=.Machine$double.eps,plot.par=FALSE){
  #Compute the second differences.
  temp.num_values=length(function_values.par)
  temp.second_difference_object<-second_difference.function(abscissa.par,function_values.par,measured_quantity.par=measured_quantity.par,
                                                            measured_units.par=measured_units.par,pdf_title.par=pdf_title.par,plot.par=plot.par)
  temp.truncated_abscissa<-temp.second_difference_object$out.truncated_abscissa
  temp.second_differences<-temp.second_difference_object$out.second_differences
  #Compute the local maxima and associated optimal abscissa.
  temp.num_function_values=length(temp.second_differences)
  temp.offset=histogram_bin_width.par/2
  temp.local_optimal_abscissa_list<-list()
  temp.adjacent_minimum_abscissa_list<-list()
  temp.list_counter=1
  temp.min_counter=1
  if(function_values.par[1]>function_values.par[2]){
    temp.local_optimal_abscissa_list[[temp.list_counter]]=abscissa.par[1]+temp.offset
    temp.list_counter=temp.list_counter+1
  }
  if(function_values.par[temp.num_values]>function_values.par[temp.num_values-1]){
    temp.local_optimal_abscissa_list[[temp.list_counter]]=abscissa.par[temp.num_values]-temp.offset
    temp.list_counter=temp.list_counter+1
  }
  for(temp.i in 2:temp.num_function_values){
    if(temp.second_differences[temp.i]<(-1)*zero_crossing_threshold.par){
      temp.local_optimal_abscissa_list[[temp.list_counter]]=temp.truncated_abscissa[temp.i]-temp.offset
      temp.list_counter=temp.list_counter+1
    }
    else if(temp.second_differences[temp.i]>zero_crossing_threshold.par){
      temp.adjacent_minimum_abscissa_list[[temp.min_counter]]=temp.truncated_abscissa[temp.i]-temp.offset
      temp.min_counter=temp.min_counter+1
    }
  }
  temp.local_optimal_abscissa<-unlist(temp.local_optimal_abscissa_list)
  temp.adjacent_minimum_abscissa<-unlist(temp.adjacent_minimum_abscissa_list)
  temp.list<-list(out.local_optimal_abscissa=temp.local_optimal_abscissa,
                  out.adjacent_minimum_abscissa=temp.adjacent_minimum_abscissa)
  return(temp.list)
}


lorenzian<-function(frequency.par,central_frequency.par,gamma.par){
  temp.numerator=0.5*gamma.par
  temp.denominator=(frequency.par-central_frequency.par)^2+(0.5*gamma.par)^2
  temp.lorentzian=1/pi*temp.numerator/temp.denominator
}

sinc_W<-function(x,W_par){
  return.output=1
  if(x){
    return.output=sin(2*pi*W_par*x)/(pi*x)
  }
  return(return.output)
}

sinc_NW<-function(x,N_par,W_par){
  return.output=1
  if(x){
    return.output=sin(pi*N_par*W_par*x)/(pi*x)
  }
  return(return.output)
}

sinc2.function<-function(x.par){
  temp.sinc_values<-sinc(x.par)^2
  return(temp.sinc_values)
}

sinc2_integrand_change_of_variables.function<-function(x){
  temp.integrand_values<-4*sinc2.function(2*x)
  return(temp.integrand_values)
}

#General sample statistics.

significance_marker.function<-function(p_value.par){
  temp.significance_marker="."
  if(p_value.par<0.05){
    temp.significance_marker="*"
  }
  else if(p_value.par<0.01){
    temp.significance_marker="**"
  }
  else if(p_value.par<0.001){
    temp.significance_marker="***"
  }
  return(temp.significance_marker)
}

sample.variance<-function(ts.par,num_pars.par=1){
  temp.N=length(ts.par)
  return((sum(ts.par^2)-sum(ts.par)^2/temp.N)/(temp.N-num_pars.par))
}

sample.median<-function(ts.par){
  temp.N=length(ts.par)
  temp.median=0
  ts.par<-sort(ts.par)
  if(!(temp.N%%2)){
    temp.median=ts.par[temp.N/2]
  }
  else{
    temp.median=ts.par[(temp.N-1)/2+1]
  }
  return(temp.median)
}


jackknife_variance_cluster_sample.function<-function(vector_list.par){
  temp.num_strata=length(vector_list.par)
  temp.all_list_elements<-unlist(vector_list.par)
  temp.num_list_elements<-length(temp.all_list_elements)
  temp.wi_vector<-c()
  temp.estimate_list<-list()
  temp.global_counter=0
  temp.local_counter=1
  for(temp.h in 1:temp.num_strata){
    temp.weighted_vector_h<-vector_list.par[[temp.h]]
    temp.num_primary_sampling_units_h=1
    temp.num_per_stratum_h=length(temp.weighted_vector_h)
    for(temp.j in 1:temp.num_per_stratum_h){
      temp.weights<-rep(0,temp.num_list_elements)
      temp.estimates_h<-temp.weights
      for(temp.i in 1:temp.num_list_elements){
        #The weights below have been specified on page 305 of Lohr (1999).  Refer to page 99 of that text for definitions of the relevant terms.
        if(temp.h==1 & temp.j==1){
          temp.wi_vector[temp.i]=temp.num_primary_sampling_units_h/temp.num_per_stratum_h
        }
        if(temp.i<temp.global_counter || temp.i>(temp.global_counter+temp.num_per_stratum_h)){
          temp.weights[temp.i]=temp.wi_vector[temp.i] #From page 227 of Lohr (1999).
        }
        else if(temp.i!=temp.local_counter){
          temp.weights[temp.i]=temp.num_per_stratum_h/(temp.num_per_stratum_h-1)
        }
      }
      #print(temp.weights)
      temp.local_counter=temp.local_counter+1
      temp.estimates_h[temp.j]=crossprod(temp.weights,temp.all_list_elements)/crossprod(temp.weights)
    }
    temp.estimate_list[[temp.h]]<-temp.estimates_h
    temp.global_counter=temp.global_counter+temp.num_per_stratum_h
  }
  temp.average=crossprod(temp.wi_vector,temp.all_list_elements)/crossprod(temp.wi_vector)
  temp.jk_variance=0
  for(temp.h in 1:temp.num_strata){
    temp.weighted_vector_h<-vector_list.par[[temp.h]]
    temp.num_per_stratum_h=length(temp.weighted_vector_h)
    temp.RSS_h=0
    temp.estimates_h<-temp.estimate_list[[temp.h]]
    for(temp.j in 1:temp.num_per_stratum_h){
      temp.estimate_jh=temp.estimates_h[temp.j]
      temp.RSS_h=temp.RSS_h+(temp.estimate_jh-temp.average)^2
    }
    temp.jk_variance=temp.jk_variance+(1-1/temp.num_per_stratum_h)*temp.RSS_h
  }
  temp.list<-list(out.average=temp.average,
                  out.jk_variance=temp.jk_variance)
  return(temp.list)
}


stratified_samples_fitting.function<-function(responses.par,covariates_matrix.par,strata_vector.par,bins.par,strata_vector2.par=NA){
  temp.num_bins=0
  if(is.matrix(bins.par)==TRUE){
    temp.num_bins=nrow(bins.par)
  }
  else{
    temp.num_bins=length(bins.par)
  }
  temp.responses_list<-list()
  temp.covariates_list<-list()
  temp.strata_list<-list()
  temp.indices<-c()
  for(temp.i in 1:temp.num_bins){
    if(is.matrix(bins.par)==TRUE){
      temp.LB=bins.par[temp.i,1]
      temp.UB=bins.par[temp.i,2]
      temp.indices<-which(strata_vector.par>=temp.LB & strata_vector.par<temp.UB)
    }
    else{
      temp.bin_value=bins.par[temp.i]
      temp.indices<-which(strata_vector.par==temp.bin_value)
    }
    temp.responses<-responses.par[temp.indices]
    temp.responses_list[[temp.i]]<-temp.responses
    if(is.matrix(covariates_matrix.par)==TRUE){
      temp.covariates<-covariates_matrix.par[temp.indices,]
    }
    else{
      temp.covariates<-covariates_matrix.par[temp.indices]
    }
    if(!is.na(strata_vector2.par)){
      temp.strata_list[[temp.i]]<-strata_vector2.par[temp.indices]
    }
    temp.covariates_list[[temp.i]]<-temp.covariates
  }
  if(is.na(strata_vector2.par)==TRUE){
    temp.list<-list(out.responses_list=temp.responses_list,
                    out.covariates_list=temp.covariates_list)
  }
  else{
    temp.list<-list(out.responses_list=temp.responses_list,
                    out.covariates_list=temp.covariates_list,
                    out.strata_list=temp.strata_list)
  }
  return(temp.list)
}

stratified_fitting_data.function<-function(responses.par,covariates_matrix.par,strata_vector_list.par,bins_list.par){
  temp.num_stratum_types=length(bins_list.par)
  temp.all_responses_list<-list()
  temp.all_covariates_list<-list()
  temp.running_responses_list<-list()
  temp.running_covariates_list<-list()
  temp.running_strata_list<-list()
  temp.running_responses_list[[1]]<-responses.par
  temp.running_covariates_list[[1]]<-covariates_matrix.par
  temp.running_strata_list[[1]]<-strata_vector_list.par[[2]]
  temp.counter=1
  for(temp.j in 1:temp.num_stratum_types){
    temp.bins<-bins_list.par[[temp.j]]
    temp.num_strata=length(temp.running_responses_list)
    temp.current_responses_list<-temp.running_responses_list
    temp.current_covariates_list<-temp.running_covariates_list
    temp.current_strata_list<-temp.running_strata_list
    temp.strata_vector<-strata_vector_list.par[[temp.j]]
    temp.running_responses_list<-list()
    temp.running_covariates_list<-list()
    temp.running_strata_list<-list()
    for(temp.i in 1:temp.num_strata){
      temp.responses<-temp.current_responses_list[[temp.i]]
      temp.covariates<-temp.current_covariates_list[[temp.i]]
      temp.strata_vector2<-temp.current_strata_list[[temp.i]]
      temp.stratified_samples_fitting_object<-
        stratified_samples_fitting.function(temp.responses,temp.covariates,temp.strata_vector,temp.bins,temp.strata_vector2)
      temp.running_responses_list[[temp.i]]<-temp.stratified_samples_fitting_object$out.responses_list
      temp.running_covariates_list[[temp.i]]<-temp.stratified_samples_fitting_object$out.covariates_list
      temp.running_strata_list[[temp.i]]<-temp.stratified_samples_fitting_object$out.strata_list
      if(temp.j<temp.num_stratum_types){
        temp.running_strata_list[[temp.i]]<-temp.stratified_samples_fitting_object$out.strata_list
      }
      else{
        temp.running_strata_list[[temp.i]]<-NA
      }
      temp.num_list_elements=length(temp.running_responses_list[[temp.i]])
      if(temp.num_list_elements>0){
        for(temp.k in 1:temp.num_list_elements){
          temp.num_list_elements2=length(temp.running_responses_list[[temp.i]][[temp.k]])
          if(temp.num_list_elements2>0){
            for(temp.l in 1:temp.num_list_elements2){
              temp.current_responses<-temp.running_responses_list[[temp.i]][[temp.k]][[temp.l]]
              temp.current_covariates<-temp.running_covariates_list[[temp.i]][[temp.k]][[temp.l]]
              if(length(temp.current_responses)>1 & length(temp.current_covariates)>1){
                temp.all_responses_list[[temp.counter]]<-temp.current_responses
                temp.all_covariates_list[[temp.counter]]<-temp.current_covariates
                temp.counter=temp.counter+1
              }
            }
          }
        }
      }
    }
  }
  temp.list<-list(out.all_responses_list=temp.all_responses_list,
                  out.all_covariates_list=temp.all_covariates_list)
  return(temp.list)
}


fit_list.function<-function(response_list.par,covariate_list.par){
  temp.num_list_elements=length(response_list.par)
  temp.fit_list<-list()
  temp.residual_list<-list()
  for(temp.i in 1:temp.num_list_elements){
    temp.responses<-response_list.par[[temp.i]]
    temp.covariates<-covariate_list.par[[temp.i]]
    temp.lm_object<-lm(temp.responses~temp.covariates)
    temp.fit_list[[temp.i]]<-temp.lm_object$fitted.values
    temp.residual_list[[temp.i]]<-temp.lm_object$residuals
  }
  temp.list<-list(out.fit_list=temp.fit_list,
                  out.residual_list=temp.residual_list)
  return(temp.list)
}


jackknife_ANOVA.function<-function(stratified_fitting_list.list,min_bound.par=NA,max_bound.par=NA,verbose_bool.par=FALSE){
  temp.jaccknife_variance_object<-jackknife_variance_cluster_sample.function(stratified_fitting_list.list)
  temp.average=temp.jaccknife_variance_object$out.average
  if(!is.na(min_bound.par)){
    temp.average=max(min_bound.par,temp.average)
  }
  if(!is.na(max_bound.par)){
    temp.average=min(max_bound.par,temp.average)
  }
  temp.variance=temp.jaccknife_variance_object$out.jk_variance
  temp.sd=sqrt(temp.variance)
  if(verbose_bool.par==TRUE){
    cat("Average = ",temp.average,", s.e. = ",temp.sd,".\n")
  }
  temp.list<-list(out.average=temp.average,
                  out.sd=temp.sd)
  return(temp.list)
}


regression_analysis_jackknife.function<-function(responses.par,covariates.par,strata_vector.par,bins_list.par,
                                                 min_bound.par=0,max_bound.par=NA,verbose_bool.par=TRUE){
  temp.stratified_fit_object<-stratified_fitting_data.function(responses.par,covariates.par,strata_vector.par,bins_list.par)
  temp.all_responses_list<-temp.stratified_fit_object$out.all_responses_list
  temp.all_covariates_list<-temp.stratified_fit_object$out.all_covariates_list
  temp.fit_list_object<-fit_list.function(temp.all_responses_list,temp.all_covariates_list)
  temp.fit_list<-temp.fit_list_object$out.fit_list
  temp.residual_list<-temp.fit_list_object$out.residual_list
  temp.jackknife_ANOVA_object<-jackknife_ANOVA.function(temp.fit_list,
                                                        min_bound.par=min_bound.par,max_bound.par=max_bound.par,verbose_bool.par=verbose_bool.par)
  temp.fit_average=temp.jackknife_ANOVA_object$out.average
  temp.fit_se=temp.jackknife_ANOVA_object$out.sd
  temp.jackknife_ANOVA_object<-jackknife_ANOVA.function(temp.residual_list,
                                                        min_bound.par=min_bound.par,max_bound.par=max_bound.par,verbose_bool.par=verbose_bool.par)
  temp.residual_average=temp.jackknife_ANOVA_object$out.average
  temp.residual_se=temp.jackknife_ANOVA_object$out.sd
  temp.list<-list(out.fit_average=temp.fit_average,
                  out.fit_se=temp.fit_se,
                  out.residual_average=temp.residual_average,
                  out.residual_se=temp.residual_se,
                  out.all_responses_list=temp.all_responses_list,
                  out.all_covariates_list=temp.all_covariates_list)
  return(temp.list)
}


regression_comparison_jackknife.function<-function(response_list.par,covariates_list.par,strata_list.par,bins_list.par,class_strings.par,
                                                   min_bounds.par=NA,max_bounds.par=NA,title.par=""){
  temp.num_list_elements=length(response_list.par)
  temp.fit_averages<-rep(0,temp.num_list_elements)
  temp.fit_se_vector<-temp.fit_averages
  temp.residual_averages<-temp.fit_averages
  temp.residual_se_vector<-temp.fit_averages
  sink(paste(title.par,"Summary_Statistics.txt",sep=""), append=FALSE, split=FALSE)
  cat("class\tfit_average\tfit_se\tresidual_average\tresidual_se\n")
  for(temp.i in 1:temp.num_list_elements){
    temp.responses<-response_list.par[[temp.i]]
    temp.covariates<-covariates_list.par[[temp.i]]
    temp.strata_list<-list()
    for(temp.j in 1:length(strata_list.par)){
      temp.current_strata_list<-strata_list.par[[temp.j]]
      temp.strata_list[[temp.j]]<-temp.current_strata_list[[temp.i]]
    }
    temp.min_bound=min_bounds.par[temp.i]
    if(!is.na(max_bounds.par)){
      temp.max_bound=max_bounds.par[temp.i]
    }
    else{
      temp.max_bound=NA
    }
    temp.regression_analysis_jackknife_object<-regression_analysis_jackknife.function(temp.responses,temp.covariates,temp.strata_list,bins_list.par,
                                                                                      min_bound.par=temp.min_bound,max_bound.par=temp.max_bound,
                                                                                      verbose_bool.par=FALSE)
    temp.fit_average=temp.regression_analysis_jackknife_object$out.fit_average
    temp.fit_averages[temp.i]=temp.fit_average
    temp.fit_se=temp.regression_analysis_jackknife_object$out.fit_se
    temp.fit_se_vector[temp.i]=temp.fit_se
    temp.residual_average=temp.regression_analysis_jackknife_object$out.residual_average
    temp.residual_averages[temp.i]=temp.residual_average
    temp.residual_se=temp.regression_analysis_jackknife_object$out.residual_se
    temp.residual_se_vector[temp.i]=temp.residual_se
    cat(class_strings.par[temp.i],"\t",temp.fit_average,"\t",temp.fit_se,"\t",temp.residual_average,"\t",temp.residual_se,"\n")
  }
  sink()
  temp.list<-list(out.fit_averages=temp.fit_averages,
                  out.fit_se_vector=temp.fit_se_vector,
                  out.residual_averages=temp.residual_averages,
                  out.residual_se_vector=temp.residual_se_vector)
  return(temp.list)
}


empirical.distribution<-function(rv.par){
  temp.ordered_rv<-sort(rv.par)
  temp.empirical_distribution<-ecdf(temp.ordered_rv)
  temp.empirical_distribution<-temp.empirical_distribution(temp.ordered_rv)
  temp.data_frame=data.frame(temp.ordered_rv,temp.empirical_distribution)
  return(temp.data_frame)
}

histogram.function<-function(realizations.par,pdf_title.par="Histogram.pdf",measured_value.par="Measured value",measured_units.par="units",num_breaks.par=NA,
                         lwd.par=1,curve_x.par=NA,curve_list.par=NA,curve_colours.par=NA,lty.par=NA,legend_labels.par=NA,legend_title.par=NA,
                         plot_title.par="",plot_bool.par=FALSE){
  if(is.na(num_breaks.par)==TRUE){
    num_breaks.par=floor(length(realizations.par)/2)
  }
  temp.min_realization=min(realizations.par)
  temp.max_realization=max(realizations.par)
  temp.h=hist(realizations.par,breaks=num_breaks.par,probability=TRUE,plot=FALSE,xlim=c(temp.min_realization,temp.max_realization))
  temp.x<-temp.h$breaks
  temp.num_binned_volumes=length(temp.x)
  temp.bin_width=temp.x[2]-temp.x[1]
  temp.plotting_heights<-c(temp.h$counts/sum(temp.h$counts)/(temp.x[2]-temp.x[1]),0)
  if(plot_bool.par==TRUE){
    temp.lower_x=min(temp.x)
    temp.upper_x=max(temp.x)
    temp.lower_y=0
    temp.upper_y=max(temp.plotting_heights)
    pdf(pdf_title.par,width=8,height=6)
    par(mgp=c(2,0.5,0))
    plot(0,0,xlab=paste(measured_value.par,", in ",measured_units.par,sep=""),
         ylab=paste("Frequency of Occurrence, in inverse ",measured_units.par,sep=""),
         main=plot_title.par,xlim=c(temp.lower_x,temp.upper_x),ylim=c(temp.lower_y,temp.upper_y),pch=".",lab=c(10,10,7))
    grid()
    minor.tick(10,10)
    lines(temp.x,temp.plotting_heights,main="",type="s")
    if(!is.na(curve_list.par)){
      temp.num_list_elements=length(curve_list.par)
      temp.colours<-rep(1,temp.num_list_elements)
      if(!is.na(curve_colours.par)){
        temp.colours<-curve_colours.par
      }
      temp.lty<-rep(1,temp.num_list_elements)
      if(!is.na(lty.par)){
        temp.lty<-lty.par
      }
      for(temp.i in 1:temp.num_list_elements){
        lines(curve_x.par,curve_list.par[[temp.i]],col=temp.colours[temp.i],lwd=lwd.par,lty=lty.par[temp.i])
      }
      if(!is.na(legend_labels.par)){
        temp.x_list<-list(temp.x)
        for(temp.i in 1:temp.num_list_elements){
          temp.x_list[[temp.i+1]]<-temp.x
        }
        legend.function(unlist(temp.x_list),c(temp.plotting_heights,unlist(curve_list.par)),title.par=legend_title.par,labels.par=legend_labels.par,
                        lty.par=temp.lty,lwd.par=rep(lwd.par,temp.num_list_elements),legend_plot_bool.par=TRUE,col.par=c(1,temp.colours))
      }
    }
    dev.off()
  }
  temp.list<-list(out.plotting_x=temp.x,
                  out.plotting_heights=temp.plotting_heights,
                  out.num_binned_volumes=temp.num_binned_volumes,
                  out.bin_width=temp.bin_width)
  return(temp.list)
}


significance_level_estimate.function<-function(test_statistic.par,
                                               false_alarm_thresholds.par,
                                               N.par){
  temp.num_false_alarm_rates=length(false_alarm_thresholds.par)
  temp.false_alarm_rates<-1:temp.num_false_alarm_rates/temp.num_false_alarm_rates
  temp.Bonferoni_level=(1-1/N.par)*100
  temp.significance_level=0
  if(test_statistic.par>min(false_alarm_thresholds.par[false_alarm_thresholds.par>0])){
    temp.index=
      max(which(false_alarm_thresholds.par<test_statistic.par))
    temp.significance_level=temp.false_alarm_rates[temp.index]*100
    if(temp.significance_level==100){
      temp.significance_level=round_general.function(temp.Bonferoni_level)
    }
  }
  return(temp.significance_level)
}


test_results.function<-function(test_statistic_list.par,false_alarm_thresholds_list.par,
                                labels.par,title.par){
  dir.create("Test_Results",showWarnings=FALSE)
  setwd("Test_Results")
  temp.num_test_statistics=length(test_statistic_list.par)
  temp.output_matrix<-matrix(0,nrow=1,ncol=2*temp.num_test_statistics)
  temp.labels<-c()
  for(temp.j in 1:temp.num_test_statistics){
    temp.test_statistic=test_statistic_list.par[[temp.j]]
    temp.false_alarm_thresholds=false_alarm_thresholds_list.par[[temp.j]]
    temp.significance_level=
      significance_level_estimate.function(test_statistic.par=temp.test_statistic,
                                           false_alarm_thresholds.par=temp.false_alarm_thresholds,
                                           N.par=N.par)
    #Test results.
    temp.output_matrix[,2*(temp.j-1)+1]<-temp.test_statistic
    temp.output_matrix[,2*temp.j]<-temp.significance_level
    temp.labels[2*(temp.j-1)+1]=labels.par[temp.j]
    temp.labels[2*temp.j]="Significance"
  }
  output.table(matrix.par=temp.output_matrix,labels.par=temp.labels,
               title.par=title.par)
  setwd("../")
}


ROC.function<-function(test_realizations_HA.par,false_alarm_probabilities.par,false_alarm_thresholds.par,num_tests.par,
                       min_y.par=0,max_y.par=100,pdf_title.par="ROC.pdf",plot_bool.par=FALSE){
  temp.num_false_alarm_probabilities=length(false_alarm_thresholds.par)
  temp.num_true_positives<-rep(0,temp.num_false_alarm_probabilities)
  for(temp.i in 1:temp.num_false_alarm_probabilities){
    temp.num_true_positives[temp.i]=length(which(test_realizations_HA.par>false_alarm_thresholds.par[temp.i]))/num_tests.par*100
  }
  if(plot_bool.par==TRUE){
    temp.x_plotting<-100*(1-false_alarm_probabilities.par)
    temp.y_plotting<-temp.num_true_positives
    temp.y_plotting<-temp.y_plotting[order(temp.x_plotting)]
    temp.x_plotting<-sort(temp.x_plotting)
    temp.x_plotting<-c(0,temp.x_plotting)
    temp.y_plotting<-c(0,temp.y_plotting)
    plot.graph(list(temp.x_plotting),list(temp.y_plotting),min_y.par=0,max_y.par=100,
               x_label.par="Probability of false detection",y_label.par="Probability of true detection",pdf_title.par=pdf_title.par)
  }
  temp.list<-list(out.num_true_positives=temp.num_true_positives)
  return(temp.list)
}


roc_output.function<-function(false_alarm_rates.par,
                              false_alarm_thresholds_list.par,true_positive_rates_list.par,
                              pdf_title_strings.par){
  dir.create("ROC_Curves",showWarnings=FALSE)
  setwd("ROC_Curves")
  temp.num_list_elements=length(false_alarm_thresholds_list.par)
  for(temp.j in 1:temp.num_list_elements){
    temp.num_false_alarm_rates=length(false_alarm_rates.par)
    temp.output_matrix<-matrix(0,nrow=temp.num_false_alarm_rates,ncol=3)
    temp.output_matrix[,1]<-false_alarm_rates.par
    temp.output_matrix[,2]<-false_alarm_thresholds_list.par[[temp.j]]
    temp.output_matrix[,3]<-true_positive_rates_list.par[[temp.j]]
    output.table(matrix.par=temp.output_matrix,labels.par=c("PF","PF_Threshold","PD"),title.par=pdf_title_strings.par[temp.j])
  }
  setwd("../")
}


tests_overview.function<-function(test_statistic_list.par,
                                  false_alarm_thresholds_list.par,true_positive_rates_list.par,
                                  pdf_title_string_significance.par,pdf_title_strings_ROC.par){
  dir.create("Test_Overview",showWarnings=FALSE)
  setwd("Test_Overview")
  temp.num_rates=length(false_alarm_thresholds_list.par[[1]])
  temp.false_alarm_rates<-1:temp.num_rates/temp.num_rates
  #Output the test results.
  test_results.function(test_statistic_list.par=test_statistic_list.par,false_alarm_thresholds_list.par=false_alarm_thresholds_list.par,
                        labels.par=c("GLRT","LMPIT"),
                        title.par=pdf_title_string_significance.par)
  #Output the ROC information.
  roc_output.function(false_alarm_rates.par=temp.false_alarm_rates,
                      false_alarm_thresholds_list.par=false_alarm_thresholds_list.par,
                      true_positive_rates_list.par=true_positive_rates_list.par,
                      pdf_title_strings.par=pdf_title_strings_ROC.par)
  setwd("../")
}


MAP_mixture.function<-function(realizations.par,p_ccd1.par,p_ccd2.par,mixture_fraction.par){
  temp.num_realizations=length(realizations.par)
  temp.indicator_sequence<-rep(0,temp.num_realizations)
  #Update the indicator-sequence using a MAP detector.
  for(temp.m in 1:temp.num_realizations){
    temp.joint_p1=(1-mixture_fraction.par)*p_ccd1.par[temp.m]
    temp.joint_p2=mixture_fraction.par*p_ccd2.par[temp.m]
    if(temp.joint_p1>temp.joint_p2 & !temp.indicator_sequence[temp.m]){
      temp.indicator_sequence[temp.m]=1
    }
  }
  return(temp.indicator_sequence)
}


mixture_interval_right_edges.function<-function(binned_values.par,distribution_modes.par,adjacent_minimum_abscissa.par){
  temp.num_binned_values=length(binned_values.par)
  temp.num_modes=length(distribution_modes.par)
  temp.interval_edges<-rep(0,temp.num_modes)
  for(temp.i in 1:temp.num_modes){
    if(distribution_modes.par[temp.i]==binned_values.par[temp.num_binned_values]){
      temp.interval_edges[temp.i]=binned_values.par[temp.num_binned_values]
    }
    else{
      temp.interval_edges[temp.i]=min(adjacent_minimum_abscissa.par[adjacent_minimum_abscissa.par>distribution_modes.par[temp.i]])
    }
  }
  return(temp.interval_edges)
}


mixture_interval_statistics.function<-function(binned_values.par,bin_heights.par,right_interval_edges.par){
  temp.num_local_maxima=length(right_interval_edges.par)
  temp.net_interval_frequencies<-rep(0,temp.num_local_maxima)
  temp.mean_estimates<-temp.net_interval_frequencies
  temp.standard_errors<-temp.net_interval_frequencies
  for(temp.i in 1:temp.num_local_maxima){
    temp.interval_heights<-c()
    temp.interval_volumes<-c()
    if(temp.i==1){
      temp.interval_heights<-bin_heights.par[binned_values.par<right_interval_edges.par[temp.i]]
      temp.interval_volumes<-binned_values.par[binned_values.par<right_interval_edges.par[temp.i]]
    }
    else if(temp.i==temp.num_local_maxima){
      temp.interval_heights<-bin_heights.par[binned_values.par>=right_interval_edges.par[temp.i-1]]
      temp.interval_volumes<-binned_values.par[binned_values.par>=right_interval_edges.par[temp.i-1]]
    }
    else{
      temp.interval_heights<-bin_heights.par[binned_values.par>=right_interval_edges.par[temp.i-1]] &
        bin_heights.par[binned_values.par<right_interval_edges.par[temp.i]]
      temp.interval_volumes<-binned_values.par[binned_values.par>=right_interval_edges.par[temp.i-1]] &
        bin_heights.par[binned_values.par<right_interval_edges.par[temp.i]]
    }
    temp.net_interval_frequencies[temp.i]=sum(temp.interval_heights)
    temp.mean_estimates[temp.i]=sum(temp.interval_volumes*temp.interval_heights)/sum(temp.interval_heights)
    temp.variance=crossprod((temp.interval_volumes-temp.mean_estimates[temp.i])^2,temp.interval_heights)/sum(temp.interval_heights)
    temp.standard_errors[temp.i]=sqrt(temp.variance)
  }
  temp.interval_proportions<-temp.net_interval_frequencies/sum(temp.net_interval_frequencies)
  temp.list<-list(out.interval_proportions=temp.interval_proportions,
                  out.mean_estimates=temp.mean_estimates,
                  out.standard_errors=temp.standard_errors)
  return(temp.list)
  
}


mixture_preliminary_analysis.function<-function(binned_data.par,binned_heights.par,histogram_bin_width.par,
                                                measured_quantity.par="Measured quantity",measured_units.par="units",
                                                pdf_title.par="",zero_crossing_threshold.par=.Machine$double.eps,plot.par=FALSE){
  temp.local_maxima_second_derivative_test_object<-
    local_maxima_second_derivative_test.function(binned_data.par,binned_heights.par,measured_quantity.par=measured_quantity.par,
                                                 measured_units.par=measured_units.par,pdf_title.par=pdf_title.par,
                                                 histogram_bin_width.par=histogram_bin_width.par,zero_crossing_threshold.par=zero_crossing_threshold.par,
                                                 plot.par=plot.par)
  temp.local_optimal_abscissa<-temp.local_maxima_second_derivative_test_object$out.local_optimal_abscissa
  temp.adjacent_minimum_abscissa<-temp.local_maxima_second_derivative_test_object$out.adjacent_minimum_abscissa
  temp.right_interval_edges<-mixture_interval_right_edges.function(binned_data.par,temp.local_optimal_abscissa,temp.adjacent_minimum_abscissa)
  temp.mixture_interval_statistics_object<-mixture_interval_statistics.function(binned_data.par,binned_heights.par,temp.right_interval_edges)
  temp.interval_proportions<-temp.mixture_interval_statistics_object$out.interval_proportions
  temp.mean_estimates<-temp.mixture_interval_statistics_object$out.mean_estimates
  temp.standard_errors<-temp.mixture_interval_statistics_object$out.standard_errors
  temp.list<-list(out.local_optimal_abscissa=temp.local_optimal_abscissa,
                  out.adjacent_minimum_abscissa=temp.adjacent_minimum_abscissa,
                  out.interval_proportions=temp.interval_proportions,
                  out.mean_estimates=temp.mean_estimates,
                  out.standard_errors=temp.standard_errors,
                  out.right_interval_edges=temp.right_interval_edges)
  return(temp.list)
}


mixture_components.function<-function(binned_data.par,parameters.par,distribution_string.par="normal"){
  temp.num_components=length(parameters.par[[1]])
  temp.p_ccd_list<-list()
  for(temp.i in 1:temp.num_components){
    if(distribution_string.par=="normal"){
      temp.p_ccd_list[[temp.i]]<-dnorm(binned_data.par,parameters.par[[1]][temp.i],parameters.par[[2]][temp.i])
    }
    else if(distribution_string.par=="chisq"){
      temp.p_ccd_list[[temp.i]]<-dchisq(binned_data.par,parameters.par[[1]][temp.i],parameters.par[[2]][temp.i])
    }
  }
  temp.list<-list(out.p_ccd_list=temp.p_ccd_list)
  return(temp.list)
}


mixture_analysis.function<-function(realizations.par,binned_data.par,bin_heights.par,num_breaks.par=10,
                                    zero_crossing_threshold.par=1e-15,distribution_string.par="normal",
                                    pdf_title.par="",measured_value.par="Measured quantity",measured_units.par="units",
                                    lwd.par=3,plot_bool.par=FALSE){
  #Determine preliminary estimates of statistics of the mixture distribution.
  temp.bin_width=binned_data.par[2]-binned_data.par[1]
  temp.mixture_preliminary_analysis_object<-mixture_preliminary_analysis.function(binned_data.par,bin_heights.par,temp.bin_width,
                                                                                  measured_quantity.par=measured_value.par,
                                                                                  measured_units.par=measured_units.par,
                                                                                  pdf_title.par=paste(measured_value.par,"_Histogram_Second_Diffs.pdf",sep=""),
                                                                                  zero_crossing_threshold.par=zero_crossing_threshold.par,plot.par=plot_bool.par)
  temp.local_optimal_abscissa<-temp.mixture_preliminary_analysis_object$out.local_optimal_abscissa
  temp.adjacent_minimum_abscissa<-temp.mixture_preliminary_analysis_object$out.adjacent_minimum_abscissa
  temp.interval_proportions<-temp.mixture_preliminary_analysis_object$out.interval_proportions
  temp.mean_estimates<-temp.mixture_preliminary_analysis_object$out.mean_estimates
  temp.standard_errors<-temp.mixture_preliminary_analysis_object$out.standard_errors
  temp.right_interval_edges<-temp.mixture_preliminary_analysis_object$out.right_interval_edges
  #Update the mixture model.
  temp.mixdat_object<-data.frame(temp.right_interval_edges,temp.interval_proportions)
  temp.mixture_parameters_object<-data.frame(temp.interval_proportions,temp.mean_estimates,temp.standard_errors)
  temp.mixture_object<-mix(temp.mixdat_object,temp.mixture_parameters_object,dist="norm")
  temp.mixture_parameters<-temp.mixture_object$parameters
  temp.mixture_component_proportions<-temp.mixture_parameters$pi
  temp.mixture_component_means<-temp.mixture_parameters$mu
  temp.mixture_component_se<-temp.mixture_parameters$sigma
  temp.normal_curves_list<-list()
  temp.mixture_components_object<-mixture_components.function(binned_data.par,parameters.par=list(temp.mixture_component_means,temp.mixture_component_se),
                                                              distribution_string.par=distribution_string.par)
  temp.p_ccd_list<-temp.mixture_components_object$out.p_ccd_list
  temp.p_ccd1_vector<-temp.p_ccd_list[[1]]
  temp.p_ccd2_vector<-temp.p_ccd_list[[2]]
  temp.normal_curves_list[[1]]<-temp.mixture_component_proportions[1]*temp.p_ccd1_vector
  temp.normal_curves_list[[2]]<-temp.mixture_component_proportions[2]*temp.p_ccd2_vector
  temp.normal_curves_list[[3]]<-temp.normal_curves_list[[1]]+temp.normal_curves_list[[2]]
  if(plot_bool.par==TRUE){
    temp.normal_mixture_histogram_object<-histogram.function(realizations.par=realizations.par,pdf_title.par=pdf_title.par,
                                                             measured_value.par=measured_value.par,measured_units.par=measured_units.par,
                                                             num_breaks.par=num_breaks.par,lwd.par=lwd.par,
                                                             curve_x.par=binned_data.par,curve_list.par=temp.normal_curves_list,lty.par=c(3,2,1),
                                                             plot_title.par=,plot_bool.par=plot_bool.par)
  }
  temp.list<-list(out.local_optimal_abscissa=temp.local_optimal_abscissa,
                  out.adjacent_minimum_abscissa=temp.adjacent_minimum_abscissa,
                  out.normal_curves_list=temp.normal_curves_list,
                  out.mixture_parameters=temp.mixture_parameters)
  return(temp.list)
}


MAP_classification.function<-function(realizations.par,mixture_component_proportions.par,mixture_component_means.par,mixture_component_sd.par,
                                      distribution_string.par="normal"){
  temp.num_realizations=length(realizations.par)
  temp.indices<-1:temp.num_realizations
  temp.indices<-temp.indices[order(realizations.par)]
  temp.sorted_volumes<-sort(realizations.par)
  temp.mixture_components_object<-mixture_components.function(realizations.par,parameters.par=list(mixture_component_means.par,mixture_component_sd.par),
                                                              distribution_string.par=distribution_string.par)
  temp.p_ccd_list<-temp.mixture_components_object$out.p_ccd_list
  temp.p_ccd1_vector<-temp.p_ccd_list[[1]]
  temp.p_ccd2_vector<-temp.p_ccd_list[[2]]
  temp.MAP_indicator_sequence<-MAP_mixture.function(temp.sorted_volumes,temp.p_ccd1_vector,temp.p_ccd2_vector,
                                                    mixture_fraction.par=mixture_component_proportions.par[1])
  temp.component1_indices<-temp.indices[temp.MAP_indicator_sequence==1]
  temp.component2_indices<-temp.indices[temp.MAP_indicator_sequence==0]
  temp.component1_values<-temp.component1_indices
  temp.component2_values<-temp.component2_indices
  temp.list<-list(out.component1_values=temp.component1_values,
                  out.component2_values=temp.component2_values)
  return(temp.list)
}


mixture_MAP_classification_analysis.function<-function(realizations.par,num_breaks.par=10,measured_value.par="Measured value",
                                                       measured_units.par="units",pdf_title.par="",
                                                       distribution_string.par="normal",zero_crossing_threshold.par=1e-15,
                                                       lwd.par=3,plot_bool.par=TRUE){
  temp.histogram_object<-histogram.function(realizations.par=realizations.par,pdf_title.par=pdf_title.par,
                                            measured_value.par=measured_value.par,measured_units.par=measured_units.par,num_breaks.par=num_breaks.par,
                                            lwd.par=lwd.par,plot_bool.par=plot_bool.par)
  temp.plotting_abscissa<-temp.histogram_object$out.plotting_x
  temp.plotting_heights<-temp.histogram_object$out.plotting_heights
  #Estimation of the mixture-distribution parameters.
  temp.mixture_analysis_object<-mixture_analysis.function(realizations.par=realizations.par,binned_data.par=temp.plotting_abscissa,
                                                          bin_heights.par=temp.plotting_heights,num_breaks.par=num_breaks.par,
                                                          zero_crossing_threshold.par=zero_crossing_threshold.par,
                                                          distribution_string.par=distribution_string.par,
                                                          pdf_title.par=paste("Mixture_",pdf_title.par,sep=""),measured_value.par=measured_value.par,
                                                          measured_units.par=measured_units.par,lwd.par=lwd.par,plot_bool.par=plot_bool.par)
  temp.mixture_parameters<-temp.mixture_analysis_object$out.mixture_parameters
  temp.mixture_component_proportions<-temp.mixture_parameters$pi
  temp.mixture_component_means<-temp.mixture_parameters$mu
  temp.mixture_component_sd<-temp.mixture_parameters$sigma
  #Determine which points are from the different component distributions.
  temp.MAP_classification_object<-MAP_classification.function(realizations.par=realizations.par,
                                                              mixture_component_proportions.par=temp.mixture_component_proportions[1],
                                                              mixture_component_means.par=temp.mixture_component_means,
                                                              mixture_component_sd.par=temp.mixture_component_sd,
                                                              distribution_string.par=distribution_string.par)
  temp.component1<-temp.MAP_classification_object$out.component1_values
  temp.component2<-temp.MAP_classification_object$out.component1_values
  temp.list<-list(out.component1=temp.component1,
                  out.component2=temp.component2,
                  out.mixture_component_proportions=temp.mixture_component_proportions,
                  out.mixture_component_means=temp.mixture_component_means,
                  out.mixture_component_sd=temp.mixture_component_sd)
  return(temp.list)
}


Kolmogorov_distribution_test.function<-function(realizations.par,parameter_vector.par,distribution_string.par="normal"){
  temp.num_realizations=length(realizations.par)
  temp.sorted_realizations<-sort(realizations.par)
  temp.empirical_percentiles<-empirical.distribution(temp.sorted_realizations)$temp.empirical_distribution
  temp.nominal_percentiles<-c()
  if(distribution_string.par=="normal"){
    temp.nominal_percentiles<-pnorm(temp.sorted_realizations,parameter_vector.par[1],parameter_vector.par[2])
  }
  else if(distribution_string.par=="chisq"){
    temp.nominal_percentiles<-pchisq(temp.sorted_realizations,parameter_vector.par[1])
  }
  else if(distribution_string.par=="exponential"){
    temp.nominal_percentiles<-pexp(temp.sorted_realizations,parameter_vector.par[1])
  }
  temp.differences_minus<-temp.empirical_percentiles[1:(temp.num_realizations-1)]-temp.nominal_percentiles[2:temp.num_realizations]
  temp.KS_D_value_minus=max(abs(temp.differences_minus))
  temp.differences_plus<-temp.empirical_percentiles[2:temp.num_realizations]-temp.nominal_percentiles[2:temp.num_realizations]
  temp.KS_D_value_plus=max(abs(temp.differences_plus))
  temp.KS_D_value=max(temp.differences_minus,temp.differences_plus)
  temp.KS_percentile=0
  if(temp.KS_D_value>0){
    temp.KS_percentile=pkolmim(temp.KS_D_value,temp.num_realizations-1)
  }
  temp.list<-list(out.KS_D_value=temp.KS_D_value,
                  out.KS_percentile=temp.KS_percentile,
                  out.nominal_percentiles=temp.nominal_percentiles,
                  out.empirical_percentiles=temp.empirical_percentiles)
  return(temp.list)
}


boxplot_sorting.function<-function(working_directory_string.par,file_strings.par,column_indices.par,class_indices.par){
  temp.num_categories=length(file_strings.par)
  temp.quantiles_matrices<-list()
  for(temp.i in 1:temp.num_categories){
    #Read in the statistics.
    temp.dataset<-read.table(paste(working_directory_string.par,"/",file_strings.par[temp.i],sep=""),header=TRUE)
    temp.class_strings<-temp.dataset[[1]]
    temp.num_classes=length(class_indices.par)
    #Initialize the statistics matrix.
    temp.quantiles_matrix<-matrix(0,nrow=temp.num_classes,ncol=5)
    temp.quantiles_matrix[,1]<-temp.dataset[[column_indices.par[1]]][class_indices.par]
    temp.quantiles_matrix[,2]<-temp.dataset[[column_indices.par[2]]][class_indices.par]
    temp.quantiles_matrix[,3]<-temp.dataset[[column_indices.par[3]]][class_indices.par]
    temp.quantiles_matrix[,4]<-temp.dataset[[column_indices.par[4]]][class_indices.par]
    temp.quantiles_matrix[,5]<-temp.dataset[[column_indices.par[5]]][class_indices.par]
    temp.quantiles_matrix[is.na(temp.quantiles_matrix)==TRUE]<-0
    temp.quantiles_matrices[[temp.i]]<-temp.quantiles_matrix
    temp.min_quantile=min(temp.quantiles_matrix)
    temp.max_quantile=max(temp.quantiles_matrix)
  }
  temp.list<-list(out.quantiles_matrices=temp.quantiles_matrices)
  return(temp.list)
}


two_dimensional_box_plot_input.function<-function(working_directory_string.par,file_strings.par,class_indices.par){
  temp.boxplot_sorting_object<-boxplot_sorting.function(working_directory_string.par=working_directory_string.par,
                                                        file_strings.par=file_strings.par,column_indices.par=2:6,
                                                        class_indices.par=class_indices.par)
  temp.x_quantiles_matrices<-temp.boxplot_sorting_object$out.quantiles_matrices
  temp.boxplot_sorting_object<-boxplot_sorting.function(working_directory_string.par=working_directory_string.par,
                                                        file_strings.par=file_strings.par,column_indices.par=7:11,
                                                        class_indices.par=class_indices.par)
  temp.y_quantiles_matrices<-temp.boxplot_sorting_object$out.quantiles_matrices
  temp.list<-list(out.x_quantiles_matrices=temp.x_quantiles_matrices,
                  out.y_quantiles_matrices=temp.y_quantiles_matrices)
  return(temp.list)
}









#GLM's

GLM_analysis_specific.function<-function(factor_variables_list.par,response_variables.par,factor_strings.par,response_distribution.par="binomial",
                                         verbose_bool.par=FALSE){
  temp.num_factors=length(factor_variables_list.par)
  temp.dataframe<-data.frame(response=response_variables.par)
  temp.data_frames_list<-list()
  temp.names<-c()
  temp.names[1]="response"
  for(temp.i in 1:temp.num_factors){
    temp.appended_dataframe<-data.frame(factor(factor_variables_list.par[[temp.i]]))
    temp.names[temp.i+1]<-factor_strings.par[temp.i]
    names(temp.appended_dataframe)<-factor_strings.par[temp.i]
    temp.running_data_frame<-c()
    if(temp.i==1){
      temp.running_data_frame<-temp.dataframe
    }
    else{
      temp.running_data_frame<-temp.data_frames_list[[temp.i-1]]
    }
    temp.data_frames_list[[temp.i]]<-cbind(temp.running_data_frame,temp.appended_dataframe)
  }
  #https://stackoverflow.com/questions/4227223/convert-a-list-to-a-data-frame
  temp.new_dataframe<-data.frame(matrix(unlist(temp.data_frames_list[[temp.num_factors]]),ncol=length(temp.data_frames_list[[temp.num_factors]]),byrow=F))
  names(temp.new_dataframe)<-temp.names
  #temp.new_dataframe<-temp.data_frames_list[[temp.num_factors]]
  temp.model<-c()
  if(response_distribution.par=="binomial"){
    #https://stackoverflow.com/questions/11633403/how-to-automatically-include-all-2-way-interactions-in-a-glm-model-in-r
    temp.model<-glm(response~.*.,family=binomial,data=temp.new_dataframe)
  }
  else if(response_distribution.par=="poisson"){
    temp.model<-glm(response~.*.,family=poisson,data=temp.new_dataframe)
  }
  if(verbose_bool.par==TRUE){
    print(summary(temp.model))
  }
  temp.deviance=temp.model$deviance
  temp.dof=temp.model$df.residual
  temp.summary_object<-summary(temp.model)
  #https://stackoverflow.com/questions/23838937/extract-pvalue-from-glm
  temp.p_values<-as.numeric(coef(temp.summary_object)[,'Pr(>|z|)'])
  #https://www.r-project.org/nosvn/pandoc/broom.html
  temp.factor_strings<-tidy(temp.model)$term
  #print(temp.p_values)
  temp.deviance_residuals<-residuals.glm(temp.model,"deviance")
  temp.list<-list(out.deviance=temp.deviance,
                  out.dof=temp.dof,
                  out.p_values=temp.p_values,
                  out.deviance_residuals=temp.deviance_residuals,
                  out.factor_strings=temp.factor_strings)
  return(temp.list)
}


GLM_analysis.function<-function(factor_variables_list.par,response_variables.par,factor_strings.par,response_string.par,response_distribution.par="binomial",
                                verbose_bool.par=FALSE){
  temp.num_factors=length(factor_variables_list.par)
  #Saturated model.
  temp.GLM_object<-GLM_analysis_specific.function(factor_variables_list.par=factor_variables_list.par,response_variables.par=response_variables.par,
                                                  factor_strings.par,response_distribution.par=response_distribution.par,verbose_bool.par=FALSE)
  temp.saturated_deviance=temp.GLM_object$out.deviance
  temp.saturated_dof=temp.GLM_object$out.dof
  temp.p_values<-temp.GLM_object$out.p_values
  temp.significant_p_value_indices<-which(temp.p_values<0.1)
  temp.num_significant=length(temp.significant_p_value_indices)
  temp.variable_strings<-temp.GLM_object$out.factor_strings
  cat("model\tdf\tdeviance\tdeviance_percentile\tkolmogorov_percentile\ttpt_percentile\tPr(>|z|)\n")
  if(temp.num_significant>0){
    temp.significant_p_values<-temp.p_values[temp.significant_p_value_indices]
    temp.deviance_residuals<-temp.GLM_object$out.deviance_residuals
    temp.kolmogorov_object<-Kolmogorov_distribution_test.function(temp.deviance_residuals,c(0,1),distribution_string.par="normal")
    temp.KS_percentile=temp.kolmogorov_object$out.KS_percentile
    temp.deviance_residuals_kolmogorov_list=(1-temp.KS_percentile)*100
    temp.tpt_percentile<-(1-turning_point.test(temp.deviance_residuals))*100
    cat("Saturated\t",temp.saturated_dof,"\t",temp.saturated_deviance,"\tNA\t",temp.deviance_residuals_kolmogorov_list,"\t",temp.tpt_percentile,"\t")
    temp.significant_factor_strings<-temp.variable_strings[temp.significant_p_value_indices]
    for(temp.k in 1:temp.num_significant){
      temp.significant_p=temp.significant_p_values[temp.k]
      temp.significance_marker=significance_marker.function(temp.significant_p)
      if(temp.k<temp.num_significant){
        cat(paste(temp.significant_factor_strings[temp.k],temp.significance_marker,", ",sep=""))
      }
      else{
        cat(paste(temp.significant_factor_strings[temp.k],temp.significance_marker,sep=""))
      }
    }
    cat("\n")
  }
  #
  temp.factor_list<-c()
  temp.factor_strings_vector<-c()
  temp.model_strings_list<-list()
  temp.p_values_list<-list()
  temp.deviance_percentile_list<-list()
  temp.deviance_residuals_kolmogorov_list<-list()
  temp.counter=1
  for(temp.i in 1:temp.num_factors){
    for(temp.j in temp.i:temp.num_factors){
      if(temp.j==temp.i){
        temp.factor_list<-list(factor_variables_list.par[[temp.i]])
        temp.factor_strings_vector<-factor_strings.par[temp.i]
      }
      else if(temp.j>temp.i){
        temp.factor_list<-list(factor_variables_list.par[[temp.i]],factor_variables_list.par[[temp.j]])
        temp.factor_strings_vector<-c(factor_strings.par[temp.i],factor_strings.par[temp.j])
      }
      temp.GLM_object<-GLM_analysis_specific.function(factor_variables_list.par=temp.factor_list,response_variables.par=response_variables.par,
                                             temp.factor_strings_vector,response_distribution.par=response_distribution.par,verbose_bool.par=FALSE)
      temp.p_values<-temp.GLM_object$out.p_values
      temp.significant_p_value_indices<-which(temp.p_values<0.1)
      temp.num_significant=length(temp.significant_p_value_indices)
      temp.variable_strings<-temp.GLM_object$out.factor_strings
      if(temp.num_significant>0){
        if(temp.j==temp.i){
          temp.model_strings_list[[temp.counter]]<-paste(factor_strings.par[temp.i],sep="")
        }
        else{
          temp.model_strings_list[[temp.counter]]<-paste(factor_strings.par[temp.i],"+",factor_strings.par[temp.j],sep="")
        }
        temp.significant_p_values<-temp.p_values[temp.significant_p_value_indices]
        temp.p_values_list[[temp.counter]]<-temp.significant_p_values
        temp.dof=temp.GLM_object$out.dof
        temp.dof_difference=temp.dof-temp.saturated_dof
        temp.deviance=temp.GLM_object$out.deviance
        temp.deviance_difference=temp.deviance-temp.saturated_deviance
        temp.deviance_percentile_list[[temp.counter]]=(1-pchisq(temp.deviance_difference,temp.dof_difference))*100
        temp.deviance_residuals<-temp.GLM_object$out.deviance_residuals
        temp.kolmogorov_object<-Kolmogorov_distribution_test.function(temp.deviance_residuals,c(0,1),distribution_string.par="normal")
        temp.KS_percentile=temp.kolmogorov_object$out.KS_percentile
        temp.deviance_residuals_kolmogorov_list[[temp.counter]]=(1-temp.KS_percentile)*100
        temp.tpt_percentile<-(1-turning_point.test(temp.deviance_residuals))*100
        cat(temp.model_strings_list[[temp.counter]],"\t",temp.dof,"\t",temp.deviance,"\t",temp.deviance_percentile_list[[temp.counter]],"\t",
            temp.deviance_residuals_kolmogorov_list[[temp.counter]],"\t",temp.tpt_percentile,"\t")
        temp.significant_factor_strings<-temp.variable_strings[temp.significant_p_value_indices]
        for(temp.k in 1:temp.num_significant){
          temp.significant_p=temp.significant_p_values[temp.k]
          temp.significance_marker=significance_marker.function(temp.significant_p)
          if(temp.k<temp.num_significant){
            cat(paste(temp.significant_factor_strings[temp.k],temp.significance_marker,", ",sep=""))
          }
          else{
            cat(paste(temp.significant_factor_strings[temp.k],temp.significance_marker,sep=""))
          }
        }
        cat("\n")
        temp.counter=temp.counter+1
      }
    }
  }
  
}









###################################################################################################################
#Diagnostic tests.

turning_point.test<-function(ts_par,p_par=0,alpha.par=0.05,verbose.par=FALSE){
  if(!p_par){
    p_par=1-alpha.par
  }
  #Find the turning points.
  temp_N=length(ts_par)
  n_tp=0
  if(temp_N>2){
    for(i in 2:(temp_N-1)){
      if((ts_par[i]>ts_par[i-1]) && (ts_par[i]>ts_par[i+1])){
        n_tp=n_tp+1
      }
      else if((ts_par[i]<ts_par[i-1]) && (ts_par[i]<ts_par[i+1])){
        n_tp=n_tp+1
      }
    }
  }
  E_T=2*(temp_N-2)/3
  Var_T=(16*temp_N-29)/90
  standardized.n_tp=abs(n_tp-E_T)/sqrt(Var_T)
  norm.quantile=qnorm(p_par)
  if(verbose.par==TRUE){
    cat("Turning-point test:\n\n")
    cat("\tE_T = ",E_T,", Var_T = ",Var_T,"\n")
    cat("\tStandardized number of turning points = ",standardized.n_tp,"\n")
    cat("\tp value = ",p_par,": standard-normal quantile = ",norm.quantile,"\n")
    if(standardized.n_tp>norm.quantile){
      cat("\tReject the null hypothesis of a random sample.\n\n\n")
    } else{
      cat("Cannot reject the null hypothesis of a random sample.\n\n\n")
    }
  }
  temp.standardized_n_tp_percentile=pnorm(standardized.n_tp)
  return(temp.standardized_n_tp_percentile)
}


residual_analysis.function<-function(fitted_values.par,residuals.par,TPT_threshold.par=0){
  if(!TPT_threshold.par){
    TPT_threshold.par=1-alpha.par
  }
  temp.training_size=length(residuals.par)
  #Compute the R-squared statistic.
  temp.RSS1=var(residuals.par)
  temp.RSS2=var(fitted_values.par)
  temp.Rsq=1-temp.RSS1/temp.RSS2
  #Compute the turning-point test percentile.
  temp.TPT_value=turning_point.test(residuals.par,p_par=TPT_threshold.par)
  temp.TPT_percentile=pnorm(temp.TPT_value)
  #Test for whether the residuals are consistent with realized independent samples from a standard normal law.
  temp.ts<-fitted_values.par+residuals.par
  temp.data_matrix<-matrix(0,nrow=temp.training_size,ncol=2)
  for(temp.l in 1:2){
    temp.data_matrix[,temp.l]<-temp.ts^(temp.l-1)
  }
  temp.invertible_matrix<-t(temp.data_matrix)%*%temp.data_matrix
  temp.KS_percentile=0
  if(rcond(temp.invertible_matrix)>1e-15 & length(residuals.par)>0){
    tryCatch({
      temp.P_matrix<-temp.data_matrix%*%solve(temp.invertible_matrix)%*%t(temp.data_matrix)
      temp.standardized_residuals<-residuals.par/sqrt(sample.variance(residuals.par,num_pars.par=2))/sqrt(1-diag(temp.P_matrix))
      temp.edf_object<-empirical.distribution(temp.standardized_residuals)
      temp.empirical_distribution<-temp.edf_object$temp.empirical_distribution
      temp.distribution<-pnorm(temp.standardized_residuals)
      temp.D_value_minus=max(temp.distribution[2:temp.training_size]-temp.empirical_distribution[1:(temp.training_size-1)])
      temp.D_value_plus=max(temp.empirical_distribution[2:temp.training_size]-temp.distribution[2:temp.training_size])
      temp.D_value=max(temp.D_value_minus,temp.D_value_plus)
      temp.KS_percentile=pkolmim(temp.D_value,temp.training_size-1)*100
    },error=function(e)"Error: Negative definite.\n")#end tryCatch
  }
  if(is.nan(temp.Rsq)==TRUE){
    temp.Rsq=0
  }
  temp.list<-list(out.Rsq=temp.Rsq,
                  out.TPT_percentile=temp.TPT_percentile,
                  out.KS_percentile=temp.KS_percentile)
  return(temp.list)
}


remove_outliers.function<-function(ts.par,indices.par,outlier_percentile.par=0.99){
  temp.N=length(ts.par)
  temp.ndiffs=ndiffs(ts.par)
  temp.diff_indices<-temp.ndiffs:length(indices.par)
  temp.differenced_series<-ts.par
  if(temp.ndiffs>0){
    temp.differenced_series<-diff(ts.par,temp.ndiffs)
  }
  temp.average=mean(temp.differenced_series)
  temp.var=var(temp.differenced_series)
  temp.diffs<-abs(temp.differenced_series-temp.average)/sqrt(temp.var)
  temp.outlier_indices<-temp.ndiffs+
    temp.diff_indices[temp.diffs>qt(outlier_percentile.par+(1-outlier_percentile.par)/2,length(temp.differenced_series))]-1
  temp.num_outliers=length(temp.outlier_indices)
  temp.outlier_indices<-temp.outlier_indices[temp.outlier_indices>1 & temp.outlier_indices<temp.N]
  ts.par[temp.outlier_indices]<-(ts.par[temp.outlier_indices+1]+ts.par[temp.outlier_indices-1])/2
  temp.list<-list(out.ts=ts.par,
                  out.ndiffs=temp.ndiffs,
                  out.num_outliers=temp.num_outliers)
  return(temp.list)
}







###################################################################################################################
#Quantile statistics.

min_median_max.function<-function(matrix.par){
  temp.num_rows=nrow(matrix.par)
  temp.matrix<-matrix(0,nrow=temp.num_rows,ncol=3)
  for(temp.j in 1:temp.num_rows){
    temp.matrix[temp.j,1]=min(matrix.par[temp.j,])
    temp.matrix[temp.j,2]=median(matrix.par[temp.j,])
    temp.matrix[temp.j,3]=max(matrix.par[temp.j,])
  }
  return(temp.matrix)
}


quantile.variance<-function(J_eff.par,dof.par,empirical_percentile.par,mixture_percentile.par,mixture_quantile.par){
  temp.p=empirical_percentile.par
  temp.q=1-empirical_percentile.par
  temp.variance=(dof.par/mixture_quantile.par/mixture_percentile.par)^2*temp.p*temp.q/J_eff.par
  return(temp.variance)
}


two_dimensional_PCA.function<-function(abscissa_percentiles.par,ordinate_percentiles.par,num_samples.par=NA,num_components.par=NA){
  temp.num_samples=length(abscissa_percentiles.par)
  if(!is.na(num_samples.par) & num_samples.par<temp.num_samples){
    temp.step_size=floor(temp.num_samples/num_samples.par)
    temp.index_sequence<-seq(from=1,to=temp.num_samples,by=temp.step_size)
    abscissa_percentiles.par<-abscissa_percentiles.par[temp.index_sequence]
    ordinate_percentiles.par<-ordinate_percentiles.par[temp.index_sequence]
  }
  temp.data_matrix<-matrix(0,nrow=temp.num_samples,ncol=2)
  temp.mean_abscissum=mean(abscissa_percentiles.par)
  temp.mean_ordinate=mean(ordinate_percentiles.par)
  temp.data_matrix[,1]<-abscissa_percentiles.par-temp.mean_abscissum
  temp.data_matrix[,2]<-ordinate_percentiles.par-temp.mean_ordinate
  temp.svd_object<-svd(temp.data_matrix)
  temp.pc_directions<-temp.svd_object$v
  temp.pc_se_vector<-temp.svd_object$d/sqrt(temp.num_samples)
  if(!is.na(num_components.par)){
    temp.num_components=min(num_components.par,ncol(temp.pc_directions))
    temp.pc_directions<-temp.pc_directions[,1:temp.num_components]
    temp.pc_se_vector<-temp.pc_se_vector[1:temp.num_components]
  }
  temp.list<-list(out.pc_directions=temp.pc_directions,
                  out.pc_se_vector=temp.pc_se_vector,
                  out.mean_abscissum=temp.mean_abscissum,
                  out.mean_ordinate=temp.mean_ordinate)
  return(temp.list)
}


percentile_comparison.function<-function(abscissa_percentiles.par,ordinate_percentiles.par,
                                         abscissa_quantity.par="",ordinates_quantity.par="",heights_quantity.par="",pdf_title.par="",
                                         percentiles.par=c(0,25,50,75,100),PCA_num_samples.par=100,num_PC_directions.par=3,
                                         verbose_bool.par=FALSE){
  #PCA.
  temp.num_samples=length(abscissa_percentiles.par)
  temp.two_dimensional_PCA_object<-two_dimensional_PCA.function(abscissa_percentiles.par,ordinate_percentiles.par,num_samples.par=PCA_num_samples.par,
                                                                num_components.par=num_PC_directions.par)
  temp.mean_abscissum=temp.two_dimensional_PCA_object$out.mean_abscissum
  temp.mean_ordinate=temp.two_dimensional_PCA_object$out.mean_ordinate
  temp.pc_directions<-temp.two_dimensional_PCA_object$out.pc_directions
  temp.pc_se_vector<-temp.two_dimensional_PCA_object$out.pc_se_vector
  temp.num_PCA_directions=min(num_PC_directions.par,ncol(temp.pc_directions))
  temp.angular_differences<-rep(0,temp.num_PCA_directions)
  for(temp.i in 1:temp.num_PCA_directions){
    temp.angular_differences[temp.i]<-45-atan2(temp.pc_directions[2,temp.i],temp.pc_directions[1,temp.i])*180/pi
  }
  #Summary plot.
  temp.percentiles<-percentiles.par/100
  temp.num_percentiles=length(temp.percentiles)
  temp.num_bins=temp.num_percentiles-1
  temp.plotting_percentiles<-(temp.percentiles[1:temp.num_bins]+temp.percentiles[1:temp.num_bins+1])/2*100
  temp.matrix<-matrix(0,nrow=temp.num_bins,ncol=temp.num_bins)
  for(temp.i in 1:temp.num_bins){
    temp.percentiles1<-c(temp.percentiles[temp.i],temp.percentiles[temp.i+1])
    temp.abscissa_indices<-which(abscissa_percentiles.par>=temp.percentiles1[1] & abscissa_percentiles.par<=temp.percentiles1[2])
    for(temp.j in 1:temp.num_bins){
      temp.percentiles2<-c(temp.percentiles[temp.j],temp.percentiles[temp.j+1])
      temp.ordinate_indices<-which(ordinate_percentiles.par>=temp.percentiles2[1] & ordinate_percentiles.par<=temp.percentiles2[2])
      temp.bin_frequency=length(intersect(temp.abscissa_indices,temp.ordinate_indices))/temp.num_percentiles*100
      temp.matrix[temp.i,temp.j]=temp.bin_frequency
    }
  }
  heat_map.function(x.par=temp.plotting_percentiles,y.par=temp.plotting_percentiles,matrix.par=temp.matrix,
                    abscissa_quantity.par=abscissa_quantity.par,abscissa_units.par="percentage points",
                    ordinates_quantity.par=ordinates_quantity.par,ordinates_units.par="percentage points",
                    heights_quantity.par=heights_quantity.par,heights_units.par="percentage points",
                    pdf_title.par=pdf_title.par,smooth_image.par=FALSE,theta.par=0,log_bool.par=FALSE)
  if(verbose_bool.par==TRUE){
    sink("PCA_General_Statistics.txt", append=FALSE, split=FALSE)
    cat("mean_abscissum\tmean_ordinate\n")
    cat(temp.mean_abscissum,"\t",temp.mean_ordinate,"\n")
    sink()
    sink("PCA_Dispersion_Statistics.txt", append=FALSE, split=FALSE)
    cat("se_value\tangular_difference\n")
    for(temp.i in 1:temp.num_PCA_directions){
      cat(temp.pc_se_vector[temp.i],"\t",temp.angular_differences[temp.i],"\n")
    }
    sink()
  }
  temp.list<-list(out.plotting_percentiles=temp.plotting_percentiles,
                  out.matrix=temp.matrix,
                  out.angular_differences=temp.angular_differences,
                  out.pc_se_vector=temp.pc_se_vector)
  return(temp.list)
}







#Probability distribution denstities.


wishart_pdf.function<-function(covariance_matrix.par,trial_covariance_matrix.par,num_observations.par){
  #Compute the sample covariance matrix based on all of the samples.
  temp.dimension=nrow(covariance_matrix.par)/2
  #Compute the test statistic.
  temp.pdf_value=0
  try({
    temp.determinant=determinant_partitioned_matrix.function(trial_covariance_matrix.par)
    temp.numerator_factor1=temp.determinant*((num_observations.par-1)/2-temp.dimension)
    temp.numerator_factor2=(-1)*matrix.trace(inverse_square_partitioned_matrix.function(covariance_matrix.par)%*%trial_covariance_matrix.par)/2
    temp.numerator=temp.numerator_factor1+temp.numerator_factor2
    temp.denominator_factor1=log(2)*(num_observations.par*temp.dimension)
    temp.denominator_factor2=log(pi)*(temp.dimension*(2*temp.dimension-1)/2)+sum(log(gamma((num_observations.par-1:(2*temp.dimension)+1)/2)))
    temp.denominator_factor3=determinant_partitioned_matrix.function(covariance_matrix.par)*(num_observations.par/2)
    temp.denominator=temp.denominator_factor1+temp.denominator_factor2+temp.denominator_factor3
    temp.pdf_value=temp.numerator-temp.denominator
  }, silent=TRUE)
  return(temp.pdf_value)
}





pca_processing.function<-function(MUA_window_times_vector.par,MUA_window_ordinates_500_vector.par,
                                  units_string.par="",
                                  plot_bool.par=FALSE){
  temp.N_MUA=length(MUA_window_times_vector.par)
  temp.pca_argument_matrix<-matrix(0,nrow=temp.N_MUA,ncol=2)
  temp.time_mean_signal<-mean(MUA_window_times_vector.par)
  temp.time_sd_signal<-sqrt(var(MUA_window_times_vector.par))
  temp.pca_argument_matrix[,1]<-(MUA_window_times_vector.par-temp.time_mean_signal)/temp.time_sd_signal
  temp.ordinate_mean_signal_500<-mean(MUA_window_ordinates_500_vector.par)
  temp.ordinate_sd_signal_500<-sqrt(var(MUA_window_ordinates_500_vector.par))
  temp.pca_argument_matrix[,2]<-
    (MUA_window_ordinates_500_vector.par-temp.ordinate_mean_signal_500)/temp.ordinate_sd_signal_500
  temp.pca_object<-prcomp(temp.pca_argument_matrix,scale=TRUE)
  temp.pc_sdev<-temp.pca_object$sdev
  temp.pc_sdev_percentages_vector<-temp.pc_sdev^2/sum(temp.pc_sdev^2)*100
  temp.pc_matrix<-temp.pca_object$x
  temp.pc_unit_vectors<-temp.pca_object$rotation
  temp.PC1<-plotting.sampled_vector(temp.pc_matrix[,1])
  temp.PC2<-plotting.sampled_vector(temp.pc_matrix[,2])
  temp.N_decimated_j=length(temp.PC1)
  temp.PC1_scale=max(temp.PC1)-min(temp.PC1)
  temp.PC2_scale=max(temp.PC2)-min(temp.PC2)
  temp.PC_scale=max(temp.PC1_scale,temp.PC2_scale)
  temp.N_original=nrow(temp.pc_matrix)
  temp.pc1_original<-temp.pc_matrix[,1]
  temp.pc2_original<-temp.pc_matrix[,2]
  if(plot_bool.par==TRUE){
    temp.units_string<-""
    if(!strcmp(units_string.par,"")){
      temp.units_string<-paste(", in ",units_string.par,sep="")
    }
    plot.graph(x_list.par=list(temp.PC1,
                               c(0,temp.pc_unit_vectors[1,1]*temp.PC_scale),
                               c(0,temp.pc_unit_vectors[1,2]*temp.PC_scale)),
               y_list.par=list(temp.PC2,
                               c(0,temp.pc_unit_vectors[2,1]*temp.PC_scale),
                               c(0,temp.pc_unit_vectors[2,2]*temp.PC_scale)),
               type.par=c("p","l","l"),pch.par=".",cex.par=3,col.par=c(1,2,2),
               x_label.par=paste("First principal component",temp.units_string," (",round_general.function(temp.pc_sdev_percentages_vector[1]),"%)",sep=""),
               y_label.par=paste("Second principal component",temp.units_string," (",round_general.function(temp.pc_sdev_percentages_vector[2]),"%)",sep=""),
               pdf_title.par="PCA_Plot.pdf")
  }
  temp.list<-list(out.pc_unit_vectors=temp.pc_unit_vectors,
                  out.PC1=temp.PC1,
                  out.PC2=temp.PC2,
                  out.N_decimated_j=temp.N_decimated_j,
                  out.pc1_original=temp.pc1_original,
                  out.pc2_original=temp.pc2_original,
                  out.N_original=temp.N_original)
  return(temp.list)
}



pca_pilot_classification.function<-function(pc_unit_vectors.par,
                                            PC1.par,PC2.par,
                                            pc_outlier_threshold_quantile.par=5,
                                            units_string.par="",
                                            plot_bool.par=FALSE){
  #Rotate the scatter points so that the PC1-axis lies on the horizontal.
  temp.theta<-atan2(pc_unit_vectors.par[2,1],pc_unit_vectors.par[1,1])
  temp.rotation_matrix<-matrix(0,nrow=2,ncol=2)
  temp.rotation_matrix[1,]<-c(cos(temp.theta),-sin(temp.theta))
  temp.rotation_matrix[2,]<-c(sin(temp.theta),cos(temp.theta))
  temp.N_decimated=length(PC1.par)
  temp.rotated_pc_matrix<-matrix(0,nrow=temp.N_decimated,ncol=2)
  for(temp.k in 1:temp.N_decimated){
    temp.rotated_pc_matrix[temp.k,]<-temp.rotation_matrix%*%c(PC1.par[temp.k],PC2.par[temp.k])
  }
  #Outliers identified using the Weiss et al. (2013) assumption of the PC2 vs. PC1 scatter being one realization of an IID standard-normal process.
  temp.500Hz_omitted_pc_mean<-mean(temp.rotated_pc_matrix[,2])
  temp.500Hz_omitted_pc_sigma<-sqrt(var(temp.rotated_pc_matrix[,2]))
  temp.500Hz_omitted_pc_standardized_vector<-(temp.rotated_pc_matrix[,2]-temp.500Hz_omitted_pc_mean)/temp.500Hz_omitted_pc_sigma
  temp.population1_indices<-which(temp.500Hz_omitted_pc_standardized_vector<=pc_outlier_threshold_quantile.par)
  temp.population2_indices<-which(temp.500Hz_omitted_pc_standardized_vector>pc_outlier_threshold_quantile.par)
  #Initialize the scatter plot for each of the two identified populations.
  temp.500Hz_omitted_pc_population_abscissa_list<-list()
  temp.500Hz_omitted_pc_population_abscissa_list[[1]]<-temp.rotated_pc_matrix[temp.population1_indices,1]
  temp.500Hz_omitted_pc_population_abscissa_list[[2]]<-temp.rotated_pc_matrix[temp.population2_indices,1]
  temp.500Hz_omitted_pc_population_ordinates_list<-list()
  temp.500Hz_omitted_pc_population_ordinates_list[[1]]<-temp.500Hz_omitted_pc_standardized_vector[temp.population1_indices]
  temp.500Hz_omitted_pc_population_ordinates_list[[2]]<-temp.500Hz_omitted_pc_standardized_vector[temp.population2_indices]
  temp.N_population1_times=length(temp.500Hz_omitted_pc_population_abscissa_list[[1]])
  temp.N_population2_times=length(temp.500Hz_omitted_pc_population_abscissa_list[[2]])
  temp.pc_pilot_class_vector<-c(rep(1,temp.N_population1_times),rep(2,temp.N_population2_times))
  temp.500Hz_omitted_all_pc_population_times<-unlist(temp.500Hz_omitted_pc_population_abscissa_list)
  temp.500Hz_omitted_all_pc_population_ordinates<-unlist(temp.500Hz_omitted_pc_population_ordinates_list)
  if(plot_bool.par==TRUE){
    temp.units_string<-""
    if(!strcmp(units_string.par,"")){
      temp.units_string<-paste(", in ",units_string.par,sep="")
    }
    plot.graph(x_list.par=temp.500Hz_omitted_pc_population_abscissa_list,y_list.par=temp.500Hz_omitted_pc_population_ordinates_list,
               x_label.par=paste("First principal component axis",temp.units_string,sep=""),
               y_label.par=paste("Second principal component axis",temp.units_string,sep=""),
               type.par=c(rep("p",2),"l"),pch.par=c(rep(".",2),NA),cex.par=c(rep(3,2),NA),col.par=c(1,2,"grey75"),
               pdf_title.par="Pilot_Classification.pdf")
  }
  temp.list<-list(out.pc_pilot_class_vector=temp.pc_pilot_class_vector,
                  out.500Hz_omitted_all_pc_population_times=temp.500Hz_omitted_all_pc_population_times,
                  out.500Hz_omitted_all_pc_population_ordinates=temp.500Hz_omitted_all_pc_population_ordinates,
                  out.rotation_matrix=temp.rotation_matrix,
                  out.500Hz_omitted_pc_mean=temp.500Hz_omitted_pc_mean,
                  out.500Hz_omitted_pc_sigma=temp.500Hz_omitted_pc_sigma)
  return(temp.list)
}


pca_pilot_test_classification.function<-function(pc1_original.par,pc2_original.par,
                                                 rotation_matrix.par,pc_mean.par,pc_sigma.par,
                                                 pc_outlier_threshold_quantile.par=5,
                                                 units_string.par="",
                                                 plot_bool.par=FALSE){
  temp.N_original=length(pc1_original.par)
  #Transform the test data to be compatable with the training data used to obtain the linear pilot classification boundary.
  #Rotate the coordinates accordingly.
  temp.rotated_pc_matrix_original_sampling_j<-matrix(0,nrow=temp.N_original,ncol=2)
  for(temp.k in 1:temp.N_original){
    temp.rotated_pc_matrix_original_sampling_j[temp.k,]<-
      rotation_matrix.par%*%c(pc1_original.par[temp.k],pc2_original.par[temp.k])
  }
  #Normalize the coordinates accordingly.
  temp.pc1_original_sampling<-temp.rotated_pc_matrix_original_sampling_j[,1]
  temp.pc2_original_sampling<-(temp.rotated_pc_matrix_original_sampling_j[,2]-pc_mean.par)/pc_sigma.par
  temp.pc_population1_indices_original_sampling<-which(temp.pc2_original_sampling<=pc_outlier_threshold_quantile.par)
  temp.pc_population2_indices_original_sampling<-which(temp.pc2_original_sampling>pc_outlier_threshold_quantile.par)
  temp.pc1_populations_original_sampling<-c(temp.pc1_original_sampling[temp.pc_population1_indices_original_sampling],
                                            temp.pc1_original_sampling[temp.pc_population2_indices_original_sampling])
  temp.pc2_populations_original_sampling<-c(temp.pc2_original_sampling[temp.pc_population1_indices_original_sampling],
                                            temp.pc2_original_sampling[temp.pc_population2_indices_original_sampling])
  temp.N_test_population1_times=length(temp.pc_population1_indices_original_sampling)
  temp.N_test_population2_times=length(temp.pc_population2_indices_original_sampling)
  temp.N_total_test_population_times=temp.N_test_population1_times+temp.N_test_population2_times
  temp.pc_test_class_vector<-c(rep(1,temp.N_test_population1_times),rep(2,temp.N_test_population2_times))
  if(plot_bool.par==TRUE){
    temp.units_string<-""
    if(!strcmp(units_string.par,"")){
      temp.units_string<-paste(", in ",units_string.par,sep="")
    }
    temp.indices1<-which(temp.pc_test_class_vector==1)
    temp.indices2<-which(temp.pc_test_class_vector==2)
    plot.graph(x_list.par=list(temp.pc1_populations_original_sampling[temp.indices1],
                               temp.pc1_populations_original_sampling[temp.indices2]),
               y_list.par=list(temp.pc2_populations_original_sampling[temp.indices1],
                               temp.pc2_populations_original_sampling[temp.indices2]),
               x_label.par=paste("First principal component axis",temp.units_string,sep=""),
               y_label.par=paste("Second principal component axis",temp.units_string,sep=""),
               type.par=rep("p",2),pch.par=rep(".",2),cex.par=rep(3,2),col.par=c(1,2),
               plotting_UB.par=rep(18,2),
               pdf_title.par="Test_Classification_PC_Space.pdf")
  }
  temp.list<-list(out.pc1_original_sampling=temp.pc1_original_sampling,
                  out.pc2_original_sampling=temp.pc2_original_sampling)
  return(temp.list)
}





svm_classification.function<-function(all_pc_population_times.par,all_pc_population_ordinates.par,
                                      pc1_original_sampling.par,pc2_original_sampling.par,
                                      pc_pilot_class_vector.par,
                                      plot_bool.par=TRUE){
  #https://www.datacamp.com/community/tutorials/support-vector-machines-r
  #Training data for the SVM classifier.
  temp.x_matrix<-cbind(all_pc_population_times.par,all_pc_population_ordinates.par)
  temp.pca_classification_data_frame<-data.frame(class_indices=as.factor(pc_pilot_class_vector.par),
                                                 PC1=all_pc_population_times.par,
                                                 PC2=all_pc_population_ordinates.par)
  #The cost has been decided using visual inspection of scatter plots overlaid with the support lines, with those support boundaries
  #chosen large enough on the size of the PC2 uncertainty band about the centre PC1 line.
  temp.svmfit<-svm(class_indices~.,data=temp.pca_classification_data_frame,
                   kernel="linear",cost=0.05,scale=FALSE)
  temp.beta<-drop(t(temp.svmfit$coefs)%*%temp.x_matrix[temp.svmfit$index,])
  temp.beta0=temp.svmfit$rho
  temp.plotting_matrix<-temp.x_matrix[temp.svmfit$index,]
  #Classify based on whether points are on one side of the other of the decision boundary.
  temp.x_matrix_original_sampling<-cbind(pc1_original_sampling.par,pc2_original_sampling.par)
  temp.intecept=(temp.beta0) / temp.beta[2]
  temp.slope=-temp.beta[1] / temp.beta[2]
  temp.predicted_values<-temp.slope*pc1_original_sampling.par+temp.intecept
  temp.class1_indices<-which(pc2_original_sampling.par<=temp.predicted_values)
  temp.class2_indices<-which(pc2_original_sampling.par>temp.predicted_values)
  temp.colour_vector<-rep(1,nrow(temp.x_matrix_original_sampling))
  temp.colour_vector[temp.class2_indices]<-2
  if(plot_bool.par==TRUE){
    #Classification, full.
    pdf("SVM_Plot.pdf",width=8,height=6)
    par(mgp=c(2,1,0))
    plot(temp.x_matrix_original_sampling,col=temp.colour_vector,xlab="Rotated PC1",ylab="Rotated PC2",lab=c(10,10,7),
         xlim=c(min(temp.x_matrix_original_sampling[,1]),max(temp.x_matrix_original_sampling[,1])),
         ylim=c(min(temp.x_matrix_original_sampling[,2]),max(temp.x_matrix_original_sampling[,2])),
         pch=".")
    grid()
    minor.tick(10,10)
    points(temp.x_matrix, col = pc_pilot_class_vector.par+2,pch=".",cex=3)
    points(temp.plotting_matrix, pch = 5, cex = 2,col=4)
    abline(temp.beta0 / temp.beta[2], -temp.beta[1] / temp.beta[2],col=4,lwd=2)
    abline((temp.beta0 - 1) / temp.beta[2], -temp.beta[1] / temp.beta[2], lty = 2,col=4,lwd=2)
    abline((temp.beta0 + 1) / temp.beta[2], -temp.beta[1] / temp.beta[2], lty = 2,col=4,lwd=2)
    dev.off()
    #A plot of the results of the classification accuracy given the training data.
    pdf("SVM_Plot_Default.pdf",width=8,height=6)
    plot(temp.svmfit,data=temp.pca_classification_data_frame)
    dev.off()
  }
  temp.list<-list(out.class1_indices=temp.class1_indices,
                  out.class2_indices=temp.class2_indices)
  return(temp.list)
}





two_class_PCA_identification.function<-
  function(MUA_window_times_vector.par,MUA_window_ordinates_500_vector.par,
           time_sequence_Marshall_MUA.par,
           abbreviated_time_units_string.par="",time_units_string.par="",
           units_string.par="",
           pc_outlier_threshold_quantile.par=5,scale.par=5,
           min_record_size_MUA.par,
           working_directory_string.par="",
           plot_bool.par=TRUE){
    temp.pca_directory_string<-"PCA_Processing"
    dir.create(temp.pca_directory_string,showWarnings=FALSE)
    temp.pca_directory_string_full<-paste(working_directory_string.par,"/",temp.pca_directory_string,sep="")
    setwd(temp.pca_directory_string_full)
    #PCA processing.
    temp.pca_processing_object<-
      pca_processing.function(MUA_window_times_vector.par=MUA_window_times_vector.par,
                              MUA_window_ordinates_500_vector.par=MUA_window_ordinates_500_vector.par,
                              units_string.par=units_string.par,
                              plot_bool.par=plot_bool.par)
    temp.pc_unit_vectors<-temp.pca_processing_object$out.pc_unit_vectors
    temp.PC1<-temp.pca_processing_object$out.PC1
    temp.PC2<-temp.pca_processing_object$out.PC2
    temp.N_decimated_j=temp.pca_processing_object$out.N_decimated_j
    temp.pc1_original<-temp.pca_processing_object$out.pc1_original
    temp.pc2_original<-temp.pca_processing_object$out.pc2_original
    temp.N_original=temp.pca_processing_object$out.N_original
    #Pilot classification using standard-normal innovations.
    temp.pca_pilot_classification_object<-
      pca_pilot_classification.function(pc_unit_vectors.par=temp.pc_unit_vectors,
                                        PC1.par=temp.PC1,PC2.par=temp.PC2,
                                        pc_outlier_threshold_quantile.par=pc_outlier_threshold_quantile.par,
                                        units_string.par=units_string.par,
                                        plot_bool.par=plot_bool.par)
    temp.pc_pilot_class_vector<-temp.pca_pilot_classification_object$out.pc_pilot_class_vector
    temp.500Hz_omitted_all_pc_population_times<-temp.pca_pilot_classification_object$out.500Hz_omitted_all_pc_population_times
    temp.500Hz_omitted_all_pc_population_ordinates<-temp.pca_pilot_classification_object$out.500Hz_omitted_all_pc_population_ordinates
    temp.rotation_matrix<-temp.pca_pilot_classification_object$out.rotation_matrix
    temp.500Hz_omitted_pc_mean<-temp.pca_pilot_classification_object$out.500Hz_omitted_pc_mean
    temp.500Hz_omitted_pc_sigma<-temp.pca_pilot_classification_object$out.500Hz_omitted_pc_sigma
    #Implement the pilot classifier on test data.
    temp.pca_pilot_test_classification_object<-
      pca_pilot_test_classification.function(pc1_original.par=temp.pc1_original,
                                             pc2_original.par=temp.pc2_original,
                                             rotation_matrix.par=temp.rotation_matrix,
                                             pc_mean.par=temp.500Hz_omitted_pc_mean,
                                             pc_sigma.par=temp.500Hz_omitted_pc_sigma,
                                             pc_outlier_threshold_quantile.par=pc_outlier_threshold_quantile.par,
                                             units_string.par=units_string.par,
                                             plot_bool.par=plot_bool.par)
    temp.pc1_original_sampling<-temp.pca_pilot_test_classification_object$out.pc1_original_sampling
    temp.pc2_original_sampling<-temp.pca_pilot_test_classification_object$out.pc2_original_sampling
    #SVM step.
    temp.class1_indices<-c()
    temp.class2_indices<-c()
    if(length(unique(temp.pc_pilot_class_vector))>1){
      temp.svm_classification_object<-
        svm_classification.function(all_pc_population_times.par=temp.500Hz_omitted_all_pc_population_times,
                                    all_pc_population_ordinates.par=temp.500Hz_omitted_all_pc_population_ordinates,
                                    pc1_original_sampling.par=temp.pc1_original_sampling,
                                    pc2_original_sampling.par=temp.pc2_original_sampling,
                                    pc_pilot_class_vector.par=temp.pc_pilot_class_vector,
                                    plot_bool.par=TRUE)
      temp.class1_indices<-temp.svm_classification_object$out.class1_indices
      temp.class2_indices<-temp.svm_classification_object$out.class2_indices
    } else{
      temp.num_pc_values=length(temp.pc_pilot_class_vector)
      temp.indices_sorted_pc_values<-1:temp.num_pc_values
      temp.ordered_class_indices<-temp.indices_sorted_pc_values[order(temp.pc_pilot_class_vector)]
      temp.class1_indices<-temp.ordered_class_indices[3:temp.num_pc_values-2]
      temp.class2_indices<-temp.ordered_class_indices[c(temp.num_pc_values-1,temp.num_pc_values)]
    }
    #Return to the original time-domain space to view the results of the classification.
    temp.abscissa1<-MUA_window_times_vector.par[temp.class2_indices]
    temp.abscissa2<-MUA_window_times_vector.par[temp.class1_indices]
    temp.ordinates1<-MUA_window_ordinates_500_vector.par[temp.class2_indices]
    temp.ordinates2<-MUA_window_ordinates_500_vector.par[temp.class1_indices]
    temp.MUA_500Hzdifferenced_filtered_absolute_series_cleaned1<-c(0)
    temp.MUA_500Hzdifferenced_filtered_absolute_series_cleaned2<-c(0)
    if(!length(temp.ordinates1)){
      temp.abscissa1<-c(0)
    } else{
      temp.MUA_500Hzdifferenced_filtered_absolute_series_cleaned1<-basic_cleaner.function(temp.ordinates1,scale.par=scale.par)
    }
    if(!length(temp.ordinates2)){
      temp.abscissa2<-c(0)
    } else{
      temp.MUA_500Hzdifferenced_filtered_absolute_series_cleaned2<-basic_cleaner.function(temp.ordinates2,scale.par=scale.par)
    }
    temp.plotting_x1<-temp.abscissa1
    temp.plotting_y1<-temp.MUA_500Hzdifferenced_filtered_absolute_series_cleaned1
    temp.plotting_x2<-temp.abscissa2
    temp.plotting_y2<-temp.MUA_500Hzdifferenced_filtered_absolute_series_cleaned2
    temp.total_plot_size=length(temp.plotting_y1)+length(temp.plotting_y2)
    if(plot_bool.par==TRUE){
      multipage_plot_comparison.function(x_plotting_list.par=list(temp.plotting_x1),y_plotting_list.par=list(temp.plotting_y1),
                                         x_plotting_list2.par=list(temp.plotting_x2),y_plotting_list2.par=list(temp.plotting_y2),
                                         bounds_all.par=c(0,sort(c(temp.plotting_y1,temp.plotting_y2))[floor((1-1/temp.total_plot_size)*temp.total_plot_size)]),
                                         x_label.par=paste("Time, in ",abbreviated_time_units.string," since ",
                                                           round_general.function(time_sequence_Marshall_MUA.par[1])," ",
                                                           time_units.string,sep=""),
                                         y_label.par="Normalized units",title_strings.par=c(""),
                                         pdf_title.par="500Hzdifferenced_MUA_Squared_Values_Normalized_Classes.pdf",
                                         no_comparison_bool.par=FALSE,
                                         num_samples.par=min(min_record_size_MUA.par,5e3),shade_intervals.par=NA,
                                         types.par=rep("h",2))
    }
    setwd(working_directory_string.par)
    temp.list<-list(out.pc_pilot_class_vector=temp.pc_pilot_class_vector,
                    out.500Hz_omitted_all_pc_population_times=temp.500Hz_omitted_all_pc_population_times,
                    out.500Hz_omitted_all_pc_population_ordinates=temp.500Hz_omitted_all_pc_population_ordinates,
                    out.plotting_x1=temp.plotting_x1,
                    out.plotting_y1=temp.plotting_y1,
                    out.plotting_x2=temp.plotting_x2,
                    out.plotting_y2=temp.plotting_y2)
    return(temp.list)
  }



























