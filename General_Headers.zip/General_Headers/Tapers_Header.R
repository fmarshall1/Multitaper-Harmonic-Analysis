#Francois Marshall, Boston University
#Header file for presenting output of results.

###################################################################################################################
#Established tapers.

box.filter<-function(N.par){
  temp.box_filter<-rep(1/sqrt(N.par),N.par)
  return(temp.box_filter)
}

Hamming.taper<-function(N_par){
  temp.indices<-1:N_par-1
  return(0.54-0.46*cos(2*pi*(temp.indices)/N_par))
}

Dirichlet.fft<-function(box_filter.par,M.par){
  temp.box_filter<-as.matrix(box_filter.par)
  temp.N=nrow(temp.box_filter)
  padded.matrix<-pad.matrix(temp.box_filter,M.par)
  slepian.fft<-mvfft(padded.matrix)
  slepian.fft<-fft.rearrange_matrix(slepian.fft)
  return(slepian.fft)
}

concentrations.Fejer<-function(Dirichlet.par,N.par,NW.par){
  temp.M=length(Dirichlet.par)
  temp.M_2=temp.M/2
  temp.lower_index=temp.M_2-NW.par/N.par*temp.M+1
  temp.upper_index=temp.M_2+NW.par/N.par*temp.M+1
  temp.interior_indices<-temp.lower_index:temp.upper_index
  temp.exterior_indices<-c(1:(temp.lower_index-1),(temp.upper_index+1):temp.M)
  temp.spectral_window<-Mod(Dirichlet.par)^2
  temp.interior_energy=0
  temp.exterior_energy=0
  temp.interior_energies=mean(temp.spectral_window[temp.interior_indices])
  temp.exterior_energies=mean(temp.spectral_window[temp.exterior_indices])
  temp.concentrations=temp.interior_energies/(temp.interior_energies+temp.exterior_energies)
  return(temp.concentrations)
}




###################################################################################################################
#DPSS's.

dpss.matrix<-function(N.par,NW.par,K.par=NA){
  if(is.na(K.par)==TRUE){
    K.par=2*NW.par-1
  }
  dpss.object<-dpss(N.par,K.par,NW.par)
  dpss.tapers<-dpss.object$v
  dpss.eigenvalues<-dpss.object$eigen
  temp.list<-list(out.dpss=dpss.tapers,out.eigenvalues=dpss.eigenvalues)
  return(temp.list)
}

Slepian.functions<-function(dpss.par,M.par){
  temp.N=nrow(dpss.par)
  temp.K=ncol(dpss.par)
  padded.matrix<-pad.matrix(dpss.par,M.par)
  slepian.fft<-mvfft(padded.matrix)
  slepian.fft<-fft.rearrange_matrix(slepian.fft)
  return(slepian.fft)
}

Slepian.windows<-function(slepian.par){
  slepian.windows<-Mod(slepian.par)^2
  return(slepian.windows)
}

concentrations.Slepian<-function(Slepian_functions.par,N.par,NW.par){
  temp.M=nrow(Slepian_functions.par)
  temp.M_2=temp.M/2
  temp.K=ncol(Slepian_functions.par)
  temp.lower_index=temp.M_2-NW.par/N.par*temp.M+1
  temp.upper_index=temp.M_2+NW.par/N.par*temp.M+1
  temp.interior_indices<-temp.lower_index:temp.upper_index
  temp.exterior_indices<-c(1:(temp.lower_index-1),(temp.upper_index+1):temp.M)
  temp.spectral_windows<-Mod(Slepian_functions.par)^2
  temp.interior_energies<-rep(0,temp.K)
  temp.exterior_energies<-rep(0,temp.K)
  if(temp.K>1){
    temp.interior_energies=colMeans(temp.spectral_windows[temp.interior_indices,])
    temp.exterior_energies=colMeans(temp.spectral_windows[temp.exterior_indices,])
  }
  else{
    temp.interior_energies=sum(temp.spectral_windows[temp.interior_indices,1])/temp.M
    temp.exterior_energies=sum(temp.spectral_windows[temp.exterior_indices,1])/temp.M
  }
  temp.concentrations=temp.interior_energies/(temp.interior_energies+temp.exterior_energies)
  return(temp.concentrations)
}


###################################################################################################################
#Taper properties.

spectral_window.decay_rate<-function(log_frequencies.par,log_window.par){
  temp.N=length(log_window.par)
  temp.index_sequence<-1:temp.N
  temp.sums<-sapply(temp.index_sequence,running.sum,log_window.par)
  temp.first_diffs<-temp.sums[2:temp.N]-temp.sums[1:(temp.N-1)]
  temp.N_first<-length(temp.first_diffs)
  temp.second_diffs<-temp.first_diffs[2:temp.N_first]-temp.first_diffs[1:(temp.N_first-1)]
  temp.N_second=length(temp.second_diffs)
  temp.threshold.diff=0
  temp.where_optimal<-which(temp.second_diffs>temp.threshold.diff)
  temp.optimal_indices<-list()
  temp.counter=1
  for(i in 1:length(temp.where_optimal)){
    temp.index=temp.where_optimal[i]
    if(temp.index<(temp.N_second-1)){
      if(temp.second_diffs[temp.index+1]<=0){
        temp.optimal_indices[[temp.counter]]=temp.index+2
        temp.counter=temp.counter+1
      }
    }
  }
  temp.optimal_indices<-as.numeric(temp.optimal_indices)
  temp.optimal_frequencies<-log_frequencies.par[temp.optimal_indices]
  temp.maxima<-log_window.par[temp.optimal_indices]
  temp.fit_object<-lm(temp.maxima~temp.optimal_frequencies)
  temp.maxima_fit<-temp.fit_object$fitted.values
  temp.coefficients<-temp.fit_object$coefficients
  temp.decay_rate=abs(temp.coefficients[2])
  temp.summary_object<-summary(temp.fit_object)
  temp.se=temp.summary_object$sigma
  temp.R2=temp.summary_object$adj.r.squared
  temp.list<-list(temp.decay_rate,temp.optimal_frequencies,temp.maxima_fit,temp.se,temp.R2)
  return(temp.list)
}



#Window analysis.
window_analysis.fejer<-function(frequencies.par,N.par,NW.par,verbose.par=FALSE){
  if(verbose.par==TRUE){
    tic()
  }
  temp.M=2*length(frequencies.par-1)
  temp.log_frequencies<-10*log10(frequencies.par[frequencies.par>0])
  #Boxcar filter information, for measure of relative quality for the two filters.
  temp.boxcar_taper<-box.filter(N.par)
  temp.dirichlet_kernel<-Dirichlet.fft(temp.boxcar_taper,temp.M)
  temp.Fejer_gain<-Mod(temp.dirichlet_kernel)^2
  temp.Fejer_energy_concentration=concentrations.Fejer(temp.dirichlet_kernel,N.par,NW.par)
  #Decay-rate calculations.
  #Clip the windows to avoid -Inf values.
  temp.Fejer_gain[temp.Fejer_gain<=0]<-max(temp.Fejer_gain)*1e-12
  temp.log_window<-10*log10(temp.Fejer_gain)
  temp.log_window<-non_negative.principle_domain(temp.log_window)
  temp.log_Fejer_window<-temp.log_window[frequencies.par>0]
  temp.log_linear_object<-spectral_window.decay_rate(temp.log_frequencies,temp.log_Fejer_window)
  temp.fejer_decay_rate=temp.log_linear_object[[1]]
  temp.log_linear_fejer_frequencies<-temp.log_linear_object[[2]]
  temp.linear_fit_fejer<-temp.log_linear_object[[3]]
  temp.se_fejer=temp.log_linear_object[[4]]
  temp.R2_fejer=temp.log_linear_object[[5]]
  #Display the output.
  temp.rounding_object<-round.results(temp.fejer_decay_rate,temp.se_fejer)
  temp.rounded_results<-temp.rounding_object[[1]]
  temp.rounded_uncertainties<-temp.rounding_object[[2]]
  temp.fejer_bias_factor=signif(log10(1-temp.Fejer_energy_concentration),3)
  if(verbose.par==TRUE){
    cat("fejer_decay_rate\ts_error\tR2\tlog_bias\n")
    cat(temp.rounded_results[1],"\t",temp.rounded_uncertainties[1],"\t",signif(temp.R2_fejer,3),"\t",temp.fejer_bias_factor,"\n")
    cat("Time to perform the spectral-window analysis for the Fejer kernel: ")
    toc()
  }
}

window_analysis.dpss<-function(plotting_times.par,frequencies.par,N.par,NW.par,K.par=0,M.par=0,x_measurement.par="Measured quantity",
                               y_measurement.par="Measured quantity",time_units.par="units",y_units.par="units",
                               pdf_title.par="Net_Taper_Weights.pdf",plot.par=FALSE,verbose.par=FALSE){
  if(verbose.par==TRUE){
    tic()
  }
  if(!K.par){
    K.par=2*NW.par-1
  }
  if(!M.par){
    M.par=N.par
  }
  temp.M2=length(frequencies.par)
  temp.M=2*temp.M2-1
  temp.log_frequencies<-10*log10(frequencies.par[frequencies.par>0])
  #Compute the Slepian vectors which will be required for the reconstruction.
  temp.dpss_object<-dpss.matrix(N.par,NW.par,K.par)
  temp.slepian_sequences<-temp.dpss_object[[1]]
  temp.slepian_functions<-Slepian.functions(temp.slepian_sequences,temp.M)
  temp.slepian_windows<-Mod(temp.slepian_functions)^2
  temp.energy.concentrations<-concentrations.Slepian(temp.slepian_functions,N.par,NW.par)
  temp.net_squared_weight_slepian<-rowSums(temp.slepian_sequences^2)
  temp.net_L2_weight.slepian<-sqrt(temp.net_squared_weight_slepian)
  #Plot the net contributions of the DPSS's over time.
  temp.x_list<-list(plotting_times.par)
  temp.y_list<-list(temp.net_L2_weight.slepian*1e3)
  if(plot.par==TRUE){
    plot.graph(temp.x_list,temp.y_list,x_label.par=paste(x_measurement.par,", in ",time_units.par,sep=""),
               y_label.par=paste(y_measurement.par,", in ",y_units.par,sep=""),plot_title.par="",pdf_title.par=pdf_title.par,lwd.par=2)
  }
  #Compute the decay rates for the sets of tapers.
  temp.log_slepian_windows<-matrix(0,nrow=temp.M2-1,ncol=K.par)
  #Clip the windows to avoid -Inf values.
  temp.slepian_windows[temp.slepian_windows<=0]<-max(temp.slepian_windows)*1e-12
  for(temp.k in 1:K.par){
    temp.log_window<-10*log10(temp.slepian_windows[,temp.k])
    temp.log_window<-non_negative.principle_domain(temp.log_window)
    temp.log_slepian_windows[,temp.k]<-temp.log_window[frequencies.par>0]
    temp.log_window<-non_negative.principle_domain(temp.log_window)
  }
  #Write out the results.
  sink("Window_Analysis.txt", append=FALSE, split=FALSE)
  cat("k\tdpss_decay_rate\ts_error\tR2\tlog_bias\n")
  for(temp.k in 1:K.par){
    #Slepian windows.
    temp.log_linear_object<-spectral_window.decay_rate(temp.log_frequencies,temp.log_slepian_windows[,temp.k])
    temp.decay_rate=temp.log_linear_object[[1]]
    temp.log_linear_frequencies<-temp.log_linear_object[[2]]
    temp.linear_fit<-temp.log_linear_object[[3]]
    temp.se_slepian=temp.log_linear_object[[4]]
    temp.R2_slepian=temp.log_linear_object[[5]]
    #Display the output.
    temp.rounding_object<-round.results(temp.decay_rate,temp.se_slepian)
    temp.rounded_results<-temp.rounding_object[[1]]
    temp.rounded_uncertainties<-temp.rounding_object[[2]]
    temp.slepian_bias_factor=signif(log10(1-temp.energy.concentrations[temp.k]),3)
    cat(temp.k,"\t",temp.rounded_results[1],"\t",temp.rounded_uncertainties[1],"\t",signif(temp.R2_slepian,3),"\t",temp.slepian_bias_factor,"\n")
  }
  sink()
  if(verbose.par==TRUE){
    cat("Time to perform the spectral-window analysis for the DPSS's: ")
    toc()
  }
}


basic_window_analysis.function<-function(times.par,N.par,NW.par,frequencies.par,K.par=0,M.par=0,x_measurement.par="Measured quantity",
                                         y_measurement.par="Measured quantity",time_units.par="units",
                                         y_units.par="units",pdf_title.par="Net_Taper_Weights.pdf",plot.par=FALSE,verbose.par=FALSE){
  if(!K.par){
    K.par=2*NW.par-1
  }
  if(!M.par){
    M.par=N.par
  }
  #Compute the DPSS's and their DFT's.
  if(verbose.par==TRUE){
    tic()
    cat("DPSS computations: ")
    tic()
  }
  temp.slepian_sequences_object<-dpss.matrix(N.par,NW.par,K.par)
  temp.slepian_sequences<-temp.slepian_sequences_object[[1]]
  if(verbose.par==TRUE){
    toc()
    cat("Slepian functions: ")
    tic()
  }
  temp.slepian_functions<-Slepian.functions(temp.slepian_sequences,M.par)
  if(verbose.par==TRUE){
    toc()
    cat("All DPSS computations: ")
    toc()
  }
  window_analysis.fejer(frequencies.par,N.par,NW.par,verbose.par=verbose.par)
  window_analysis.dpss(times.par,frequencies.par,N.par,NW.par,K.par,M.par,x_measurement.par=x_measurement.par,
                       y_measurement.par=y_measurement.par,time_units.par=time_units.par,
                       y_units.par=y_units.par,pdf_title.par=pdf_title.par,plot.par=plot.par,verbose.par=verbose.par)
}




#Gapped multitaper spectrum estimator.

sinc.matrix<-function(N.par,W.par,num_nodes.par){
  temp.gauss_legendre_object<-gauss.quad(num_nodes.par)
  temp.gc_weights<-temp.gauss_legendre_object$weights
  temp.gc_nodes<-temp.gauss_legendre_object$nodes
  temp.sinc_matrix<-matrix(0,nrow=num_nodes.par,ncol=num_nodes.par)
  for(temp.m in 1:num_nodes.par){
    for(temp.j in 1:num_nodes.par){
      temp.sinc_matrix[temp.m,temp.j]=sinc_NW(temp.gc_nodes[temp.m]-temp.gc_nodes[temp.j],N.par,W.par)
      temp.sinc_matrix[temp.m,temp.j]=sqrt(temp.gc_weights[temp.m]*temp.gc_weights[temp.j])*temp.sinc_matrix[temp.m,temp.j]
    }
  }
  temp.list<-list(temp.sinc_matrix,temp.gc_weights,temp.gc_nodes)
  return(temp.list)
}

continuous.prolates<-function(N.par,W.par,num_nodes.par,K.par=NA){
  temp.K=2*N.par*W.par-1
  if(!is.na(K.par)){
    temp.K=K.par
  }
  temp.kernel_object<-sinc.matrix(N.par,W.par,num_nodes.par)
  temp.kernel_matrix<-temp.kernel_object[[1]]
  temp.gc_weights<-temp.kernel_object[[2]]
  temp.gc_nodes<-temp.kernel_object[[3]]
  temp.kernel_eigen_object<-eigs_sym(temp.kernel_matrix,temp.K)
  temp.kernel_eigenvectors<-temp.kernel_eigen_object$vectors
  temp.eigenvalues<-temp.kernel_eigen_object$values
  temp.eigenvalues[temp.eigenvalues<0]<-0
  temp.list<-list(temp.kernel_eigenvectors,temp.gc_weights,temp.gc_nodes,out.eigenvalues=temp.eigenvalues)
  return(temp.list)
}


gapped.slepians2<-function(num_elements.par,gap_start_index.par,gap_end_index.par,W.par,K.par,M.par,nugget.par=zero.threshold^2){
  #Construct an indicator response.
  temp.I_t<-rep(1,num_elements.par)
  cat("nugget.par = ",nugget.par,"\n")
  temp.I_t[gap_start_index.par:gap_end_index.par]<-nugget.par
  temp.I_g<-diag(temp.I_t)
  temp.A_g<-matrix(0,nrow=num_elements.par,ncol=num_elements.par)
  for(i in 1:num_elements.par){
    for(j in 1:num_elements.par){
      temp.A_g[i,j]=temp.I_t[i]*temp.I_t[j]*sinc_W((i-1)-(j-1),W.par)
    }
  }
  temp.L_g<-diag(sqrt(temp.I_t))
  temp.L_g_1<-diag(1/sqrt(temp.I_t))
  temp.H_g<-temp.L_g_1 %*% temp.A_g %*% t(temp.L_g_1)
  temp.H_g_eigen<-eigen(temp.H_g)
  temp.lambdas<-Re(temp.H_g_eigen$values)
  temp.eigenvectors<-Re(temp.H_g_eigen$vectors)
  for(j in 1:K.par){
    temp.eigenvectors[,j]<-t(temp.L_g_1) %*% temp.eigenvectors[,j]
  }
  temp.I_t[gap_start_index.par:gap_end_index.par]<-0
  for(i in 1:K.par){
    temp.eigenvectors[,i]<-temp.eigenvectors[,i]*temp.I_t
  }
  temp.zero_matrix<-matrix(0,nrow=M.par-num_elements.par,ncol=K.par)
  temp.eigen_matrix<-rbind(temp.eigenvectors[,1:K.par],temp.zero_matrix)
  temp.V_k<-mvfft(temp.eigen_matrix)
  temp.V_k<-fft.rearrange_matrix(temp.V_k)
  temp.Vk_2<-Mod(temp.V_k)^2
  temp.H_fK<-rowSums(temp.Vk_2)/K.par
  temp.list<-list(temp.V_k,temp.eigen_matrix,temp.H_fK,temp.lambdas[1:K.par],temp.eigenvectors[,1:K.par])
  return(temp.list)
}

gapped.sinc_matrix<-function(gap_start_index.par,gap_end_index.par,N.par,W.par,K.par,node_number.par=35,nugget.par=zero.threshold^2){
  temp.gauss_legendre_object<-gauss.quad(node_number.par)
  temp.gc_weights<-temp.gauss_legendre_object$weights
  temp.gc_nodes<-temp.gauss_legendre_object$nodes
  temp.gap_indices<-gap_start_index.par:gap_end_index.par
  temp.continuous_taper_gap_times<-2*(temp.gap_indices-1)/N.par-1
  temp.min_continuous_taper_gap_time=min(temp.continuous_taper_gap_times)
  temp.max_continuous_taper_gap_time=max(temp.continuous_taper_gap_times)
  temp.chi_t<-rep(1,node_number.par)
  for(j in 1:node_number.par){
    temp.gc_node=temp.gc_nodes[j]
    if(temp.gc_node>temp.min_continuous_taper_gap_time & temp.gc_node<temp.max_continuous_taper_gap_time){
      temp.index=1
      temp.supremum=max(which(temp.continuous_taper_gap_times<temp.gc_node))
      temp.infimum=min(which(temp.continuous_taper_gap_times>temp.gc_node))
      temp.diff=temp.infimum-temp.supremum
      if(!temp.diff || (temp.diff==1)){
        temp.index=temp.supremum
      }
      else if(temp.diff==2){
        temp.index=temp.supremum+1
      }
      else{
        temp.sequence<-temp.supremum:temp.infimum
        temp.index=median(temp.sequence)
      }
      temp.chi_t[j]=nugget.par
    }
  }
  #Avoid zero occurring in the indices, and not having to set it to 1 when another instance of 1 is in the rounded index set.
  temp.eigen_kernel<-matrix(0,nrow=node_number.par,ncol=node_number.par)
  for(i in 1:node_number.par){
    for(j in 1:node_number.par){
      temp.eigen_kernel[i,j]<-temp.gc_nodes[j]*sinc_NW(temp.gc_nodes[i]-temp.gc_nodes[j],N.par,W.par)*temp.chi_t[j]
    }
  }
  temp.L_matrix<-diag(temp.chi_t)
  temp.inverse_L_matrix<-diag(1/sqrt(temp.chi_t))
  temp.sinc_matrix<-temp.inverse_L_matrix%*%temp.eigen_kernel%*%t(temp.inverse_L_matrix)
  temp.list<-list(temp.sinc_matrix,temp.gc_weights,temp.gc_nodes,temp.L_matrix,temp.chi_t)
  return(temp.list)
}

gapped.continuous_prolates<-function(gap_start_index.par,gap_end_index.par,N.par,W.par,K.par,node_number.par=35,nugget.par=zero.threshold){
  temp.kernel_object<-gapped.sinc_matrix(gap_start_index.par,gap_end_index.par,N.par,W.par,K.par,node_number.par,nugget.par)
  temp.kernel_matrix<-temp.kernel_object[[1]]
  temp.gc_weights<-temp.kernel_object[[2]]
  temp.gc_nodes<-temp.kernel_object[[3]]
  temp.num_nodes=length(temp.gc_nodes)
  temp.L_matrix<-temp.kernel_object[[4]]
  temp.chi_t<-temp.kernel_object[[5]]
  temp.inverse_transposed_L_matrix<-t(diag(1/diag(temp.L_matrix)))
  temp.kernel_eigen_object<-eigen(temp.kernel_matrix)
  temp.kernel_eigenvalues<-temp.kernel_eigen_object$values
  temp.kernel_eigenvectors<-temp.kernel_eigen_object$vectors
  temp.kernel_eigenvectors<-Re(temp.kernel_eigenvectors)
  print(temp.kernel_eigenvectors)
  for(j in 1:temp.num_nodes){
    temp.kernel_eigenvectors[,j]<-temp.inverse_transposed_L_matrix%*%temp.kernel_eigenvectors[,j]
  }
  temp.squared_kernel<-temp.kernel_eigenvectors^2
  temp.l2_norms<-sqrt(colSums(temp.squared_kernel))
  for(j in 1:temp.num_nodes){
    temp.kernel_eigenvectors[,j]<-temp.kernel_eigenvectors[,j]#*sqrt(abs(temp.kernel_eigenvalues[j]))/temp.l2_norms[j]
  }
  temp.list<-list(temp.kernel_eigenvectors,temp.gc_weights,temp.gc_nodes,temp.kernel_eigenvalues,temp.chi_t)
  return(temp.list)
}

gapped.discrete_prolates<-function(gap_start_index.par,gap_end_index.par,N.par,W.par,K.par,node_number.par=35,nugget.par=zero.threshold){
  temp.gcp_object<-gapped.continuous_prolates(gap_start_index.par,gap_end_index.par,N.par,W.par,K.par,node_number.par,nugget.par)
  temp.kernel_eigenvectors<-temp.gcp_object[[1]]
  temp.gc_weights<-temp.gcp_object[[2]]
  temp.gc_nodes<-temp.gcp_object[[3]]
  temp.chi_t<-temp.gcp_object[[5]]
  temp.num_nodes=length(temp.gc_nodes)
  temp.indicator_sequence<-rep(1,N.par)
  temp.indicator_sequence[gap_start_index.par:gap_end_index.par]<-zero.threshold
  temp.gdpss<-matrix(0,nrow=N.par,ncol=temp.num_nodes)
  for(l in 1:temp.num_nodes){
    for(n in 1:N.par){
      temp.sequence<-rep(0,temp.num_nodes)
      for(j in 1:temp.num_nodes){
        temp.sequence<-sqrt(temp.gc_weights[j])*sinc_NW(2*(n-1)/N.par-1-temp.gc_nodes[j],N.par,W.par)*temp.chi_t[j]*temp.kernel_eigenvectors[j,l]
      }
      temp.gdpss[n,l]=sum(temp.sequence)
    }
  }
  for(j in 1:temp.num_nodes){
    temp.gdpss[,j]<-temp.gdpss[,j]*temp.indicator_sequence
  }
  temp.squared_gdpss<-temp.gdpss^2
  temp.rms_gdpss<-sqrt(colSums(temp.squared_gdpss))
  for(j in 1:temp.num_nodes){
    temp.gdpss[,j]<-temp.gdpss[,j]/temp.rms_gdpss[j]
  }
  return(temp.gdpss)
}
gapped.slepians<-function(gap_start_index.par,gap_end_index.par,N.par,W.par,K.par,M.par){
  temp.I_t<-rep(1,N.par)
  temp.I_t[gap_start_index.par:gap_end_index.par]<-0
  temp.CPSW_object<-gapped.continuous_prolates(gap_start_index.par,gap_end_index.par,N.par,W.par,K.par)
  temp.kernel_eigenvectors<-temp.CPSW_object[[1]]
  temp.gc_weights<-temp.CPSW_object[[2]]
  temp.gc_nodes<-temp.CPSW_object[[3]]
  temp.kernel_eigenvalues<-temp.CPSW_object[[4]]
  temp.num_nodes=temp.CPSW_object[[5]]
  #cat("temp.num_nodes = ",temp.num_nodes,"\n")
  temp.time_indices<-1:N.par-1
  temp.slepians_matrix<-matrix(0,nrow=N.par,ncol=temp.num_nodes)
  for(k in 1:temp.num_nodes){
    temp.sinc_matrix<-matrix(0,nrow=N.par,ncol=temp.num_nodes)
    for(j in 1:temp.num_nodes){
      temp.sinc_matrix[,j]<-sin(pi*N.par*W.par*(2*temp.time_indices/N.par-1-temp.gc_nodes[j]))/(pi*(2*temp.time_indices/N.par-1-temp.gc_nodes[j]))
    }
    temp.slepian_vector<-as.vector(sqrt(temp.gc_weights)*temp.kernel_eigenvectors[,k])
    temp.slepians_matrix[,k]<-temp.sinc_matrix%*%temp.slepian_vector
  }
  for(k in 1:K.par){
    temp.slepians_matrix[,k]<-temp.slepians_matrix[,k]
    temp.slepians_matrix[,k]<-temp.slepians_matrix[,k]/sqrt(sum(temp.slepians_matrix[,k]^2))
  }
  temp.zero_matrix<-matrix(0,nrow=M.par-N.par,ncol=K.par)
  temp.eigen_matrix<-rbind(temp.slepians_matrix[,1:K.par],temp.zero_matrix)
  temp.V_k<-mvfft(temp.eigen_matrix)
  temp.V_k<-fft.rearrange_matrix(temp.V_k)
  temp.Vk_2<-Mod(temp.V_k)^2
  temp.H_fK<-rowSums(temp.Vk_2)/K.par
  temp.list<-list(temp.V_k,temp.slepians_matrix[,1:K.par],temp.H_fK,temp.kernel_eigenvalues)
  return(temp.list)
}






#Chave's MDSS tapers.
mdss.function<-function(nonzero_indices.par,N.par,NW.par,M.par){
  temp.K=2*NW.par-1
  temp.mdss_kernel<-dpss_kernel.function(NW.par,N.par,nonzero_indices.par)
  temp.eigen_object<-eigs_sym(temp.mdss_kernel,temp.K)
  temp.eigenvalues<-temp.eigen_object$values
  temp.mdss_matrix<-matrix(0,nrow=N.par,ncol=temp.K)
  temp.mdss_matrix[nonzero_indices.par,]<-temp.eigen_object$vectors
  temp.list<-list(out.eigenvalues=temp.eigenvalues,
                  out.mdss_matrix=temp.mdss_matrix)
  return(temp.list)
}








###################################################################################################################
#Minimum-bias tapers.

mb.tapers<-function(N.par,K.par){
  temp.sine_tapers<-matrix(0,nrow=N.par,ncol=K.par)
  temp.indices<-1:N.par-1
  for(k in 1:K.par){
    temp.sine_tapers[,k]<-sqrt(2/(N.par+1))*sin(pi*k*temp.indices/(N.par+1))
  }
  return(temp.sine_tapers)
}


mb.gapped_kernel<-function(gap_start_index.par,gap_end_index.par,N.par){
  temp.I_t<-rep(1,N.par)
  temp.I_t[gap_start_index.par:gap_end_index.par]<-0
  temp.matrix<-matrix(0,nrow=N.par,ncol=N.par)
  temp.indices<-1:N.par-1
  for(s in 1:N.par){
    temp.differences<-temp.indices-s
    temp.matrix[,s]<-(-1)^(temp.differences+1)/temp.differences^2
  }
  temp.matrix<-temp.matrix/2/pi^2
  for(i in 1:N.par){
    temp.matrix[,i]<-sqrt(2/(N.par+1))*sin(pi*i*temp.indices/(N.par+1))*temp.I_t
    temp.matrix[i,]<-temp.matrix[i,]*temp.I_t
  }
  return(temp.matrix)
}

mb.gapped_tapers<-function(gap_start_index.par,gap_end_index.par,N.par,K.par,M.par){
  temp.kernel<-mb.gapped_kernel(gap_start_index.par,gap_end_index.par,N.par)
  temp.eigen_object<-eigen(temp.kernel)
  temp.eigenvalues<-temp.eigen_object$values
  temp.eigenvalues<-temp.eigenvalues[1:K.par]
  temp.eigenvectors<-temp.eigen_object$vectors
  temp.eigenvectors<-temp.eigenvectors[,1:K.par]
  temp.eigenvectors<-fft.rearrange_matrix(temp.eigenvectors)
  temp.zero_matrix<-matrix(0,nrow=M.par-N.par,ncol=K.par)
  temp.eigen_matrix<-rbind(temp.eigenvectors,temp.zero_matrix)
  temp.V_k<-mvfft(temp.eigen_matrix)
  temp.list<-list(temp.eigenvectors,temp.eigenvalues,temp.V_k)
  return(temp.list)
}


