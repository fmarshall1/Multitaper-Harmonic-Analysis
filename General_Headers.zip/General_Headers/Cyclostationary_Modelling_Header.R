#Francois Marshall, Boston University
#Header file for cyclostationary modeling.
###################################################################################################################

laptv.function<-function(innovations_sequence.par,time_sequence.par,frequencies.par,transient_offset.par,cyclic_frequency_indices.par=NA,
                         ar_coefficients.par=0,sampling_rate.par=1,first_time.par=0){
  temp.num_innovations=length(innovations_sequence.par)
  temp.num_reconstruction=temp.num_innovations-transient_offset.par
  temp.time_indices<-1:temp.num_innovations-transient_offset.par
  temp.ar_order=length(ar_coefficients.par)
  temp.time_indices<-1:temp.num_innovations-1
  temp.laptv_output<-c()
  if(!is.na(cyclic_frequency_indices.par)){
    temp.num_cyclic_frequencies=length(cyclic_frequency_indices.par)
    temp.filtered_sequences<-matrix(0,nrow=temp.num_reconstruction,ncol=temp.num_cyclic_frequencies)
    for(temp.l in 1:temp.num_cyclic_frequencies){
      temp.index=cyclic_frequency_indices.par[temp.l]
      temp.frequency=frequencies.par[temp.index]
      temp.cosine_sequence<-cos(2*pi*temp.frequency*temp.time_indices)
      temp.modulated_innovations<-temp.cosine_sequence*innovations_sequence.par
      temp.output_sequence<-innovations_sequence.par
      if(temp.ar_order>0){
        for(temp.j in temp.ar_order+1:temp.num_reconstruction){
          temp.linear_part=crossprod(ar_coefficients.par,rev(temp.output_sequence[(temp.j-temp.ar_order):(temp.j-1)]))
          temp.output_sequence[temp.j]=temp.modulated_innovations[temp.j]+temp.linear_part
        }
      }
      temp.filtered_sequences[,temp.l]<-temp.output_sequence[transient_offset.par+1:temp.num_reconstruction]
    }
    temp.laptv_output<-rowSums(temp.filtered_sequences)
  }
  else{
    temp.output_sequence<-innovations_sequence.par
    if(temp.ar_order>0){
      for(temp.j in temp.ar_order+1:temp.num_reconstruction){
        temp.linear_part=crossprod(ar_coefficients.par,rev(temp.output_sequence[(temp.j-temp.ar_order):(temp.j-1)]))
        temp.output_sequence[temp.j]=innovations_sequence.par[temp.j]+temp.linear_part
      }
      temp.laptv_output<-temp.output_sequence[transient_offset.par+1:temp.num_reconstruction]
    }
  }
  temp.laptv_times<-(1:temp.num_reconstruction-1)/sampling_rate.par+first_time.par
  temp.list<-list(out.laptv_output=temp.laptv_output,
                  out.laptv_times=temp.laptv_times)
  return(temp.list)
}



laptv_ACVS.function<-function(times.par,frequencies.par,spectral_power_estimates.par,means.par,first_time.par=0,normal_quantile.par=1,
                              sampling_rate.par=1,cyclic_frequency_indices.par=NA,conjugate_correlation.par=FALSE,plot_bool.par=FALSE,
                              abscissa_quantity.par="Measured value",abscissa_units.par="units",
                              ordinates_quantity.par="Measured value",ordinates_units.par="units",
                              laptv_ordinates_quantity.par="Measured value",laptv_ordinates_units.par="units",
                              measured_quantity.par="",
                              max_size.par=NA,plot_titles.par="",
                              #Ends reconstruction booleans.
                              periodic_reconstruction_bool.par=FALSE,ts_interp_ends_bool.par=FALSE,mdss_bool_ends.par=FALSE,gn_bool_ends.par=FALSE,
                              num_iterations.par=1,max_length.par=200,
                              main_directory_string.par="",directory_label.par="",old_directory_interp.par="",revised_specific_directory_string.par=""){
  temp.N=length(times.par)
  if(is.na(max_size.par)==TRUE){
    max_size.par=temp.N
  }
  temp.M2=length(frequencies.par)
  temp.M=2*(temp.M2-1)
  temp.times<-plotting.sampled_vector(times.par,num_samples.par=max_size.par)
  temp.num_downsampled=length(temp.times)
  #Prewhiten the spectral-power estimates.
  temp.spectral_powers<-c(rev(spectral_power_estimates.par[2:(temp.M2-1)]),spectral_power_estimates.par)
  temp.spectral_powers<-return.to.fft_ordering(temp.spectral_powers)
  temp.mt_autocorrelation_values<-Re(fft(spectral_power_estimates.par,inverse=TRUE)/temp.M)
  temp.mt_autocorrelation_coefficients<-temp.mt_autocorrelation_values/temp.mt_autocorrelation_values[1]
  temp.lags<-(1:temp.M2-1)*sampling_rate.par
  temp.prewhitening_object<-prewhitening_algorithm.function(temp.spectral_powers,
                                                            temp.mt_autocorrelation_coefficients,frequencies.par,temp.N,
                                                            verbose.par=FALSE)
  temp.ar_coefficients<-temp.prewhitening_object$out.alphas
  temp.ar_order<-temp.prewhitening_object$out.ar_order
  temp.prewhitened_spectrum<-temp.prewhitening_object$out.prewhitened_spectrum
  temp.prewhitened_process_variance=2*sum(temp.prewhitened_spectrum[2:(temp.M2-1)])+temp.prewhitened_spectrum[1]+temp.prewhitened_spectrum[temp.M2]
  temp.prewhitened_process_variance=temp.prewhitened_process_variance/temp.M
  temp.z_label<-""
  if(!conjugate_correlation.par){
    temp.z_label<-"Autocorrelation value"
  }
  else{
    temp.z_label<-"Conjugate autocorrelation value"
  }
  temp.list<-list(out.ar_coefficients=temp.ar_coefficients,
                  out.ar_order=temp.ar_order,
                  out.mt_autocorrelation_values=temp.mt_autocorrelation_values,
                  out.mt_autocorrelation_coefficients=temp.mt_autocorrelation_coefficients,
                  out.lags=temp.lags,
                  out.prewhitened_spectrum=temp.prewhitened_spectrum,
                  out.prewhitened_process_variance=temp.prewhitened_process_variance)
  if(!is.na(cyclic_frequency_indices.par)){
    temp.num_cyclic_frequencies=length(cyclic_frequency_indices.par)
    temp.cyclic_TF_representations<-matrix(0,nrow=temp.M,ncol=temp.num_cyclic_frequencies)
    for(temp.l in 1:temp.num_cyclic_frequencies){
      temp.index=cyclic_frequency_indices.par[temp.l]
      temp.frequency=frequencies.par[temp.index]
      temp.TF_1<-1/Ap_f(frequencies.par,temp.ar_coefficients)
      temp.TF_2<-1/Ap_f(frequencies.par-temp.frequency,temp.ar_coefficients)
      if(!conjugate_correlation.par){
        temp.TF_2<-Conj(temp.TF_2)
      }
      temp.TF<-temp.TF_1*temp.TF_2
      temp.TF<-c(rev(Conj(temp.TF[2:(temp.M2-1)])),temp.TF)
      temp.cyclic_representation<-return.to.fft_ordering(temp.TF)
      temp.cyclic_TF_representations[,temp.l]<-temp.cyclic_representation
    }
    temp.cyclic_correlation_matrix<-mvfft(temp.cyclic_TF_representations,inverse=TRUE)/temp.M
    temp.cyclic_correlation_matrix<-Re(temp.cyclic_correlation_matrix)
    temp.autocorrelation_matrix<-matrix(0,nrow=temp.M,ncol=temp.M)
    for(temp.n in 1:temp.M){
      temp.Fourier_series<-rep(0,temp.M)
      for(temp.l in 1:temp.num_cyclic_frequencies){
        temp.coefficients<-temp.cyclic_correlation_matrix[,temp.l]
        temp.amplitudes=Mod(temp.coefficients)
        temp.phases=atan2(Im(temp.coefficients),Re(temp.coefficients))
        temp.index=cyclic_frequency_indices.par[temp.l]
        temp.frequency=frequencies.par[temp.index]
        temp.Fourier_series<-temp.Fourier_series+temp.amplitudes*cos(2*pi*temp.frequency*(temp.n-1)+temp.phases)
      }
      temp.Fourier_series<-2*temp.Fourier_series
      temp.autocorrelation_matrix[temp.n,]<-temp.Fourier_series
    }
    temp.autocorrelation_matrix<-temp.autocorrelation_matrix*temp.prewhitened_process_variance
    if(plot_bool.par==TRUE){
      temp.plotting_autocorrelation_matrix<-temp.autocorrelation_matrix
      temp.empirical_distribution_object<-empirical.distribution(temp.plotting_autocorrelation_matrix)
      temp.ordered_values<-temp.empirical_distribution_object[[1]]
      temp.empirical_distribution<-temp.empirical_distribution_object[[2]]
      temp.min_z=min(temp.ordered_values[temp.empirical_distribution>0.1 & temp.empirical_distribution<0.9])
      temp.max_z=max(temp.ordered_values[temp.empirical_distribution>0.1 & temp.empirical_distribution<0.9])
      temp.plotting_autocorrelation_matrix[temp.plotting_autocorrelation_matrix<temp.min_z]<-temp.min_z
      temp.plotting_autocorrelation_matrix[temp.plotting_autocorrelation_matrix>temp.max_z]<-temp.max_z
      temp.min_autocorrelation_value=min(temp.plotting_autocorrelation_matrix)
      temp.plotting_z<-(temp.plotting_autocorrelation_matrix-temp.min_autocorrelation_value)
      temp.plotting_z<-temp.plotting_z/max(temp.plotting_z)*100
      temp.z_bounds<-c(min(temp.plotting_z),max(temp.plotting_z))#c(0,100)
      temp.z_label<-paste(temp.z_label," above minimum",sep="")
      temp.downsampled_z<-matrix(0,nrow=temp.num_downsampled,ncol=temp.num_downsampled)
      temp.step_size=floor(temp.N/max_size.par)
      temp.index_sequence<-seq(from=1,to=temp.N,by=temp.step_size)
      temp.downsampled_z<-temp.plotting_z[temp.index_sequence,temp.index_sequence]
      heat_map.function(temp.times,temp.times-temp.times[1],temp.downsampled_z,z_bounds.par=temp.z_bounds,
                        abscissa_quantity.par=abscissa_quantity.par,abscissa_units.par=abscissa_units.par,
                        ordinates_quantity.par=ordinates_quantity.par,ordinates_units.par=ordinates_units.par,
                        heights_quantity.par=temp.z_label,heights_units.par="% of maximum value",pdf_title.par="LAPTV_ACVS.pdf")
    }
    temp.variances<-rep(0,temp.N)
    if(!is.na(cyclic_frequency_indices.par)){
      temp.autocorrelation_matrix<-temp.autocorrelation_matrix[1:temp.N,]
      temp.variances<-temp.autocorrelation_matrix[,1]
    } else{
      temp.variances<-rep(temp.autocorrelation_matrix[1],temp.N)
    }
    temp.negative_variance_indices<-which(temp.variances<0)
    temp.variances[temp.negative_variance_indices]<-0
    #Ends reconstruction for the variance sequence.
    if(length(which(temp.variances==0))<temp.N){
      temp.variances_ends_reconstruction_label<-"Variances_Ends_Reconstruction"
      cat("directory_label.par\n")
      print(directory_label.par)
      temp.variances<-ends_interpolation.function(ts.par=temp.variances,first_time.par=first_time.par,
                                                  ts_interp_bool.par=ts_interp_ends_bool.par,mdss_bool.par=mdss_bool.par,gn_bool.par=gn_bool_ends.par,
                                                  num_iterations.par=num_iterations.par,max_length.par=max_length.par,
                                                  main_directory_string.par=main_directory_string.par,
                                                  directory_label.par=directory_label.par,
                                                  old_directory.par=old_directory_interp.par,
                                                  revised_specific_directory_string.par=revised_specific_directory_string.par,
                                                  measured_quantity.par=measured_quantity.par)
      temp.variances[temp.variances<0]<-0
    }
    temp.sd_vector<-sqrt(temp.variances)
    temp.LB_vector<-means.par-normal_quantile.par*temp.sd_vector
    temp.UB_vector<-means.par+normal_quantile.par*temp.sd_vector
    temp.plotting_times<-times.par
    x.list<-list(temp.plotting_times,temp.plotting_times,temp.plotting_times)
    y.list<-list(temp.LB_vector,temp.UB_vector,means.par)
    temp.abscissa_string<-paste(abscissa_quantity.par,", in seconds since ",
                                round(first_time.par/60,ceil(log10(first_time.par/60-floor(first_time.par/60)))+1)," min",sep="")
    temp.ordinate_string<-paste(laptv_ordinates_quantity.par,", in ",laptv_ordinates_units.par,sep="")
    plot.graph(x.list,y.list,plot_title.par=plot_titles.par,
               x_label.par=temp.abscissa_string,y_label.par=temp.ordinate_string,pdf_title.par="Training_Performance.pdf",col.par=c("grey80","grey80",1))
    temp.list<-list.append(temp.list,
                           out.autocorrelation_matrix=temp.autocorrelation_matrix,
                           out.cyclic_correlation_matrix=temp.cyclic_correlation_matrix,
                           out.variances=temp.variances,
                           out.sd_vector=temp.sd_vector)
  }
  else{
    plot.graph(list(temp.lags),list(temp.mt_autocorrelation_coefficients),
               x_label.par="Lag, in seconds",y_label.par=temp.z_label,pdf_title.par="LAPTV_ACVS.pdf")
  }
  return(temp.list)
}



sarima.function<-function(epoch_harmonic_reconstruction.par,epoch_time_indices_vector.par,auto_arima_object.par,
                          auto_arima_coefficients.par,harmonic_residuals.par,arima_residuals.par,
                          mean_estimate.par,innovations.par=NULL,
                          arima_mean.par=0,sigma2.par=1,ar_order.par=NA,ma_order.par=NA,seasonal_periods.par=0,
                          nonseasonal_periods.par=0){
  temp.N_original=length(epoch_harmonic_reconstruction.par)
  temp.N_truncated=length(epoch_time_indices_vector.par)
  temp.num_previous_times=min(epoch_time_indices_vector.par)-1
  temp.num_following_times=temp.N_original-epoch_time_indices_vector.par[length(epoch_time_indices_vector.par)]
  temp.num_arima_differences=length(nonseasonal_periods.par)
  if(temp.num_arima_differences>0){
    seasonal_periods.par<-unique(seasonal_periods.par)
    temp.num_unit_cyclic_periods=length(which(seasonal_periods.par==1))
    if(temp.num_unit_cyclic_periods<temp.num_arima_differences){
      seasonal_periods.par<-c(seasonal_periods.par,rep(1,temp.num_arima_differences-temp.num_unit_cyclic_periods))
    }
    seasonal_periods.par<-sort(seasonal_periods.par)
  }
  temp.ar_coefficients=0
  if(ar_order.par>0){
    temp.ar_coefficients<-auto_arima_coefficients.par[1:ar_order.par]
  }
  temp.ma_coefficients=0
  if(ma_order.par>0){
    temp.ma_coefficients<-auto_arima_coefficients.par[1:ma_order.par+ar_order.par]
  }
  #https://pkg.robjhyndman.com/forecast/reference/simulate.ets.html
  temp.previous_realizations<-c()
  if(temp.num_previous_times>0){
    temp.previous_realizations<-innovations.par[1]
    if(temp.num_previous_times>1){
      temp.previous_realizations<-sample(innovations.par[1:temp.num_previous_times])
    }
  }
  temp.following_realizations<-c()
  if(temp.num_following_times>0){
    temp.following_realizations<-sample(innovations.par[length(innovations.par)-1:temp.num_following_times])
  }
  innovations.par<-c(innovations.par,temp.following_realizations)
  temp.arima_ts_object<-simulate(auto_arima_object.par,innov=sample(innovations.par[1:temp.N_truncated]))
  temp.arima_ts<-c(temp.previous_realizations,as.numeric(temp.arima_ts_object))+arima_mean.par
  temp.num_arima_reconstructions=length(temp.arima_ts)
  temp.arima_ts<-(temp.arima_ts-mean(temp.arima_ts))*
    sqrt(crossprod(arima_residuals.par-mean(arima_residuals.par))/crossprod(temp.arima_ts-mean(temp.arima_ts))*
           length(temp.arima_ts)/length(arima_residuals.par))+mean(arima_residuals.par)
  temp.sarima_ts<-temp.arima_ts
  temp.num_seasonal_periods=length(seasonal_periods.par)
  if(temp.num_seasonal_periods>0){
    temp.original_sarima_size=length(epoch_time_indices_vector.par)
    temp.start_index=0
    for(temp.l in rev(1:temp.num_seasonal_periods)){
      temp.K_value=seasonal_periods.par[temp.l]
      temp.start_index=temp.start_index+temp.K_value
      temp.previous_sarima<-temp.sarima_ts
      for(temp.u in temp.start_index+1:(temp.num_arima_reconstructions-temp.start_index)){
        temp.sarima_ts[temp.u]=temp.previous_sarima[temp.u]+temp.sarima_ts[temp.u-temp.K_value]
      }
    }
  }
  temp.sarima_ts<-(temp.sarima_ts-mean(temp.sarima_ts))*
    sqrt(crossprod(harmonic_residuals.par-mean(temp.arima_residuals))/crossprod(temp.sarima_ts-mean(temp.sarima_ts))*
           length(temp.sarima_ts)/length(harmonic_residuals.par))+mean(harmonic_residuals.par)
  temp.sarima_size=length(temp.sarima_ts)
  temp.epoch_ts_reconstruction<-temp.sarima_ts+epoch_harmonic_reconstruction.par+mean_estimate.par
  temp.list<-list(out.arima_ts=temp.arima_ts,
                  out.sarima_ts=temp.sarima_ts,
                  out.epoch_ts_reconstruction=temp.epoch_ts_reconstruction)
  return(temp.list)
}


sarima_bootstrap.function<-function(epoch_harmonic_reconstruction.par,epoch_time_indices_vector.par,auto_arima_object.par,
                                    harmonic_residuals.par,arima_residuals.par,
                                    auto_arima_coefficients.par,mean_estimate.par,innovations.par=NULL,
                                    arima_mean.par=0,sigma2.par=1,ar_order.par=NA,ma_order.par=NA,seasonal_periods.par=0,nonseasonal_periods.par=0,
                                    num_realizations.par=300){
  temp.num_innovations=length(innovations.par)
  temp.N_value=length(epoch_harmonic_reconstruction.par)
  temp.reconstruction_realizations<-matrix(0,nrow=temp.N_value,ncol=num_realizations.par)
  for(temp.i in 1:num_realizations.par){
    #Sample with replacement.
    set.seed(temp.i+1)
    temp.resampled_innovations<-sample(innovations.par)
    temp.sarima_object<-sarima.function(epoch_harmonic_reconstruction.par=epoch_harmonic_reconstruction.par,
                                        epoch_time_indices_vector.par=epoch_time_indices_vector.par,auto_arima_object.par=auto_arima_object.par,
                                        auto_arima_coefficients.par=auto_arima_coefficients.par,
                                        harmonic_residuals.par,arima_residuals.par=arima_residuals.par,
                                        mean_estimate.par=mean_estimate.par,
                                        innovations.par=temp.resampled_innovations,
                                        arima_mean.par=arima_mean.par,sigma2.par=sigma2.par,ar_order.par=ar_order.par,ma_order.par=ma_order.par,
                                        seasonal_periods.par=seasonal_periods.par,nonseasonal_periods.par=nonseasonal_periods.par)
    temp.reconstruction_realizations[,temp.i]<-temp.sarima_object$out.epoch_ts_reconstruction
  }
  temp.reconstruction_averages<-rowMeans(temp.reconstruction_realizations)
  temp.reconstruction_residual_matrix<-temp.reconstruction_realizations
  for(temp.i in 1:num_realizations.par){
    temp.reconstruction_residual_matrix[,temp.i]<-(temp.reconstruction_residual_matrix[,temp.i]-temp.reconstruction_averages)^2
  }
  temp.reconstruction_rss_vector<-rowSums(temp.reconstruction_residual_matrix)
  temp.reconstruction_bs_se_vector<-sqrt(temp.reconstruction_rss_vector/(num_realizations.par-1))
  for(temp.i in 1:temp.N_value){
    temp.reconstruction_realizations[temp.i,]<-sort(temp.reconstruction_realizations[temp.i,])
  }
  temp.empirical_quantile_LB=ceil(0.05*num_realizations.par)
  temp.empirical_quantile_LB=max(1,temp.empirical_quantile_LB)
  temp.empirical_quantile_LB=min(num_realizations.par,temp.empirical_quantile_LB)
  temp.empirical_quantile_UB=floor(0.95*num_realizations.par)
  temp.empirical_quantile_UB=max(1,temp.empirical_quantile_UB)
  temp.empirical_quantile_UB=min(num_realizations.par,temp.empirical_quantile_UB)
  temp.empirical_quantile_median=round(0.5*num_realizations.par)
  temp.empirical_quantile_median=max(1,temp.empirical_quantile_median)
  temp.empirical_quantile_median=min(num_realizations.par,temp.empirical_quantile_median)
  temp.reconstruction_LB<-temp.reconstruction_realizations[,temp.empirical_quantile_LB]
  temp.reconstruction_UB<-temp.reconstruction_realizations[,temp.empirical_quantile_UB]
  temp.reconstruction_medians<-temp.reconstruction_realizations[,temp.empirical_quantile_median]
  temp.list<-list(out.reconstruction_medians=temp.reconstruction_medians,
                  out.reconstruction_LB=temp.reconstruction_LB,
                  out.reconstruction_UB=temp.reconstruction_UB,
                  out.bs_se_vector=temp.reconstruction_bs_se_vector)
  return(temp.list)
}



sarima_construction.function<-function(epoch_harmonic_reconstruction.par,epoch_time_indices_vector.par,auto_arima_object.par,
                                       auto_arima_coefficients.par,harmonic_residuals.par,arima_residuals.par,
                                       mean_estimate.par,
                                       arima_mean.par=0,sigma2.par=1,ar_order.par=NA,ma_order.par=NA,seasonal_periods.par=0,nonseasonal_periods.par=0,
                                       num_realizations.par=300,seeds.par=c(1,2),
                                       student_dof.par=5,distribution_string.par="Gaussian",uniform_numbers.par=NA,crude_rv_num_samples.par=NA){
  cat(distribution_string.par,"\n")
  temp.N_original=length(epoch_harmonic_reconstruction.par)
  temp.num_previous_times=min(epoch_time_indices_vector.par)-1
  temp.num_following_times=temp.N_original-epoch_time_indices_vector.par[length(epoch_time_indices_vector.par)]
  temp.N_value=max(length(epoch_time_indices_vector.par),temp.num_previous_times,temp.num_following_times)
  temp.innovations_object<-multitaper_innovations_RNG.function(mt_autocorrelation_coefficients.par=NA,
                                                               N.par=temp.N_value,mean.par=0,variance.par=sigma2.par,seeds.par=seeds.par,
                                                               student_dof.par=student_dof.par,distribution_string.par=distribution_string.par,
                                                               uniform_numbers.par=uniform_numbers.par,crude_rv_num_samples.par=crude_rv_num_samples.par)
  temp.innovations_sequence<-temp.innovations_object$out.innovations_sequence
  temp.uniform_numbers<-temp.innovations_object$out.uniform_numbers
  #Compute the SARIMA with the cosine reconstruction included.
  temp.sarima_object<-sarima_bootstrap.function(epoch_harmonic_reconstruction.par=epoch_harmonic_reconstruction.par,
                                                epoch_time_indices_vector.par=epoch_time_indices_vector.par,auto_arima_object.par=auto_arima_object.par,
                                                auto_arima_coefficients.par=auto_arima_coefficients.par,
                                                harmonic_residuals.par=harmonic_residuals.par,arima_residuals.par=arima_residuals.par,
                                                mean_estimate.par=mean_estimate.par,
                                                innovations.par=temp.innovations_sequence,
                                                arima_mean.par=arima_mean.par,sigma2.par=sigma2.par,ar_order.par=ar_order.par,ma_order.par=ma_order.par,
                                                seasonal_periods.par=seasonal_periods.par,nonseasonal_periods.par=nonseasonal_periods.par,
                                                num_realizations.par=num_realizations.par)
  temp.reconstruction_medians<-temp.sarima_object$out.reconstruction_medians
  temp.reconstruction_LB<-temp.sarima_object$out.reconstruction_LB
  temp.reconstruction_UB<-temp.sarima_object$out.reconstruction_UB
  temp.reconstruction_se<-temp.sarima_object$out.bs_se_vector
  temp.list<-list(out.innovations_sequence=temp.innovations_sequence,
                  out.reconstruction_medians=temp.reconstruction_medians,
                  out.reconstruction_LB=temp.reconstruction_LB,
                  out.reconstruction_UB=temp.reconstruction_UB,
                  out.reconstruction_se=temp.reconstruction_se,
                  out.uniform_numbers=temp.uniform_numbers)
  return(temp.list)
}


sarima_analysis.function<-function(epoch_harmonic_reconstruction.par,epoch_time_indices_vector.par,ts.par,auto_arima_object.par,
                                   auto_arima_coefficients.par,harmonic_residuals.par=harmonic_residuals.par,arima_residuals.par,
                                   mean_estimate.par,
                                   arima_mean.par=0,sigma2.par=1,ar_order.par=NA,ma_order.par=NA,seasonal_periods.par=0,nonseasonal_periods.par=0,
                                   num_realizations.par=300,student_dof.par=5,
                                   nominal_distribution_string.par="Gaussian",alternative_distribution_strings.par=NA,crude_rv_num_samples.par=NA,
                                   time_efficieny_bool.par=FALSE){
  temp.N=length(ts.par)
  if(time_efficieny_bool.par==TRUE){
    if(temp.N>5e3){
      num_realizations.par=30
      #if(temp.N>1e5 || !is.na(seasonal_periods.par)){
      #  alternative_distribution_strings.par=NA
      #}
    }
  }
  #Simulate the SARIMA process.
  temp.uniform_numbers=NA
  temp.running_seeds<-c(1,2)
  temp.sarima_construction_object<-sarima_construction.function(epoch_harmonic_reconstruction.par=epoch_harmonic_reconstruction.par,
                                                                epoch_time_indices_vector.par=epoch_time_indices_vector.par,
                                                                auto_arima_object.par=auto_arima_object.par,
                                                                auto_arima_coefficients.par=auto_arima_coefficients.par,
                                                                harmonic_residuals.par=harmonic_residuals.par,arima_residuals.par=arima_residuals.par,
                                                                mean_estimate.par=mean_estimate.par,
                                                                arima_mean.par=arima_mean.par,sigma2.par=sigma2.par,
                                                                ar_order.par=ar_order.par,ma_order.par=ma_order.par,
                                                                seasonal_periods.par=seasonal_periods.par,nonseasonal_periods.par=nonseasonal_periods.par,
                                                                num_realizations.par=num_realizations.par,
                                                                seeds.par=temp.running_seeds,student_dof.par=student_dof.par,
                                                                distribution_string.par=nominal_distribution_string.par,
                                                                uniform_numbers.par=temp.uniform_numbers,
                                                                crude_rv_num_samples.par=crude_rv_num_samples.par)
  temp.reconstruction_medians<-temp.sarima_construction_object$out.reconstruction_medians
  temp.reconstruction_LB<-temp.sarima_construction_object$out.reconstruction_LB
  temp.reconstruction_UB<-temp.sarima_construction_object$out.reconstruction_UB
  temp.reconstruction_se<-temp.sarima_construction_object$out.reconstruction_se
  temp.num_reconstructed=length(temp.reconstruction_medians)
  #Initialize the optimal summary-statistic vectors in the case that model-uncertainty analysis is to be performed.
  temp.min_reconstruction_LB<-temp.reconstruction_LB
  temp.min_reconstruction_UB<-temp.reconstruction_UB
  temp.max_reconstruction_LB<-temp.reconstruction_LB
  temp.max_reconstruction_UB<-temp.reconstruction_UB
  temp.min_reconstruction_median<-temp.reconstruction_medians
  temp.max_reconstruction_median<-temp.reconstruction_medians
  if(!is.na(alternative_distribution_strings.par)){
    temp.num_list_elements=length(alternative_distribution_strings.par)
    for(temp.i in 1:temp.num_list_elements){
      temp.distribution_string<-alternative_distribution_strings.par[temp.i]
      temp.sarima_construction_object<-sarima_construction.function(epoch_harmonic_reconstruction.par=epoch_harmonic_reconstruction.par,
                                                                    epoch_time_indices_vector.par=epoch_time_indices_vector.par,
                                                                    auto_arima_object.par=auto_arima_object.par,
                                                                    auto_arima_coefficients.par=auto_arima_coefficients.par,
                                                                    harmonic_residuals.par=harmonic_residuals.par,arima_residuals.par=arima_residuals.par,
                                                                    mean_estimate.par=mean_estimate.par,
                                                                    arima_mean.par=arima_mean.par,sigma2.par=sigma2.par,
                                                                    ar_order.par=ar_order.par,ma_order.par=ma_order.par,
                                                                    seasonal_periods.par=seasonal_periods.par,
                                                                    nonseasonal_periods.par=nonseasonal_periods.par,
                                                                    num_realizations.par=num_realizations.par,
                                                                    seeds.par=temp.running_seeds,student_dof.par=student_dof.par,
                                                                    distribution_string.par=temp.distribution_string,
                                                                    uniform_numbers.par=temp.uniform_numbers,
                                                                    crude_rv_num_samples.par=crude_rv_num_samples.par)
      temp.medians<-temp.sarima_construction_object$out.reconstruction_medians
      temp.LB<-temp.sarima_construction_object$out.reconstruction_LB
      temp.UB<-temp.sarima_construction_object$out.reconstruction_UB
      #Update the lowest and highest confidence bounds.
      for(temp.j in 1:temp.num_reconstructed){
        #LB computations.
        if(temp.min_reconstruction_LB[temp.j]>temp.LB[temp.j]){
          temp.min_reconstruction_LB[temp.j]=temp.LB[temp.j]
        }
        if(temp.max_reconstruction_LB[temp.j]<temp.LB[temp.j]){
          temp.max_reconstruction_LB[temp.j]=temp.LB[temp.j]
        }
        #Median computations.
        if(temp.min_reconstruction_median[temp.j]>temp.medians[temp.j]){
          temp.min_reconstruction_median[temp.j]=temp.medians[temp.j]
        }
        if(temp.max_reconstruction_median[temp.j]<temp.medians[temp.j]){
          temp.max_reconstruction_median[temp.j]=temp.medians[temp.j]
        }
        #UB computations.
        if(temp.min_reconstruction_UB[temp.j]>temp.UB[temp.j]){
          temp.min_reconstruction_UB[temp.j]=temp.UB[temp.j]
        }
        if(temp.max_reconstruction_UB[temp.j]<temp.UB[temp.j]){
          temp.max_reconstruction_UB[temp.j]=temp.UB[temp.j]
        }
      }
      #Update the uniform numbers with the ones that have just been sampled to avoid having to generate a new set every time.  Update the seeds used
      #for the "sample" function used to permute the original collection of uniform numbers.
      temp.running_seeds<-running_seed.function(temp.running_seeds)
    }
  }
  else{
    temp.min_reconstruction_median<-NA
    temp.max_reconstruction_median<-NA
    temp.min_reconstruction_LB<-NA
    temp.max_reconstruction_LB<-NA
    temp.min_reconstruction_UB<-NA
    temp.max_reconstruction_UB<-NA
  }
  temp.list<-list(out.reconstruction_medians=temp.reconstruction_medians,
                  out.reconstruction_LB=temp.reconstruction_LB,
                  out.reconstruction_UB=temp.reconstruction_UB,
                  out.min_reconstruction_median=temp.min_reconstruction_median,
                  out.max_reconstruction_median=temp.max_reconstruction_median,
                  out.min_reconstruction_LB=temp.min_reconstruction_LB,
                  out.min_reconstruction_UB=temp.min_reconstruction_UB,
                  out.max_reconstruction_LB=temp.max_reconstruction_LB,
                  out.max_reconstruction_UB=temp.max_reconstruction_UB)
  return(temp.list)
}





laptv_bootstrap.function<-function(innovations_sequence.par,time_sequence.par,N_truncated.par,frequencies.par,
                                  transient_offset.par,sampling_rate.par=1,cyclic_frequency_indices.par=NA,ar_coefficients.par=0,cosine_reconstruction.par=NA,
                                  num_realizations.par=300,first_time.par=0){
  temp.num_innovations=length(innovations_sequence.par)
  temp.num_reconstruction=temp.num_innovations-transient_offset.par
  temp.laptv_realizations<-matrix(0,nrow=N_truncated.par,ncol=num_realizations.par)
  temp.laptv_times<-c()
  for(temp.i in 1:num_realizations.par){
    cat(temp.i," out of ",num_realizations.par,"\n")
    set.seed(temp.i+1)
    #Sample with replacement.
    temp.resampled_innovations<-sample(innovations_sequence.par)
    temp.laptv_object<-laptv.function(innovations_sequence.par=temp.resampled_innovations,time_sequence.par=time_sequence.par,frequencies.par=frequencies.par,
                                      transient_offset.par=transient_offset.par,cyclic_frequency_indices.par=cyclic_frequency_indices.par,
                                      ar_coefficients.par=ar_coefficients.par,sampling_rate.par=sampling_rate.par,first_time.par=first_time.par)
    if(temp.i==1){
      temp.laptv_times<-temp.laptv_object$out.laptv_times
    }
    temp.offset=(temp.num_reconstruction-N_truncated.par)/2
    if(temp.i==1){
      temp.laptv_times<-temp.laptv_times[1:N_truncated.par]
    }
    if(!is.na(cosine_reconstruction.par)){
      temp.laptv_realizations[,temp.i]<-temp.laptv_object$out.laptv_output[temp.offset+1:N_truncated.par]+cosine_reconstruction.par
    }
    else{
      temp.laptv_realizations[,temp.i]<-temp.laptv_object$out.laptv_output[temp.offset+1:N_truncated.par]
    }
  }
  temp.laptv_averages<-rowMeans(temp.laptv_realizations)
  temp.laptv_residual_matrix<-temp.laptv_realizations
  for(temp.i in 1:num_realizations.par){
    temp.laptv_residual_matrix[,temp.i]<-(temp.laptv_residual_matrix[,temp.i]-temp.laptv_averages)^2
  }
  temp.rss_vector<-rowSums(temp.laptv_residual_matrix)
  temp.bs_se_vector<-sqrt(temp.rss_vector/(num_realizations.par-1))
  #temp.student_terms=qt(0.95,num_realizations.par-1)*temp.bs_se_vector
  #temp.laptv_LB<-temp.laptv_averages-temp.student_terms
  #temp.laptv_UB<-temp.laptv_averages+temp.student_terms
  for(temp.i in 1:N_truncated.par){
    temp.laptv_realizations[temp.i,]<-sort(temp.laptv_realizations[temp.i,])
  }
  temp.empirical_quantile_LB=ceil(0.05*num_realizations.par)
  temp.empirical_quantile_LB=max(1,temp.empirical_quantile_LB)
  temp.empirical_quantile_LB=min(num_realizations.par,temp.empirical_quantile_LB)
  temp.empirical_quantile_UB=floor(0.95*num_realizations.par)
  temp.empirical_quantile_UB=max(1,temp.empirical_quantile_UB)
  temp.empirical_quantile_UB=min(num_realizations.par,temp.empirical_quantile_UB)
  temp.empirical_quantile_median=round(0.5*num_realizations.par)
  temp.empirical_quantile_median=max(1,temp.empirical_quantile_median)
  temp.empirical_quantile_median=min(num_realizations.par,temp.empirical_quantile_median)
  temp.laptv_LB<-temp.laptv_realizations[,temp.empirical_quantile_LB]
  temp.laptv_UB<-temp.laptv_realizations[,temp.empirical_quantile_UB]
  temp.laptv_averages<-temp.laptv_realizations[,temp.empirical_quantile_median]
  temp.list<-list(out.laptv_averages=temp.laptv_averages,
                  out.laptv_LB=temp.laptv_LB,
                  out.laptv_UB=temp.laptv_UB,
                  out.laptv_times=temp.laptv_times,
                  out.bs_se_vector=temp.bs_se_vector)
  return(temp.list)
}


laptv_construction.function<-function(mt_autocorrelation_coefficients.par,time_sequence.par,frequencies.par,N.par,N_truncated.par,
                                      cyclic_frequency_indices.par=NA,cosine_reconstruction.par=NA,ar_coefficients.par=0,sampling_rate.par=1,
                                      mean.par=0,variance.par=1,num_innovations.par=300,seeds.par=c(1,2),correlation_memory_threshold.par=0.01,
                                      student_dof.par=5,distribution_string.par="Gaussian",uniform_numbers.par=NA,crude_rv_num_samples.par=NA,
                                      first_time.par=0){
  cat(distribution_string.par,"\n")
  temp.innovations_object<-multitaper_innovations_RNG.function(mt_autocorrelation_coefficients.par=mt_autocorrelation_coefficients.par,
                                                               N.par=N.par,mean.par=mean.par,variance.par=variance.par,seeds.par=seeds.par,
                                                               correlation_memory_threshold.par=correlation_memory_threshold.par,
                                                               student_dof.par=student_dof.par,distribution_string.par=distribution_string.par,
                                                               uniform_numbers.par=uniform_numbers.par,crude_rv_num_samples.par=crude_rv_num_samples.par)
  temp.innovations_sequence<-temp.innovations_object$out.innovations_sequence
  temp.transient_offset=temp.innovations_object$out.transient_offset
  temp.uniform_numbers<-temp.innovations_object$out.uniform_numbers
  #Compute the LAPTV with the cosine reconstruction included.
  temp.laptv_object<-laptv_bootstrap.function(innovations_sequence.par=temp.innovations_sequence,time_sequence.par=time_sequence.par,
                                              N_truncated.par=N_truncated.par,frequencies.par=frequencies.par,transient_offset.par=temp.transient_offset,
                                              sampling_rate.par=sampling_rate.par,cyclic_frequency_indices.par=cyclic_frequency_indices.par,
                                              ar_coefficients.par=ar_coefficients.par,
                                              cosine_reconstruction.par=cosine_reconstruction.par,num_realizations.par=num_innovations.par,
                                              first_time.par=first_time.par)
  temp.laptv_averages<-temp.laptv_object$out.laptv_averages
  temp.laptv_LB<-temp.laptv_object$out.laptv_LB
  temp.laptv_UB<-temp.laptv_object$out.laptv_UB
  temp.laptv_se<-temp.laptv_object$out.bs_se_vector
  temp.laptv_times<-temp.laptv_object$out.laptv_times
  temp.list<-list(out.innovations_sequence=temp.innovations_sequence,
                  out.transient_offset=temp.transient_offset,
                  out.laptv_averages=temp.laptv_averages,
                  out.laptv_LB=temp.laptv_LB,
                  out.laptv_UB=temp.laptv_UB,
                  out.laptv_times=temp.laptv_times,
                  out.uniform_numbers=temp.uniform_numbers,
                  out.laptv_se=temp.laptv_se)
  return(temp.list)
}


plot_laptv.function<-function(ts.par,outlier_thresholds.par=NA,laptv_averages.par,laptv_LB.par,laptv_UB.par,time_sequence.par,laptv_times.par,
                              laptv_min_average.par=NA,laptv_max_average.par=NA,laptv_min_LB.par=NA,laptv_max_LB.par=NA,laptv_min_UB.par=NA,
                              laptv_max_UB.par=NA,
                              measure_quantity_string.par="Measured quantity",measure_units_string.par="units",pdf_title.par="LAPTV_Reconstruction.pdf",
                              min_y.par=NA,max_y.par=NA,first_time.par=0){
  temp.x_list<-c()
  temp.y_list<-c()
  temp.plotting_laptv_times<-plotting.sampled_vector(laptv_times.par)
  temp.plotting_laptv_LB<-plotting.sampled_vector(laptv_LB.par)
  temp.plotting_laptv_UB<-plotting.sampled_vector(laptv_UB.par)
  temp.plotting_laptv_averages<-plotting.sampled_vector(laptv_averages.par)
  temp.plotting_times<-plotting.sampled_vector(time_sequence.par-time_sequence.par[1])
  temp.plotting_ts<-plotting.sampled_vector(ts.par)
  temp.min_y=0
  temp.max_y=0
  if(is.na(laptv_min_average.par)==TRUE){
    temp.x_list<-list(temp.plotting_laptv_times,temp.plotting_laptv_times,temp.plotting_laptv_times,temp.plotting_times)
    temp.y_list<-list(temp.plotting_laptv_LB,temp.plotting_laptv_UB,temp.plotting_laptv_averages,temp.plotting_ts)
    temp.all_y<-unlist(temp.y_list)
    temp.min_y=min(temp.all_y)
    temp.max_y=max(temp.all_y)
    if(!is.na(min_y.par) & !is.na(max_y.par)){
      temp.min_y=min(temp.min_y,min_y.par)
      temp.max_y=max(temp.max_y,max_y.par)
    }
    plot.graph(temp.x_list,temp.y_list,x_label.par=paste("Time, in seconds beyond ",round(time_sequence.par[1]/60,3),sep=""),
               y_label.par=paste(measure_quantity_string.par,", in ",measure_units_string.par,sep=""),
               plot_title.par="",pdf_title.par=pdf_title.par,col.par=c("grey75","grey75","grey50",1),lty.par=c(1,1,1,1),
               min_y.par=temp.min_y,max_y.par=temp.max_y)
  }
  else{
    temp.plotting_min_laptv_LB<-plotting.sampled_vector(laptv_min_LB.par)
    temp.plotting_max_laptv_LB<-plotting.sampled_vector(laptv_max_LB.par)
    temp.plotting_min_laptv_UB<-plotting.sampled_vector(laptv_min_UB.par)
    temp.plotting_max_laptv_UB<-plotting.sampled_vector(laptv_max_UB.par)
    temp.plotting_min_laptv_averages<-plotting.sampled_vector(laptv_min_average.par)
    temp.plotting_max_laptv_averages<-plotting.sampled_vector(laptv_max_average.par)
    temp.x_list<-list(#temp.plotting_laptv_times,temp.plotting_laptv_times,
                      temp.plotting_laptv_times,
                      #temp.plotting_laptv_times,temp.plotting_laptv_times,
                      temp.plotting_laptv_times,
                      #temp.plotting_laptv_times,temp.plotting_laptv_times,
                      temp.plotting_laptv_times,temp.plotting_laptv_times,
                      #temp.plotting_laptv_times,
                      temp.plotting_times)
    temp.y_list<-list(#outlier_thresholds.par[,1],outlier_thresholds.par[,2],
                      temp.plotting_min_laptv_LB,
                      #temp.plotting_max_laptv_LB,temp.plotting_min_laptv_UB,
                      temp.plotting_max_laptv_UB,
                      #temp.plotting_laptv_LB,temp.plotting_laptv_UB,
                      temp.plotting_min_laptv_averages,temp.plotting_max_laptv_averages,
                      #temp.plotting_laptv_averages,
                      temp.plotting_ts)
    temp.all_y<-unlist(temp.y_list)
    temp.min_y=min(temp.all_y)
    temp.max_y=max(temp.all_y)
    if(!is.na(min_y.par) & !is.na(max_y.par)){
      temp.min_y=min(temp.min_y,min_y.par)
      temp.max_y=max(temp.max_y,max_y.par)
    }
    temp.outlier_min_col="grey50"
    temp.outlier_max_col="grey50"
    temp.min_LB_col="grey75"
    temp.max_LB_col="grey75"
    temp.min_UB_col="grey75"
    temp.max_UB_col="grey75"
    temp.nominal_LB_col="grey50"
    temp.nominal_UB_col="grey50"
    temp.min_averages_col="grey90"
    temp.max_averages_col="grey90"
    temp.nominal_averages_col="grey50"
    temp.ts_col=1
    temp.colours<-c(#temp.outlier_min_col,temp.outlier_max_col,
      temp.min_LB_col,
      #temp.max_LB_col,temp.min_UB_col,
      temp.max_UB_col,
      #temp.nominal_LB_col,temp.nominal_UB_col,
      temp.min_averages_col,temp.max_averages_col,
      #temp.nominal_averages_col,
      temp.ts_col)
    temp.num_curves=length(temp.colours)
    plot.ts_model_uncertainty(temp.x_list,temp.y_list,
                              x_label.par=paste("Time, in seconds beyond ",round_general.function(first_time.par),sep=""),
                              y_label.par=paste(measure_quantity_string.par,", in ",measure_units_string.par,sep=""),
                              plot_title.par="",pdf_title.par=paste("Model_Uncertainty_",pdf_title.par,sep=""),
                              col.par=temp.colours,lty.par=rep(1,temp.num_curves),lwd.par=c(rep(1,temp.num_curves-1),2),
                              min_y.par=temp.min_y,max_y.par=temp.max_y)
    sink(paste("Model_Uncertainty_",str_remove(pdf_title.par,".pdf"),"_Statistics.txt",sep=""), append=FALSE, split=FALSE)
    cat("time\tmin_LB\tmax_UB\tmin_average\tmax_average\n")
    for(temp.i in 1:length(temp.plotting_laptv_times)){
      cat(temp.plotting_laptv_times[temp.i],"\t",temp.plotting_min_laptv_LB[temp.i],"\t",temp.plotting_max_laptv_UB[temp.i],"\t",
          temp.plotting_min_laptv_averages[temp.i],"\t",temp.plotting_max_laptv_averages[temp.i],"\n")
    }
    sink()
  }
  temp.list<-list(out.min_y=temp.min_y,
                  out.max_y=temp.max_y,
                  out.plotting_laptv_times=temp.plotting_laptv_times,
                  out.plotting_min_laptv_LB=temp.plotting_min_laptv_LB,
                  out.plotting_max_laptv_UB=temp.plotting_max_laptv_UB,
                  out.plotting_min_laptv_averages=temp.plotting_min_laptv_averages,
                  out.plotting_max_laptv_averages=temp.plotting_max_laptv_averages,
                  out.plotting_ts=temp.plotting_ts)
  return(temp.list)
}


laptv_analysis.function<-function(spectral_power_estimates.par,frequencies.par,time_sequence.par,ts.par,all_times.par,
                                  N_truncated.par,cyclic_frequency_indices.par=NA,cosine_reconstruction.par=NA,NW.par=5,
                                  sampling_rate.par=1,first_time.par=0,
                                  num_realizations.par=300,student_dof.par=5,
                                  nominal_distribution_string.par="Gaussian",alternative_distribution_strings.par=NA,
                                  correlation_memory_threshold.par=0.01,crude_rv_num_samples.par=NA,
                                  measure_quantity_string.par="Measured quantity",measure_units_string.par="units",pdf_title.par="LAPTV_Reconstruction.pdf",
                                  prewhitening_bool.par=FALSE,plot_acvs_bool.par=FALSE,plot_acvs.bool=FALSE,prewhitening_verbose_bool.par=FALSE,
                                  min_y.par=NA,max_y.par=NA,time_efficieny_bool.par=FALSE){
  temp.N=length(ts.par)
  if(time_efficieny_bool.par==TRUE){
    if(N_truncated.par>5e3){
      num_realizations.par=30
      if(N_truncated.par>1e5 || !is.na(cyclic_frequency_indices.par)){
        alternative_distribution_strings.par=NA
      }
    }
  }
  #Whiten the sequence of spectral-power estimates.
  #Compute the ACVS.
  temp.M2=length(spectral_power_estimates.par)
  temp.M=2*(temp.M2-1)
  temp.mt_acvs_object<-multitaper_acvs_analysis.function(spectral_power_estimates.par,NW.par=NW.par,
                                                         sampling_rate.par=sampling_rate.par,plot_bool.par=plot_acvs.bool)
  temp.mt_acvs<-temp.mt_acvs_object$out.mt_acvs
  temp.mt_autocorrelation_coefficients<-temp.mt_acvs_object$out.autocorrelation_coefficient_sequence
  temp.process_variance<-temp.mt_acvs_object$out.process_variance
  temp.prewhitened_spectrum<-spectral_power_estimates.par
  temp.ar_coefficients=0
  temp.ar_order=0
  if(prewhitening_bool.par==TRUE){
    #Prewhiten the spectral-power estimates.
    temp.prewhitening_object<-prewhitening_algorithm.function(spectral_power_estimates.par,temp.mt_autocorrelation_coefficients,frequencies.par,temp.N,
                                                              verbose.par=prewhitening_verbose_bool.par)
    temp.ar_coefficients<-temp.prewhitening_object$out.alphas
    temp.ar_order<-temp.prewhitening_object$out.ar_order
    temp.prewhitened_spectrum<-temp.prewhitening_object$out.prewhitened_spectrum
  }
  #Simulate the LAPTV process.
  temp.prewhitened_process_variance=(temp.prewhitened_spectrum[1]+2*sum(temp.prewhitened_spectrum[2:temp.M2]))/temp.M
  temp.uniform_numbers=NA
  temp.running_seeds<-c(1,2)
  temp.laptv_construction_object<-laptv_construction.function(mt_autocorrelation_coefficients.par=temp.mt_autocorrelation_coefficients,
                                                              time_sequence.par=time_sequence.par,frequencies.par=frequencies.par,N.par=temp.N,
                                                              N_truncated.par=N_truncated.par,cyclic_frequency_indices.par=cyclic_frequency_indices.par,
                                                              cosine_reconstruction.par=NA,ar_coefficients.par=temp.ar_coefficients,
                                                              sampling_rate.par=sampling_rate.par,mean.par=0,variance.par=temp.prewhitened_process_variance,
                                                              num_innovations.par=num_realizations.par,seeds.par=temp.running_seeds,
                                                              correlation_memory_threshold.par=correlation_memory_threshold.par,
                                                              student_dof.par=student_dof.par,distribution_string.par=nominal_distribution_string.par,
                                                              uniform_numbers.par=temp.uniform_numbers,crude_rv_num_samples.par=crude_rv_num_samples.par,
                                                              first_time.par=0)
  temp.laptv_averages<-temp.laptv_construction_object$out.laptv_averages+cosine_reconstruction.par
  temp.num_reconstructed=length(temp.laptv_averages)
  temp.laptv_LB<-temp.laptv_construction_object$out.laptv_LB+cosine_reconstruction.par
  temp.laptv_UB<-temp.laptv_construction_object$out.laptv_UB+cosine_reconstruction.par
  temp.laptv_times<-temp.laptv_construction_object$out.laptv_times
  temp.running_uniform_numbers<-temp.laptv_construction_object$out.uniform_numbers
  temp.laptv_se<-temp.laptv_construction_object$out.laptv_se
  temp.cutoff=3*temp.laptv_se
  temp.outlier_thresholds<-matrix(0,nrow=temp.num_reconstructed,ncol=2)
  temp.outlier_thresholds[,1]<-temp.laptv_averages-temp.cutoff
  temp.outlier_thresholds[,2]<-temp.laptv_averages+temp.cutoff
  #Initialize the optimal summary-statistic vectors in the case that model-uncertainty analysis is to be performed.
  temp.min_laptv_average<-temp.laptv_averages
  temp.max_laptv_average<-temp.laptv_averages
  temp.min_laptv_LB<-temp.laptv_LB
  temp.max_laptv_LB<-temp.laptv_LB
  temp.min_laptv_UB<-temp.laptv_UB
  temp.max_laptv_UB<-temp.laptv_UB
  if(!is.na(alternative_distribution_strings.par)){
    temp.num_list_elements=length(alternative_distribution_strings.par)
    for(temp.i in 1:temp.num_list_elements){
      temp.distribution_string<-alternative_distribution_strings.par[temp.i]
      temp.laptv_construction_object<-laptv_construction.function(mt_autocorrelation_coefficients.par=temp.mt_autocorrelation_coefficients,
                                                                  time_sequence.par=time_sequence.par,
                                                                  frequencies.par=frequencies.par,N.par=temp.N,N_truncated.par=N_truncated.par,
                                                                  cyclic_frequency_indices.par=cyclic_frequency_indices.par,
                                                                  cosine_reconstruction.par=NA,ar_coefficients.par=temp.ar_coefficients,
                                                                  sampling_rate.par=sampling_rate.par,mean.par=0,
                                                                  variance.par=temp.prewhitened_process_variance,
                                                                  num_innovations.par=num_realizations.par,seeds.par=temp.running_seeds,
                                                                  correlation_memory_threshold.par=correlation_memory_threshold.par,
                                                                  student_dof.par=student_dof.par,distribution_string.par=temp.distribution_string,
                                                                  uniform_numbers.par=temp.uniform_numbers,crude_rv_num_samples.par=crude_rv_num_samples.par)
      temp.averages<-temp.laptv_construction_object$out.laptv_averages+cosine_reconstruction.par
      temp.LB<-temp.laptv_construction_object$out.laptv_LB+cosine_reconstruction.par
      temp.UB<-temp.laptv_construction_object$out.laptv_UB+cosine_reconstruction.par
      #Update the lowest and highest confidence bounds.
      for(temp.j in 1:temp.num_reconstructed){
        #LB computations.
        if(temp.LB[temp.j]>temp.outlier_thresholds[temp.j,1] & temp.LB[temp.j]<temp.outlier_thresholds[temp.j,2]){
          if(temp.min_laptv_LB[temp.j]>temp.LB[temp.j]){
            temp.min_laptv_LB[temp.j]=temp.LB[temp.j]
          }
          if(temp.max_laptv_LB[temp.j]<temp.LB[temp.j]){
            temp.max_laptv_LB[temp.j]=temp.LB[temp.j]
          }
        }
        #Average computations.
        if(temp.averages[temp.j]>temp.outlier_thresholds[temp.j,1] & temp.averages[temp.j]<temp.outlier_thresholds[temp.j,2]){
          if(temp.min_laptv_average[temp.j]>temp.averages[temp.j]){
            temp.min_laptv_average[temp.j]=temp.averages[temp.j]
          }
          if(temp.max_laptv_average[temp.j]<temp.averages[temp.j]){
            temp.max_laptv_average[temp.j]=temp.averages[temp.j]
          }
        }
        #UB computations.
        if(temp.UB[temp.j]>temp.outlier_thresholds[temp.j,1] & temp.UB[temp.j]<temp.outlier_thresholds[temp.j,2]){
          if(temp.min_laptv_UB[temp.j]>temp.UB[temp.j]){
            temp.min_laptv_UB[temp.j]=temp.UB[temp.j]
          }
          if(temp.max_laptv_UB[temp.j]<temp.UB[temp.j]){
            temp.max_laptv_UB[temp.j]=temp.UB[temp.j]
          }
        }
      }
      #Update the uniform numbers with the ones that have just been sampled to avoid having to generate a new set every time.  Update the seeds used
      #for the "sample" function used to permute the original collection of uniform numbers.
      temp.running_seeds<-running_seed.function(temp.running_seeds)
    }
  }
  else{
    temp.min_laptv_average<-NA
    temp.max_laptv_average<-NA
    temp.min_laptv_LB<-NA
    temp.max_laptv_LB<-NA
    temp.min_laptv_UB<-NA
    temp.max_laptv_UB<-NA
  }
  #Plotting.
  temp.plot_laptv_object<-plot_laptv.function(ts.par=ts.par,outlier_thresholds.par=temp.outlier_thresholds,
                                              laptv_averages.par=temp.laptv_averages,laptv_LB.par=temp.laptv_LB,laptv_UB.par=temp.laptv_UB,
                                              time_sequence.par=all_times.par,laptv_times.par=temp.laptv_times,
                                              laptv_min_average.par=temp.min_laptv_average,laptv_max_average.par=temp.max_laptv_average,
                                              laptv_min_LB.par=temp.min_laptv_LB,laptv_max_LB.par=temp.max_laptv_LB,
                                              laptv_min_UB.par=temp.min_laptv_UB,laptv_max_UB.par=temp.max_laptv_UB,
                                              measure_quantity_string.par=measure_quantity_string.par,measure_units_string.par=measure_units_string.par,
                                              pdf_title.par=pdf_title.par,min_y.par=min_y.par,max_y.par=max_y.par,first_time.par=first_time.par)
  temp.min_y=temp.plot_laptv_object$out.min_y
  temp.max_y=temp.plot_laptv_object$out.max_y
  temp.plotting_min_laptv_LB<-temp.plot_laptv_object$out.plotting_min_laptv_LB
  temp.plotting_max_laptv_UB<-temp.plot_laptv_object$out.plotting_max_laptv_UB
  temp.plotting_min_laptv_averages<-temp.plot_laptv_object$out.plotting_min_laptv_averages
  temp.plotting_max_laptv_averages<-temp.plot_laptv_object$out.plotting_max_laptv_averages
  temp.list<-list(out.mt_acvs=temp.mt_acvs,
                  out.process_variance=temp.process_variance,
                  out.ar_order=temp.ar_order,
                  out.ar_coefficients=temp.ar_coefficients,
                  out.prewhitened_spectrum=temp.prewhitened_spectrum,
                  out.prewhitened_process_variance=temp.prewhitened_process_variance,
                  out.min_y=temp.min_y,
                  out.max_y=temp.max_y,
                  out.laptv_averages=temp.laptv_averages,
                  out.laptv_LB=temp.laptv_LB,
                  out.laptv_UB=temp.laptv_UB,
                  out.min_laptv_average=temp.min_laptv_average,
                  out.max_laptv_average=temp.max_laptv_average,
                  out.min_laptv_LB=temp.min_laptv_LB,
                  out.max_laptv_LB=temp.max_laptv_LB,
                  out.min_laptv_UB=temp.min_laptv_UB,
                  out.max_laptv_UB=temp.max_laptv_UB,
                  out.laptv_times=temp.laptv_times,
                  out.plotting_min_laptv_LB=temp.plotting_min_laptv_LB,
                  out.plotting_max_laptv_UB=temp.plotting_max_laptv_UB,
                  out.plotting_min_laptv_averages=temp.plotting_min_laptv_averages,
                  out.plotting_max_laptv_averages=temp.plotting_max_laptv_averages)
  return(temp.list)
}


laptv_vs_signal_comparison.function<-function(spectral_power_estimates.par,frequencies.par,time_sequence.par,ts.par,all_times.par,
                                              N_truncated.par,cyclic_frequency_indices.par=NA,cosine_reconstruction.par=NA,NW.par=5,
                                              sampling_rate.par=1,first_time.par=0,
                                              num_realizations.par=300,student_dof.par=5,
                                              nominal_distribution_string.par="Gaussian",alternative_distribution_strings.par=NA,
                                              correlation_memory_threshold.par=0.01,crude_rv_num_samples.par=NA,
                                              measure_quantity_string.par="Measured quantity",measure_units_string.par="units",
                                              pdf_title.par="LAPTV_Reconstruction.pdf",
                                              prewhitening_bool.par=FALSE,plot_acvs_bool.par=FALSE,plot_acvs.bool=FALSE,prewhitening_verbose_bool.par=FALSE,
                                              min_y.par=NA,max_y.par=NA,time_efficieny_bool.par=FALSE){
  temp.min_y=min_y.par
  temp.max_y=max_y.par
  temp.acs_mt_acvs<-c()
  temp.acs_process_variance=0
  temp.acs_ar_order=0
  temp.acs_ar_coefficients<-c()
  temp.acs_prewhitened_spectrum<-c()
  temp.acs_prewhitened_process_variance=0
  temp.acs_laptv_averages<-c()
  temp.acs_laptv_LB<-c()
  temp.acs_laptv_UB<-c()
  temp.acs_min_laptv_average<-c()
  temp.acs_max_laptv_average<-c()
  temp.acs_min_laptv_LB<-c()
  temp.acs_max_laptv_LB<-c()
  temp.acs_min_laptv_UB<-c()
  temp.acs_max_laptv_UB<-c()
  temp.laptv_times<-c()
  temp.plotting_min_laptv_LB<-c()
  temp.plotting_max_laptv_UB<-c()
  temp.plotting_min_laptv_averages<-c()
  temp.plotting_max_laptv_averages<-c()
  if(!is.na(cyclic_frequency_indices.par)){
    #LAPTV.
    temp.laptv_analysis_object<-laptv_analysis.function(spectral_power_estimates.par=spectral_power_estimates.par,
                                                        frequencies.par=frequencies.par,time_sequence.par=time_sequence.par,ts.par=ts.par,
                                                        all_times.par=all_times.par,
                                                        N_truncated.par=N_truncated.par,cyclic_frequency_indices.par=cyclic_frequency_indices.par,
                                                        cosine_reconstruction.par=cosine_reconstruction.par,NW.par=NW.par,
                                                        sampling_rate.par=sampling_rate.par,first_time.par=first_time.par,
                                                        num_realizations.par=num_realizations.par,
                                                        student_dof.par=student_dof.par,
                                                        nominal_distribution_string.par=nominal_distribution_string.par,
                                                        alternative_distribution_strings.par=alternative_distribution_strings.par,
                                                        correlation_memory_threshold.par=correlation_memory_threshold.par,
                                                        crude_rv_num_samples.par=crude_rv_num_samples.par,
                                                        measure_quantity_string.par=measure_quantity_string.par,measure_units_string.par=measure_units_string.par,
                                                        pdf_title.par=pdf_title.par,
                                                        prewhitening_bool.par=prewhitening_bool.par,plot_acvs_bool.par=plot_acvs_bool.par,
                                                        prewhitening_verbose_bool.par=prewhitening_verbose_bool.par,min_y.par=temp.min_y,max_y.par=temp.max_y,
                                                        time_efficieny_bool.par=time_efficieny_bool.par)
    temp.min_y=temp.laptv_analysis_object$out.min_y
    temp.max_y=temp.laptv_analysis_object$out.max_y
    temp.acs_mt_acvs<-temp.laptv_analysis_object$out.mt_acvs
    temp.acs_process_variance=temp.laptv_analysis_object$out.process_variance
    temp.acs_ar_order=temp.laptv_analysis_object$out.ar_order
    temp.acs_ar_coefficients<-temp.laptv_analysis_object$out.ar_coefficients
    temp.acs_prewhitened_spectrum<-temp.laptv_analysis_object$out.prewhitened_spectrum
    temp.acs_prewhitened_process_variance=temp.laptv_analysis_object$out.prewhitened_process_variance
    temp.acs_laptv_averages<-temp.laptv_analysis_object$out.laptv_averages
    if(!is.na(alternative_distribution_strings.par)){
      temp.acs_laptv_LB<-temp.laptv_analysis_object$out.laptv_LB
      temp.acs_laptv_UB<-temp.laptv_analysis_object$out.laptv_UB
      temp.acs_min_laptv_average<-temp.laptv_analysis_object$out.min_laptv_average
      temp.acs_max_laptv_average<-temp.laptv_analysis_object$out.max_laptv_average
      temp.acs_min_laptv_LB<-temp.laptv_analysis_object$out.min_laptv_LB
      temp.acs_max_laptv_LB<-temp.laptv_analysis_object$out.max_laptv_LB
      temp.acs_min_laptv_UB<-temp.laptv_analysis_object$out.min_laptv_UB
      temp.acs_max_laptv_UB<-temp.laptv_analysis_object$out.max_laptv_UB
      temp.laptv_times<-temp.laptv_analysis_object$out.laptv_times
      temp.plotting_min_laptv_LB<-temp.laptv_analysis_object$out.plotting_min_laptv_LB
      temp.plotting_max_laptv_UB<-temp.laptv_analysis_object$out.plotting_max_laptv_UB
      temp.plotting_min_laptv_averages<-temp.laptv_analysis_object$out.plotting_min_laptv_averages
      temp.plotting_max_laptv_averages<-temp.laptv_analysis_object$out.plotting_max_laptv_averages
    }
  }
  #Signal plus noise.
  temp.laptv_analysis_object<-laptv_analysis.function(spectral_power_estimates.par=spectral_power_estimates.par,
                                                      cyclic_frequency_indices.par=NA,
                                                      frequencies.par=frequencies.par,time_sequence.par=time_sequence.par,ts.par=ts.par,
                                                      all_times.par=all_times.par,
                                                      N_truncated.par=N_truncated.par,cosine_reconstruction.par=cosine_reconstruction.par,NW.par=NW.par,
                                                      sampling_rate.par=sampling_rate.par,first_time.par=first_time.par,
                                                      num_realizations.par=num_realizations.par,student_dof.par=student_dof.par,
                                                      nominal_distribution_string.par=nominal_distribution_string.par,
                                                      alternative_distribution_strings.par=alternative_distribution_strings.par,
                                                      correlation_memory_threshold.par=correlation_memory_threshold.par,
                                                      crude_rv_num_samples.par=crude_rv_num_samples.par,
                                                      measure_quantity_string.par=measure_quantity_string.par,measure_units_string.par=measure_units_string.par,
                                                      pdf_title.par=paste("Signal_Plus_Noise_Reconstruction.pdf",sep=""),
                                                      prewhitening_bool.par=prewhitening_bool.par,plot_acvs_bool.par=plot_acvs_bool.par,
                                                      prewhitening_verbose_bool.par=prewhitening_verbose_bool.par,
                                                      min_y.par=temp.min_y,max_y.par=temp.max_y,time_efficieny_bool.par=time_efficieny_bool.par)
  temp.spn_min_y=temp.laptv_analysis_object$out.min_y
  temp.spn_max_y=temp.laptv_analysis_object$out.max_y
  temp.spn_mt_acvs<-temp.laptv_analysis_object$out.mt_acvs
  temp.spn_process_variance<-temp.laptv_analysis_object$out.process_variance
  temp.spn_ar_order<-temp.laptv_analysis_object$out.ar_order
  temp.spn_ar_coefficients<-temp.laptv_analysis_object$out.ar_coefficients
  temp.spn_prewhitened_spectrum<-temp.laptv_analysis_object$out.prewhitened_spectrum
  temp.spn_prewhitened_process_variance<-temp.laptv_analysis_object$out.prewhitened_process_variance
  temp.spn_laptv_averages<-temp.laptv_analysis_object$out.laptv_averages
  if(!is.na(alternative_distribution_strings.par)){
    temp.spn_laptv_LB<-temp.laptv_analysis_object$out.laptv_LB
    temp.spn_laptv_UB<-temp.laptv_analysis_object$out.laptv_UB
    temp.spn_min_laptv_average<-temp.laptv_analysis_object$out.min_laptv_average
    temp.spn_max_laptv_average<-temp.laptv_analysis_object$out.max_laptv_average
    temp.spn_min_laptv_LB<-temp.laptv_analysis_object$out.min_laptv_LB
    temp.spn_max_laptv_LB<-temp.laptv_analysis_object$out.max_laptv_LB
    temp.spn_min_laptv_UB<-temp.laptv_analysis_object$out.min_laptv_UB
    temp.spn_max_laptv_UB<-temp.laptv_analysis_object$out.max_laptv_UB
  }
  temp.list<-list(out.spn_mt_acvs=temp.spn_mt_acvs,
                  out.spn_process_variance=temp.spn_process_variance,
                  out.spn_ar_order=temp.spn_ar_order,
                  out.spn_ar_coefficients=temp.spn_ar_coefficients,
                  out.spn_prewhitened_spectrum=temp.spn_prewhitened_spectrum,
                  out.spn_prewhitened_process_variance=temp.spn_prewhitened_process_variance,
                  out.spn_laptv_averages=temp.spn_laptv_averages)
  if(!is.na(cyclic_frequency_indices.par)){
    temp.list<-list.append(temp.list,
                           out.acs_mt_acvs=temp.acs_mt_acvs,
                           out.acs_process_variance=temp.acs_process_variance,
                           out.acs_ar_order=temp.acs_ar_order,
                           out.acs_ar_coefficients=temp.acs_ar_coefficients,
                           out.acs_prewhitened_spectrum=temp.acs_prewhitened_spectrum,
                           out.acs_prewhitened_process_variance=temp.acs_prewhitened_process_variance,
                           out.acs_laptv_averages=temp.acs_laptv_averages)
    if(!is.na(alternative_distribution_strings.par)){
      temp.list<-list.append(temp.list,
                             out.acs_laptv_LB=temp.acs_laptv_LB,
                             out.acs_laptv_UB=temp.acs_laptv_UB,
                             out.acs_min_laptv_average=temp.acs_min_laptv_average,
                             out.acs_max_laptv_average=temp.acs_max_laptv_average,
                             out.acs_min_laptv_LB=temp.acs_min_laptv_LB,
                             out.acs_max_laptv_LB=temp.acs_max_laptv_LB,
                             out.acs_min_laptv_UB=temp.acs_min_laptv_UB,
                             out.acs_max_laptv_UB=temp.acs_max_laptv_UB,
                             out.laptv_times=temp.laptv_times,
                             out.plotting_min_laptv_LB=temp.plotting_min_laptv_LB,
                             out.plotting_max_laptv_UB=temp.plotting_max_laptv_UB,
                             out.plotting_min_laptv_averages=temp.plotting_min_laptv_averages,
                             out.plotting_max_laptv_averages=temp.plotting_max_laptv_averages)
    }
  }
  if(!is.na(alternative_distribution_strings.par)){
    temp.list<-list.append(temp.list,
                           out.spn_laptv_LB=temp.spn_laptv_LB,
                           out.spn_laptv_UB=temp.spn_laptv_UB,
                           out.spn_min_laptv_average=temp.spn_min_laptv_average,
                           out.spn_max_laptv_average=temp.spn_max_laptv_average,
                           out.spn_min_laptv_LB=temp.spn_min_laptv_LB,
                           out.spn_max_laptv_LB=temp.spn_max_laptv_LB,
                           out.spn_min_laptv_UB=temp.spn_min_laptv_UB,
                           out.spn_max_laptv_UB=temp.spn_max_laptv_UB)
  }
  return(temp.list)
}



laptv_statistics.function<-function(spectral_power_estimates.par,frequencies.par,time_sequence.par,ts.par,all_times.par,N_truncated.par,
                                    cyclic_frequency_indices.par,cosine_reconstruction.par,
                                    NW.par=5,sampling_rate.par=1,first_time.par=0,
                                    num_realizations.par=100,student_dof.par=5,nominal_distribution_string.par="Gaussian",
                                    alternative_distribution_strings.par=c("logistic","Student" ,"uniform" ),correlation_memory_threshold.par=0.01,
                                    crude_rv_num_samples.par=5e3,random_seeds.par=c(1,2),
                                    measure_quantity_string.par="",measure_units_string.par="",
                                    pdf_title.par="LAPTV_Reconstruction.pdf",prewhitening_bool.par=FALSE,plot_acvs_bool.par=FALSE,
                                    prewhitening_verbose_bool.par=FALSE,time_efficieny_bool.par=FALSE,synthetic_data.par=FALSE){
  temp.all_cyclic_frequency_indices=cyclic_frequency_indices.par
  temp.mt_acvs<-c()
  temp.process_variance=0
  temp.ar_order=0
  temp.ar_coefficients<-c()
  temp.prewhitened_spectrum<-c()
  temp.prewhitened_process_variance=0
  temp.laptv_averages<-c()
  temp.laptv_LB<-c()
  temp.laptv_UB<-c()
  temp.min_laptv_average<-c()
  temp.max_laptv_average<-c()
  temp.min_laptv_LB<-c()
  temp.max_laptv_LB<-c()
  temp.min_laptv_UB<-c()
  temp.max_laptv_UB<-c()
  if(synthetic_data.par==TRUE){
    temp.laptv_analysis_object<-
      laptv_vs_signal_comparison.function(spectral_power_estimates.par,frequencies.par=frequencies.par,time_sequence.par=time_sequence.par,
                                          ts.par=ts.par,all_times.par=time_sequence.par,N_truncated.par=N_truncated.par,
                                          cyclic_frequency_indices.par=temp.all_cyclic_frequency_indices,
                                          cosine_reconstruction.par=cosine_reconstruction.par,NW.par=NW.par,
                                          sampling_rate.par=sampling_rate.par,first_time.par=first_time.par,
                                          num_realizations.par=num_realizations.par,student_dof.par=student_dof.par,
                                          nominal_distribution_string.par=nominal_distribution.string,
                                          alternative_distribution_strings.par=alternative_distribution_strings.par,
                                          correlation_memory_threshold.par=correlation_memory_threshold.par,crude_rv_num_samples.par=crude_rv_num_samples.par,
                                          measure_quantity_string.par=measure_quantity_string.par,measure_units_string.par=measure_units_string.par,
                                          pdf_title.par=pdf_title.par,prewhitening_bool.par=prewhitening_bool.par,plot_acvs_bool.par=plot_acvs_bool.par,
                                          prewhitening_verbose_bool.par=prewhitening_verbose_bool.par,time_efficieny_bool.par=time_efficieny_bool.par)
    if(!is.na(temp.all_cyclic_frequency_indices)){
      temp.mt_acvs<-temp.laptv_analysis_object$out.acs_mt_acvs
      temp.process_variance=temp.laptv_analysis_object$out.acs_process_variance
      temp.ar_order=temp.laptv_analysis_object$out.acs_ar_order
      temp.ar_coefficients<-temp.laptv_analysis_object$out.acs_ar_coefficients
      temp.prewhitened_spectrum<-temp.laptv_analysis_object$out.acs_prewhitened_spectrum
      temp.prewhitened_process_variance=temp.laptv_analysis_object$out.acs_prewhitened_process_variance
      temp.laptv_averages<-temp.laptv_analysis_object$out.acs_laptv_averages
      temp.laptv_LB<-temp.laptv_analysis_object$out.acs_laptv_LB
      temp.laptv_UB<-temp.laptv_analysis_object$out.acs_laptv_UB
      temp.min_laptv_average<-temp.laptv_analysis_object$out.acs_min_laptv_average
      temp.max_laptv_average<-temp.laptv_analysis_object$out.acs_max_laptv_average
      temp.min_laptv_LB<-temp.laptv_analysis_object$out.acs_min_laptv_LB
      temp.max_laptv_LB<-temp.laptv_analysis_object$out.acs_max_laptv_LB
      temp.min_laptv_UB<-temp.laptv_analysis_object$out.acs_min_laptv_UB
      temp.max_laptv_UB<-temp.laptv_analysis_object$out.acs_max_laptv_UB
    }
    else{
      temp.mt_acvs<-temp.laptv_analysis_object$out.spn_mt_acvs
      temp.process_variance=temp.laptv_analysis_object$out.spn_process_variance
      temp.ar_order=temp.laptv_analysis_object$out.spn_ar_order
      temp.ar_coefficients<-temp.laptv_analysis_object$out.spn_ar_coefficients
      temp.prewhitened_spectrum<-temp.laptv_analysis_object$out.spn_prewhitened_spectrum
      temp.prewhitened_process_variance=temp.laptv_analysis_object$out.spn_prewhitened_process_variance
      temp.laptv_averages<-temp.laptv_analysis_object$out.spn_laptv_averages
      temp.laptv_LB<-temp.laptv_analysis_object$out.spn_laptv_LB
      temp.laptv_UB<-temp.laptv_analysis_object$out.spn_laptv_UB
      temp.min_laptv_average<-temp.laptv_analysis_object$out.spn_min_laptv_average
      temp.max_laptv_average<-temp.laptv_analysis_object$out.spn_max_laptv_average
      temp.min_laptv_LB<-temp.laptv_analysis_object$out.spn_min_laptv_LB
      temp.max_laptv_LB<-temp.laptv_analysis_object$out.spn_max_laptv_LB
      temp.min_laptv_UB<-temp.laptv_analysis_object$out.spn_min_laptv_UB
      temp.max_laptv_UB<-temp.laptv_analysis_object$out.spn_max_laptv_UB
    }
    #Reconstruct the measured quantity in the entire epoch based on the training data above.
    temp.section_size=length(ts.par)
    temp.multitaper_innovations_RNG_function<-multitaper_innovations_RNG.function(mt_autocorrelation_coefficients.par=NA,N.par=temp.section_size,mean.par=0,
                                                                                  variance.par=temp.prewhitened_process_variance,seeds.par=random_seeds.par,
                                                                                  distribution_string.par=nominal_distribution_string.par,
                                                                                  crude_rv_num_samples.par=crude_rv_num_samples.par)
    temp.innovations_sequence<-temp.multitaper_innovations_RNG_function$out.innovations_sequence
  }
  temp.list<-list(out.mt_acvs=temp.mt_acvs,
                  out.process_variance=temp.process_variance,
                  out.ar_order=temp.ar_order,
                  out.ar_coefficients=temp.ar_coefficients,
                  out.prewhitened_spectrum=temp.prewhitened_spectrum,
                  out.prewhitened_process_variance=temp.prewhitened_process_variance,
                  out.laptv_averages=temp.laptv_averages,
                  out.laptv_LB=temp.laptv_LB,
                  out.laptv_UB=temp.laptv_UB,
                  out.min_laptv_average=temp.min_laptv_average,
                  out.max_laptv_average=temp.max_laptv_average,
                  out.min_laptv_LB=temp.min_laptv_LB,
                  out.max_laptv_LB=temp.max_laptv_LB,
                  out.min_laptv_UB=temp.min_laptv_UB,
                  out.max_laptv_UB=temp.max_laptv_UB)
  return(temp.list)
}



basic_laptv_single_section.function<-function(training_times.par,training_ts_values.par,
                                              previous_changepoint.par,current_changepoint.par,
                                              specific_subdirectory_string.par="",old_directory.par="",revised_specific_directory_string.par="",
                                              spectral_power_estimates.par,frequencies.par,time_sequence.par,ts.par,all_times.par,N_truncated.par,
                                              cyclic_frequency_indices.par,cosine_reconstruction.par,
                                              NW.par=5,sampling_rate.par=1,first_time.par=0,start_time.par=0,
                                              #laptv_ACVS.function
                                              normal_quantile.par=1,conjugate_correlation.par=FALSE,plot_ACVS_bool.par=FALSE,
                                              abscissa_quantity.par="Measured value",abscissa_units.par="units",
                                              ordinates_quantity.par="Measured value",ordinates_units.par="units",
                                              laptv_ordinates_quantity.par="Measured value",laptv_ordinates_units.par="units",
                                              max_size.par=100,measured_quantity.par="",plot_titles.par="",
                                              #laptv_vs_signal_comparison.function
                                              num_realizations.par=100,student_dof.par=5,nominal_distribution_string.par="Gaussian",
                                              alternative_distribution_strings.par=c("logistic","Student" ,"uniform" ),correlation_memory_threshold.par=0.01,
                                              crude_rv_num_samples.par=5e3,random_seeds.par=c(1,2),
                                              measure_quantity_string.par="",measure_units_string.par="",
                                              pdf_title.par="LAPTV_Reconstruction.pdf",prewhitening_bool.par=FALSE,plot_acvs_bool.par=FALSE,
                                              prewhitening_verbose_bool.par=FALSE,time_efficieny_bool.par=FALSE,synthetic_data.par=TRUE,
                                              #Ends reconstruction booleans.
                                              periodic_reconstruction_bool.par=FALSE,ts_interp_ends_bool.par=FALSE,mdss_bool_ends.par=FALSE,gn_bool_ends.par=FALSE,
                                              num_iterations.par=1,max_length.par=200,
                                              main_directory_string.par="",directory_label.par="",old_directory_interp.par=""){
  temp.laptv_label<-"LAPTV_Analysis"
  dir.create(temp.laptv_label,showWarnings=FALSE)
  temp.specific_subdirectory_string<-paste(specific_subdirectory_string.par,temp.laptv_label,"/",sep="")
  temp.revised_specific_directory_string<-paste(revised_specific_directory_string.par,"/",temp.laptv_label,sep="")
  temp.working_directory_string<-paste(old_directory.par,temp.laptv_label,"/",sep="")
  setwd(temp.working_directory_string)
  for(temp.i in 1:length(cyclic_frequency_indices.par)){
    temp.pdf_title<-pdf_title.par
    if(temp.i>1){
      temp.pdf_title<-paste("Stationary_Noise_",temp.pdf_title,sep="")
    }
    temp.laptv_statistics_object<-laptv_statistics.function(spectral_power_estimates.par,frequencies.par,training_times.par,training_ts_values.par,
                                                            all_times.par,N_truncated.par,
                                                            cyclic_frequency_indices.par[[temp.i]],cosine_reconstruction.par,NW.par=NW.par,
                                                            sampling_rate.par=sampling_rate.par,first_time.par=first_time.par,
                                                            num_realizations.par=num_realizations.par,
                                                            student_dof.par=student_dof.par,nominal_distribution_string.par=nominal_distribution_string.par,
                                                            alternative_distribution_strings.par=alternative_distribution_strings.par,
                                                            correlation_memory_threshold.par=correlation_memory_threshold.par,
                                                            crude_rv_num_samples.par=crude_rv_num_samples.par,random_seeds.par=random_seeds.par,
                                                            measure_quantity_string.par=measure_quantity_string.par,
                                                            measure_units_string.par=measure_units_string.par,pdf_title.par=temp.pdf_title,
                                                            prewhitening_bool.par=prewhitening_bool.par,plot_acvs_bool.par=plot_acvs_bool.par,
                                                            prewhitening_verbose_bool.par=prewhitening_verbose_bool.par,
                                                            time_efficieny_bool.par=time_efficieny_bool.par,synthetic_data.par=synthetic_data.par)
  }
  temp.mt_acvs<-temp.laptv_statistics_object$out.mt_acvs
  temp.process_variance=temp.laptv_statistics_object$out.process_variance
  temp.ar_order=temp.laptv_statistics_object$out.ar_order
  temp.ar_coefficients<-temp.laptv_statistics_object$out.ar_coefficients
  temp.prewhitened_spectrum<-temp.laptv_statistics_object$out.prewhitened_spectrum
  temp.prewhitened_process_variance=temp.laptv_statistics_object$out.prewhitened_process_variance
  temp.laptv_averages<-temp.laptv_statistics_object$out.laptv_averages
  temp.laptv_LB<-temp.laptv_statistics_object$out.laptv_LB
  temp.laptv_UB<-temp.laptv_statistics_object$out.laptv_UB
  temp.min_laptv_average<-temp.laptv_statistics_object$out.min_laptv_average
  temp.max_laptv_average<-temp.laptv_statistics_object$out.max_laptv_average
  temp.min_laptv_LB<-temp.laptv_statistics_object$out.min_laptv_LB
  temp.max_laptv_LB<-temp.laptv_statistics_object$out.max_laptv_LB
  temp.min_laptv_UB<-temp.laptv_statistics_object$out.min_laptv_UB
  temp.max_laptv_UB<-temp.laptv_statistics_object$out.max_laptv_UB
  #Compute the LAPTV ACVS.
  temp.laptv_ACVS_object<-laptv_ACVS.function(times.par=training_times.par,frequencies.par=frequencies.par,
                                              spectral_power_estimates.par=spectral_power_estimates.par,means.par=cosine_reconstruction.par,
                                              first_time.par=first_time.par,sampling_rate.par=sampling_rate.par,normal_quantile.par=normal_quantile.par,
                                              cyclic_frequency_indices.par=cyclic_frequency_indices.par[[1]],
                                              conjugate_correlation.par=conjugate_correlation.par,plot_bool.par=plot_ACVS_bool.par,
                                              abscissa_quantity.par="Time",abscissa_units.par="minutes",
                                              ordinates_quantity.par=ordinates_quantity.par,ordinates_units.par=ordinates_units.par,
                                              laptv_ordinates_quantity.par=laptv_ordinates_quantity.par,laptv_ordinates_units.par=laptv_ordinates_units.par,
                                              max_size.par=100,measured_quantity.par=measured_quantity.par,
                                              plot_titles.par="",
                                              #Ends reconstruction booleans.
                                              periodic_reconstruction_bool.par=periodic_reconstruction_bool.par,ts_interp_ends_bool.par=ts_interp_ends_bool.par,
                                              mdss_bool_ends.par=mdss_bool_ends.par,gn_bool_ends.par=gn_bool_ends.par,num_iterations.par=num_iterations.par,
                                              max_length.par=max_length.par,main_directory_string.par=main_directory_string.par,
                                              directory_label.par=directory_label.par,
                                              old_directory_interp.par=old_directory_interp.par,
                                              revised_specific_directory_string.par=paste(temp.specific_subdirectory_string,sep=""))
  temp.ar_coefficients_LAPTV<-temp.laptv_ACVS_object$out.ar_coefficients
  temp.prewhitened_process_variance_LAPTV<-temp.laptv_ACVS_object$out.prewhitened_process_variance
  temp.variances<-temp.laptv_ACVS_object$out.variances
  temp.sd_vector<-temp.laptv_ACVS_object$out.sd_vector
  #Periodic extension of the fitted values from the training interval to the full epoch interval.
  temp.truncated_times<-time_sequence.par#[time_sequence.par>=previous_changepoint.par & time_sequence.par<current_changepoint.par]
  temp.truncated_ts<-ts.par#[time_sequence.par>=previous_changepoint.par & time_sequence.par<current_changepoint.par]
  temp.epoch_periodic_extension_object<-epoch_periodic_extension.function(time_sequence.par=temp.truncated_times,ts_sequence.par=temp.truncated_ts,
                                                                          training_times.par=training_times.par,
                                                                          training_ts_values.par=training_ts_values.par,
                                                                          mean_vector.par=cosine_reconstruction.par,sd_vector.par=temp.sd_vector,
                                                                          previous_changepoint.par=previous_changepoint.par,
                                                                          current_changepoint.par=current_changepoint.par,first_time.par=first_time.par,
                                                                          start_time.par=start_time.par,plot_titles.par=plot_titles.par)
  temp.all_times<-temp.epoch_periodic_extension_object$out.all_times
  temp.all_ts_values<-temp.epoch_periodic_extension_object$out.all_ts_values
  temp.all_reconstructions<-temp.epoch_periodic_extension_object$out.all_reconstructions
  temp.all_sd<-temp.epoch_periodic_extension_object$out.all_sd
  setwd(old_directory.par)
  temp.list<-list(out.specific_subdirectory_string=temp.specific_subdirectory_string,
                  out.revised_specific_directory_string=temp.revised_specific_directory_string,
                  out.working_directory_string=temp.working_directory_string,
                  out.mt_acvs=temp.mt_acvs,
                  out.process_variance=temp.process_variance,
                  out.ar_order=temp.ar_order,
                  out.ar_coefficients=temp.ar_coefficients,
                  out.prewhitened_spectrum=temp.prewhitened_spectrum,
                  out.prewhitened_process_variance=temp.prewhitened_process_variance,
                  out.laptv_averages=temp.laptv_averages,
                  out.laptv_LB=temp.laptv_LB,
                  out.laptv_UB=temp.laptv_UB,
                  out.min_laptv_average=temp.min_laptv_average,
                  out.max_laptv_average=temp.max_laptv_average,
                  out.min_laptv_LB=temp.min_laptv_LB,
                  out.max_laptv_LB=temp.max_laptv_LB,
                  out.min_laptv_UB=temp.min_laptv_UB,
                  out.max_laptv_UB=temp.max_laptv_UB,
                  out.ar_coefficients_LAPTV=temp.ar_coefficients_LAPTV,
                  out.prewhitened_process_variance_LAPTV=temp.prewhitened_process_variance_LAPTV,
                  out.sd_vector=temp.sd_vector,
                  out.all_times=temp.all_times,
                  out.all_ts_values=temp.all_ts_values,
                  out.all_reconstructions=temp.all_reconstructions,
                  out.all_sd=temp.all_sd)
  return(temp.list)
}



#############################################################################################
#Functions for the Ramirez (2015) detectors for cyclostationarity.
#############################################################################################

Ramirez_harmonic_analysis.function<-function(y_matrix_list.par,num_detectors.par){
  temp.num_longitudinal_samples=length(y_matrix_list.par)
  temp.N=temp.y_matrix_list[[1]][1,]
  temp.mean_signals<-list()
  temp.residual_trace_matrix_list<-list()
  for(temp.k in 1:temp.num_longitudinal_samples){
    temp.residual_trace_matrix_list[[temp.k]]<-matrix(0,nrow=num_detectors.par,ncol=temp.N)
  }
  for(temp.j in 1:num_detectors.par){
    temp.mean_signal_j<-rep(0,temp.N)
    for(temp.k in 1:temp.num_longitudinal_samples){
      temp.mean_signal_j<-temp.mean_signal_j+temp.y_matrix_list[[temp.k]][temp.j,]
    }
    temp.mean_signal_j<-temp.mean_signal_j/temp.num_longitudinal_samples
    temp.mean_signals[[temp.j]]<-temp.mean_signal_j
    temp.residual_trace_matrix_list[[temp.k]][temp.j,]<-temp.y_matrix_list[[temp.k]][temp.j,]-temp.mean_signal_j
  }
  temp.list<-list(out.residual_trace_matrix_list=temp.residual_trace_matrix_list,
                  out.mean_signals=temp.mean_signals)
  return(temp.list)
}


construct_centred_realizations_list.function<-function(y_matrix_list.par,num_detectors.par,decimation_step.par=1){
  temp.num_decimated=0
  temp.decimated_series_list<-list()
  temp.num_longitudinal_samples=length(y_matrix_list.par)
  for(temp.k in 1:temp.num_longitudinal_samples){
    temp.decimated_series_list_k<-list()
    for(temp.j in 1:num_detectors.par){
      temp.row_series<-y_matrix_list.par[[temp.k]][temp.j,]
      temp.N=length(temp.row_series)
      if(decimation_step.par>1){
        temp.decimation_indices<-seq(from=1,to=temp.N,by=decimation_step.par)
        temp.decimation_indices<-temp.decimation_indices[temp.decimation_indices<=temp.N]
        temp.decimated_series_list_k[[temp.j]]<-temp.row_series[temp.decimation_indices]
      } else{
        temp.decimated_series_list_k[[temp.j]]<-temp.row_series
      }
      if(temp.k==1 & temp.j==1){
        temp.num_decimated=length(temp.decimated_series_list_k[[temp.j]])
      }
    }
    temp.decimated_series_list[[temp.k]]<-temp.decimated_series_list_k
  }
  temp.list<-list(out.decimated_series_list=temp.decimated_series_list,
                  out.num_decimated=temp.num_decimated)
  return(temp.list)
}


construct_decimated_series_matrix_list.function<-function(decimated_series_list.par,num_detectors.par){
  temp.num_longitudinal_samples=length(decimated_series_list.par)
  temp.num_decimated=length(decimated_series_list.par[[1]][[1]])
  temp.decimated_y_matrix_list<-list()
  for(temp.k in 1:temp.num_longitudinal_samples){
    temp.matrix<-matrix(0,nrow=num_detectors.par,ncol=temp.num_decimated)
    for(temp.j in 1:num_detectors.par){
      temp.matrix[temp.j,]<-decimated_series_list.par[[temp.k]][[temp.j]]
    }
    temp.decimated_y_matrix_list[[temp.k]]<-temp.matrix
  }
  return(temp.decimated_y_matrix_list)
}


Ramirez_preprocessing.function<-function(y_matrix_list.par,N.par,num_detectors.par,num_cycles.par,
                                         decimation_step.par=1,harmonic_bool.par=FALSE){
  #Decimate the time series.
  temp.construct_centred_realizations_list_object<-construct_centred_realizations_list.function(y_matrix_list.par=y_matrix_list.par,
                                                                                                num_detectors.par,
                                                                                                decimation_step.par=decimation_step.par)
  temp.num_decimated=temp.construct_centred_realizations_list_object$out.num_decimated
  temp.decimated_series_list<-temp.construct_centred_realizations_list_object$out.decimated_series_list
  temp.decimated_y_matrix_list<-construct_decimated_series_matrix_list.function(decimated_series_list.par=temp.decimated_series_list,num_detectors.par)
  #Assign appropriate time-series parameters to prepare for conducting the test.
  temp.cyclic_period_index=max(2,floor(N.par/num_cycles.par/decimation_step.par))
  temp.period_index=floor(temp.num_decimated/num_cycles.par)
  num_cycles.par=floor(temp.num_decimated/temp.period_index)
  temp.record_size=num_cycles.par*temp.period_index
  temp.num_cycles=num_cycles.par
  #Fourier matrix.
  temp.Fourier_matrix<-dftMatrix(temp.record_size)
  temp.residual_trace_matrix_list<-y_matrix_list.par
  if(harmonic_bool.par==TRUE){
    #Subtract the mean trend.
    temp.Ramirez_harmonic_analysis_object<-Ramirez_harmonic_analysis.function(y_matrix_list.par=y_matrix_list.par,num_detectors.par=num_detectors.par)
    temp.residual_trace_matrix_list<-temp.Ramirez_harmonic_analysis_object$out.residual_trace_matrix_list
  }
  temp.list<-list(out.decimated_y_matrix_list=temp.decimated_y_matrix_list,
                  out.cyclic_period_index=temp.cyclic_period_index,
                  out.record_size=temp.record_size,
                  out.num_cycles=temp.num_cycles,
                  out.num_decimated=temp.num_decimated,
                  out.Fourier_matrix=temp.Fourier_matrix)
  return(temp.list)
}


Ramirez_z_vector_reordered_frequencies_Shat<-function(decimated_y_matrix_list.par,Fourier_matrix.par,
                                                      cyclic_period_index.par=1,num_cycles.par=1,num_detectors.par=1,
                                                      num_trial_samples.par,decimation_step.par,
                                                      record_size.par=NA,verbose.par=FALSE){
  temp.num_trial_samples=length(decimated_y_matrix_list.par)
  temp.num_decimated=length(decimated_y_matrix_list.par[[1]][1,])
  if(is.na(record_size.par)==TRUE){
    cyclic_period_index.par=max(2,floor(temp.N/num_cycles.par/decimation_step.par))
    record_size.par=min(temp.num_decimated,num_cycles.par*cyclic_period_index.par)
    num_cycles.par=max(1,floor(record_size.par/cyclic_period_index.par))
  }
  temp.period_size=floor(record_size.par/num_cycles.par)
  record_size.par=num_cycles.par*temp.period_size
  temp.identity_matrix_dimension<-Diag(rep(1,num_detectors.par))
  temp.commutation_matrix<-commutation.matrix(num_cycles.par,temp.period_size)
  temp.matrix1<-temp.commutation_matrix%x%temp.identity_matrix_dimension
  temp.z_data_matrix<-matrix(0,nrow=num_detectors.par*record_size.par,ncol=temp.num_trial_samples)
  for(temp.k in 1:temp.num_trial_samples){
    if(verbose.par==TRUE){
      cat(temp.k," out of ",temp.num_trial_samples,"\n")
    }
    temp.y_vector<-as.vector(decimated_y_matrix_list.par[[temp.k]][,1:record_size.par])
    temp.matrix2<-hermitian.conjugate(Fourier_matrix.par%x%temp.identity_matrix_dimension)
    temp.z_vector<-(temp.matrix1%*%temp.matrix2)%*%temp.y_vector
    temp.z_data_matrix[,temp.k]<-temp.z_vector
  }
  temp.z_mean_vector<-rowMeans(temp.z_data_matrix)
  #cat("nrow(temp.z_data_matrix)=",nrow(temp.z_data_matrix),"\n")
  #cat("temp.z_data_matrix\n")
  #print(temp.z_data_matrix)
  temp.S_hat<-temp.z_data_matrix%*%hermitian.conjugate(temp.z_data_matrix)/num_trial_samples.par-temp.z_mean_vector%*%hermitian.conjugate(temp.z_mean_vector)
  return(temp.S_hat)
}


S_dimension_blocks_matrix.function<-function(S_hat.par,num_detectors.par,record_size.par,verbose.par=FALSE){
  temp.S_dimension=num_detectors.par*record_size.par
  if(verbose.par==TRUE){
    cat("temp.S_dimension_blocks_list\n")
  }
  temp.S_dimension_blocks_matrix<-matrix(0,nrow=temp.S_dimension,ncol=temp.S_dimension)
  temp.inverse<-temp.S_dimension_blocks_matrix
  temp.num_blocks=temp.S_dimension/num_detectors.par
  temp.denominator_determinant=log(1)
  for(temp.j in 1:temp.num_blocks){
    temp.indices<-(temp.j-1)*num_detectors.par+1:num_detectors.par
    temp.block<-S_hat.par[temp.indices,temp.indices]
    temp.S_dimension_blocks_matrix[temp.indices,temp.indices]<-temp.block
    temp.determinant=1
    if(num_detectors.par==2){
      temp.determinant=temp.block[1,1]*temp.block[2,2]-temp.block[1,2]*temp.block[2,1]
    }
    else{
      temp.determinant=determinant_large_square_partitioned_matrix.function(temp.block)
    }
    temp.determinant=Re(temp.determinant)
    temp.denominator_determinant=temp.denominator_determinant+log(temp.determinant)
    temp.running_inverse<-c()
    if(!Det(temp.block)){
      temp.running_inverse<-ginv(temp.block)
    } else{
      temp.running_inverse<-matrix.inverse(temp.block)
    }
    temp.inverse[temp.indices,temp.indices]<-complex.cholesky_square_root(temp.running_inverse)#matrix.square_root(temp.running_inverse)
  }
  temp.list<-list(out.S_dimension_blocks_matrix=temp.S_dimension_blocks_matrix,
                  out.inverse=temp.inverse,
                  out.denominator_determinant=temp.denominator_determinant)
  return(temp.list)
}


S_dimension_cycle_blocks_matrix.function<-function(S_hat.par,num_detectors.par,cyclic_period_index.par,record_size.par,verbose.par=FALSE){
  temp.S_dimension=num_detectors.par*record_size.par
  if(verbose.par==TRUE){
    cat("S_dimension_cycle_blocks_list\n")
  }
  temp.S_dimension_blocks_matrix<-matrix(0,nrow=temp.S_dimension,ncol=temp.S_dimension)
  temp.inverse<-temp.S_dimension_blocks_matrix
  temp.num_blocks=temp.S_dimension/(num_detectors.par*cyclic_period_index.par)
  temp.numerator_determinant=log(1)
  for(temp.j in 1:temp.num_blocks){
    temp.indices<-(temp.j-1)*(num_detectors.par*cyclic_period_index.par)+1:(num_detectors.par*cyclic_period_index.par)
    temp.block<-S_hat.par[temp.indices,temp.indices]
    temp.S_dimension_blocks_matrix[temp.indices,temp.indices]<-temp.block
    temp.numerator_determinant=temp.numerator_determinant+determinant_large_square_partitioned_matrix.function(temp.block)
    temp.running_inverse<-c()
    if(!Det(temp.block)){
      temp.running_inverse<-ginv(temp.block)
    } else{
      temp.running_inverse<-matrix.inverse(temp.block)
    }
    temp.block_square_root<-complex.cholesky_square_root(temp.running_inverse)
    temp.inverse[temp.indices,temp.indices]<-temp.block_square_root
  }
  temp.list<-list(out.S_dimension_blocks_matrix=temp.S_dimension_blocks_matrix,
                  out.inverse=temp.inverse,
                  out.numerator_determinant=temp.numerator_determinant)
  return(temp.list)
}


block_diagonal_rotational_coherence_matrix.function<-function(S_dimension_blocks_matrix.par,S_dimension_cycle_blocks_matrix.par,
                                                              num_detectors.par,cyclic_period_index.par,verbose.par=FALSE){
  if(verbose.par==TRUE){
    cat("temp.rotational_correlation_matrix\n")
  }
  temp.S_dimension=nrow(S_dimension_blocks_matrix.par)
  temp.num_blocks=temp.S_dimension/num_detectors.par
  temp.product_matrix1<-matrix(0,nrow=temp.S_dimension,ncol=temp.S_dimension)
  for(temp.j in 1:temp.num_blocks){
    temp.indices<-(temp.j-1)*num_detectors.par+1:num_detectors.par
    temp.block1<-S_dimension_cycle_blocks_matrix.par[temp.indices,temp.indices]
    temp.block2<-S_dimension_blocks_matrix.par[temp.indices,temp.indices]
    temp.block<-temp.block1%*%temp.block2
    temp.product_matrix1[temp.indices,temp.indices]<-temp.block
  }
  temp.rotational_correlation_matrix<-matrix(0,nrow=temp.S_dimension,ncol=temp.S_dimension)
  for(temp.j in 1:temp.num_blocks){
    temp.indices<-(temp.j-1)*num_detectors.par+1:num_detectors.par
    temp.block1<-S_dimension_blocks_matrix.par[temp.indices,temp.indices]
    temp.block2<-temp.product_matrix1[temp.indices,temp.indices]
    temp.block<-temp.block1%*%temp.block2
    temp.rotational_correlation_matrix[temp.indices,temp.indices]<-temp.block
  }
  return(temp.rotational_correlation_matrix)
}


block_diagonal_inverses_rotational_coherence_matrix.function<-function(S_dimension_blocks_matrix.par,S_dimension_cycle_blocks_matrix.par,
                                                                       num_detectors.par,cyclic_period_index.par,verbose.par=FALSE){
  if(verbose.par==TRUE){
    cat("temp.rotational_correlation_matrix\n")
  }
  temp.S_dimension=nrow(S_dimension_blocks_matrix.par)
  temp.num_blocks=temp.S_dimension/(num_detectors.par*cyclic_period_index.par)
  temp.product_matrix1<-matrix(0,nrow=temp.S_dimension,ncol=temp.S_dimension)
  for(temp.j in 1:temp.num_blocks){
    temp.indices<-(temp.j-1)*(num_detectors.par*cyclic_period_index.par)+1:(num_detectors.par*cyclic_period_index.par)
    temp.block1<-S_dimension_cycle_blocks_matrix.par[temp.indices,temp.indices]
    for(temp.k in 1:temp.num_blocks){
      temp.indices2<-(temp.k-1)*(num_detectors.par*cyclic_period_index.par)+1:(num_detectors.par*cyclic_period_index.par)
      temp.block2<-S_dimension_blocks_matrix.par[temp.indices,temp.indices2]
      temp.block<-temp.block1%*%temp.block2
      temp.product_matrix1[temp.indices,temp.indices2]<-temp.block
    }
  }
  temp.rotational_correlation_matrix<-matrix(0,nrow=temp.S_dimension,ncol=temp.S_dimension)
  for(temp.j in 1:temp.num_blocks){
    temp.indices<-(temp.j-1)*(num_detectors.par*cyclic_period_index.par)+1:(num_detectors.par*cyclic_period_index.par)
    temp.block1<-S_dimension_blocks_matrix.par[temp.indices,temp.indices]
    for(temp.k in 1:temp.num_blocks){
      temp.indices2<-(temp.k-1)*(num_detectors.par*cyclic_period_index.par)+1:(num_detectors.par*cyclic_period_index.par)
      temp.block2<-temp.product_matrix1[temp.indices,temp.indices2]
      temp.block<-temp.block1%*%temp.block2
      temp.rotational_correlation_matrix[temp.indices,temp.indices2]<-temp.block
    }
  }
  return(temp.rotational_correlation_matrix)
}


#ACS vs. WSS
Ramirez_ACS_vs_WSS_preparation.function<-function(S_hat.par,num_detectors.par,record_size.par,cyclic_period_index.par,verbose.par=FALSE){
  temp.S_dimension_blocks_matrix_object<-S_dimension_blocks_matrix.function(S_hat.par=S_hat.par,num_detectors.par=num_detectors.par,
                                                                            record_size.par=record_size.par,verbose.par=verbose.par)
  temp.S_dimension_blocks_matrix<-temp.S_dimension_blocks_matrix_object$out.inverse
  temp.denominator_determinant=temp.S_dimension_blocks_matrix_object$out.denominator_determinant
  cat("temp.denominator_determinant=",temp.denominator_determinant,"\n")
  temp.S_dimension_cycle_blocks_matrix_object<-S_dimension_cycle_blocks_matrix.function(S_hat.par=S_hat.par,num_detectors.par=num_detectors.par,
                                                                                        cyclic_period_index.par=cyclic_period_index.par,
                                                                                        record_size.par=record_size.par,
                                                                                        verbose.par=verbose.par)
  temp.S_dimension_cycle_blocks_matrix<-temp.S_dimension_cycle_blocks_matrix_object$out.S_dimension_blocks_matrix
  temp.numerator_determinant=temp.S_dimension_cycle_blocks_matrix_object$out.numerator_determinant
  cat("temp.numerator_determinant=",temp.numerator_determinant,"\n")
  temp.glr=temp.numerator_determinant-temp.denominator_determinant
  cat("temp.glr=",temp.glr,"\n")
  temp.rotational_correlation_matrix<-#temp.S_dimension_blocks_matrix%*%temp.S_dimension_cycle_blocks_matrix%*%temp.S_dimension_blocks_matrix
    block_diagonal_rotational_coherence_matrix.function(S_dimension_blocks_matrix.par=temp.S_dimension_blocks_matrix,
                                                        S_dimension_cycle_blocks_matrix.par=temp.S_dimension_cycle_blocks_matrix,
                                                        num_detectors.par=num_detectors.par,cyclic_period_index.par=cyclic_period_index.par,
                                                        verbose.par=verbose.par)
  temp.list<-list(out.glr=temp.glr,
                  out.rotational_correlation_matrix=temp.rotational_correlation_matrix)
  return(temp.list)
}


Ramirez_ACS_vs_nonsingular_preparation.function<-function(S_hat.par,num_detectors.par,record_size.par,cyclic_period_index.par,
                                                          GLRT_bool.par=FALSE,verbose.par=FALSE){
  temp.rotational_correlation_matrix<-c()
  temp.determinant_rotational_correlation_matrix=0
  temp.S_dimension_ACS_blocks_matrix<-c()
  temp.S_dimension_cycle_blocks_matrix_object<-S_dimension_cycle_blocks_matrix.function(S_hat.par=S_hat.par,num_detectors.par=num_detectors.par,
                                                                                        cyclic_period_index.par=cyclic_period_index.par,
                                                                                        record_size.par=record_size.par,
                                                                                        verbose.par=verbose.par)
  temp.S_dimension_cycle_blocks_matrix<-temp.S_dimension_cycle_blocks_matrix_object$out.inverse
  temp.denominator_determinant=temp.S_dimension_cycle_blocks_matrix_object$out.numerator_determinant
  temp.numerator_determinant=determinant_large_square_partitioned_matrix.function(S_hat.par)
  #temp.numerator_determinant=log(Re(Det(S_hat.par)))
  temp.glr=temp.numerator_determinant-temp.denominator_determinant
  temp.rotational_correlation_matrix<-#temp.S_dimension_cycle_blocks_matrix%*%S_hat.par%*%temp.S_dimension_cycle_blocks_matrix
    block_diagonal_inverses_rotational_coherence_matrix.function(S_dimension_blocks_matrix.par=temp.S_dimension_cycle_blocks_matrix,
                                                                 S_dimension_cycle_blocks_matrix.par=S_hat.par,
                                                                 num_detectors.par=num_detectors.par,cyclic_period_index.par=cyclic_period_index.par,
                                                                 verbose.par=verbose.par)
  temp.list<-list(out.determinant_rotational_correlation_matrix=temp.determinant_rotational_correlation_matrix,
                  out.rotational_correlation_matrix=temp.rotational_correlation_matrix,
                  out.glr=temp.glr)
  return(temp.list)
}


Ramirez_ACS_vs_WSS.function<-function(rotational_correlation_matrix.par,num_detectors.par,cyclic_period_index.par,num_trial_samples.par,
                                      record_size.par,asymptotic_distribution_bool.par=FALSE,verbose.par=FALSE){
  temp.S_dimension=nrow(rotational_correlation_matrix.par)
  #LMPIT
  temp.lmpit_statistic=0
  temp.num_blocks=temp.S_dimension/num_detectors.par
  for(temp.j in 1:temp.num_blocks){
    temp.indices<-(temp.j-1)*num_detectors.par+1:num_detectors.par
    temp.block<-rotational_correlation_matrix.par[temp.indices,temp.indices]
    temp.lmpit_statistic=temp.lmpit_statistic+sum(Mod(temp.block)^2)
  }
  temp.lmpit_statistic=log(temp.lmpit_statistic)
  if(verbose.par==TRUE){
    cat("temp.lmpit_statistic=",temp.lmpit_statistic,"\n")
  }
  temp.list<-list(out.lmpit_statistic=temp.lmpit_statistic)
  if(asymptotic_distribution_bool.par==TRUE){
    #Asymptotic distribution analysis.
    #LMPIT
    temp.lmpit_asymptotic_statistic=num_trial_samples.par*(temp.lmpit_statistic-num_detectors.par*temp.S_dimension)
    #GLRT
    temp.df=2*num_detectors.par^2*record_size.par*(cyclic_period_index.par-1)
    temp.chi_squared_threshold=qchisq(1-1/(record_size.par*num_trial_samples.par),temp.df)
    list.append(temp.list,
                out.lmpit_asymptotic_statistic=temp.lmpit_asymptotic_statistic,
                out.chi_squared_threshold=temp.chi_squared_threshold,
                out.df=temp.df)
  }
  return(temp.list)
}


Ramirez_ACS_vs_nonsingular.function<-function(rotational_correlation_matrix.par,num_detectors.par,cyclic_period_index.par,num_trial_samples.par,
                                              record_size.par,asymptotic_distribution_bool.par=FALSE,verbose.par=FALSE){
  temp.S_dimension=nrow(rotational_correlation_matrix.par)
  #LMPIT
  temp.lmpit_statistic=0
  temp.num_blocks=temp.S_dimension/(num_detectors.par*cyclic_period_index.par)
  for(temp.j in 1:temp.num_blocks){
    temp.indices<-(temp.j-1)*(num_detectors.par*cyclic_period_index.par)+1:(num_detectors.par*cyclic_period_index.par)
    temp.block<-rotational_correlation_matrix.par[temp.indices,temp.indices]
    temp.lmpit_statistic=temp.lmpit_statistic+sum(Mod(temp.block)^2)
  }
  temp.lmpit_statistic=log(temp.lmpit_statistic)
  if(verbose.par==TRUE){
    cat("temp.lmpit_statistic=",temp.lmpit_statistic,"\n")
  }
  temp.list<-list(out.lmpit_statistic=temp.lmpit_statistic)
  if(asymptotic_distribution_bool.par==TRUE){
    #Asymptotic distribution analysis.
    #LMPIT
    temp.lmpit_asymptotic_statistic=num_trial_samples.par*(temp.lmpit_statistic-num_detectors.par*temp.S_dimension)
    #GLRT
    temp.df=2*num_detectors.par^2*record_size.par*(cyclic_period_index.par-1)
    temp.chi_squared_threshold=qchisq(1-1/(record_size.par*num_trial_samples.par),temp.df)
    list.append(temp.list,
                out.lmpit_asymptotic_statistic=temp.lmpit_asymptotic_statistic,
                out.chi_squared_threshold=temp.chi_squared_threshold,
                out.df=temp.df)
  }
  return(temp.list)
}


Ramirez_ACS_vs_WSS_analysis.function<-function(S_hat.par,num_detectors.par,record_size.par,cyclic_period_index.par,num_trial_samples.par,
                                               asymptotic_distribution_bool.par=FALSE,verbose.par=FALSE){
  temp.Ramirez_ACS_vs_WSS_preparation_object<-
    Ramirez_ACS_vs_WSS_preparation.function(S_hat.par=S_hat.par,num_detectors.par=num_detectors.par,record_size.par=record_size.par,
                                            cyclic_period_index.par=cyclic_period_index.par,verbose.par=verbose.par)
  temp.rotational_correlation_matrix_ACS_vs_WSS<-temp.Ramirez_ACS_vs_WSS_preparation_object$out.rotational_correlation_matrix
  temp.GLR=temp.Ramirez_ACS_vs_WSS_preparation_object$out.glr
  cat("temp.GLR=",temp.GLR,"\n")
  temp.Ramirez_ACS_vs_WSS_object<-
    Ramirez_ACS_vs_WSS.function(rotational_correlation_matrix.par=temp.rotational_correlation_matrix_ACS_vs_WSS,
                                num_detectors.par=num_detectors.par,cyclic_period_index.par=cyclic_period_index.par,
                                num_trial_samples.par=num_trial_samples.par,record_size.par=record_size.par,
                                asymptotic_distribution_bool.par=asymptotic_distribution_bool.par,verbose.par=verbose.par)
  temp.lmpit_statistic=temp.Ramirez_ACS_vs_WSS_object$out.lmpit_statistic
  temp.list<-list(out.lmpit_statistic=temp.lmpit_statistic,
                  out.GLR=temp.GLR)
  return(temp.list)
}


Ramirez_ACS_vs_nonsingular_analysis.function<-function(S_hat.par,num_detectors.par,record_size.par,cyclic_period_index.par,num_trial_samples.par,
                                                       null_hypothesis_bool.par=FALSE,
                                                       asymptotic_distribution_bool.par=FALSE,verbose.par=FALSE){
  temp.Ramirez_ACS_vs_nonsingular_preparation_object<-
    Ramirez_ACS_vs_nonsingular_preparation.function(S_hat.par=S_hat.par,num_detectors.par=num_detectors.par,record_size.par=record_size.par,
                                                    cyclic_period_index.par=cyclic_period_index.par,
                                                    GLRT_bool.par=FALSE,verbose.par=verbose.par)
  temp.rotational_correlation_matrix_ACS_vs_nonsingular<-temp.Ramirez_ACS_vs_nonsingular_preparation_object$out.rotational_correlation_matrix
  temp.GLR=temp.Ramirez_ACS_vs_nonsingular_preparation_object$out.glr
  temp.Ramirez_ACS_vs_nonsingular_object<-
    Ramirez_ACS_vs_nonsingular.function(rotational_correlation_matrix.par=temp.rotational_correlation_matrix_ACS_vs_nonsingular,
                                        num_detectors.par=num_detectors.par,cyclic_period_index.par=cyclic_period_index.par,
                                        num_trial_samples.par=num_trial_samples.par,record_size.par=record_size.par,
                                        asymptotic_distribution_bool.par=asymptotic_distribution_bool.par,verbose.par=verbose.par)
  temp.lmpit_statistic=temp.Ramirez_ACS_vs_nonsingular_object$out.lmpit_statistic
  temp.list<-list(out.lmpit_statistic=temp.lmpit_statistic,
                  out.GLR=temp.GLR)
  return(temp.list)
}


Ramirez_null_distributions_ACS_WSS.function<-function(N.par,ar_coefficients.par,
                                                      innovation_variance.par,noise_variance.par,
                                                      frequencies.par,
                                                      num_cycles.par,num_detectors.par,
                                                      num_longitudinal_samples.par,num_decimated_sim.par,
                                                      decimation_sampling_rate.par=1,first_time.par=0,
                                                      num_tests.par=1,
                                                      decimation_step.par=1,dimension_multiple.par=1,
                                                      sampling_rate.par=1,base_time.par=0,
                                                      ecdf_abscissa_label.par="Measured value",
                                                      plot_bool.par=FALSE){
  temp.innovation_sd=sqrt(innovation_variance.par)
  temp.noise_sd=sqrt(noise_variance.par)
  temp.times_original<-base_time.par+(1:N.par-1)*sampling_rate.par
  temp.decimation_indices<-seq(from=1,to=N.par,by=decimation_step.par)
  #temp.decimation_indices<-temp.decimation_indices[1:floor(num_longitudinal_samples.par/2/dimension_multiple.par/num_detectors.par)]
  temp.num_decimated_sim=length(temp.decimation_indices)
  temp.period_size=floor(temp.num_decimated_sim/num_cycles.par)
  temp.num_decimated_sim=num_cycles.par*temp.period_size
  temp.decimation_indices<-temp.decimation_indices[1:temp.num_decimated_sim]
  temp.decimated_times<-temp.times_original[temp.decimation_indices]
  temp.decimation_sampling_period=temp.decimated_times[2]-temp.decimated_times[1]
  temp.decimation_sampling_rate=1/temp.decimation_sampling_period
  temp.GLRT_realizations<-rep(0,num_tests.par)
  temp.LMPIT_realizations<-temp.GLRT_realizations
  temp.all_y_matrices<-list()
  temp.all_Gaussian_deviates_input_matrix_list<-list()
  temp.all_Gaussian_deviates_residual_matrix_list<-list()
  temp.running_seeds<-c(1,2)
  for(temp.i in 1:num_tests.par){
    cat(temp.i," out of ",num_tests.par,"\n")
    temp.y_matrix_list<-list()
    temp.Gaussian_deviates_input_matrix_list<-list()
    temp.Gaussian_deviates_residual_matrix_list<-list()
    for(temp.k in 1:num_longitudinal_samples.par){
      temp.y_matrix_list[[temp.k]]<-matrix(0,nrow=num_detectors.par,ncol=temp.num_decimated_sim)
      temp.Gaussian_deviates_input_matrix_list[[temp.k]]<-matrix(0,nrow=num_detectors.par,ncol=N.par)
      temp.Gaussian_deviates_residual_matrix_list[[temp.k]]<-temp.Gaussian_deviates_input_matrix_list[[temp.k]]
    }
    temp.standard_normal_variates<-c()
    for(temp.k in 1:num_longitudinal_samples.par){
      cat(temp.k," out of ",num_longitudinal_samples.par,"\n")
      for(temp.j in 1:num_detectors.par){
        if(temp.k==1 & temp.j==1){
          temp.gaussian_RNG_object<-gaussian.RNG(num_rv.par=temp.num_decimated_sim,seed.par=temp.running_seeds,
                                                 uniform_numbers.par=NA)
          temp.running_uniform_numbers0<-temp.gaussian_RNG_object$out.uniform_rvs
          temp.standard_normal_variates0<-temp.gaussian_RNG_object$out.random_numbers
          temp.running_uniform_numbers1<-temp.running_uniform_numbers0
          temp.standard_normal_variates1<-temp.standard_normal_variates0
          temp.seed_counter=1
          while(length(temp.running_uniform_numbers1)<N.par){
            set.seed(temp.i+temp.j+temp.k+temp.seed_counter)
            temp.running_uniform_numbers1<-c(temp.running_uniform_numbers1,sample(temp.running_uniform_numbers0))
            set.seed(temp.i+temp.j+temp.k+temp.seed_counter+2)
            temp.standard_normal_variates1<-c(temp.standard_normal_variates1,sample(temp.standard_normal_variates0))
            temp.seed_counter=temp.seed_counter+1
          }
          temp.standard_normal_variates<-temp.standard_normal_variates1[1:N.par]
          temp.standard_normal_variates<-temp.standard_normal_variates*temp.innovation_sd
        }
        set.seed(temp.i+temp.k+temp.j)
        temp.standard_normal_variates<-sample(temp.standard_normal_variates)
        temp.laptv_object<-laptv.function(innovations_sequence.par=temp.standard_normal_variates,time_sequence.par=temp.times_original,
                                          frequencies.par=frequencies.par,
                                          transient_offset.par=0,cyclic_frequency_indices.par=NA,
                                          ar_coefficients.par=ar_coefficients.par,
                                          sampling_rate.par=temp.decimation_sampling_rate,first_time.par=first_time.par)
        #temp.y_matrix_list[[temp.k]][temp.j,]<-temp.laptv_object$out.laptv_output
        #Generate substantial noise.
        set.seed(temp.i+1+temp.k+1+temp.j+1)
        temp.noise_deviates<-sample(temp.standard_normal_variates)*temp.noise_sd/temp.innovation_sd
        temp.Gaussian_deviates_input_matrix_list[[temp.k]][temp.j,]<-temp.standard_normal_variates
        temp.Gaussian_deviates_residual_matrix_list[[temp.k]][temp.j,]<-temp.noise_deviates
        temp.noise_deviates<-temp.noise_deviates[temp.decimation_indices]
        temp.laptv_output<-temp.laptv_object$out.laptv_output
        temp.laptv_output<-temp.laptv_output[temp.decimation_indices]
        temp.y_matrix_list[[temp.k]][temp.j,]<-temp.laptv_output+temp.noise_deviates
        temp.running_seeds<-c(temp.i,temp.j)+temp.k
      }
    }
    temp.all_y_matrices[[temp.i]]<-temp.y_matrix_list
    temp.all_Gaussian_deviates_input_matrix_list[[temp.i]]<-temp.Gaussian_deviates_input_matrix_list
    temp.all_Gaussian_deviates_residual_matrix_list[[temp.i]]<-temp.Gaussian_deviates_residual_matrix_list
    temp.Ramirez_preprocessing_object<-Ramirez_preprocessing.function(y_matrix_list.par=temp.y_matrix_list,N.par=temp.num_decimated_sim,
                                                                      num_detectors.par=num_detectors.par,
                                                                      num_cycles.par=num_cycles.par,decimation_step.par=1,
                                                                      harmonic_bool.par=FALSE)
    temp.record_size=temp.Ramirez_preprocessing_object$out.record_size
    temp.num_decimated=temp.Ramirez_preprocessing_object$out.num_decimated
    temp.cyclic_period_index=temp.Ramirez_preprocessing_object$out.cyclic_period_index
    temp.Fourier_matrix<-temp.Ramirez_preprocessing_object$out.Fourier_matrix
    temp.decimated_y_matrix_list<-temp.Ramirez_preprocessing_object$out.decimated_y_matrix_list
    temp.S_hat<-Ramirez_z_vector_reordered_frequencies_Shat(decimated_y_matrix_list.par=temp.decimated_y_matrix_list,
                                                            Fourier_matrix.par=temp.Fourier_matrix,cyclic_period_index.par=temp.cyclic_period_index,
                                                            num_cycles.par=num_cycles.par,num_detectors.par=num_detectors.par,
                                                            num_trial_samples.par=num_longitudinal_samples.par,decimation_step.par=decimation_step.par,
                                                            record_size.par=temp.record_size,verbose.par=TRUE)
    temp.Ramirez_ACS_vs_WSS_analysis_object<-
      Ramirez_ACS_vs_WSS_analysis.function(S_hat.par=temp.S_hat,num_detectors.par=num_detectors.par,
                                           record_size.par=temp.record_size,
                                           cyclic_period_index.par=temp.cyclic_period_index,
                                           num_trial_samples.par=num_longitudinal_samples.par,
                                           asymptotic_distribution_bool.par=TRUE,verbose.par=TRUE)
    temp.lmpit_statistic=temp.Ramirez_ACS_vs_WSS_analysis_object$out.lmpit_statistic
    temp.GLR=temp.Ramirez_ACS_vs_WSS_analysis_object$out.GLR
    temp.GLRT_realizations[temp.i]=temp.GLR
    temp.LMPIT_realizations[temp.i]=temp.lmpit_statistic
  }
  cat("temp.GLRT_realizations\n")
  print(temp.GLRT_realizations)
  #GLRT
  temp.GLRT_realizations<-temp.GLRT_realizations[is.infinite(temp.GLRT_realizations)==FALSE]
  temp.empirical_distribution_GLRT_object<-empirical.distribution(temp.GLRT_realizations)
  temp.empirical_distribution_GLRT<-temp.empirical_distribution_GLRT_object$temp.empirical_distribution
  temp.sorted_GLRT_realizations<-temp.empirical_distribution_GLRT_object$temp.ordered_rv
  if(plot_bool.par==TRUE){
    plot.graph(list(temp.sorted_GLRT_realizations),list(temp.empirical_distribution_GLRT*100),
               x_label.par="Logarithmic GLR",y_label.par="Percentage cumulative probability",
               pdf_title.par="GLRT_Empirical_CDF_ACS_vs_WSS.pdf")
  }
  #LMPIT
  temp.LMPIT_realizations<-temp.LMPIT_realizations[is.infinite(temp.LMPIT_realizations)==FALSE]
  temp.empirical_distribution_LMPIT_object<-empirical.distribution(temp.LMPIT_realizations)
  temp.empirical_distribution_LMPIT<-temp.empirical_distribution_LMPIT_object$temp.empirical_distribution
  temp.sorted_LMPIT_realizations<-temp.empirical_distribution_LMPIT_object$temp.ordered_rv
  if(plot_bool.par==TRUE){
    plot.graph(list(temp.sorted_LMPIT_realizations),list(temp.empirical_distribution_LMPIT*100),
               x_label.par="Logarithmic LMPIT statistic",y_label.par="Percentage cumulative probability",
               pdf_title.par="LMPIT_Empirical_CDF_ACS_vs_WSS.pdf")
  }
  temp.list<-list(out.decimated_times=temp.decimated_times,
                  out.sorted_GLRT_realizations=temp.sorted_GLRT_realizations,
                  out.sorted_LMPIT_realizations=temp.sorted_LMPIT_realizations,
                  out.empirical_distribution_GLRT=temp.empirical_distribution_GLRT,
                  out.empirical_distribution_LMPIT=temp.empirical_distribution_LMPIT,
                  out.all_y_matrices=temp.all_y_matrices,
                  out.all_Gaussian_deviates_input_matrix_list=temp.all_Gaussian_deviates_input_matrix_list,
                  out.all_Gaussian_deviates_residual_matrix_list=temp.all_Gaussian_deviates_residual_matrix_list,
                  out.num_decimated_sim=temp.num_decimated_sim)
  return(temp.list)
}


Ramirez_null_distributions_ACS_nonsingular.function<-function(N.par,ar_coefficients.par,cyclic_frequency_indices.par,
                                                              innovation_variance.par,noise_variance.par,
                                                              num_cycles.par,num_detectors.par,num_longitudinal_samples.par,
                                                              num_tests.par=1,
                                                              decimation_step.par=1,dimension_multiple.par=1,
                                                              base_time.par=0,sampling_rate.par=1,first_time.par=0,
                                                              plot_bool.par=FALSE){
  temp.innovation_sd=sqrt(innovation_variance.par)
  temp.noise_sd=sqrt(noise_variance.par)
  temp.times_original<-base_time.par+(1:N.par-1)*sampling_rate.par
  temp.decimation_indices<-seq(from=1,to=N.par,by=decimation_step.par)
  #temp.decimation_indices<-temp.decimation_indices[1:floor(num_longitudinal_samples.par/2/dimension_multiple.par/num_detectors.par)]
  temp.num_decimated_sim=length(temp.decimation_indices)
  temp.period_size=floor(temp.num_decimated_sim/num_cycles.par)
  temp.num_decimated_sim=num_cycles.par*temp.period_size
  temp.decimation_indices<-temp.decimation_indices[1:temp.num_decimated_sim]
  temp.decimated_times<-temp.times_original[temp.decimation_indices]
  temp.multitaper_parameters_object<-multitaper_parameters.function(temp.num_decimated_sim,NW.par=NW.par)
  temp.M=temp.multitaper_parameters_object$out.M
  temp.M2=temp.multitaper_parameters_object$out.M_2
  temp.frequencies<-(1:temp.M2-1)/temp.M
  temp.decimation_sampling_period=temp.decimated_times[2]-temp.decimated_times[1]
  temp.decimation_sampling_rate=1/temp.decimation_sampling_period
  temp.GLRT_realizations<-rep(0,num_tests.par)
  temp.LMPIT_realizations<-temp.GLRT_realizations
  temp.all_y_matrices<-list()
  temp.all_Gaussian_deviates_input_matrix_list<-list()
  temp.all_Gaussian_deviates_residual_matrix_list<-list()
  temp.running_seeds<-c(1,2)
  for(temp.i in 1:num_tests.par){
    cat(temp.i," out of ",num_tests.par,"\n")
    temp.y_matrix_list<-list()
    temp.Gaussian_deviates_input_matrix_list<-list()
    temp.Gaussian_deviates_residual_matrix_list<-list()
    for(temp.k in 1:num_longitudinal_samples.par){
      temp.y_matrix_list[[temp.k]]<-matrix(0,nrow=num_detectors.par,ncol=temp.num_decimated_sim)
      temp.Gaussian_deviates_input_matrix_list[[temp.k]]<-matrix(0,nrow=num_detectors.par,ncol=N.par)
      temp.Gaussian_deviates_residual_matrix_list[[temp.k]]<-temp.Gaussian_deviates_input_matrix_list[[temp.k]]
    }
    temp.standard_normal_variates<-c()
    for(temp.k in 1:num_longitudinal_samples.par){
      cat(temp.k," out of ",num_longitudinal_samples.par,"\n")
      for(temp.j in 1:num_detectors.par){
        if(temp.k==1 & temp.j==1){
          temp.gaussian_RNG_object<-gaussian.RNG(num_rv.par=temp.num_decimated_sim,seed.par=temp.running_seeds,
                                                 uniform_numbers.par=NA)
          temp.running_uniform_numbers0<-temp.gaussian_RNG_object$out.uniform_rvs
          temp.standard_normal_variates0<-temp.gaussian_RNG_object$out.random_numbers
          temp.running_uniform_numbers1<-temp.running_uniform_numbers0
          temp.standard_normal_variates1<-temp.standard_normal_variates0
          temp.seed_counter=1
          while(length(temp.running_uniform_numbers1)<N.par){
            set.seed(temp.i+temp.j+temp.k+temp.seed_counter)
            temp.running_uniform_numbers1<-c(temp.running_uniform_numbers1,sample(temp.running_uniform_numbers0))
            set.seed(temp.i+temp.j+temp.k+temp.seed_counter+2)
            temp.standard_normal_variates1<-c(temp.standard_normal_variates1,sample(temp.standard_normal_variates0))
            temp.seed_counter=temp.seed_counter+1
          }
          temp.standard_normal_variates<-temp.standard_normal_variates1[1:N.par]
          temp.standard_normal_variates<-temp.standard_normal_variates*temp.innovation_sd
        }
        set.seed(temp.i+temp.k+temp.j)
        temp.standard_normal_variates<-sample(temp.standard_normal_variates)
        temp.laptv_object<-laptv.function(innovations_sequence.par=temp.standard_normal_variates,time_sequence.par=temp.times_original,
                                          frequencies.par=temp.frequencies,
                                          transient_offset.par=0,cyclic_frequency_indices.par=cyclic_frequency_indices.par,
                                          ar_coefficients.par=ar_coefficients.par,
                                          sampling_rate.par=sampling_rate.par,first_time.par=first_time.par)
        #temp.y_matrix_list[[temp.k]][temp.j,]<-temp.laptv_object$out.laptv_output
        #Generate substantial noise.
        set.seed(temp.i+1+temp.k+1+temp.j+1)
        temp.noise_deviates<-sample(temp.standard_normal_variates)*temp.noise_sd/temp.innovation_sd
        temp.Gaussian_deviates_input_matrix_list[[temp.k]][temp.j,]<-temp.standard_normal_variates
        temp.Gaussian_deviates_residual_matrix_list[[temp.k]][temp.j,]<-temp.noise_deviates
        temp.noise_deviates<-temp.noise_deviates[temp.decimation_indices]
        temp.y_matrix_list[[temp.k]][temp.j,]<-temp.laptv_object$out.laptv_output[temp.decimation_indices]+temp.noise_deviates
        temp.running_seeds<-c(temp.i,temp.j)+temp.k
      }
    }
    temp.all_y_matrices[[temp.i]]<-temp.y_matrix_list
    temp.all_Gaussian_deviates_input_matrix_list[[temp.i]]<-temp.Gaussian_deviates_input_matrix_list
    temp.all_Gaussian_deviates_residual_matrix_list[[temp.i]]<-temp.Gaussian_deviates_residual_matrix_list
    temp.Ramirez_preprocessing_object<-Ramirez_preprocessing.function(y_matrix_list.par=temp.y_matrix_list,N.par=temp.num_decimated_sim,
                                                                      num_detectors.par=num_detectors.par,
                                                                      num_cycles.par=num_cycles.par,decimation_step.par=1,
                                                                      harmonic_bool.par=FALSE)
    temp.record_size=temp.Ramirez_preprocessing_object$out.record_size
    temp.num_decimated=temp.Ramirez_preprocessing_object$out.num_decimated
    temp.cyclic_period_index=temp.Ramirez_preprocessing_object$out.cyclic_period_index
    temp.Fourier_matrix<-temp.Ramirez_preprocessing_object$out.Fourier_matrix
    temp.decimated_y_matrix_list<-temp.Ramirez_preprocessing_object$out.decimated_y_matrix_list
    temp.S_hat<-Ramirez_z_vector_reordered_frequencies_Shat(decimated_y_matrix_list.par=temp.decimated_y_matrix_list,
                                                            Fourier_matrix.par=temp.Fourier_matrix,cyclic_period_index.par=temp.cyclic_period_index,
                                                            num_cycles.par=num_cycles.par,num_detectors.par=num_detectors.par,
                                                            num_trial_samples.par=num_longitudinal_samples.par,
                                                            record_size.par=temp.record_size,verbose.par=TRUE)
    temp.Ramirez_ACS_vs_nonsingular_analysis_object<-
      Ramirez_ACS_vs_nonsingular_analysis.function(S_hat.par=temp.S_hat,num_detectors.par=num_detectors.par,
                                                   record_size.par=temp.record_size,
                                                   cyclic_period_index.par=temp.cyclic_period_index,
                                                   num_trial_samples.par=num_longitudinal_samples.par,
                                                   null_hypothesis_bool.par=TRUE,asymptotic_distribution_bool.par=TRUE,verbose.par=TRUE)
    temp.lmpit_statistic=temp.Ramirez_ACS_vs_nonsingular_analysis_object$out.lmpit_statistic
    temp.GLR=temp.Ramirez_ACS_vs_nonsingular_analysis_object$out.GLR
    temp.GLRT_realizations[temp.i]=temp.GLR
    cat("temp.GLR\n")
    print(temp.GLR)
    temp.LMPIT_realizations[temp.i]=temp.lmpit_statistic
    cat("temp.lmpit_statistic\n")
    print(temp.lmpit_statistic)
  }
  #GLRT
  cat("temp.GLRT_realizations\n")
  print(temp.GLRT_realizations)
  temp.GLRT_realizations<-temp.GLRT_realizations[is.infinite(temp.GLRT_realizations)==FALSE]
  temp.empirical_distribution_GLRT_object<-empirical.distribution(temp.GLRT_realizations)
  temp.empirical_distribution_GLRT<-temp.empirical_distribution_GLRT_object$temp.empirical_distribution
  temp.sorted_GLRT_realizations<-temp.empirical_distribution_GLRT_object$temp.ordered_rv
  if(plot_bool.par==TRUE){
    plot.graph(list(temp.sorted_GLRT_realizations),list(temp.empirical_distribution_GLRT*100),
               x_label.par="Logarithmic GLR",y_label.par="Percentage cumulative probability",
               pdf_title.par="GLRT_Empirical_CDF_ACS_vs_nonsingular.pdf")
  }
  #LMPIT
  temp.LMPIT_realizations<-temp.LMPIT_realizations[is.infinite(temp.LMPIT_realizations)==FALSE]
  temp.empirical_distribution_LMPIT_object<-empirical.distribution(temp.LMPIT_realizations)
  temp.empirical_distribution_LMPIT<-temp.empirical_distribution_LMPIT_object$temp.empirical_distribution
  temp.sorted_LMPIT_realizations<-temp.empirical_distribution_LMPIT_object$temp.ordered_rv
  cat("temp.sorted_LMPIT_realizations\n")
  print(temp.sorted_LMPIT_realizations)
  if(plot_bool.par==TRUE){
    plot.graph(list(temp.sorted_LMPIT_realizations),list(temp.empirical_distribution_LMPIT*100),
               x_label.par="Logarithmic LMPIT statistic",y_label.par="Percentage cumulative probability",
               pdf_title.par="LMPIT_Empirical_CDF_ACS_vs_nonsingular.pdf")
  }
  temp.list<-list(out.decimated_times=temp.decimated_times,
                  out.sorted_GLRT_realizations=temp.sorted_GLRT_realizations,
                  out.sorted_LMPIT_realizations=temp.sorted_LMPIT_realizations,
                  out.empirical_distribution_GLRT=temp.empirical_distribution_GLRT,
                  out.empirical_distribution_LMPIT=temp.empirical_distribution_LMPIT,
                  out.all_y_matrices=temp.all_y_matrices,
                  out.all_Gaussian_deviates_input_matrix_list=temp.all_Gaussian_deviates_input_matrix_list,
                  out.all_Gaussian_deviates_residual_matrix_list=temp.all_Gaussian_deviates_residual_matrix_list,
                  out.num_decimated_sim=temp.num_decimated_sim)
  return(temp.list)
}



roc_initialize_false_alarm_probabilities.function<-function(sorted_realizations.par,empirical_distribution.par,num_false_alarm_probabilities.par=20){
  temp.false_alarm_probabilities<-(1:num_false_alarm_probabilities.par-1)/num_false_alarm_probabilities.par
  temp.false_alarm_thresholds<-rep(0,num_false_alarm_probabilities.par)
  for(temp.j in 1:num_false_alarm_probabilities.par){
    temp.fa_probability=temp.false_alarm_probabilities[temp.j]
    temp.indices<-which(empirical_distribution.par<temp.fa_probability)
    temp.num_indices=length(temp.indices)
    if(temp.num_indices>0){
      temp.false_alarm_thresholds[temp.j]=max(sorted_realizations.par[temp.indices])
    }
  }
  temp.list<-list(out.false_alarm_probabilities=temp.false_alarm_probabilities,
                  out.false_alarm_thresholds=temp.false_alarm_thresholds)
  return(temp.list)
}


laptv_roc_true_positive.function<-function(all_Gaussian_deviates_input_matrix_list.par,
                                           all_Gaussian_deviates_residual_matrix_list.par,
                                           cyclic_frequency_indices.par,ar_coefficients.par,decimation_sampling_rate.par,
                                           num_tests.par,dimension_multiple.par,
                                           num_detectors.par,num_decimated_sim.par,num_longitudinal_samples.par,num_cycles.par,
                                           decimation_step.par,N.par,
                                           sampling_rate.par=1,first_time.par=0,NW.par=5,verbose.par=FALSE){
  cat("cyclic_frequency_indices.par\n")
  print(cyclic_frequency_indices.par)
  temp.multitaper_parameters_object<-multitaper_parameters.function(num_decimated_sim.par,NW.par=NW.par)
  temp.M=temp.multitaper_parameters_object$out.M
  temp.M2=temp.multitaper_parameters_object$out.M_2
  temp.frequencies<-(1:temp.M2-1)/temp.M
  #Generate realizations from a standard-normal innovations process to obtain an empirical null distribution.
  temp.times_original<-first_time.par+(1:N.par-1)*sampling_rate.par
  temp.decimation_indices<-seq(from=1,to=N.par,by=decimation_step.par)
  #temp.decimation_indices<-temp.decimation_indices[1:floor(num_longitudinal_samples.par/2/dimension_multiple.par/num_detectors.par)]
  temp.num_decimated_sim=length(temp.decimation_indices)
  temp.period_size=floor(temp.num_decimated_sim/num_cycles.par)
  cat("N.par=",N.par,"\n")
  cat("temp.num_decimated_sim=",temp.num_decimated_sim,"\n")
  temp.num_decimated_sim=num_cycles.par*temp.period_size
  temp.decimation_indices<-temp.decimation_indices[1:temp.num_decimated_sim]
  temp.decimated_times<-temp.times_original[temp.decimation_indices]
  temp.decimated_sampling_period=temp.decimated_times[2]-temp.decimated_times[1]
  temp.decimation_sampling_rate=1/temp.decimated_sampling_period
  temp.time_indices<-1:num_decimated_sim.par
  temp.GLRT_realizations_H1<-rep(0,num_tests.par)
  temp.LMPIT_realizations_H1<-temp.GLRT_realizations_H1
  for(temp.i in 1:num_tests.par){
    if(verbose.par==TRUE){
      cat(temp.i," out of ",num_tests.par,"\n")
    }
    temp.LAPTV_matrix_list<-list()
    for(temp.k in 1:num_longitudinal_samples.par){
      temp.LAPTV_matrix_list[[temp.k]]<-matrix(0,nrow=num_detectors.par,ncol=temp.num_decimated_sim)
    }
    for(temp.k in 1:num_longitudinal_samples.par){
      for(temp.j in 1:num_detectors.par){
        temp.standard_normal_variates<-all_Gaussian_deviates_input_matrix_list.par[[temp.i]][[temp.k]][temp.j,]
        temp.noise_deviates<-all_Gaussian_deviates_residual_matrix_list.par[[temp.i]][[temp.k]][temp.j,]
        temp.noise_deviates<-temp.noise_deviates[temp.decimation_indices]
        temp.laptv_object<-laptv.function(innovations_sequence.par=temp.standard_normal_variates,time_sequence.par=temp.times_original,
                                          frequencies.par=temp.frequencies,
                                          transient_offset.par=0,cyclic_frequency_indices.par=cyclic_frequency_indices.par,
                                          ar_coefficients.par=ar_coefficients.par,
                                          sampling_rate.par=temp.decimation_sampling_rate,first_time.par=first_time.par)
        temp.laptv_output<-temp.laptv_object$out.laptv_output
        temp.laptv_output<-temp.laptv_output[temp.decimation_indices]
        temp.LAPTV_matrix_list[[temp.k]][temp.j,]<-temp.laptv_output+temp.noise_deviates
      }
    }
    temp.Ramirez_preprocessing_object<-Ramirez_preprocessing.function(y_matrix_list.par=temp.LAPTV_matrix_list,N.par=num_decimated_sim.par,
                                                                      num_detectors.par=num_detectors.par,
                                                                      num_cycles.par=num_cycles.par,decimation_step.par=1,
                                                                      harmonic_bool.par=FALSE)
    temp.record_size=temp.Ramirez_preprocessing_object$out.record_size
    temp.num_decimated=temp.Ramirez_preprocessing_object$out.num_decimated
    temp.cyclic_period_index=temp.Ramirez_preprocessing_object$out.cyclic_period_index
    temp.Fourier_matrix<-temp.Ramirez_preprocessing_object$out.Fourier_matrix
    temp.decimated_y_matrix_list<-temp.Ramirez_preprocessing_object$out.decimated_y_matrix_list
    temp.S_hat<-Ramirez_z_vector_reordered_frequencies_Shat(decimated_y_matrix_list.par=temp.decimated_y_matrix_list,
                                                            Fourier_matrix.par=temp.Fourier_matrix,cyclic_period_index.par=temp.cyclic_period_index,
                                                            num_cycles.par=num_cycles.par,num_detectors.par=num_detectors.par,
                                                            num_trial_samples.par=num_longitudinal_samples.par,
                                                            record_size.par=temp.record_size,verbose.par=verbose.par)
    temp.Ramirez_ACS_vs_WSS_analysis_object<-
      Ramirez_ACS_vs_WSS_analysis.function(S_hat.par=temp.S_hat,num_detectors.par=num_detectors.par,
                                           record_size.par=temp.record_size,
                                           cyclic_period_index.par=temp.cyclic_period_index,
                                           num_trial_samples.par=num_longitudinal_samples.par,
                                           asymptotic_distribution_bool.par=FALSE,verbose.par=verbose.par)
    temp.lmpit_statistic=temp.Ramirez_ACS_vs_WSS_analysis_object$out.lmpit_statistic
    temp.GLR=temp.Ramirez_ACS_vs_WSS_analysis_object$out.GLR
    temp.GLRT_realizations_H1[temp.i]=temp.GLR
    temp.LMPIT_realizations_H1[temp.i]=temp.lmpit_statistic
  }
  temp.list<-list(out.GLRT_realizations_H1=temp.GLRT_realizations_H1,
                  out.LMPIT_realizations_H1=temp.LMPIT_realizations_H1)
  return(temp.list)
}


sarima_roc_true_positive.function<-function(all_Gaussian_deviates_input_matrix_list.par,
                                            all_Gaussian_deviates_residual_matrix_list.par,
                                            innovation_variance.par,noise_variance.par,
                                            cyclic_frequency_indices.par,auto_arima.par,
                                            decimation_sampling_rate.par,num_tests.par,
                                            dimension_multiple.par,
                                            num_detectors.par,
                                            N.par,num_decimated_sim.par,num_longitudinal_samples.par,num_cycles.par,
                                            decimation_step.par,
                                            sampling_rate.par=1,
                                            first_time.par=0,NW.par=5,verbose.par=FALSE){
  cat("cyclic_frequency_indices.par\n")
  print(cyclic_frequency_indices.par)
  temp.multitaper_parameters_object<-multitaper_parameters.function(num_decimated_sim.par,NW.par=NW.par)
  temp.M=temp.multitaper_parameters_object$out.M
  temp.M2=temp.multitaper_parameters_object$out.M_2
  temp.frequencies<-(1:temp.M2-1)/temp.M
  #Generate realizations from a standard-normal innovations process to obtain an empirical null distribution.
  temp.times_original<-first_time.par+(1:N.par-1)*sampling_rate.par
  temp.decimation_indices<-seq(from=1,to=N.par,by=decimation_step.par)
  #temp.decimation_indices<-temp.decimation_indices[1:floor(num_longitudinal_samples.par/2/dimension_multiple.par/num_detectors.par)]
  temp.num_sim=length(temp.decimation_indices)
  temp.time_indices<-1:num_decimated_sim.par
  temp.GLRT_realizations_H1<-rep(0,num_tests.par)
  temp.LMPIT_realizations_H1<-temp.GLRT_realizations_H1
  for(temp.i in 1:num_tests.par){
    if(verbose.par==TRUE){
      cat(temp.i," out of ",num_tests.par,"\n")
    }
    temp.SARIMA_matrix_list<-list()
    temp.cyclic_frequency_indices<-cyclic_frequency_indices.par[cyclic_frequency_indices.par<temp.num_sim]
    for(temp.k in 1:num_longitudinal_samples.par){
      temp.SARIMA_matrix_list[[temp.k]]<-matrix(0,nrow=num_detectors.par,ncol=temp.num_sim)
    }
    for(temp.k in 1:num_longitudinal_samples.par){
      for(temp.j in 1:num_detectors.par){
        temp.standard_normal_variates<-all_Gaussian_deviates_input_matrix_list.par[[temp.i]][[temp.k]][temp.j,]
        temp.noise_deviates<-all_Gaussian_deviates_residual_matrix_list.par[[temp.i]][[temp.k]][temp.j,]
        temp.simulated<-simulate(auto_arima.par,innov=temp.standard_normal_variates,nsim=N.par,future=FALSE)
        temp.integrated_realization<-temp.simulated
        for(temp.l in 1:length(temp.cyclic_frequency_indices)){
          temp.cyclic_frequency_index=temp.cyclic_frequency_indices[temp.l]
          #cat("temp.cyclic_frequency_index=",temp.cyclic_frequency_index,"\n")
          temp.running_indices<-1:(N.par-temp.cyclic_frequency_index)
          temp.integrated_realization[temp.running_indices]<-
            temp.integrated_realization[temp.running_indices]+temp.integrated_realization[temp.running_indices+temp.cyclic_frequency_index]
        }
        #temp.SARIMA_matrix_list[[temp.k]][temp.j,]<-temp.integrated_realization
        temp.SARIMA_matrix_list[[temp.k]][temp.j,]<-temp.integrated_realization[temp.decimation_indices]+temp.noise_deviates[temp.decimation_indices]
      }
    }
    temp.Ramirez_preprocessing_object<-Ramirez_preprocessing.function(y_matrix_list.par=temp.SARIMA_matrix_list,N.par=num_decimated_sim.par,
                                                                      num_detectors.par=num_detectors.par,
                                                                      num_cycles.par=num_cycles.par,decimation_step.par=1,
                                                                      harmonic_bool.par=FALSE)
    temp.record_size=temp.Ramirez_preprocessing_object$out.record_size
    temp.num_decimated=temp.Ramirez_preprocessing_object$out.num_decimated
    temp.cyclic_period_index=temp.Ramirez_preprocessing_object$out.cyclic_period_index
    temp.Fourier_matrix<-temp.Ramirez_preprocessing_object$out.Fourier_matrix
    temp.decimated_y_matrix_list<-temp.Ramirez_preprocessing_object$out.decimated_y_matrix_list
    temp.S_hat<-Ramirez_z_vector_reordered_frequencies_Shat(decimated_y_matrix_list.par=temp.decimated_y_matrix_list,
                                                            Fourier_matrix.par=temp.Fourier_matrix,cyclic_period_index.par=temp.cyclic_period_index,
                                                            num_cycles.par=num_cycles.par,num_detectors.par=num_detectors.par,
                                                            num_trial_samples.par=num_longitudinal_samples.par,
                                                            record_size.par=temp.record_size,verbose.par=verbose.par)
    temp.Ramirez_ACS_vs_WSS_analysis_object<-
      Ramirez_ACS_vs_WSS_analysis.function(S_hat.par=temp.S_hat,num_detectors.par=num_detectors.par,
                                           record_size.par=temp.record_size,
                                           cyclic_period_index.par=temp.cyclic_period_index,
                                           num_trial_samples.par=num_longitudinal_samples.par,
                                           asymptotic_distribution_bool.par=FALSE,verbose.par=verbose.par)
    temp.lmpit_statistic=temp.Ramirez_ACS_vs_WSS_analysis_object$out.lmpit_statistic
    temp.GLR=temp.Ramirez_ACS_vs_WSS_analysis_object$out.GLR
    temp.GLRT_realizations_H1[temp.i]=temp.GLR
    temp.LMPIT_realizations_H1[temp.i]=temp.lmpit_statistic
  }
  temp.list<-list(out.GLRT_realizations_H1=temp.GLRT_realizations_H1,
                  out.LMPIT_realizations_H1=temp.LMPIT_realizations_H1)
  return(temp.list)
}


Ramirez_ACS_vs_WSS_test_metrics.function<-function(cyclic_frequency_indices.par,
                                                   ar_coefficients.par,
                                                   innovation_variance.par,noise_variance.par,
                                                   frequencies.par,
                                                   num_detectors.par,num_longitudinal_samples.par,num_decimated_sim.par,
                                                   num_tests.par,decimation_sampling_rate.par,sampling_rate.par,
                                                   decimation_step.par=1,dimension_multiple.par=1,
                                                   num_cycles.par,
                                                   N.par,M.par,
                                                   base_time.par=0,NW.par=5,
                                                   num_false_alarm_probabilities.par=20,
                                                   min_y.par=0,max_y.par=100,
                                                   GLRT_pdf_title.par="ROC_GLRT.pdf",LMPIT_pdf_title.par="ROC_LMPIT.pdf",
                                                   ecdf_abscissa_label.par="Measured value",
                                                   plot_bool.par=FALSE,verbose.par=FALSE){
  temp.cyclic_frequency_indices<-c(1,cyclic_frequency_indices.par)
  temp.cyclic_frequency_indices<-unique(temp.cyclic_frequency_indices)
  temp.cyclic_frequency_indices<-temp.cyclic_frequency_indices[is.na(temp.cyclic_frequency_indices)==FALSE]
  cat("temp.cyclic_frequency_indices\n")
  print(temp.cyclic_frequency_indices)
  temp.Ramirez_null_distributions_ACS_WSS_object<-
    Ramirez_null_distributions_ACS_WSS.function(N.par=N.par,ar_coefficients.par=ar_coefficients.par,
                                                innovation_variance.par=innovation_variance.par,
                                                noise_variance.par=noise_variance.par,
                                                frequencies.par=frequencies.par,
                                                num_cycles.par=num_cycles.par,
                                                num_detectors.par=num_detectors.par,
                                                num_longitudinal_samples.par=num_longitudinal_samples.par,
                                                num_decimated_sim.par=num_decimated_sim.par,
                                                decimation_sampling_rate.par=decimation_sampling_rate.par,
                                                first_time.par=base_time.par,
                                                num_tests.par=num_tests.par,
                                                decimation_step.par=decimation_step.par,
                                                dimension_multiple.par=dimension_multiple.par,
                                                sampling_rate.par=sampling_rate.par,
                                                base_time.par=base_time.par,
                                                ecdf_abscissa_label.par=ecdf_abscissa_label.par,
                                                plot_bool.par=plot_bool.par)
  temp.decimated_times<-temp.Ramirez_null_distributions_ACS_WSS_object$out.decimated_times
  temp.sorted_GLRT_realizations<-temp.Ramirez_null_distributions_ACS_WSS_object$out.sorted_GLRT_realizations
  temp.sorted_LMPIT_realizations<-temp.Ramirez_null_distributions_ACS_WSS_object$out.sorted_LMPIT_realizations
  temp.empirical_distribution_GLRT<-temp.Ramirez_null_distributions_ACS_WSS_object$out.empirical_distribution_GLRT
  temp.empirical_distribution_LMPIT<-temp.Ramirez_null_distributions_ACS_WSS_object$out.empirical_distribution_LMPIT
  temp.all_y_matrices<-temp.Ramirez_null_distributions_ACS_WSS_object$out.all_y_matrices
  temp.all_Gaussian_deviates_input_matrix_list<-temp.Ramirez_null_distributions_ACS_WSS_object$out.all_Gaussian_deviates_input_matrix_list
  temp.all_Gaussian_deviates_residual_matrix_list<-temp.Ramirez_null_distributions_ACS_WSS_object$out.all_Gaussian_deviates_residual_matrix_list
  temp.num_decimated_sim=temp.Ramirez_null_distributions_ACS_WSS_object$out.num_decimated_sim
  #Obtain the threshold values for the specified false-alarm rates.
  temp.roc_initialize_false_alarm_object_GLRT<-
    roc_initialize_false_alarm_probabilities.function(sorted_realizations.par=temp.sorted_GLRT_realizations,
                                                      empirical_distribution.par=temp.empirical_distribution_GLRT,
                                                      num_false_alarm_probabilities.par=num_false_alarm_probabilities.par)
  temp.false_alarm_thresholds_GLRT<-temp.roc_initialize_false_alarm_object_GLRT$out.false_alarm_thresholds
  temp.false_alarm_probabilities<-temp.roc_initialize_false_alarm_object_GLRT$out.false_alarm_probabilities
  temp.roc_initialize_false_alarm_object_LMPIT<-
    roc_initialize_false_alarm_probabilities.function(sorted_realizations.par=temp.sorted_LMPIT_realizations,
                                                      empirical_distribution.par=temp.empirical_distribution_LMPIT,
                                                      num_false_alarm_probabilities.par=num_false_alarm_probabilities.par)
  temp.false_alarm_thresholds_LMPIT<-temp.roc_initialize_false_alarm_object_LMPIT$out.false_alarm_thresholds
  temp.laptv_roc_true_positive_object<-
    laptv_roc_true_positive.function(all_Gaussian_deviates_input_matrix_list.par=temp.all_Gaussian_deviates_input_matrix_list,
                                     all_Gaussian_deviates_residual_matrix_list.par=temp.all_Gaussian_deviates_residual_matrix_list,
                                     num_cycles.par=num_cycles.par,
                                     cyclic_frequency_indices.par=temp.cyclic_frequency_indices,
                                     ar_coefficients.par=ar_coefficients.par,
                                     decimation_sampling_rate.par=decimation_sampling_rate.par,
                                     num_tests.par=num_tests.par,dimension_multiple.par=dimension_multiple.par,
                                     num_detectors.par=num_detectors.par,
                                     num_decimated_sim.par=temp.num_decimated_sim,
                                     decimation_step.par=decimation_step.par,N.par=N.par,
                                     num_longitudinal_samples.par=num_longitudinal_samples.par,
                                     sampling_rate.par=sampling_rate.par,
                                     first_time.par=base_time.par,
                                     NW.par=NW.par,verbose.par=verbose.par)
  temp.GLRT_realizations_H1<-temp.laptv_roc_true_positive_object$out.GLRT_realizations_H1
  temp.LMPIT_realizations_H1<-temp.laptv_roc_true_positive_object$out.LMPIT_realizations_H1
  #Create the ROCs.
  #GLRT
  temp.ROC_object_GLRT<-ROC.function(test_realizations_HA.par=temp.GLRT_realizations_H1,
                                     false_alarm_probabilities.par=temp.false_alarm_probabilities,
                                     false_alarm_thresholds.par=temp.false_alarm_thresholds_GLRT,
                                     num_tests.par=num_tests.par,
                                     min_y.par=min_y.par,max_y.par=max_y.par,pdf_title.par=GLRT_pdf_title.par,
                                     plot_bool.par=plot_bool.par)
  temp.num_true_positives_GLRT<-temp.ROC_object_GLRT$out.num_true_positives
  #LMPIT
  temp.ROC_object_LMPIT<-ROC.function(test_realizations_HA.par=temp.LMPIT_realizations_H1,
                                      false_alarm_probabilities.par=temp.false_alarm_probabilities,
                                      false_alarm_thresholds.par=temp.false_alarm_thresholds_LMPIT,
                                      num_tests.par=num_tests.par,
                                      min_y.par=min_y.par,max_y.par=max_y.par,pdf_title.par=LMPIT_pdf_title.par,
                                      plot_bool.par=plot_bool.par)
  temp.num_true_positives_LMPIT<-temp.ROC_object_LMPIT$out.num_true_positives
  temp.list<-list(out.decimated_times=temp.decimated_times,
                  out.false_alarm_thresholds_GLRT=temp.false_alarm_thresholds_GLRT,
                  out.false_alarm_thresholds_LMPIT=temp.false_alarm_thresholds_LMPIT,
                  out.num_true_positives_GLRT=temp.num_true_positives_GLRT,
                  out.num_true_positives_LMPIT=temp.num_true_positives_LMPIT,
                  out.empirical_distribution_GLRT=temp.empirical_distribution_GLRT,
                  out.empirical_distribution_LMPIT=temp.empirical_distribution_LMPIT)
  return(temp.list)
}


Ramirez_ACS_vs_nonsingular_test_metrics.function<-function(cyclic_frequency_indices.par,
                                                           ar_coefficients.par,auto_arima.par,
                                                           innovation_variance.par,noise_variance.par,
                                                           num_detectors.par,num_longitudinal_samples.par,
                                                           num_tests.par,
                                                           decimation_sampling_rate.par,dimension_multiple.par,
                                                           sampling_rate.par,
                                                           num_cycles.par,decimation_step.par,
                                                           N.par,M.par,
                                                           base_time.par=0,NW.par=5,
                                                           num_false_alarm_probabilities.par=20,
                                                           min_y.par=0,max_y.par=100,
                                                           GLRT_pdf_title.par="ROC_GLRT.pdf",LMPIT_pdf_title.par="ROC_LMPIT.pdf",
                                                           plot_bool.par=FALSE,verbose.par=FALSE){
  temp.M2=M.par/2
  temp.cyclic_frequency_indices<-c(1,cyclic_frequency_indices.par)
  temp.cyclic_frequency_indices<-unique(temp.cyclic_frequency_indices)
  temp.cyclic_frequency_indices<-temp.cyclic_frequency_indices[is.na(temp.cyclic_frequency_indices)==FALSE]
  temp.num_cyclic_frequencies=length(temp.cyclic_frequency_indices)
  temp.Ramirez_null_distributions_ACS_nonsingular_object<-
    Ramirez_null_distributions_ACS_nonsingular.function(N.par=N.par,ar_coefficients.par=ar_coefficients.par,
                                                        innovation_variance.par=innovation_variance.par,
                                                        noise_variance.par=noise_variance.par,
                                                        cyclic_frequency_indices.par=temp.cyclic_frequency_indices,
                                                        num_cycles.par=num_cycles.par,num_detectors.par=num_detectors.par,
                                                        num_longitudinal_samples.par=num_longitudinal_samples.par,
                                                        num_tests.par=num_tests.par,
                                                        decimation_step.par=decimation_step.par,dimension_multiple.par=dimension_multiple.par,
                                                        base_time.par=base_time.par,
                                                        sampling_rate.par=sampling_rate.par,first_time.par=base_time.par,
                                                        plot_bool.par=plot_bool.par)
  temp.decimated_times<-temp.Ramirez_null_distributions_ACS_nonsingular_object$out.decimated_times
  temp.sorted_GLRT_realizations<-temp.Ramirez_null_distributions_ACS_nonsingular_object$out.sorted_GLRT_realizations
  temp.sorted_LMPIT_realizations<-temp.Ramirez_null_distributions_ACS_nonsingular_object$out.sorted_LMPIT_realizations
  temp.empirical_distribution_GLRT<-temp.Ramirez_null_distributions_ACS_nonsingular_object$out.empirical_distribution_GLRT
  temp.empirical_distribution_LMPIT<-temp.Ramirez_null_distributions_ACS_nonsingular_object$out.empirical_distribution_LMPIT
  temp.all_y_matrices<-temp.Ramirez_null_distributions_ACS_nonsingular_object$out.all_y_matrices
  temp.all_Gaussian_deviates_input_matrix_list<-temp.Ramirez_null_distributions_ACS_nonsingular_object$out.all_Gaussian_deviates_input_matrix_list
  temp.all_Gaussian_deviates_residual_matrix_list<-temp.Ramirez_null_distributions_ACS_nonsingular_object$out.all_Gaussian_deviates_residual_matrix_list
  temp.num_decimated_sim=temp.Ramirez_null_distributions_ACS_nonsingular_object$out.num_decimated_sim
  #Obtain the threshold values for the specified false-alarm rates.
  temp.roc_initialize_false_alarm_object_GLRT<-
    roc_initialize_false_alarm_probabilities.function(sorted_realizations.par=temp.sorted_GLRT_realizations,
                                                      empirical_distribution.par=temp.empirical_distribution_GLRT,
                                                      num_false_alarm_probabilities.par=num_false_alarm_probabilities.par)
  temp.false_alarm_thresholds_GLRT<-temp.roc_initialize_false_alarm_object_GLRT$out.false_alarm_thresholds
  temp.false_alarm_probabilities<-temp.roc_initialize_false_alarm_object_GLRT$out.false_alarm_probabilities
  temp.roc_initialize_false_alarm_object_LMPIT<-
    roc_initialize_false_alarm_probabilities.function(sorted_realizations.par=temp.sorted_LMPIT_realizations,
                                                      empirical_distribution.par=temp.empirical_distribution_LMPIT,
                                                      num_false_alarm_probabilities.par=num_false_alarm_probabilities.par)
  temp.false_alarm_thresholds_LMPIT<-temp.roc_initialize_false_alarm_object_LMPIT$out.false_alarm_thresholds
  #Obtain the ROC true-positive rates.
  temp.sarima_roc_true_positive_object<-
    sarima_roc_true_positive.function(all_Gaussian_deviates_input_matrix_list.par=temp.all_Gaussian_deviates_input_matrix_list,
                                      all_Gaussian_deviates_residual_matrix_list.par=temp.all_Gaussian_deviates_residual_matrix_list,
                                      innovation_variance.par=innovation_variance.par,
                                      noise_variance.par=noise_variance.par,
                                      num_cycles.par=num_cycles.par,
                                      cyclic_frequency_indices.par=temp.cyclic_frequency_indices,
                                      auto_arima.par=auto_arima.par,
                                      decimation_sampling_rate.par=decimation_sampling_rate.par,
                                      num_tests.par=num_tests.par,dimension_multiple.par=dimension_multiple.par,
                                      num_detectors.par=num_detectors.par,
                                      num_decimated_sim.par=temp.num_decimated_sim,N.par=N.par,
                                      decimation_step.par=decimation_step.par,
                                      num_longitudinal_samples.par=num_longitudinal_samples.par,
                                      sampling_rate.par=sampling_rate.par,
                                      first_time.par=base_time.par,
                                      NW.par=NW.par,verbose.par=verbose.par)
  temp.GLRT_realizations_H1<-temp.sarima_roc_true_positive_object$out.GLRT_realizations_H1
  temp.LMPIT_realizations_H1<-temp.sarima_roc_true_positive_object$out.LMPIT_realizations_H1
  #Create the ROCs.
  #GLRT
  temp.ROC_object_GLRT<-ROC.function(test_realizations_HA.par=temp.GLRT_realizations_H1,
                                     false_alarm_thresholds.par=temp.false_alarm_thresholds_GLRT,
                                     false_alarm_probabilities.par=temp.false_alarm_probabilities,
                                     num_tests.par=num_tests.par,
                                     min_y.par=min_y.par,max_y.par=max_y.par,pdf_title.par=GLRT_pdf_title.par,
                                     plot_bool.par=plot_bool.par)
  temp.num_true_positives_GLRT<-temp.ROC_object_GLRT$out.num_true_positives
  #LMPIT
  temp.ROC_object_LMPIT<-ROC.function(test_realizations_HA.par=temp.LMPIT_realizations_H1,
                                      false_alarm_thresholds.par=temp.false_alarm_thresholds_LMPIT,
                                      false_alarm_probabilities.par=temp.false_alarm_probabilities,
                                      num_tests.par=num_tests.par,
                                      min_y.par=min_y.par,max_y.par=max_y.par,pdf_title.par=LMPIT_pdf_title.par,
                                      plot_bool.par=plot_bool.par)
  temp.num_true_positives_LMPIT<-temp.ROC_object_LMPIT$out.num_true_positives
  temp.list<-list(out.decimated_times=temp.decimated_times,
                  out.false_alarm_thresholds_GLRT=temp.false_alarm_thresholds_GLRT,
                  out.false_alarm_thresholds_LMPIT=temp.false_alarm_thresholds_LMPIT,
                  out.num_true_positives_GLRT=temp.num_true_positives_GLRT,
                  out.num_true_positives_LMPIT=temp.num_true_positives_LMPIT,
                  out.empirical_distribution_GLRT=temp.empirical_distribution_GLRT,
                  out.empirical_distribution_LMPIT=temp.empirical_distribution_LMPIT)
  return(temp.list)
}

#############################################################################################
#############################################################################################


sort_cyclic_parameters.function<-function(N_section_original.par,
                                          cyclic_amplitude_dataset.par,cyclic_frequency_dataset.par,
                                          section_start_time.par,section_end_time.par,
                                          section_index.par,sampling_rate.par,decimation_sampling_rate.par,
                                          num_all_detectors.par,
                                          num_detectors.par,dimension_multiple.par,num_longitudinal_samples.par,
                                          base_time.par=0,NW.par=5,time_stratified_bool.par=FALSE){
  temp.sampling_period=1/sampling_rate.par
  temp.section_length=section_end_time.par-section_start_time.par
  temp.section_intermediate_indices=(section_start_time.par*decimation_sampling_rate.par):(section_end_time.par*decimation_sampling_rate.par)
  temp.section_indices<-c()
  if(!time_stratified_bool.par){
    temp.section_indices<-(section_start_time.par*decimation_sampling_rate.par):(section_end_time.par*decimation_sampling_rate.par)
  }
  else{
    temp.section_indices<-
      ((section_start_time.par-num_longitudinal_samples.par/2*temp.section_length)*decimation_sampling_rate.par):
      ((section_end_time.par+(num_longitudinal_samples.par/2-1)*temp.section_length)*decimation_sampling_rate.par)
  } 
  temp.N=length(temp.section_intermediate_indices)
  temp.N_all_sections=num_longitudinal_samples.par*temp.N
  temp.times_original<-base_time.par+(1:temp.N-1)*sampling_rate.par
  #Multitaper parameters.
  temp.multitaper_parameters_object<-multitaper_parameters.function(N_section_original.par,NW.par=NW.par,verbose.par=FALSE)
  temp.M_original<-temp.multitaper_parameters_object$out.M
  temp.M2_original=temp.M_original/2+1
  temp.frequencies<-temp.multitaper_parameters_object$out.frequencies
  #Read in the cepstrum data.
  temp.cyclic_amplitudes0<-abs(as.numeric(cyclic_amplitude_dataset.par[section_index.par,2:ncol(cyclic_frequency_dataset.par)]))
  temp.cyclic_periods_unitless0<-
    as.numeric(cyclic_frequency_dataset.par[section_index.par,2:ncol(cyclic_frequency_dataset.par)])*decimation_sampling_rate.par/temp.M_original
  temp.cyclic_periods_unitless0<-temp.cyclic_periods_unitless0[temp.cyclic_amplitudes0>0]
  temp.cyclic_amplitudes0<-temp.cyclic_amplitudes0[temp.cyclic_amplitudes0>0]
  temp.cyclic_periods_unitless<-unique(temp.cyclic_periods_unitless0)
  temp.cyclic_periods_unitless<-sort(temp.cyclic_periods_unitless)
  temp.threshold_summed_cyclic_periods=(N_section_original.par-N_section_original.par%%2)/2
  temp.summed_cyclic_periods=sum(ceil(temp.cyclic_periods_unitless*temp.M_original))
  #if(FALSE){
  #If the index periods sum to a value greater than half the record size, then only retain periods such that their sum total
  #is bounded above by half the record size, and omit only the periods having the lowest amplitude because those explain the
  #least of the variability.
  if(temp.summed_cyclic_periods>temp.threshold_summed_cyclic_periods){
    temp.buffer_cyclic_periods<-temp.cyclic_periods_unitless0[rev(order(temp.cyclic_amplitudes0))]
    temp.cyclic_amplitudes<-rev(temp.cyclic_amplitudes0)
    temp.buffer_cyclic_period_list<-list()
    temp.buffer_cyclic_amplitude_list<-list()
    temp.counter=1
    #First, retain only unique cyclic periods, retaining those associated with the greatest amplitude.
    for(temp.u in 1:length(temp.buffer_cyclic_periods)){
      if(temp.u==1){
        temp.buffer_cyclic_period_list[[temp.counter]]=temp.buffer_cyclic_periods[temp.u]
        temp.buffer_cyclic_amplitude_list[[temp.counter]]=temp.cyclic_amplitudes[temp.u]
        temp.counter=temp.counter+1
      } else{
        temp.running_buffer_cyclic_periods<-unlist(temp.buffer_cyclic_period_list)
        temp.running_buffer_cyclic_amplitudes<-unlist(temp.buffer_cyclic_amplitude_list)
        if(temp.buffer_cyclic_periods[temp.u] %in% temp.running_buffer_cyclic_periods){
          temp.previous_instance_indices<-which(temp.running_buffer_cyclic_periods==temp.buffer_cyclic_periods[temp.u])
          temp.previous_instance_amplitudes<-temp.running_buffer_cyclic_amplitudes[temp.previous_instance_indices]
          temp.max_previous_instance_amplitude=max(temp.previous_instance_amplitudes)
          temp.optimal_indices<-which(temp.previous_instance_amplitudes==temp.max_previous_instance_amplitude)
          temp.optimal_previous_instance_amplitude_index=temp.optimal_indices
          if(length(temp.optimal_indices)>1){
            temp.optimal_previous_instance_amplitude_index=min(temp.optimal_indices)
          }
          if(temp.previous_instance_amplitudes[temp.optimal_previous_instance_amplitude_index]<temp.cyclic_amplitudes[temp.u]){
            temp.running_summed_cyclic_periods=sum(ceil(c(temp.running_buffer_cyclic_periods,temp.buffer_cyclic_periods[temp.u])*temp.M_original))
            if(temp.running_summed_cyclic_periods<temp.threshold_summed_cyclic_periods){
              temp.replacement_index=temp.previous_instance_indices[temp.optimal_previous_instance_amplitude_index]
              temp.buffer_cyclic_period_list[[temp.replacement_index]]=temp.buffer_cyclic_periods[temp.u]
              temp.buffer_cyclic_amplitude_list[[temp.replacement_index]]=temp.cyclic_amplitudes[temp.u]
            }
          }
        }
        else{
          temp.running_summed_cyclic_periods=sum(ceil(temp.running_buffer_cyclic_periods*temp.M_original))
          if(temp.running_summed_cyclic_periods<temp.threshold_summed_cyclic_periods){
            temp.buffer_cyclic_period_list[[temp.counter]]=temp.buffer_cyclic_periods[temp.u]
            temp.buffer_cyclic_amplitude_list[[temp.counter]]=temp.cyclic_amplitudes[temp.u]
            temp.counter=temp.counter+1
          }
        }
      }
    }
    temp.cyclic_periods_unitless<-sort(unlist(temp.buffer_cyclic_period_list))
    temp.cyclic_amplitudes0<-sort(unlist(temp.buffer_cyclic_amplitude_list))
  }
  #}#endif
  temp.cyclic_periods_unitless<-rev(temp.cyclic_periods_unitless)
  temp.cyclic_amplitudes0<-rev(temp.cyclic_amplitudes0)
  temp.cyclic_periods<-ceil(temp.cyclic_periods_unitless*temp.M_original)
  temp.cyclic_periods_unitless<-temp.cyclic_periods_unitless[temp.cyclic_periods>0 & temp.cyclic_periods<temp.threshold_summed_cyclic_periods]
  temp.cyclic_periods<-temp.cyclic_periods[temp.cyclic_periods>0 & temp.cyclic_periods<temp.threshold_summed_cyclic_periods]
  if(!length(temp.cyclic_periods)){
    temp.cyclic_periods<-c((N_section_original.par-N_section_original.par%%2)/2)
  }
  temp.optimal_amplitude_index=min(which(temp.cyclic_amplitudes0==max(temp.cyclic_amplitudes0)))
  temp.optimal_cyclic_period=temp.cyclic_periods[temp.optimal_amplitude_index]
  temp.optimal_cyclic_period=max(temp.optimal_cyclic_period,2)
  temp.optimal_cyclic_period_index=min(temp.optimal_cyclic_period,temp.threshold_summed_cyclic_periods)
  temp.num_cycles=floor(N_section_original.par/temp.optimal_cyclic_period_index)
  temp.num_cycles=max(temp.num_cycles,2)
  if(temp.num_cycles>100){
    temp.num_cycles=2
  }
  temp.num_sample_detectors=(num_all_detectors.par-num_all_detectors.par%%num_detectors.par)/num_detectors.par
  temp.num_all_samples=num_longitudinal_samples.par*temp.num_sample_detectors*temp.num_cycles
  temp.decimation_step=dimension_multiple.par*2*ceil(temp.N*num_detectors.par/temp.num_all_samples)
  temp.decimation_indices<-seq(from=1,to=temp.N,by=temp.decimation_step)
  temp.decimation_indices<-temp.decimation_indices[1:floor(temp.num_all_samples/2/dimension_multiple.par/num_detectors.par)]
  temp.num_decimated_sim=length(temp.decimation_indices)
  temp.period_size=floor(temp.num_decimated_sim/temp.num_cycles)
  temp.num_decimated_sim=temp.num_cycles*temp.period_size
  temp.list<-list(out.sampling_period=temp.sampling_period,
                  out.N=temp.N,
                  out.N_all_sections=temp.N_all_sections,
                  out.M_original=temp.M_original,
                  out.M2_original=temp.M2_original,
                  out.frequencies=temp.frequencies,
                  out.num_cycles=temp.num_cycles,
                  out.num_all_detectors=num_all_detectors.par,
                  out.num_all_samples=temp.num_all_samples,
                  out.num_decimated_sim=temp.num_decimated_sim,
                  out.period_size=temp.period_size,
                  out.times_original=temp.times_original,
                  out.section_indices=temp.section_indices,
                  out.cyclic_periods_unitless=temp.cyclic_periods_unitless,
                  out.num_sample_detectors=temp.num_sample_detectors)
  return(temp.list)
}


read_partitioned_time_series.function<-function(N.par,
                                                section_start_time.par,section_end_time.par,N_all_sections.par,
                                                section_indices.par,
                                                num_all_detectors.par,num_longitudinal_samples.par,
                                                num_detectors.par,num_sample_detectors.par,
                                                band_frequencies.par,decimation_sampling_rate.par=1,
                                                patient_home_data_directory_string.par,directory_strings.par,
                                                abbreviated_frequency_units_string.par){
  temp.intermediate_section_indices<-
    (section_start_time.par*decimation_sampling_rate.par):(section_end_time.par*decimation_sampling_rate.par)-section_start_time.par*decimation_sampling_rate.par+1
  temp.dataset<-matrix(0,nrow=num_all_detectors.par*N.par,ncol=num_all_detectors.par)
  for(temp.j in 1:num_detectors.par){
    for(temp.l in 1:num_sample_detectors.par){
      temp.index=(temp.j-1)*num_sample_detectors.par+temp.l
      temp.patient_data_directory_string<-paste(patient_home_data_directory_string.par,"/",directory_strings.par[temp.index],"/",
                                                band_frequencies.par[1],"_",band_frequencies.par[2],"_",abbreviated_frequency_units_string.par,"/Filtered_Data/",
                                                band_frequencies.par[1],"_",band_frequencies.par[2],"_",abbreviated_frequency_units_string.par,
                                                "_Demodulate.txt",sep="")
      temp.full_ts_object<-read.table(temp.patient_data_directory_string,header=TRUE)
      temp.full_ts<-temp.full_ts_object$ts_value[section_indices.par]
      for(temp.k in 1:num_longitudinal_samples.par){
        temp.indices<-(temp.k-1)*N.par+temp.intermediate_section_indices
        temp.dataset[temp.indices,(temp.j-1)*num_sample_detectors.par+temp.l]<-temp.full_ts[temp.indices]
      }
    }
  }
  temp.dataset<-as.matrix(temp.dataset)
  temp.list<-list(out.intermediate_section_indices=temp.intermediate_section_indices,
                  out.dataset=temp.dataset)
  return(temp.list)
}


read_partitioned_time_series_simulation.function<-function(N.par,
                                                           section_start_time.par,section_end_time.par,N_all_sections.par,
                                                           section_indices.par,
                                                           num_all_detectors.par,num_longitudinal_samples.par,
                                                           num_detectors.par,num_sample_detectors.par,
                                                           band_frequencies.par,decimation_sampling_rate.par=1,
                                                           patient_data_string.par,
                                                           abbreviated_frequency_units_string.par){
  temp.full_ts_object<-read.table(temp.dataset_string,header=FALSE)
  temp.full_ts<-temp.full_ts_object[section_indices.par,1]
  temp.intermediate_section_indices<-
    (section_start_time.par*decimation_sampling_rate.par):(section_end_time.par*decimation_sampling_rate.par)-section_start_time.par*decimation_sampling_rate.par+1
  temp.list<-list(out.intermediate_section_indices=temp.intermediate_section_indices,
                  out.dataset=temp.full_ts_object)
  return(temp.list)
}


LAPTV_sort_parameters.function<-function(N_section.par,frequencies.par,
                                         cyclic_periods_unitless.par,
                                         electrode_index.par,section_index.par,
                                         band_frequencies.par,
                                         directory_strings.par,patient_home_data_directory_string.par,
                                         abbreviated_frequency_units_string.par){
  temp.M2_original=length(frequencies.par)
  temp.M_original=(temp.M2_original-1)*2
  temp.multitaper_parameters_object<-multitaper_parameters.function(N_section.par,NW.par=NW.par,verbose.par=FALSE)
  temp.M=temp.multitaper_parameters_object$out.M
  temp.section_frequencies<-temp.multitaper_parameters_object$out.frequencies
  temp.section_data_directory_string<-paste(patient_home_data_directory_string.par,"/Electrode_",electrode_index.par,"/",
                                            band_frequencies.par[1],"_",band_frequencies.par[2],"_",abbreviated_frequency_units_string.par,"/",
                                            section_index.par,"_Section_",section_index.par,sep="")
  temp.LAPTV_data_directory_string<-paste(temp.section_data_directory_string,"/LAPTV_Analysis",sep="")
  temp.LAPTV_AR_dataset_string<-paste(temp.LAPTV_data_directory_string,"/AR_Coefficients.txt",sep="")
  temp.LAPTV_AR_dataset<-read.table(temp.LAPTV_AR_dataset_string,header=TRUE)
  temp.ar_coefficients<-temp.LAPTV_AR_dataset$coefficient
  temp.LAPTV_innovations_dataset_string<-paste(temp.LAPTV_data_directory_string,"/Innovation_Variance.txt",sep="")
  temp.LAPTV_innovations_dataset<-read.table(temp.LAPTV_innovations_dataset_string,header=TRUE)
  temp.innovation_variance<-temp.LAPTV_innovations_dataset$prediction_variance
  #Sort the cyclic parameters for the LAPTV model.
  temp.ar_spectrum<-rep(0,temp.M2_original)
  for(temp.m in 1:temp.M2_original){
    temp.ar_spectrum[temp.m]=1/Mod(Ap_f(frequencies.par[temp.m],temp.ar_coefficients))^2
  }
  temp.ar_spectrum<-temp.innovation_variance*temp.ar_spectrum
  temp.ar_variance=sum(temp.ar_spectrum,temp.ar_spectrum[2:temp.M2_original])/temp.M_original
  #Sort the cyclic frequencies.
  temp.unitless_cyclic_frequencies<-1/cyclic_periods_unitless.par
  temp.cyclic_frequency_indices<-round(temp.unitless_cyclic_frequencies)
  temp.cyclic_frequency_indices[temp.cyclic_frequency_indices<=0]<-1
  temp.cyclic_frequency_indices<-temp.cyclic_frequency_indices[temp.cyclic_frequency_indices<=(temp.M/2)]
  if(!length(temp.cyclic_frequency_indices)){
    temp.cyclic_frequency_indices<-c(1)
  }
  temp.cyclic_frequencies<-temp.section_frequencies[temp.cyclic_frequency_indices]
  temp.list<-list(out.ar_coefficients=temp.ar_coefficients,
                  out.ar_variance=temp.ar_variance,
                  out.innovation_variance=temp.innovation_variance,
                  out.cyclic_frequencies=temp.cyclic_frequencies,
                  out.cyclic_frequency_indices=temp.cyclic_frequency_indices,
                  out.M=temp.M)
  return(temp.list)
}


MSARIMA_sort_parameters.function<-function(dataset.par,
                                           N.par,M.par,M_original.par,
                                           cyclic_periods_unitless.par,period_size.par,
                                           intermediate_section_indices.par,
                                           electrode_index.par){
  #Sort the parameters for the MSARIMA model.
  temp.decimated_full_ts<-dataset.par[intermediate_section_indices.par,electrode_index.par]
  temp.quefrency_indices<-floor(cyclic_periods_unitless.par*M_original.par)
  temp.quefrency_indices<-temp.quefrency_indices[temp.quefrency_indices<=0 & temp.quefrency_indices<=(N.par/2)]
  temp.num_quefrencies=length(temp.quefrency_indices)
  if(!temp.num_quefrencies){
    temp.quefrency_indices<-c(period_size.par)
  }
  temp.num_quefrencies=length(temp.quefrency_indices)
  temp.differenced_decimated_full_ts<-temp.decimated_full_ts
  for(temp.l in 1:temp.num_quefrencies){
    temp.quefrency_index=temp.quefrency_indices[temp.l]
    temp.indices<-1:(length(temp.differenced_decimated_full_ts)-temp.quefrency_indices[temp.l])
    temp.differenced_decimated_full_ts<-
      temp.differenced_decimated_full_ts[temp.indices+temp.quefrency_index]-temp.differenced_decimated_full_ts[temp.indices]
  }
  temp.auto_arima_object<-auto.arima(temp.differenced_decimated_full_ts,seasonal=FALSE,test="adf",method="ML",allowmean=FALSE)
  #Extract the parameters.
  temp.sigma2=temp.auto_arima_object$sigma2
  temp.auto_arima_coefficients<-as.numeric(temp.auto_arima_object$coef)
  temp.num_auto_arima_coefficients=length(temp.auto_arima_coefficients)
  temp.list<-list(out.sigma2=temp.sigma2,
                  out.auto_arima_coefficients=temp.auto_arima_coefficients,
                  out.num_auto_arima_coefficients=temp.num_auto_arima_coefficients,
                  out.auto_arima_object=temp.auto_arima_object)
  return(temp.list)
}


Ramirez_alternatives_preparation.function<-function(N_section_original.par,
                                                    section_start_time.par,section_end_time.par,
                                                    section_index.par=temp.section_index,
                                                    sampling_rate.par,decimation_sampling_rate.par,
                                                    directory_strings.par,
                                                    num_detectors.par,dimension_multiple.par,
                                                    num_longitudinal_samples.par,
                                                    base_time.par=0,NW.par=5,electrode_index.par=1,
                                                    patient_home_data_directory_string.par,
                                                    band_frequencies.par,
                                                    abbreviated_frequency_units_string.par){
  #Cyclic frequencies
  temp.section_data_directory_string<-paste(patient_home_data_directory_string.par,"/Electrode_",electrode_index.par,"/",
                                            temp.band_frequencies[1],"_",temp.band_frequencies[2],"_",abbreviated_frequency_units_string.par,
                                            "/Summary_Files/Harmonic_ACS_Frequencies_All_Epochs.txt",sep="")
  temp.cyclic_frequency_dataset<-read.table(temp.section_data_directory_string,header=TRUE)
  #Cyclic amplitudes
  temp.section_data_directory_string<-paste(patient_home_data_directory_string.par,"/Electrode_",electrode_index.par,"/",
                                            temp.band_frequencies[1],"_",temp.band_frequencies[2],"_",abbreviated_frequency_units_string.par,
                                            "/Summary_Files/Harmonic_ACS_Amplitudes_All_Epochs.txt",sep="")
  temp.cyclic_amplitude_dataset<-read.table(temp.section_data_directory_string,header=TRUE)
  temp.num_all_detectors=length(directory_strings.par)
  temp.sort_cyclic_parameters_object<-
    sort_cyclic_parameters.function(N_section_original.par=N_section_original.par,
                                    cyclic_amplitude_dataset.par=temp.cyclic_amplitude_dataset,
                                    cyclic_frequency_dataset.par=temp.cyclic_frequency_dataset,
                                    section_start_time.par=section_start_time.par,section_end_time.par=section_end_time.par,
                                    section_index.par=section_index.par,sampling_rate.par=sampling_rate.par,
                                    decimation_sampling_rate.par=decimation_sampling_rate.par,
                                    num_all_detectors.par=temp.num_all_detectors,
                                    num_detectors.par=num_detectors.par,dimension_multiple.par=dimension_multiple.par,
                                    num_longitudinal_samples.par=num_longitudinal_samples.par,
                                    base_time.par=base_time.par,NW.par=NW.par,time_stratified_bool.par=TRUE)
  temp.sampling_period=temp.sort_cyclic_parameters_object$out.sampling_period
  temp.N=temp.sort_cyclic_parameters_object$out.N
  temp.N_all_sections=temp.sort_cyclic_parameters_object$out.N_all_sections
  temp.M_original=temp.sort_cyclic_parameters_object$out.M_original
  temp.frequencies<-temp.sort_cyclic_parameters_object$out.frequencies
  temp.num_cycles=temp.sort_cyclic_parameters_object$out.num_cycles
  temp.num_all_detectors=temp.sort_cyclic_parameters_object$out.num_all_detectors
  temp.num_all_samples=temp.sort_cyclic_parameters_object$out.num_all_samples
  temp.num_decimated_sim=temp.sort_cyclic_parameters_object$out.num_decimated_sim
  temp.period_size=temp.sort_cyclic_parameters_object$out.period_size
  temp.times_original<-temp.sort_cyclic_parameters_object$out.times_original
  temp.section_indices<-temp.sort_cyclic_parameters_object$out.section_indices
  temp.cyclic_periods_unitless<-temp.sort_cyclic_parameters_object$out.cyclic_periods_unitless
  temp.num_sample_detectors=temp.sort_cyclic_parameters_object$out.num_sample_detectors
  temp.read_partitioned_time_series_object<-
    read_partitioned_time_series.function(N.par=temp.N,
                                          section_start_time.par=section_start_time.par,section_end_time.par=section_end_time.par,
                                          N_all_sections.par=temp.N_all_sections,
                                          section_indices.par=temp.section_indices,
                                          num_all_detectors.par=temp.num_all_detectors,
                                          num_detectors.par=num_detectors.par,
                                          num_sample_detectors.par=temp.num_sample_detectors,
                                          num_longitudinal_samples.par=num_longitudinal_samples.par,
                                          band_frequencies.par=band_frequencies.par,
                                          decimation_sampling_rate.par=decimation_sampling_rate.par,
                                          patient_home_data_directory_string.par=patient_home_data_directory_string.par,
                                          directory_strings.par=directory_strings.par,
                                          abbreviated_frequency_units_string.par=abbreviated_frequency_units_string.par)
  temp.intermediate_section_indices<-temp.read_partitioned_time_series_object$out.intermediate_section_indices
  temp.dataset<-temp.read_partitioned_time_series_object$out.dataset
  #LAPTV preparation.
  temp.LAPTV_sort_parameters_object<-
    LAPTV_sort_parameters.function(N_section.par=temp.N,frequencies.par=temp.frequencies,
                                   cyclic_periods_unitless.par=temp.cyclic_periods_unitless,
                                   electrode_index.par=electrode_index.par,
                                   section_index.par=section_index.par,
                                   band_frequencies.par=band_frequencies.par,
                                   directory_strings.par=directory_strings.par,
                                   patient_home_data_directory_string.par=patient_home_data_directory_string.par,
                                   abbreviated_frequency_units_string.par=abbreviated_frequency_units_string.par)
  temp.ar_coefficients<-temp.LAPTV_sort_parameters_object$out.ar_coefficients
  temp.noise_variance=temp.LAPTV_sort_parameters_object$out.ar_variance
  temp.innovation_variance=temp.LAPTV_sort_parameters_object$out.innovation_variance
  temp.cyclic_frequencies=temp.LAPTV_sort_parameters_object$out.cyclic_frequencies
  temp.cyclic_frequency_indices<-temp.LAPTV_sort_parameters_object$out.cyclic_frequency_indices
  temp.M=temp.LAPTV_sort_parameters_object$out.M
  #MSARIMA preparation.
  temp.MSARIMA_sort_parameters_object<-
    MSARIMA_sort_parameters.function(dataset.par=temp.dataset,
                                     N.par=temp.N,M.par=temp.M,M_original.par=temp.M_original,
                                     cyclic_periods_unitless.par=temp.cyclic_periods_unitless,period_size.par=temp.period_size,
                                     intermediate_section_indices.par=temp.intermediate_section_indices,
                                     electrode_index.par=electrode_index.par)
  temp.sigma2=temp.MSARIMA_sort_parameters_object$out.sigma2
  temp.auto_arima_coefficients<-temp.MSARIMA_sort_parameters_object$out.auto_arima_coefficients
  temp.num_auto_arima_coefficients=temp.MSARIMA_sort_parameters_object$out.num_auto_arima_coefficients
  temp.auto_arima_object<-temp.MSARIMA_sort_parameters_object$out.auto_arima_object
  #Downsampling parameter initialization.
  temp.decimation_step=dimension_multiple.par*2*ceil(temp.N*num_detectors.par/temp.num_all_samples)
  temp.decimation_indices<-seq(from=1,to=temp.N,by=temp.decimation_step)
  temp.num_downsampled=length(temp.decimation_indices)
  temp.list<-list(out.sampling_period=temp.sampling_period,
                  out.N=temp.N,
                  out.N_all_sections=temp.N_all_sections,
                  out.frequencies=temp.frequencies,
                  out.num_cycles=temp.num_cycles,
                  out.num_all_samples=temp.num_all_samples,
                  out.num_decimated_sim=temp.num_decimated_sim,
                  out.intermediate_section_indices=temp.intermediate_section_indices,
                  out.dataset=temp.dataset,
                  out.sigma2=temp.sigma2,
                  out.auto_arima_coefficients=temp.auto_arima_coefficients,
                  out.num_auto_arima_coefficients=temp.num_auto_arima_coefficients,
                  out.decimation_step=temp.decimation_step,
                  out.num_downsampled=temp.num_downsampled,
                  out.num_sample_detectors=temp.num_sample_detectors,
                  out.auto_arima_object=temp.auto_arima_object,
                  out.cyclic_frequency_indices=temp.cyclic_frequency_indices,
                  out.innovation_variance=temp.innovation_variance,
                  out.noise_variance=temp.noise_variance,
                  out.num_cycles=temp.num_cycles,
                  out.ar_coefficients=temp.ar_coefficients,
                  out.M=temp.M)
  return(temp.list)
}


Ramirez_alternatives_preparation_simulation.function<-function(N_section_original.par,
                                                               section_start_time.par,section_end_time.par,
                                                               section_index.par=temp.section_index,
                                                               sampling_rate.par,decimation_sampling_rate.par,
                                                               directory_string.par,num_all_detectors.par,
                                                               num_detectors.par,dimension_multiple.par,
                                                               num_longitudinal_samples.par,
                                                               base_time.par=0,NW.par=5,electrode_index.par=1,
                                                               patient_home_data_directory_string.par,
                                                               patient_data_string.par,
                                                               band_frequencies.par,
                                                               abbreviated_frequency_units_string.par){
  #Cyclic frequencies
  temp.section_data_directory_string<-paste(patient_home_data_directory_string.par,"/Electrode_",electrode_index.par,"/",
                                            temp.band_frequencies[1],"_",temp.band_frequencies[2],"_",abbreviated_frequency_units_string.par,
                                            "/Summary_Files/Harmonic_ACS_Frequencies_All_Epochs.txt",sep="")
  temp.cyclic_frequency_dataset<-read.table(temp.section_data_directory_string,header=TRUE)
  #Cyclic amplitudes
  temp.section_data_directory_string<-paste(patient_home_data_directory_string.par,"/Electrode_",electrode_index.par,"/",
                                            temp.band_frequencies[1],"_",temp.band_frequencies[2],"_",abbreviated_frequency_units_string.par,
                                            "/Summary_Files/Harmonic_ACS_Amplitudes_All_Epochs.txt",sep="")
  temp.cyclic_amplitude_dataset<-read.table(temp.section_data_directory_string,header=TRUE)
  temp.sort_cyclic_parameters_object<-
    sort_cyclic_parameters.function(N_section_original.par=N_section_original.par,
                                    cyclic_amplitude_dataset.par=temp.cyclic_amplitude_dataset,
                                    cyclic_frequency_dataset.par=temp.cyclic_frequency_dataset,
                                    section_start_time.par=section_start_time.par,section_end_time.par=section_end_time.par,
                                    section_index.par=section_index.par,sampling_rate.par=sampling_rate.par,
                                    decimation_sampling_rate.par=decimation_sampling_rate.par,
                                    num_all_detectors.par=num_all_detectors.par,
                                    num_detectors.par=num_detectors.par,dimension_multiple.par=dimension_multiple.par,
                                    num_longitudinal_samples.par=num_longitudinal_samples.par,
                                    base_time.par=base_time.par,NW.par=NW.par,time_stratified_bool.par=FALSE)
  temp.sampling_period=temp.sort_cyclic_parameters_object$out.sampling_period
  temp.N=temp.sort_cyclic_parameters_object$out.N
  temp.N_all_sections=temp.sort_cyclic_parameters_object$out.N_all_sections
  temp.M_original=temp.sort_cyclic_parameters_object$out.M_original
  temp.frequencies<-temp.sort_cyclic_parameters_object$out.frequencies
  temp.num_cycles=temp.sort_cyclic_parameters_object$out.num_cycles
  temp.num_all_detectors=temp.sort_cyclic_parameters_object$out.num_all_detectors
  temp.num_all_samples=temp.sort_cyclic_parameters_object$out.num_all_samples
  temp.num_decimated_sim=temp.sort_cyclic_parameters_object$out.num_decimated_sim
  temp.period_size=temp.sort_cyclic_parameters_object$out.period_size
  temp.times_original<-temp.sort_cyclic_parameters_object$out.times_original
  temp.section_indices<-temp.sort_cyclic_parameters_object$out.section_indices
  temp.cyclic_periods_unitless<-temp.sort_cyclic_parameters_object$out.cyclic_periods_unitless
  temp.num_sample_detectors=temp.sort_cyclic_parameters_object$out.num_sample_detectors
  temp.read_partitioned_time_series_object<-
    read_partitioned_time_series_simulation.function(N.par=temp.N,
                                                     section_start_time.par=section_start_time.par,section_end_time.par=section_end_time.par,
                                                     N_all_sections.par=temp.N_all_sections,
                                                     section_indices.par=temp.section_indices,
                                                     num_all_detectors.par=temp.num_all_detectors,
                                                     num_detectors.par=num_detectors.par,
                                                     num_sample_detectors.par=temp.num_sample_detectors,
                                                     num_longitudinal_samples.par=num_longitudinal_samples.par,
                                                     band_frequencies.par=band_frequencies.par,
                                                     decimation_sampling_rate.par=decimation_sampling_rate.par,
                                                     patient_data_string.par=patient_data_string.par,
                                                     abbreviated_frequency_units_string.par=abbreviated_frequency_units_string.par)
  temp.intermediate_section_indices<-temp.read_partitioned_time_series_object$out.intermediate_section_indices
  temp.dataset<-temp.read_partitioned_time_series_object$out.dataset
  #LAPTV preparation.
  temp.LAPTV_sort_parameters_object<-
    LAPTV_sort_parameters.function(N_section.par=temp.N,frequencies.par=temp.frequencies,
                                   cyclic_periods_unitless.par=temp.cyclic_periods_unitless,
                                   electrode_index.par=electrode_index.par,
                                   section_index.par=section_index.par,
                                   band_frequencies.par=band_frequencies.par,
                                   directory_strings.par=directory_strings.par,
                                   patient_home_data_directory_string.par=patient_home_data_directory_string.par,
                                   abbreviated_frequency_units_string.par=abbreviated_frequency_units_string.par)
  temp.ar_coefficients<-temp.LAPTV_sort_parameters_object$out.ar_coefficients
  temp.noise_variance=temp.LAPTV_sort_parameters_object$out.ar_variance
  temp.innovation_variance=temp.LAPTV_sort_parameters_object$out.innovation_variance
  temp.cyclic_frequencies=temp.LAPTV_sort_parameters_object$out.cyclic_frequencies
  temp.cyclic_frequency_indices<-temp.LAPTV_sort_parameters_object$out.cyclic_frequency_indices
  temp.M=temp.LAPTV_sort_parameters_object$out.M
  #MSARIMA preparation.
  temp.MSARIMA_sort_parameters_object<-
    MSARIMA_sort_parameters.function(dataset.par=temp.dataset,
                                     N.par=temp.N,M.par=temp.M,M_original.par=temp.M_original,
                                     cyclic_periods_unitless.par=temp.cyclic_periods_unitless,period_size.par=temp.period_size,
                                     intermediate_section_indices.par=temp.intermediate_section_indices,
                                     electrode_index.par=electrode_index.par)
  temp.sigma2=temp.MSARIMA_sort_parameters_object$out.sigma2
  temp.auto_arima_coefficients<-temp.MSARIMA_sort_parameters_object$out.auto_arima_coefficients
  temp.num_auto_arima_coefficients=temp.MSARIMA_sort_parameters_object$out.num_auto_arima_coefficients
  temp.auto_arima_object<-temp.MSARIMA_sort_parameters_object$out.auto_arima_object
  #Downsampling parameter initialization.
  temp.decimation_step=dimension_multiple.par*2*ceil(temp.N*num_detectors.par/temp.num_all_samples)
  temp.decimation_indices<-seq(from=1,to=temp.N,by=temp.decimation_step)
  temp.num_downsampled=length(temp.decimation_indices)
  temp.list<-list(out.sampling_period=temp.sampling_period,
                  out.N=temp.N,
                  out.N_all_sections=temp.N_all_sections,
                  out.frequencies=temp.frequencies,
                  out.num_cycles=temp.num_cycles,
                  out.num_all_samples=temp.num_all_samples,
                  out.num_decimated_sim=temp.num_decimated_sim,
                  out.intermediate_section_indices=temp.intermediate_section_indices,
                  out.dataset=temp.dataset,
                  out.sigma2=temp.sigma2,
                  out.auto_arima_coefficients=temp.auto_arima_coefficients,
                  out.num_auto_arima_coefficients=temp.num_auto_arima_coefficients,
                  out.decimation_step=temp.decimation_step,
                  out.num_downsampled=temp.num_downsampled,
                  out.num_sample_detectors=temp.num_sample_detectors,
                  out.cyclic_frequency_indices=temp.cyclic_frequency_indices,
                  out.innovation_variance=temp.innovation_variance,
                  out.noise_variance=temp.noise_variance,
                  out.ar_coefficients=temp.ar_coefficients,
                  out.auto_arima_object=temp.auto_arima_object)
  return(temp.list)
}


















