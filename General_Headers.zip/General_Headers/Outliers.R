#Francois Marshall, Boston University
#Header file for outlier analysis.
###################################################################################################################
#.

outlier_cleaner.function<-function(times.par,ts.par,spectral_powers.par,multitaper_autocorrelations.par,frequencies.par,u0.par=5,
                                   soft_replacement_bool.par=FALSE){
  temp.N=length(ts.par)
  temp.correlation_coefficient_sequence<-multitaper_autocorrelations.par
  temp.prewhitening_object<-prewhitening_algorithm.function(spectral_powers.par,multitaper_autocorrelations.par,frequencies.par,N.par,verbose.par=FALSE)
  temp.alphas<-temp.prewhitening_object$out.temp.alphas
  temp.ar_order=temp.prewhitening_object$out.ar_order
  temp.x_tilde<-rep(0,temp.N-temp.ar_order)
  for(temp.j in (temp.ar_order+1):temp.N){
    temp.x_tilde[temp.j-temp.ar_order]=sum(temp.alphas*ts.par[(temp.j-1):(temp.j-temp.ar_order)])
  }
  #Extract the residuals without the robust filter (linear operation).
  #If the generating process is not perverse, then the residuals should be perturbations of Gaussian white noise.
  temp.prediction_errors<-ts.par[(temp.ar_order+1):temp.N]-temp.x_tilde
  temp.ar_times<-times.par[(temp.ar_order+1):temp.N]
  temp.N_p=length(temp.prediction_errors)
  #Create weighting function to assign low importance to outliers, which cannot be predicted well, and so have large innovations variance.
  #Compute the prediction variance, which corresponds to the variance of an AR process.
  #Use the bias correction suggested by DJT 1977.
  temp.sigma2_p=prediction_variance_corrected(frequencies.par,spectral_powers.par,temp.alphas,temp.N_p)
  temp.sigma_p=sqrt(temp.sigma2_p)
  #Compute the standardized prediction errors so that quantiles of the standard normal may be used in the discriminant analysis.
  temp.standardized_prediction_errors<-temp.prediction_errors/temp.sigma_p
  #Compute the weight sequence for reconstruction of the series in places where the remote measurements are present.
  #Using the density function for the distribution of the maximum for a random sample drawn from the standard normal.
  #Assume here that temp.u0 is the expected value of that quantile which is exceeded only once in a random sample.
  #This quantile estimate is robust because it is based solely on the empirical distribution.
  temp.weight_series<-exp(-exp(u0.par*(abs(temp.standardized_prediction_errors)-u0.par)))
  #Estimate the core process using a convex reconstruction.
  temp.core_series<-temp.weight_series*ts.par[(temp.ar_order+1):temp.N]+(1-temp.weight_series)*temp.x_tilde
  temp.prediction_errors_cleaned<-temp.core_series-temp.x_tilde
  temp.cleaned_series<-c(ts.par[1:temp.ar_order],temp.core_series)
  temp.list<-list(out.cleaned_series=temp.cleaned_series,
                  out.ar_times=temp.ar_times,
                  out.times_vector=times.par)
  return(temp.list)
}


basic_cleaner.function<-function(ts.par,scale.par=1){
  temp.N=length(ts.par)
  temp.sample_dc_element=mean(ts.par)
  temp.centred_series<-ts.par-temp.sample_dc_element
  temp.sample_variance=var(temp.centred_series)
  temp.sd=sqrt(temp.sample_variance)
  for(temp.n in 1:temp.N){
    temp.absolute_diff=abs(ts.par[temp.n]-temp.sample_dc_element)
    if(temp.absolute_diff>qnorm(1-1/temp.N,sd=scale.par*temp.sd)){
      ts.par[temp.n]=NA
    }
  }
  ts.par<-TF_cleaning.function(ts.par)$out.TF
  return(ts.par)
}


basic_multitaper_cleaner.function<-function(ts.par,time_sequence.par,
                                            NW.par=5,sampling_rate.par=1,M_exponent.par=1,verbose.par=FALSE,
                                            soft_replacement_bool.par=FALSE,mean_included.bool=FALSE){
  temp.N=length(ts.par)
  temp.multitaper_parameters_object<-multitaper_parameters.function(N.par=temp.N,NW.par=NW.par,sampling_rate.par=sampling_rate.par,
                                                                    M_exponent.par=M_exponent.par,verbose.par=verbose.par)
  temp.M=temp.multitaper_parameters_object$out.M
  temp.M2=temp.M/2+1
  temp.K=temp.multitaper_parameters_object$out.K
  temp.frequencies=temp.multitaper_parameters_object$out.frequencies
  temp.centred_process_eigencoefficients_object<-centred_process.eigencoefficients(ts.par=ts.par,NW.par=NW.par,M.par=temp.M,K.par=temp.K,verbose.par=verbose.par)
  temp.eigencoeffs<-temp.centred_process_eigencoefficients_object$out.eigencoeffs
  temp.eigenvalues<-temp.centred_process_eigencoefficients_object$out.eigenvalues
  temp.mean_estimate=temp.centred_process_eigencoefficients_object$out.mean_estimate
  temp.multitaper_regularized_spectrum<-multitaper.regularized_spectrum(eigencoefficients.par=temp.eigencoeffs,frequencies.par=temp.frequencies,
                                                                        concentrations.par=temp.eigenvalues)
  temp.multitaper_acvs_analysis_object<-multitaper_acvs_analysis.function(spectral_power_estimates.par=temp.multitaper_regularized_spectrum,
                                                                          NW.par=NW.par,sampling_rate.par=sampling_rate.par,
                                                                          plot_bool.par=FALSE)
  temp.autocorrelation_coefficient_sequence<-temp.multitaper_acvs_analysis_object$out.autocorrelation_coefficient_sequence
  temp.outlier_cleaner_object<-outlier_cleaner.function(times.par=time_sequence.par,ts.par=ts.par,spectral_powers.par=temp.multitaper_regularized_spectrum,
                                                        multitaper_autocorrelations.par=temp.autocorrelation_coefficient_sequence,
                                                        frequencies.par=temp.frequencies,soft_replacement_bool.par=soft_replacement_bool.par)
  temp.cleaned_series<-temp.outlier_cleaner_object$out.cleaned_series
  if(mean_included.bool==TRUE){
    temp.cleaned_series<-temp.cleaned_series+temp.mean_estimate
  }
  time_sequence.par<-temp.outlier_cleaner_object$out.ar_times
  temp.list<-list(out.cleaned_series=temp.cleaned_series,
                  out.time_sequence=time_sequence.par)
  return(temp.list)
}
























