#Francois Marshall, Boston University
#Header file for generating random numbers.
###################################################################################################################

#Choose moduli from Table 4.1 of Brandt, for single-precision computers.
moduli<<-c(2147483647,2147483563,2147483399,2147482811,2147482801,2147482739)
primitive.elements<<-c(39373,40014,40692,41546,42024,45742)
num.moduli<<-length(moduli)

RNG.factors<-function(period.par){
  #Determine the smallest RNG period greater or equal than the required number of random numbers.
  temp.rng_period=2
  temp.counter=1
  while(temp.rng_period<period.par){
    if(temp.counter==1){
      temp.m_1_values<-moduli[temp.counter]-1
    }
    else{
      temp.m_1_values<-moduli[1:temp.counter]-1
    }
    temp.rng_period=prod(temp.m_1_values)/2
    temp.counter=temp.counter+1
  }
  temp.num_generators=temp.counter-1
  if(!temp.num_generators){
    temp.num_generators=1
  }
  #cat("The number of random generators is ",temp.num_generators," yielding a period of ",temp.rng_period,"\n")
  temp.data_frame<-data.frame(temp.rng_period,temp.num_generators)
  return(temp.data_frame)
}

random_seed.selection<-function(num_generators.par,verbose.par="FALSE"){
  #Choose the random seed using a random selection of the first num.generators integers.
  #Gives a different seed for each run.
  temp_random_seeds.permutation<-sample(1:num_generators.par,num_generators.par)
  if(verbose.par=="TRUE"){
    cat("Random seeds for the ",num_generators.par," permutation generators:\n")
    cat(temp_random_seeds.permutation,"\n")
  }
  #Randomly choose a random seed, so that the two sequences have independent initiations.
  temp.random_seeds<-sample(temp_random_seeds.permutation,num_generators.par)
  for(i in 1:num_generators.par){
    if(temp.random_seeds[i]==temp_random_seeds.permutation[i]){
      temp.random_seeds[i]=temp.random_seeds[i]+1
    }
  }
  if(verbose.par=="TRUE"){
    cat("Random seeds for the ",num_generators.par," random-variable generators:\n")
    cat(temp.random_seeds,"\n")
  }
  temp.dataframe<-data.frame(temp_random_seeds.permutation,temp.random_seeds)
  return(temp.dataframe)
}

uniform.RNG<-function(num_rv.par,seed.parameters=c(0,0)){
  #cat("Generate uniform random variables. Require ",num_rv.par," uniform random numbers.\n")
  temp_rng_factors.object<-RNG.factors(num_rv.par)
  temp_rng.period=temp_rng_factors.object$temp.rng_period
  temp.num_generators=temp_rng_factors.object$temp.num_generators
  temp.permutation_random_variables<-rep(0,num_rv.par)
  temp.mlcg_random_variables<-rep(0,num_rv.par)
  if(!seed.parameters[1] & !seed.parameters[2]){
    random_seed.object<-random_seed.selection(temp.num_generators)
    temp_random_seeds.permutation<-random_seed.object$temp_random_seeds.permutation
    temp.random_seeds<-random_seed.object$temp.random_seeds
  }
  else{
    temp_random_seeds.permutation=seed.parameters[1]
    temp.random_seeds=seed.parameters[2]
  }
  temp.running_rvs_permutation<-temp_random_seeds.permutation
  temp.running_rvs<-temp.random_seeds
  temp.signs<-(-1)^(1:temp.num_generators-1)
  for(i in 1:num_rv.par){
    temp_sum.permutation<-crossprod(temp.running_rvs_permutation,temp.signs)
    temp.sum<-crossprod(temp.running_rvs,temp.signs)
    temp.permutation_random_variables[i]=temp_sum.permutation%%(moduli[1]-1)
    temp.mlcg_random_variables[i]=temp.sum%%(moduli[1]-1)
    if(!temp.permutation_random_variables[i]){
      temp.permutation_random_variables[i]=(moduli[1]-1)/moduli[1]
    }
    else{
      temp.permutation_random_variables[i]=temp.permutation_random_variables[i]/moduli[1]
    }
    temp.permutation_random_variables[i]<-max(round(temp.permutation_random_variables[i]*num_rv.par),1)
    if(!temp.mlcg_random_variables[i]){
      temp.mlcg_random_variables[i]=(moduli[1]-1)/moduli[1]
    }
    else{
      temp.mlcg_random_variables[i]=temp.mlcg_random_variables[i]/moduli[1]
    }
    for(j in 1:temp.num_generators){
      temp.running_rvs_permutation[j]=round(primitive.elements[num.moduli-j+1]*temp.running_rvs_permutation[j])%%moduli[num.moduli-j+1]
      temp.running_rvs[j]=round(primitive.elements[j]*temp.running_rvs[j])%%moduli[j]
    }
  }
  #Randomly permute the r.v.s
  temp.permuted_mlcg_random_numbers<-temp.mlcg_random_variables[temp.permutation_random_variables]
  temp.data_frame<-data.frame(temp.mlcg_random_variables,temp.permuted_mlcg_random_numbers,temp_rng.period,temp.num_generators)
  return(temp.data_frame)
}


s.random_variable<-function(random_numbers.par,index.par){
  temp.num_rvs=length(random_numbers.par)
  temp.v1=0
  temp.v2=0
  temp.s_variable=1
  temp.counter=1
  #When generating two uniform random variables, sample with replacement.
  while(temp.s_variable>=1){
    temp.u1=sample(random_numbers.par,1)
    temp.v1=2*temp.u1-1
    temp.u2=sample(random_numbers.par,1)
    temp.v2=2*temp.u2-1
    temp.s_variable=temp.v1^2+temp.v2^2
    #cat("temp.u1 = ",temp.u1,", temp.u2 = ",temp.u2,"\n")
    #cat("temp.s_variable = ",temp.s_variable,"\n")
    temp.counter=temp.counter+1
  }
  temp.dataframe<-data.frame(temp.s_variable,temp.v1,temp.v2)
}


gaussian.RNG<-function(num_rv.par,seed.par=c(0,0)){
  temp.random_numbers<-rep(0,num_rv.par)
  temp.uniform_rvs_object<-uniform.RNG(num_rv.par,seed.par)
  temp.uniform_rvs<-temp.uniform_rvs_object$temp.permuted_mlcg_random_numbers
  for(i in seq(from=1,to=num_rv.par-1,by=2)){
    #cat(i," out of ",num_rv.par,"\n")
    if(temp.uniform_rvs[i]<1e-7 | i==1){
      temp.s_variable_object<-s.random_variable(temp.uniform_rvs,i+2)
    }
    else{
      temp.s_variable_object<-s.random_variable(temp.uniform_rvs,i)
    }
    temp.s_variable=temp.s_variable_object$temp.s
    temp.v1=temp.s_variable_object$temp.v1
    temp.v2=temp.s_variable_object$temp.v2
    temp.random_numbers[i]=temp.v1*sqrt(-(2/temp.s_variable)*log(temp.s_variable))
    temp.random_numbers[i+1]=temp.v2*sqrt(-(2/temp.s_variable)*log(temp.s_variable))
  }
  temp.random_numbers[which(is.na(temp.random_numbers))]<-mode(temp.random_numbers)
  temp.random_numbers<-as.numeric(temp.random_numbers)
  return(temp.random_numbers)
}







