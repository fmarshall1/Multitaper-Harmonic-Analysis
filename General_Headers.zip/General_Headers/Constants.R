#Francois Marshall, Boston University
#Header file for constants.

#Eule Mascherani constant.
euler_mascherani.constant<<-digamma(1)
#The number of degrees of freedom is chosen using the example of Mcullogh.
student.dof=5

#Threshold used for time-series analysis.
threshold.percentile<<-0.999
bonferoni.threshold<<-threshold.percentile





















