#Francois Marshall, Boston University
#Header file for RNG.
###################################################################################################################


###################################################################################################################
#MLCG
###################################################################################################################

#Choose moduli from Table 4.1 of Brandt, for single-precision computers.
moduli<<-c(2147483647,2147483563,2147483399,2147482811,2147482801,2147482739)
primitive.elements<<-c(39373,40014,40692,41546,42024,45742)
num.moduli<<-length(moduli)

#Set factors for the MLCG.
RNG.factors<-function(period.par){
  #Determine the smallest RNG period greater or equal than the required number of random numbers.
  temp.rng_period=2
  temp.counter=1
  while(temp.rng_period<period.par){
    if(temp.counter==1){
      temp.m_1_values<-moduli[temp.counter]-1
    }
    else{
      temp.m_1_values<-moduli[1:temp.counter]-1
    }
    temp.rng_period=prod(temp.m_1_values)/2
    temp.counter=temp.counter+1
  }
  temp.num_generators=temp.counter-1
  if(!temp.num_generators){
    temp.num_generators=1
  }
  #cat("The number of random generators is ",temp.num_generators," yielding a period of ",temp.rng_period,"\n")
  temp.data_frame<-data.frame(temp.rng_period,temp.num_generators)
  return(temp.data_frame)
}

#Set the random seeds for a given MLCG.
random_seed.selection<-function(num_generators.par,verbose.par="FALSE"){
  #Choose the random seed using a random selection of the first num.generators integers.
  #Gives a different seed for each run.
  temp_random_seeds.permutation<-sample(1:num_generators.par,num_generators.par)
  if(verbose.par=="TRUE"){
    cat("Random seeds for the ",num_generators.par," permutation generators:\n")
    cat(temp_random_seeds.permutation,"\n")
  }
  #Randomly choose a random seed, so that the two sequences have independent initiations.
  temp.random_seeds<-sample(temp_random_seeds.permutation,num_generators.par)
  for(i in 1:num_generators.par){
    if(temp.random_seeds[i]==temp_random_seeds.permutation[i]){
      temp.random_seeds[i]=temp.random_seeds[i]+1
    }
  }
  if(verbose.par=="TRUE"){
    cat("Random seeds for the ",num_generators.par," random-variable generators:\n")
    cat(temp.random_seeds,"\n")
  }
  temp.dataframe<-data.frame(temp_random_seeds.permutation,temp.random_seeds)
  return(temp.dataframe)
}


running_seed.function<-function(seed.par){
  set.seed(seed.par)
  seed.par=seed.par+1
  return(seed.par)
}


basic_rng.function<-function(num_innovations.par,N.par,mean.par=0,variance.par=1,
                             crude_rv_num_samples.par=NA,
                             seeds.par=c(1,2),
                             uniform_numbers.par=NA){
  #Generate Gaussian innovations.
  temp.rng_object<-c()
  temp.innovations_sequence_standardized_normal_numbers<-c()
  if(!is.na(crude_rv_num_samples.par) & num_innovations.par>crude_rv_num_samples.par){
    if(N.par>crude_rv_num_samples.par){
      temp.rng_object<-gaussian.RNG(crude_rv_num_samples.par,seed.par=seeds.par,uniform_numbers.par=uniform_numbers.par)
      temp.innovations_sequence_standardized_normal_numbers<-temp.rng_object$out.random_numbers
      temp.running_seeds<-running_seed.function(seeds.par)
      temp.innovations_sequence_standardized_normal_numbers<-c(temp.innovations_sequence_standardized_normal_numbers,
                                                               rnorm(num_innovations.par-crude_rv_num_samples.par))
      running_seed.function(temp.running_seeds)
      temp.innovations_sequence_standardized_normal_numbers<-sample(temp.innovations_sequence_standardized_normal_numbers)
      running_seed.function(temp.running_seeds)
    }
  }
  else{
    temp.rng_object<-gaussian.RNG(num_innovations.par,seed.par=seeds.par,uniform_numbers.par=uniform_numbers.par)
    temp.innovations_sequence_standardized_normal_numbers<-temp.rng_object$out.random_numbers
  }
  temp.innovations_sequence<-mean.par+sqrt(variance.par)*temp.innovations_sequence_standardized_normal_numbers
  temp.uniform_numbers<-temp.rng_object$out.uniform_rvs
  if(!is.na(crude_rv_num_samples.par)){
    if(N.par>crude_rv_num_samples.par){
      temp.uniform_numbers<-c(temp.uniform_numbers,runif(num_innovations.par-crude_rv_num_samples.par))
    }
  }
  return(temp.innovations_sequence)
}



#Generate uniform random numbers.
uniform.RNG<-function(num_rv.par,seed.parameters=c(0,0)){
  #cat("Generate uniform random variables. Require ",num_rv.par," uniform random numbers.\n")
  temp_rng_factors.object<-RNG.factors(num_rv.par)
  temp_rng.period=temp_rng_factors.object$temp.rng_period
  temp.num_generators=temp_rng_factors.object$temp.num_generators
  temp.permutation_random_variables<-rep(0,num_rv.par)
  temp.mlcg_random_variables<-rep(0,num_rv.par)
  if(!seed.parameters[1] & !seed.parameters[2]){
    random_seed.object<-random_seed.selection(temp.num_generators)
    temp_random_seeds.permutation<-random_seed.object$temp_random_seeds.permutation
    temp.random_seeds<-random_seed.object$temp.random_seeds
  }
  else{
    temp_random_seeds.permutation=seed.parameters[1]
    temp.random_seeds=seed.parameters[2]
  }
  temp.running_rvs_permutation<-temp_random_seeds.permutation
  temp.running_rvs<-temp.random_seeds
  temp.signs<-(-1)^(1:temp.num_generators-1)
  for(i in 1:num_rv.par){
    temp_sum.permutation<-crossprod(temp.running_rvs_permutation,temp.signs)
    temp.sum<-crossprod(temp.running_rvs,temp.signs)
    temp.permutation_random_variables[i]=temp_sum.permutation%%(moduli[1]-1)
    temp.mlcg_random_variables[i]=temp.sum%%(moduli[1]-1)
    if(!temp.permutation_random_variables[i]){
      temp.permutation_random_variables[i]=(moduli[1]-1)/moduli[1]
    }
    else{
      temp.permutation_random_variables[i]=temp.permutation_random_variables[i]/moduli[1]
    }
    temp.permutation_random_variables[i]<-max(round(temp.permutation_random_variables[i]*num_rv.par),1)
    if(!temp.mlcg_random_variables[i]){
      temp.mlcg_random_variables[i]=(moduli[1]-1)/moduli[1]
    }
    else{
      temp.mlcg_random_variables[i]=temp.mlcg_random_variables[i]/moduli[1]
    }
    for(j in 1:temp.num_generators){
      temp.running_rvs_permutation[j]=round(primitive.elements[num.moduli-j+1]*temp.running_rvs_permutation[j])%%moduli[num.moduli-j+1]
      temp.running_rvs[j]=round(primitive.elements[j]*temp.running_rvs[j])%%moduli[j]
    }
  }
  #Randomly permute the r.v.s
  temp.permuted_mlcg_random_numbers<-temp.mlcg_random_variables[temp.permutation_random_variables]
  temp.list<-list(out.mlcg_random_variables=temp.mlcg_random_variables,
                  out.permuted_mlcg_random_numbers=temp.permuted_mlcg_random_numbers,
                  out.rng_period=temp_rng.period,
                  out.num_generators=temp.num_generators)
  return(temp.list)
}

standard_uniform_RNG.function<-function(num_rv.par=100,uniform_numbers.par=NA,seed.par=c(1,2)){
  temp.uniform_rvs<-c()
  if(is.na(uniform_numbers.par)==TRUE){
    temp.uniform_rvs_object<-uniform.RNG(num_rv.par,seed.par)
    temp.uniform_rvs<-temp.uniform_rvs_object$out.permuted_mlcg_random_numbers
  }
  else{
    temp.uniform_rvs<-sample(uniform_numbers.par)
  }
  return(temp.uniform_rvs)
}

#Generate polar deviates for the Box-Muller RNG.
s.random_variable<-function(random_numbers.par,index.par){
  temp.num_rvs=length(random_numbers.par)
  temp.v1=0
  temp.v2=0
  temp.s_variable=1
  temp.counter=1
  #When generating two uniform random variables, sample with replacement.
  while(temp.s_variable>=1){
    temp.u1=sample(random_numbers.par,1)
    temp.v1=2*temp.u1-1
    temp.u2=sample(random_numbers.par,1)
    temp.v2=2*temp.u2-1
    temp.s_variable=temp.v1^2+temp.v2^2
    temp.counter=temp.counter+1
  }
  temp.dataframe<-data.frame(temp.s_variable,temp.v1,temp.v2)
}

#The Gaussian RNG.
gaussian.RNG<-function(num_rv.par=100,seed.par=c(1,2),uniform_numbers.par=NA){
  temp.random_numbers<-rep(0,num_rv.par)
  seed.par<-running_seed.function(seed.par)
  temp.uniform_rvs<-standard_uniform_RNG.function(num_rv.par=num_rv.par,uniform_numbers.par=uniform_numbers.par,seed.par=seed.par)
  for(temp.i in seq(from=1,to=num_rv.par-1,by=2)){
    if(temp.uniform_rvs[temp.i]<1e-7 || temp.i==1){
      temp.s_variable_object<-s.random_variable(temp.uniform_rvs,temp.i+2)
    }
    else{
      temp.s_variable_object<-s.random_variable(temp.uniform_rvs,temp.i)
    }
    temp.s_variable=temp.s_variable_object$temp.s
    temp.v1=temp.s_variable_object$temp.v1
    temp.v2=temp.s_variable_object$temp.v2
    temp.random_numbers[temp.i]=temp.v1*sqrt(-(2/temp.s_variable)*log(temp.s_variable))
    temp.random_numbers[temp.i+1]=temp.v2*sqrt(-(2/temp.s_variable)*log(temp.s_variable))
  }
  temp.random_numbers[which(is.na(temp.random_numbers)==TRUE)]<-mode(temp.random_numbers[which(!is.na(temp.random_numbers)==TRUE)])
  temp.random_numbers<-as.numeric(temp.random_numbers)
  temp.list<-list(out.uniform_rvs=temp.uniform_rvs,
                  out.random_numbers=temp.random_numbers)
  return(temp.list)
}

gumbel_rng.function<-function(population_variance.par,num_deviates.par=100,seeds.par=c(1,2),uniform_numbers.par=NA){
  temp.population_sd=sqrt(population_variance.par)
  temp.beta_parameter=sqrt(6/pi^2*population_variance.par)
  temp.mu_parameter=-temp.beta_parameter*euler_mascherani.constant
  #CDF trick to obtain the Gumbel deviates.
  seeds.par<-running_seed.function(seeds.par)
  temp.uniform_numbers<-standard_uniform_RNG.function(num_rv.par=num_deviates.par,uniform_numbers.par=uniform_numbers.par,seed.par=seeds.par)
  temp.innovations_sequence<-qgumbel(temp.uniform_numbers,loc=temp.mu_parameter,scale=temp.beta_parameter)
  temp.list<-list(out.uniform_numbers=temp.uniform_numbers,
                  out.innovations_sequence=temp.innovations_sequence)
  return(temp.list)
}

logistic_rng.function<-function(population_variance.par,num_deviates.par=100,seeds.par=c(1,2),uniform_numbers.par=NA){
  temp.population_sd=sqrt(population_variance.par)
  temp.scale_parameter=sqrt(3)/pi*temp.population_sd
  #CDF trick to obtain the logistic deviates.
  seeds.par<-running_seed.function(seeds.par)
  temp.uniform_numbers<-standard_uniform_RNG.function(num_rv.par=num_deviates.par,uniform_numbers.par=uniform_numbers.par,seed.par=seeds.par)
  temp.innovations_sequence<-qlogis(temp.uniform_numbers,scale=temp.scale_parameter)
  temp.list<-list(out.uniform_numbers=temp.uniform_numbers,
                  out.innovations_sequence=temp.innovations_sequence)
  return(temp.list)
}

student_rng.function<-function(population_variance.par,num_deviates.par=100,num_dof.par=5,seeds.par=c(1,2),uniform_numbers.par=NA){
  temp.population_sd=sqrt(population_variance.par)
  temp.student_t_variance=1/(1-2/num_dof.par)
  temp.student_t_conversion_factor=sqrt(population_variance.par/temp.student_t_variance)
  #CDF trick to obtain the Student deviates
  seeds.par<-running_seed.function(seeds.par)
  temp.uniform_numbers<-standard_uniform_RNG.function(num_rv.par=num_deviates.par,uniform_numbers.par=uniform_numbers.par,seed.par=seeds.par)
  temp.standardized_innovations<-qt(temp.uniform_numbers,num_dof.par)
  temp.innovations_sequence<-temp.student_t_conversion_factor*temp.standardized_innovations
  temp.list<-list(out.uniform_numbers=temp.uniform_numbers,
                  out.innovations_sequence=temp.innovations_sequence)
  return(temp.list)
}

uniform_rng.function<-function(population_variance.par,num_deviates.par=100,seeds.par=c(1,2),uniform_numbers.par=NA){
  temp.population_sd=sqrt(population_variance.par)
  temp.upper_bound=sqrt(3)*temp.population_sd
  temp.lower_bound=-temp.upper_bound
  #CDF trick to obtain the uniform deviates.
  seeds.par<-running_seed.function(seeds.par)
  temp.uniform_numbers<-standard_uniform_RNG.function(num_rv.par=num_deviates.par,uniform_numbers.par=uniform_numbers.par,seed.par=seeds.par)
  temp.innovations_sequence<-temp.uniform_numbers*(temp.upper_bound-temp.lower_bound)+temp.lower_bound
  temp.list<-list(out.uniform_numbers=temp.uniform_numbers,
                  out.innovations_sequence=temp.innovations_sequence)
  return(temp.list)
}




























