#Francois Marshall, Boston University
#Header file for decimation analysis and the construction of the relevant filters.

###################################################################################################################

initialize_bandpass_filter_strings.function<-function(trial_frequency_bands.par,trial_frequency_bands_list.par,
                                                      sampling_rate.par=1,abbreviated_frequency_units.par="",
                                                      filter_type_strings.par,filter_order_strings.par,
                                                      reference_paper_strings.par){
  temp.title_strings<-c()
  temp.num_filters=length(trial_frequency_bands.par)
  for(temp.j in 1:temp.num_filters){
    temp.band_j<-trial_frequency_bands.par[[temp.j]]*sampling_rate.par
    temp.title_strings[temp.j]<-paste("[",temp.band_j[1],",",temp.band_j[2],"]",abbreviated_frequency_units.par,"\n",
                                      filter_type_strings.par[temp.j],filter_order_strings.par[temp.j],", ",
                                      reference_paper_strings.par[temp.j],sep="")
  }
  return(temp.title_strings)
}

filter_specification.function<-function(filter_type_strings_list.par,
                                        filter_order_strings_list.par,
                                        reference_paper_strings_list.par,
                                        trial_frequency_bands_list.par,
                                        sampling_rate.par=1,
                                        filter_orders_list.par,num_filter_objects_vector.par){
  temp.num_rhythms=length(filter_type_strings_list.par)
  temp.bandpass_filter_strings_list<-list()
  temp.bandpass_filter_lists_list<-list()
  for(temp.j in 1:temp.num_rhythms){
    temp.filter_order_strings_vector_j<-filter_order_strings_list.par[[temp.j]]
    temp.filter_type_strings_vector_j<-filter_type_strings_list.par[[temp.j]]
    temp.reference_paper_strings_vector_j<-reference_paper_strings_list.par[[temp.j]]
    temp.num_filters_j=length(temp.filter_type_strings_vector_j)
    temp.trial_frequency_bands_list_j<-trial_frequency_bands_list.par[[temp.j]]
    for(temp.k in 1:temp.num_filters_j){
      temp.trial_frequency_bands_list_j[[temp.k]]=temp.trial_frequency_bands_list_j[[temp.k]]/sampling_rate.par
    }
    #Filter strings.
    temp.bandpass_filter_strings_list[[temp.j]]<-
      initialize_bandpass_filter_strings.function(trial_frequency_bands.par=temp.trial_frequency_bands_list_j,
                                                  sampling_rate.par=temp.sampling_rate,
                                                  abbreviated_frequency_units.par=abbreviated.frequency_units,
                                                  filter_type_strings.par=temp.filter_type_strings_vector_j,
                                                  filter_order_strings.par=temp.filter_order_strings_vector_j,
                                                  reference_paper_strings.par=temp.reference_paper_strings_vector_j)
    #Filter objects.
    temp.filter_orders_vector_j<-filter_orders_list.par[[temp.j]]
    temp.num_filter_objects_j=num_filter_objects_vector.par[temp.j]
    temp.filter_object_list_j<-list()
    for(temp.k in 1:temp.num_filter_objects_j){
      temp.pass_string<-""
      if(temp.trial_frequency_bands_list_j[[temp.k]][1]>0){
        temp.pass_string<-"pass"
      } else{
        temp.pass_string<-"low"
      }
      temp.filter_object<-fir1(n=temp.filter_orders_vector_j[temp.k],w=temp.trial_frequency_bands_list_j[[temp.k]],type=temp.pass_string)
      temp.filter_object_list_j[[temp.k]]<-temp.filter_object
    }
    temp.bandpass_filter_lists_list[[temp.j]]<-temp.filter_object_list_j
  }
  temp.list<-list(out.bandpass_filter_strings_list=temp.bandpass_filter_strings_list,
                  out.bandpass_filter_lists_list=temp.bandpass_filter_lists_list)
  return(temp.list)
}




#Cleaning.
TF_cleaning.function<-function(TF.par,nums_nn_interpolation.par=0){
  temp.num_TF=length(TF.par)
  temp.valid_index_list<-list()
  temp.counter=1
  for(temp.k in 1:temp.num_TF){
    temp.Re_k=Re(TF.par[temp.k])
    temp.Im_k=Im(TF.par[temp.k])
    if(is.na(temp.Re_k)==FALSE & is.nan(temp.Re_k)==FALSE & is.infinite(temp.Re_k)==FALSE &
       is.na(temp.Im_k)==FALSE & is.nan(temp.Im_k)==FALSE & is.infinite(temp.Im_k)==FALSE &
       Mod(TF.par[temp.k])>0){
      temp.valid_index_list[[temp.counter]]=temp.k
      temp.counter=temp.counter+1
    }
  }
  temp.valid_indices<-unlist(temp.valid_index_list)
  for(temp.k in 1:temp.num_TF){
    temp.Re_k=Re(TF.par[temp.k])
    temp.Im_k=Im(TF.par[temp.k])
    temp.Mod_k=Mod(TF.par[temp.k])
    if(is.na(temp.Re_k)==TRUE || is.nan(temp.Re_k)==TRUE || is.infinite(temp.Re_k)==TRUE ||
       is.na(temp.Im_k)==TRUE || is.nan(temp.Im_k)==TRUE || is.infinite(temp.Im_k)==TRUE ||
       !temp.Mod_k){
      temp.left_index=max(1,temp.k-1)
      temp.Re_k_minus=Re(TF.par[temp.left_index])
      temp.Im_k_minus=Im(TF.par[temp.left_index])
      temp.Mod_k_minus=Mod(TF.par[temp.left_index])
      if(is.na(temp.Re_k_minus)==FALSE & is.nan(temp.Re_k_minus)==FALSE & is.infinite(temp.Re_k_minus)==FALSE &
         is.na(temp.Im_k_minus)==FALSE & is.nan(temp.Im_k_minus)==FALSE & is.infinite(temp.Im_k_minus)==FALSE &
         temp.Mod_k_minus>0){
        temp.right_index=min(temp.k+1,temp.num_TF)
        temp.Re_k_plus=Re(TF.par[temp.right_index])
        temp.Im_k_plus=Im(TF.par[temp.right_index])
        temp.Mod_k_plus=Mod(TF.par[temp.right_index])
        if(is.na(temp.Re_k_plus)==FALSE & is.nan(temp.Re_k_plus)==FALSE & is.infinite(temp.Re_k_plus)==FALSE &
           is.na(temp.Im_k_plus)==FALSE & is.nan(temp.Im_k_plus)==FALSE & is.infinite(temp.Im_k_plus)==FALSE &
           Mod(temp.Mod_k_plus)>0){
          temp.slope=(TF.par[min(temp.k+1,temp.num_TF)]-TF.par[max(1,temp.k-1)])/(max(1,temp.k-1)-min(temp.k+1,temp.num_TF))
          temp.intercept=TF.par[max(1,temp.k-1)]-max(1,temp.k-1)*temp.slope
          TF.par[temp.k]=temp.intercept+temp.k*temp.slope
          nums_nn_interpolation.par=nums_nn_interpolation.par+1
          if(is.na(temp.Re_k)==TRUE || is.nan(temp.Re_k)==TRUE || is.infinite(temp.Re_k)==TRUE ||
             is.na(temp.Im_k)==TRUE || is.nan(temp.Im_k)==TRUE || is.infinite(temp.Im_k)==TRUE ||
             !temp.Mod_k){
            TF.par[temp.k]=TF.par[max(1,temp.k-1)]
            nums_nn_interpolation.par=nums_nn_interpolation.par-1
            nums_nn_interpolation.par=nums_nn_interpolation.par+1
          }
          if(is.na(temp.Re_k)==TRUE || is.nan(temp.Re_k)==TRUE || is.infinite(temp.Re_k)==TRUE ||
             is.na(temp.Im_k)==TRUE || is.nan(temp.Im_k)==TRUE || is.infinite(temp.Im_k)==TRUE ||
             !temp.Mod_k){
            temp.valid_index_diffs<-abs(temp.k-temp.valid_indices)
            temp.min_index_diff=min(temp.valid_index_diffs)
            temp.index=min(which(temp.valid_index_diffs==temp.min_index_diff))
            TF.par[temp.k]=0
            if(length(temp.index)>0){
              TF.par[temp.k]=TF.par[temp.index]
            }
          }
        }
        else{
          TF.par[temp.k]=TF.par[max(1,temp.k-1)]
          if(is.na(temp.Re_k)==TRUE || is.nan(temp.Re_k)==TRUE || is.infinite(temp.Re_k)==TRUE ||
             is.na(temp.Im_k)==TRUE || is.nan(temp.Im_k)==TRUE || is.infinite(temp.Im_k)==TRUE ||
             !temp.Mod_k){
            temp.valid_index_diffs<-abs(temp.k-temp.valid_indices)
            temp.min_index_diff=min(temp.valid_index_diffs)
            temp.matching_indices<-which(temp.valid_index_diffs==temp.min_index_diff)
            temp.index=min(temp.matching_indices)
            temp.index=temp.valid_indices[temp.index]
            TF.par[temp.k]=0
            if(length(temp.index)>0){
              TF.par[temp.k]=TF.par[temp.index]
            }
            nums_nn_interpolation.par=nums_nn_interpolation.par+1
          }
        }
      }
      else{
        temp.valid_index_diffs<-abs(temp.k-temp.valid_indices)
        temp.min_index_diff=min(temp.valid_index_diffs)
        temp.matching_indices<-which(temp.valid_index_diffs==temp.min_index_diff)
        temp.index=min(temp.matching_indices)
        temp.index=temp.valid_indices[temp.index]
        TF.par[temp.k]=0
        if(length(temp.index)>0){
          TF.par[temp.k]=TF.par[temp.index]
        }
        nums_nn_interpolation.par=nums_nn_interpolation.par+1
      }
    }
  }
  #Extract all the remaining cleaned points.
  temp.clean_TF<-TF.par
  temp.clean_TF<-temp.clean_TF[is.nan(Re(temp.clean_TF))==FALSE]
  temp.clean_TF<-temp.clean_TF[is.nan(Im(temp.clean_TF))==FALSE]
  temp.clean_TF<-temp.clean_TF[is.na(Re(temp.clean_TF))==FALSE]
  temp.clean_TF<-temp.clean_TF[is.na(Im(temp.clean_TF))==FALSE]
  temp.clean_TF<-temp.clean_TF[is.finite(abs(Re(temp.clean_TF)))==TRUE]
  temp.clean_TF<-temp.clean_TF[is.finite(abs(Im(temp.clean_TF)))==TRUE]
  #Now, use hard replacement by the median of the cleaned points.
  temp.median=median(temp.clean_TF)
  TF.par[is.nan(Re(TF.par))==TRUE]<-temp.median
  TF.par[is.nan(Im(TF.par))==TRUE]<-temp.median
  TF.par[is.na(Re(TF.par))==TRUE]<-temp.median
  TF.par[is.na(Im(TF.par))==TRUE]<-temp.median
  TF.par[is.infinite(abs(Re(TF.par)))==TRUE]<-temp.median
  TF.par[is.infinite(abs(Im(TF.par)))==TRUE]<-temp.median
  temp.list<-list(out.TF=TF.par,
                  out.nums_nn_interpolation=nums_nn_interpolation.par)
  return(temp.list)
}

quick_decimation.function<-function(times.par,ts.par,
                                    step_size.par=1,
                                    plot_bool.par=FALSE){
  #Use the R decimation method.
  temp.decimation_ts<-decimate(ts.par,step_size.par)
  temp.decimation_indices<-seq(from=1,to=N.par,by=step_size.par)
  temp.decimated_times<-times.par[temp.decimation_indices]
  temp.num_decimated=length(temp.decimation_ts)
  if(plot_bool.par==TRUE){
    plot.graph(list(temp.decimated_times),list(temp.decimation_ts),
               x_label.par=paste(measured_abscissa.string,", in ",time_units.string,sep=""),
               y_label.par=paste(measure_quantity.string,", in ",measure_units.string,sep=""),
               pdf_title.par="Decimated_Time_Series.pdf")
  }
  temp.list<-list(out.decimated_times=temp.decimated_times,
                  out.decimation_ts=temp.decimation_ts,
                  out.num_decimated=temp.num_decimated)
  return(temp.list)
}


#Extract the relevant information from the bifrequency spectrum to decide what parameters to choose for the Slepian and established filters.
decimation_energies.function<-function(bifrequency_spectrum_vector.par,frequencies.par,temp.row_indices_vector,temp.column_indices_vector,passbands.par,
                                       M.par,sampling_rate.par=1,pdf_title.par,verbose.par=FALSE){
  tic()
  if(verbose.par==TRUE){
    cat("Decimation filter, energies computation: ")
  }
  temp.num_passbands=length(passbands.par)
  temp.num_bifrequency_entries=length(bifrequency_spectrum_vector.par)
  temp.passband_energies_unaliased<-rep(0,temp.num_passbands)
  temp.passband_energies_aliased<-temp.passband_energies_unaliased
  temp.passband_PSD_energies_unaliased<-temp.passband_energies_unaliased
  temp.passband_PSD_energies_aliased<-temp.passband_energies_unaliased
  temp.stopband_max_powers<-temp.passband_energies_unaliased
  temp.stopband_optimal_frequency_coordinates<-matrix(0,nrow=temp.num_passbands,ncol=2)
  temp.stopband_min_powers<-rep(max(Mod(bifrequency_spectrum_vector.par)),temp.num_passbands)
  temp.stopband_optimal_min_frequency_coordinates<-temp.stopband_optimal_frequency_coordinates
  temp.row_frequencies<-frequencies.par[temp.row_indices_vector]
  temp.max_row_frequency=max(temp.row_frequencies)
  temp.min_row_power=min(Mod(bifrequency_spectrum_vector.par[temp.row_frequencies==temp.max_row_frequency]))
  temp.max_row_power=max(Mod(bifrequency_spectrum_vector.par[temp.row_frequencies==temp.max_row_frequency]))
  temp.column_frequencies<-frequencies.par[temp.column_indices_vector]
  temp.max_column_frequency=max(temp.column_frequencies)
  temp.min_column_power=min(Mod(bifrequency_spectrum_vector.par[temp.column_frequencies==temp.max_column_frequency]))
  temp.max_column_power=max(Mod(bifrequency_spectrum_vector.par[temp.column_frequencies==temp.max_column_frequency]))
  temp.min_boundary_power=min(temp.min_row_power,temp.min_column_power)
  temp.max_boundary_power=max(temp.max_row_power,temp.max_column_power)
  for(temp.i in 1:temp.num_bifrequency_entries){
    if(verbose.par==TRUE){
      cat(temp.i," out of ",temp.num_bifrequency_entries,"\n")
    }
    temp.row_index=temp.row_indices_vector[temp.i]
    temp.column_index=temp.column_indices_vector[temp.i]
    temp.bifrequency_power=bifrequency_spectrum_vector.par[temp.i]
    if(temp.row_index>temp.column_index){
      temp.bifrequency_power=temp.bifrequency_power+Conj(temp.bifrequency_power)
    }
    for(temp.j in 1:temp.num_passbands){
      temp.cutoff=passbands.par[temp.j]
      temp.row_frequency=frequencies.par[temp.row_index]*sampling_rate.par
      temp.column_frequency=frequencies.par[temp.column_index]*sampling_rate.par
      if(temp.row_frequency<temp.cutoff & temp.column_frequency<temp.cutoff){
        #Unaliased.
        if(temp.row_frequency==temp.column_frequency){
          temp.passband_PSD_energies_unaliased[temp.j]=temp.passband_PSD_energies_unaliased[temp.j]+Re(temp.bifrequency_power)
        }
        else{
          temp.passband_energies_unaliased[temp.j]=temp.passband_energies_unaliased[temp.j]+Mod(temp.bifrequency_power)
        }
      }
      #Aliased.
      if(temp.row_frequency==temp.column_frequency){
        temp.passband_PSD_energies_aliased[temp.j]=temp.passband_PSD_energies_aliased[temp.j]+Re(temp.bifrequency_power)
        temp.passband_energies_aliased[temp.j]=temp.passband_energies_aliased[temp.j]+Mod(temp.bifrequency_power)
      }
      else{
        temp.passband_energies_aliased[temp.j]=temp.passband_energies_aliased[temp.j]+Mod(temp.bifrequency_power)
      }
      #If in the stopband, determine if the power is optimal.
      if(temp.row_frequency>=temp.cutoff & temp.column_frequency>=temp.cutoff & temp.row_frequency!=temp.column_frequency){
        temp.mod_power=Mod(bifrequency_spectrum_vector.par[temp.i])
        if(Mod(temp.stopband_max_powers[temp.j])<temp.mod_power){
          temp.stopband_max_powers[temp.j]=bifrequency_spectrum_vector.par[temp.i]
          temp.stopband_optimal_frequency_coordinates[temp.j,]<-c(temp.row_index,temp.column_index)
        }
        if(Mod(temp.stopband_min_powers[temp.j])>temp.mod_power){
          temp.stopband_min_powers[temp.j]=bifrequency_spectrum_vector.par[temp.i]
          temp.stopband_optimal_min_frequency_coordinates[temp.j,]<-c(temp.row_index,temp.column_index)
        }
      }
    }
  }
  temp.passband_energies_unaliased=Mod(temp.passband_energies_unaliased)
  temp.passband_energies_aliased=Mod(temp.passband_energies_aliased)
  temp.passband_PSD_energies_unaliased=Mod(temp.passband_PSD_energies_unaliased)
  temp.passband_PSD_energies_aliased=Mod(temp.passband_PSD_energies_aliased)
  sink(pdf_title.par, append=FALSE, split=FALSE)
  cat("passband_index\tpassband_cutoff\tmin_stopband\trow_freq\tcolumn_freq\tmax_stopband\trow_freq\tcolumn_freq\tunaliased\taliased\tPSD_unaliased\tPSD_aliased\n")
  for(temp.j in 1:temp.num_passbands){
    temp.cutoff=passbands.par[temp.j]
    temp.frequencies1<-rep(0,2)
    temp.frequencies2<-temp.frequencies1
    if(temp.cutoff==(sampling_rate.par/2)){
      temp.stopband_min_powers[temp.j]=temp.min_boundary_power
      temp.stopband_max_powers[temp.j]=temp.max_boundary_power
      temp.passband_PSD_energies_aliased[temp.j]=temp.passband_PSD_energies_unaliased[temp.j]
    }
    else{
      temp.indices1<-temp.stopband_optimal_frequency_coordinates[temp.j,]
      temp.indices2<-temp.stopband_optimal_min_frequency_coordinates[temp.j,]
      temp.frequencies1<-frequencies.par[temp.indices1]*sampling_rate.par
      temp.frequencies2<-frequencies.par[temp.indices2]*sampling_rate.par
    }
    temp.min_mod_bifrequency_density=Mod(temp.stopband_min_powers[temp.j])
    temp.max_mod_bifrequency_density=Mod(temp.stopband_max_powers[temp.j])
    cat(temp.j,"\t",passbands.par[temp.j],"\t",temp.min_mod_bifrequency_density,"\t",temp.frequencies2[1],"\t",temp.frequencies2[2],"\t",
        temp.max_mod_bifrequency_density,"\t",temp.frequencies1[1],"\t",temp.frequencies1[2],"\t",temp.passband_energies_unaliased[temp.j],"\t",
        temp.passband_energies_aliased[temp.j],"\t",temp.passband_PSD_energies_unaliased[temp.j],"\t",temp.passband_PSD_energies_aliased[temp.j],"\n")
  }
  sink()
  if(verbose.par==TRUE){
    cat("Decimation filter, energies computation: ")
  }
  toc()
  temp.indices1<-temp.stopband_optimal_frequency_coordinates
  temp.indices2<-temp.stopband_optimal_min_frequency_coordinates[temp.j,]
  temp.list<-list(out.stopband_min_powers=temp.stopband_min_powers,
                  out.min_optimal_indices=temp.indices2,
                  out.stopband_max_powers=temp.stopband_max_powers,
                  out.max_optimal_indices=temp.indices1,
                  out.passband_energies_unaliased=temp.passband_energies_unaliased,
                  out.passband_energies_aliased=temp.passband_energies_aliased,
                  out.passband_PSD_energies_unaliased=temp.passband_PSD_energies_unaliased,
                  out.passband_PSD_energies_aliased=temp.passband_PSD_energies_aliased)
  return(temp.list)
}



multitaper_decimation_filter_TF.function<-function(passband_cutoff.par,sampling_rate.par=1,N.par,M.par,num_fitting_indices.par=20,
                                                   bandwidth_multiple.par=5){
  temp.num_fitting_indices0=passband_cutoff.par*M.par
  temp.N=N.par
  if(temp.num_fitting_indices0>num_fitting_indices.par){
    temp.N=ceil(num_fitting_indices.par/temp.num_fitting_indices0*N.par)
  }
  temp.passband_indices<-1:num_fitting_indices.par
  temp.NW=temp.N*passband_cutoff.par*bandwidth_multiple.par
  temp.mt_parameters_object<-multitaper_parameters.function(temp.N,temp.NW,sampling_rate.par=sampling_rate.par,
                                                            M_exponent.par=1,cepstral_bool.par=FALSE,verbose.par=FALSE)
  temp.M=temp.mt_parameters_object$out.M
  temp.M2=temp.mt_parameters_object$out.M_2
  temp.K=temp.mt_parameters_object$out.K
  temp.zero_index=temp.mt_parameters_object$out.zero_index
  temp.frequencies<-temp.mt_parameters_object$out.frequencies
  temp.passband_cutoff_frequency=temp.frequencies[floor(passband_cutoff.par*temp.M)]
  temp.slepian_sequences_object<-dpss.matrix(temp.N,temp.NW,temp.K)
  temp.slepian_sequences<-temp.slepian_sequences_object$out.dpss
  temp.slepian_functions<-Slepian.functions(temp.slepian_sequences,temp.M)
  #temp.num_slepians=max(c(min(c(3,max(c(temp.K,2)))),floor(0.25*temp.K)))
  temp.num_slepians=temp.K
  if(temp.num_slepians>1){
    temp.num_slepians=max(0.25*temp.K,ncol(temp.slepian_functions))
  }
  temp.real_slepian_functions<-matrix(0,nrow=temp.M2,ncol=temp.num_slepians)
  temp.basis_indices<-temp.zero_index+1:temp.M2-1
  temp.real_slepian_functions<-Mod(temp.slepian_functions[temp.basis_indices,])^2
  #cat("temp.num_slepians = ",temp.num_slepians,", length(temp.real_slepian_functions) = ",ncol(temp.real_slepian_functions),"\n")
  if(temp.num_slepians>1){
    temp.real_slepian_functions<-temp.real_slepian_functions[,1:temp.num_slepians]
  }
  temp.ideal_filter<-rep(1,num_fitting_indices.par)
  temp.slepian_data_frame<-c()
  if(temp.num_slepians>1){
    temp.slepian_data_frame<-data.frame(temp.ideal_filter,temp.real_slepian_functions[temp.passband_indices,])
  }
  else{
    temp.slepian_data_frame<-data.frame(temp.ideal_filter,temp.real_slepian_functions[temp.passband_indices])
  }
  temp.model_fit<-lm(temp.ideal_filter~.-1,data=temp.slepian_data_frame)
  temp.coefficients<-temp.model_fit$coefficients
  temp.fitted_values<-temp.model_fit$fitted.values
  temp.residuals<-temp.model_fit$residuals
  temp.residual_analysis_object<-residual_analysis.function(temp.fitted_values,temp.residuals,TPT_threshold.par=TPT_threshold.par)
  temp.Rsq=temp.residual_analysis_object$out.Rsq
  if(temp.Rsq<0){
    temp.Rsq=0
  }
  temp.KS_percentile=temp.residual_analysis_object$out.KS_percentile
  temp.TPT_percentile=temp.residual_analysis_object$out.TPT_percentile
  temp.fitting_slepians<-temp.real_slepian_functions
  if(temp.num_slepians==1){
    temp.fitting_slepians<-temp.coefficients*temp.real_slepian_functions
  }
  else{
    for(temp.k in 1:temp.num_slepians){
      temp.fitting_slepians[,temp.k]<-temp.coefficients[temp.k]*temp.real_slepian_functions[,temp.k]
    }
  }
  temp.frequency_response<-c()
  if(temp.num_slepians>1){
    temp.frequency_response<-rowSums(temp.fitting_slepians)
  }
  else{
    temp.frequency_response<-temp.fitting_slepians
  }
  temp.list<-list(out.frequency_response=temp.frequency_response,
                  out.N=temp.N,
                  out.Rsq=temp.Rsq,
                  out.KS_percentile=temp.KS_percentile,
                  out.TPT_percentile=temp.TPT_percentile,
                  out.frequencies=temp.frequencies,
                  out.passband_cutoff_frequency=temp.passband_cutoff_frequency)
  return(temp.list)
}


established_decimation_filter.function<-function(passband_edge.par,stopband_edge.par,passband_ripple_height.par,stopband_ripple_height.par,
                                                 sampling_rate.par=1,filter_type.par="Butterworth"){
  temp.order_object<-c()
  if(filter_type.par=="Butterworth"){
    temp.order_object<-buttord(Wp=passband_edge.par,Ws=stopband_edge.par,Rp=passband_ripple_height.par,Rs=stopband_ripple_height.par)
  }
  else if(filter_type.par=="Chebyshev_I" || filter_type.par=="Chebyshev_II"){
    temp.order_object<-cheb1ord(Wp=passband_edge.par,Ws=stopband_edge.par,Rp=passband_ripple_height.par,Rs=stopband_ripple_height.par)
  }
  else if(filter_type.par=="Elliptic"){
    temp.order_object<-ellipord(Wp=passband_edge.par,Ws=stopband_edge.par,Rp=passband_ripple_height.par,Rs=stopband_ripple_height.par)
  }
  temp.order0=temp.order_object$n
  temp.TF_object<-c()
  temp.filter_object<-c()
  temp.order=0
  temp.Wc=0
  temp.TF_frequencies<-rep(0,3)
  temp.TF<-temp.TF_frequencies
  if(temp.order0>0 & !is.na(temp.order0) & !is.infinite(temp.order0) & !is.nan(temp.order0)){
    temp.order=temp.order0
    temp.Wc=temp.order_object$Wc
    if(filter_type.par=="Butterworth"){
      temp.filter_object<-butter(temp.order_object)
    }
    else if(filter_type.par=="Chebyshev_I"){
      temp.filter_object<-cheby1(temp.order_object)
    }
    else if(filter_type.par=="Chebyshev_II"){
      temp.filter_object<-cheby2(temp.order_object)
    }
    else if(filter_type.par=="Elliptic"){
      temp.filter_object<-ellip(temp.order_object)
    }
    temp.TF_object<-freqz(temp.filter_object,Fs=sampling_rate.par)
    temp.TF<-Mod(temp.TF_object$h)^2
    temp.TF_frequencies<-temp.TF_object$f/sampling_rate.par
  }
  temp.list<-list(out.order=temp.order,
                  out.Wc=temp.Wc,
                  out.TF=temp.TF,
                  out.TF_frequencies=temp.TF_frequencies,
                  out.filter_object=temp.filter_object)
  return(temp.list)
}


Slepian_lowpass_filter.function<-function(frequencies.par,cutoff.par,N.par,sampling_rate.par=1,num_fitting_indices.par=10,output_bool.par=FALSE){
  temp.M2=length(frequencies.par)
  temp.M=2*(temp.M2-1)
  temp.passband_cutoff=cutoff.par/sampling_rate.par
  temp.passband_cutoff_index=max(1,round(temp.passband_cutoff*temp.M))
  temp.passband_cutoff_index=min(temp.M2,temp.passband_cutoff_index)
  temp.mt_dec_TF_object<-c()
  temp.mt_frequency_response<-c()
  temp.bandwidth_multiple=0
  temp.N_filter=0
  temp.stopband_edge=0
  temp.N=N.par
  temp.index_diff=-1
  temp.loop_counter=1
  while(temp.index_diff<0 & temp.N_filter<N.par & temp.loop_counter<100){
    temp.bandwidth_multiple=temp.bandwidth_multiple+1
    if(temp.passband_cutoff_index>num_fitting_indices.par){
      temp.N=ceil(num_fitting_indices.par/temp.passband_cutoff_index*N.par)
    }
    temp.NW=temp.N*temp.passband_cutoff*temp.bandwidth_multiple
    #DJT '82, pg.1076, final paragraph before Section XI:
    #"Compensate for the extremely rapid rolloff of the lower order prolate windows near W".
    temp.correction_factor=1/0.9 #"In practice, it is inadvisable to extend the expansions to |f - f_o| = W but rather to stop near 0.8 to 0.9W".
    temp.NW=temp.NW*temp.correction_factor
    temp.K=max(1,round(2*temp.NW-1))
    temp.frequencies<-frequencies.par
    temp.mt_frequency_response<-rep(0,temp.M2)
    #Use a condition to avoid an unfeasible bandwidth condition.
    if((temp.NW/temp.N)<0.5){
      temp.mt_dec_TF_object<-multitaper_decimation_filter_TF.function(temp.passband_cutoff*temp.correction_factor,sampling_rate.par,N.par,temp.M,
                                                                      num_fitting_indices.par=num_fitting_indices.par,
                                                                      bandwidth_multiple.par=temp.bandwidth_multiple)
      temp.mt_frequency_response<-temp.mt_dec_TF_object$out.frequency_response
      temp.frequencies<-temp.mt_dec_TF_object$out.frequencies
      temp.PTF_frequencies<-temp.frequencies[temp.frequencies>(temp.passband_cutoff*temp.correction_factor)]
      temp.PTF_indices<-which(temp.mt_frequency_response>median(temp.mt_frequency_response))
      temp.PTF_frequencies<-temp.PTF_frequencies[temp.PTF_indices]
      temp.stopband_edge=temp.PTF_frequencies[max(1,floor(0.05*length(temp.PTF_frequencies)))]
      temp.N_filter=temp.mt_dec_TF_object$out.N
      temp.index_diff=temp.stopband_edge-temp.passband_cutoff
    }
    temp.loop_counter=temp.loop_counter+1
  }
  temp.passband_edge=temp.mt_dec_TF_object$out.passband_cutoff_frequency
  #Basic cleaning.
  temp.TF_cleaning_object<-TF_cleaning.function(temp.mt_frequency_response,0)
  temp.mt_frequency_response<-temp.TF_cleaning_object$out.TF
  temp.nums_nn_interpolation=temp.TF_cleaning_object$out.nums_nn_interpolation
  #Compute the filter coefficients.
  temp.filter_sequence<-filter_sequence.function(temp.mt_frequency_response,N.par,normalization_bool.par=TRUE)
  if(!length(temp.passband_edge)){
    temp.passband_edge=0
    temp.stopband_edge=0
  }
  temp.Rsq_MT=temp.mt_dec_TF_object$out.Rsq
  temp.KS_percentile_MT=temp.mt_dec_TF_object$out.KS_percentile
  temp.TPT_percentile_MT=temp.mt_dec_TF_object$out.TPT_percentile
  if(output_bool.par==TRUE){
    sink(paste("Lowpass_Slepian_Filter_Statistics_",cutoff.par*sampling_rate.par,"_Hz.txt",sep=""),append=FALSE,split=FALSE)
    cat("passband_edge\tstopband_edge\n")
    cat(temp.passband_edge*sampling_rate.par,"\t",temp.stopband_edge*sampling_rate.par,"\n")
    sink(paste("Slepian_Filter_Statistics_",cutoff.par*sampling_rate.par,"_Hz.txt",sep=""), append=FALSE, split=FALSE)
    cat("Rsq\tKS_percentile\tTPT_percentile\n")
    cat(temp.Rsq_MT,"\t",temp.KS_percentile_MT,"\t",temp.TPT_percentile_MT,"\n")
    sink()
  }
  temp.list<-list(out.mt_frequency_response=temp.mt_frequency_response,
                  out.mt_frequencies=temp.frequencies,
                  out.N_filter=temp.N_filter,
                  out.stopband_edge=temp.stopband_edge,
                  out.passband_edge=temp.passband_edge,
                  out.Rsq_MT=temp.Rsq_MT,
                  out.KS_percentile_MT=temp.KS_percentile_MT,
                  out.TPT_percentile_MT=temp.TPT_percentile_MT,
                  out.nums_nn_interpolation=temp.nums_nn_interpolation,
                  out.NW=temp.NW,
                  out.K=temp.K,
                  out.filter_sequence=temp.filter_sequence,
                  out.mt_dec_TF_object=temp.mt_dec_TF_object)
  return(temp.list)
}



transfer_function.function<-function(passband_cutoffs.par,frequencies.par,
                                     stopband_max_optimal_indices.par,stopband_min_powers.par,
                                     stopband_max_powers.par,sampling_rate.par=1,N.par,M.par=0,num_fitting_indices.par=10,
                                     filter_labels.par=c("Slepian","Butterworth","Chebyshev_I","Chebyshev_II"),
                                     old_directory.par="",output_bool.par=FALSE,plot_bool.par=FALSE){
  if(!M.par){
    M.par=N.par
  }
  temp.M2=M.par/2+1
  temp.num_passbands=length(passband_cutoffs.par)
  temp.bandwidth_multiples<-rep(0,temp.num_passbands)
  temp.num_filters=length(filter_labels.par)
  temp.optimal_row_indices=stopband_max_optimal_indices.par[,1]
  temp.optimal_column_indices=stopband_max_optimal_indices.par[,2]
  temp.slepian_decimation_stats<-matrix(0,nrow=temp.num_passbands,ncol=3)
  temp.filtered_max_power_matrix<-matrix(0,nrow=temp.num_passbands,ncol=temp.num_filters)
  temp.passband_edges<-rep(0,temp.num_passbands)
  temp.stopband_edges<-temp.passband_edges
  temp.passband_ripples<-temp.passband_edges
  temp.stopband_ripples<-temp.passband_edges
  temp.filter_TF_lists<-list()
  temp.filter_object_lists<-list()
  temp.parameter_matrix_list<-list()
  temp.running_num_filters=temp.num_filters
  if(output_bool.par==TRUE){
    temp.string<-"Transfer_Function_Diagnostics"
    dir.create(temp.string,showWarnings=FALSE)
    setwd(temp.string)
  }
  for(temp.j in 1:temp.num_passbands){
    #cat(temp.j," out of ",temp.num_passbands,", transfer_function.function\n")
    temp.jth_row_index=temp.optimal_row_indices[temp.j]
    temp.jth_column_index=temp.optimal_column_indices[temp.j]
    temp.matrix_list<-list()
    #Start with the Slepian filters.
    temp.passband_cutoff=passband_cutoffs.par[temp.j]/sampling_rate.par
    temp.passband_cutoff_index=temp.passband_cutoff*M.par
    temp.mt_dec_TF_object<-c()
    temp.mt_frequency_response<-c()
    temp.PTF<-0
    temp.half_max_index=0
    temp.N_filter=0
    temp.stopband_edge=0
    temp.N=N.par
    temp.index_diff=-1
    temp.loop_counter=1
    while(temp.index_diff<0 & temp.N_filter<N.par & temp.loop_counter<100){
      temp.bandwidth_multiple=temp.bandwidth_multiples[temp.j]+1
      if(temp.passband_cutoff_index>num_fitting_indices.par){
        temp.N=ceil(num_fitting_indices.par/temp.passband_cutoff_index*N.par)
      }
      temp.NW=temp.N*temp.passband_cutoff*temp.bandwidth_multiple
      cat("temp.NW = ",temp.NW,"\n")
      #DJT '82, pg.1076, final paragraph before Section XI:
      #"Compensate for the extremely rapid rolloff of the lower order prolate windows near W".
      temp.correction_factor=1/0.9 #"In practice, it is unadvisable to extend the expansions to |f - f_ol = W but rather to stop near 0.8 to 0.9W".
      temp.NW=temp.NW*temp.correction_factor
      temp.K=max(1,round(2*temp.NW-1))
      temp.frequencies<-frequencies.par
      temp.mt_frequency_response<-rep(0,temp.M2)
      #Use a condition to avoid an unfeasible bandwidth condition.
      if((temp.NW/temp.N)<0.5){
        temp.mt_dec_TF_object<-multitaper_decimation_filter_TF.function(temp.passband_cutoff*temp.correction_factor,sampling_rate.par,N.par,M.par,
                                                                        num_fitting_indices.par=num_fitting_indices.par,
                                                                        bandwidth_multiple.par=temp.bandwidth_multiple)
        temp.mt_frequency_response<-temp.mt_dec_TF_object$out.frequency_response
        temp.PTF<-temp.mt_frequency_response
        temp.frequencies<-temp.mt_dec_TF_object$out.frequencies
        temp.PTF_frequencies<-temp.frequencies[temp.frequencies>(temp.passband_cutoff*temp.correction_factor)]
        temp.PTF_indices<-which(temp.PTF>median(temp.PTF))
        temp.PTF_frequencies<-temp.PTF_frequencies[temp.PTF_indices]
        temp.stopband_edge=temp.PTF_frequencies[max(1,floor(0.05*length(temp.PTF_frequencies)))]
        temp.N_filter=temp.mt_dec_TF_object$out.N
        temp.index_diff=temp.stopband_edge-temp.passband_cutoff
      }
      temp.loop_counter=temp.loop_counter+1
    }
    temp.parameter_matrix<-matrix(0,nrow=temp.num_filters,ncol=2)
    temp.passband_edge=temp.mt_dec_TF_object$out.passband_cutoff_frequency
    if(length(temp.passband_edge)>0){
      temp.passband_edges[temp.j]=temp.passband_edge*sampling_rate.par
      temp.stopband_edges[temp.j]=temp.stopband_edge*sampling_rate.par
    }
    else{
      temp.passband_edge=0
      temp.stopband_edge=0
    }
    temp.parameter_matrix[1,]<-c(temp.N_filter,temp.passband_cutoff)
    temp.Rsq_MT=temp.mt_dec_TF_object$out.Rsq
    temp.KS_percentile_MT=temp.mt_dec_TF_object$out.KS_percentile
    temp.TPT_percentile_MT=temp.mt_dec_TF_object$out.TPT_percentile
    temp.TF_matrix<-matrix(0,nrow=length(temp.frequencies),ncol=2)
    temp.TF_matrix[,1]<-temp.frequencies
    temp.TF_matrix[,2]<-temp.mt_frequency_response
    temp.matrix_list[[1]]<-temp.TF_matrix
    #For the other filters, determine the passband and stopband edges using the width at half max.
    temp.passband_reconstruction<-temp.mt_frequency_response[1:num_fitting_indices.par]
    #Allow the most flexibility for the passband ripple since the Butterworth filter optimizes this parameter.
    temp.PB_ripple_indices<-which(temp.frequencies<=temp.passband_cutoff)
    if(length(temp.PB_ripple_indices)==1){
      temp.PB_ripple_indices<-1:2
    }
    temp.PB_PTF<-temp.PTF[temp.PB_ripple_indices]
    if(length(temp.PB_PTF)>0){
      temp.passband_ripples[temp.j]=10*log10((max(sqrt(temp.PB_PTF))-min(sqrt(temp.PB_PTF)))/2)
    }
    temp.passband_ripple_height=abs(temp.passband_ripples[temp.j])
    #The stopband ripple height is small enough that the maximum stopband power with filtering is equal to the minimum stopband power without filtering.
    temp.stopband_ripples[temp.j]=10*log10(sqrt(Mod(stopband_min_powers.par[temp.j])/Mod(stopband_max_powers.par[temp.j])))
    temp.stopband_ripple_height=abs(temp.stopband_ripples[temp.j])
    if(output_bool.par==TRUE){
      sink(paste("Lowpass_Filter_Statistics_",passband_cutoffs.par[temp.j],"_Hz.txt",sep=""), append=FALSE, split=FALSE)
      cat("Rsq\tKS_percentile\tTPT_percentile\n")
      cat(temp.Rsq_MT,"\t",temp.KS_percentile_MT,"\t",temp.TPT_percentile_MT,"\n")
    }
    temp.TF_frequency_list<-list()
    temp.TF_values_list<-list()
    temp.TF_frequency_list[[1]]<-temp.frequencies*sampling_rate.par
    temp.TF_values_list[[1]]<-temp.mt_frequency_response
    temp.nums_nn_interpolation<-rep(0,temp.num_filters)
    if(output_bool.par==TRUE){
      cat("passband_edge\tstopband_edge\tpassband_ripple_height\tstopband_ripple_height\n")
      cat(temp.passband_edge*sampling_rate.par,"\t",temp.stopband_edge*sampling_rate.par,"\t",temp.passband_ripple_height,"\t",
          temp.stopband_ripple_height,"\n")
    }
    temp.filter_object_list<-list()
    temp.filter_object_list[[1]]<-0
    temp.counter1=1
    for(temp.l in 1:(temp.num_filters-1)){
      temp.filter_label<-filter_labels.par[temp.l+1]
      temp.established_filter_object<-established_decimation_filter.function(passband_edge.par=2*temp.passband_edge,
                                                                             stopband_edge.par=2*temp.stopband_edge,
                                                                             passband_ripple_height.par=temp.passband_ripple_height,
                                                                             stopband_ripple_height.par=temp.stopband_ripple_height,
                                                                             sampling_rate.par=sampling_rate.par,filter_type.par=temp.filter_label)
      temp.parameter_matrix[temp.l+1,]<-c(temp.established_filter_object$out.order,temp.established_filter_object$out.Wc)
      temp.TF<-temp.established_filter_object$out.TF
      temp.filter_object<-temp.established_filter_object$out.filter_object
      temp.filter_order=temp.established_filter_object$out.order
      temp.filter_object_list[[temp.l+1]]<-temp.filter_object
      #Modify here
      temp.TF_cleaning_object<-TF_cleaning.function(temp.TF,0)
      temp.TF<-temp.TF_cleaning_object$out.TF
      temp.nums_nn_interpolation[temp.l]=temp.TF_cleaning_object$out.nums_nn_interpolation
      temp.TF_frequencies<-temp.established_filter_object$out.TF_frequencies
      temp.TF_size=length(temp.TF)
      temp.TF_frequency_list[[temp.counter1+1]]<-temp.TF_frequencies*sampling_rate.par
      temp.TF_values_list[[temp.counter1+1]]<-temp.TF
      temp.TF_matrix<-matrix(0,nrow=length(temp.TF_frequencies),ncol=2)
      temp.TF_matrix[,1]<-temp.TF_frequencies
      temp.TF_matrix[,2]<-temp.TF
      temp.matrix_list[[temp.counter1+1]]<-temp.TF_matrix
      temp.counter1=temp.counter1+1
    }
    temp.fitting_frequencies_list<-list()
    temp.fitting_PTF_values_list<-list()
    temp.decay_rates<-rep(0,temp.num_filters)
    temp.ise_values<-temp.decay_rates
    if(output_bool.par==TRUE){
      cat("filter_type\torder\tcutoff\tdecay_rate\tRsq\tKS_percentile\tTPT_percentile\tpeak_frequency\tpeak_height\trow_frequency\t
  column_frequency\tfiltered_power\n")
    }
    for(temp.l in 1:temp.num_filters){
      #Determine how well the PTF attenuates the maximum attenuation in the stopband.
      temp.filter_label<-filter_labels.par[temp.l]
      temp.TF_matrix<-temp.matrix_list[[temp.l]]
      temp.TF_frequencies<-Re(temp.TF_matrix[,1])
      temp.TF_values<-temp.TF_matrix[,2]
      temp.optimal_max_stopband_row_index=max(which(temp.TF_frequencies<=frequencies.par[stopband_max_optimal_indices.par[1]]))
      temp.optimal_max_stopband_column_index=max(which(temp.TF_frequencies<=frequencies.par[stopband_max_optimal_indices.par[2]]))
      temp.filtered_max_power_matrix[temp.j,temp.l]=Mod(temp.TF_values[temp.optimal_max_stopband_row_index]*
                                                          Conj(temp.TF_values[temp.optimal_max_stopband_column_index])*stopband_max_powers.par[temp.j])
      #Determine the decay rate and principal-sidelobe characteristics.
      temp.decay_rate=0
      temp.Rsq=0
      temp.KS_percentile=0
      temp.TPT_percentile=0
      temp.peak_sidelobe_frequency=0
      temp.peak_sidelobe_PTF_value=0
      temp.cutoff_value=0
      temp.optimal_row_frequency=0
      temp.optimal_column_frequency=0
      temp.index1=0
      temp.index2=0
      temp.frequency1=0
      temp.frequency2=0
      temp.filtered_max_stopband_power=0
      if(length(temp.TF_frequencies[temp.TF_frequencies>0])>0){
        temp.decimation_filter_object<-decimation_filter_diagnostics.function(temp.TF_frequencies,temp.TF_values,temp.passband_cutoff,sampling_rate.par)
        temp.decay_rate=temp.decimation_filter_object$out.decay_rate
        temp.decay_rates[temp.l]=temp.decay_rate
        temp.Rsq=temp.decimation_filter_object$out.Rsq
        temp.KS_percentile=temp.decimation_filter_object$out.KS_percentile
        temp.TPT_percentile=temp.decimation_filter_object$out.TPT_percentile
        temp.peak_sidelobe_frequency=temp.decimation_filter_object$out.peak_sidelobe_frequency
        temp.peak_sidelobe_PTF_value=temp.decimation_filter_object$out.maximum
        temp.cutoff_value=temp.parameter_matrix[temp.l,2]*sampling_rate.par
        if(temp.l>1){
          temp.cutoff_value=temp.cutoff_value/2
        }
        temp.ise_values[temp.l]=temp.decimation_filter_object$out.ise
        #Filtered stopband mod bifrequency density.
        temp.optimal_row_frequency=temp.frequencies[temp.jth_row_index]
        temp.optimal_column_frequency=temp.frequencies[temp.jth_column_index]
        temp.index1=max(which(temp.frequencies<=temp.optimal_row_frequency))
        temp.index2=max(which(temp.frequencies<=temp.optimal_column_frequency))
        temp.frequency1=temp.frequencies[temp.index1]*sampling_rate.par
        temp.frequency2=temp.frequencies[temp.index2]*sampling_rate.par
        temp.filtered_max_stopband_power=Mod(temp.TF_values[temp.index1])*Mod(temp.TF_values[temp.index2])*100
      }
      temp.fitting_frequencies_list[[temp.l]]<-temp.decimation_filter_object$out.log_frequencies+10*log10(sampling_rate.par)
      temp.fitted_values<-temp.decimation_filter_object$out.fitted_values
      temp.fitted_values[is.na(temp.fitted_values)==TRUE]<-0
      temp.fitted_values[is.nan(temp.fitted_values)==TRUE]<-0
      temp.fitted_values[is.infinite(temp.fitted_values)==TRUE]<-0
      temp.fitting_PTF_values_list[[temp.l]]<-temp.fitted_values
      if(output_bool.par==TRUE){
        cat(temp.filter_label,"\t",temp.parameter_matrix[temp.l,1],"\t",temp.cutoff_value,"\t",temp.decay_rate,"\t",temp.Rsq,
            "\t",temp.KS_percentile,"\t",temp.TPT_percentile,"\t",temp.peak_sidelobe_frequency,"\t",temp.peak_sidelobe_PTF_value,
            "\t",temp.frequency1,"\t",temp.frequency2,"\t",temp.filtered_max_stopband_power,"\n")
      }
    }
    if(output_bool.par==TRUE){
      sink()
    }
    temp.filter_TF_lists[[temp.j]]<-temp.matrix_list
    temp.filter_object_lists[[temp.j]]<-temp.filter_object_list
    temp.parameter_matrix_list[[temp.j]]<-temp.parameter_matrix
    if(plot_bool.par==TRUE){
      #Plot the PTF's.
      temp.cutoff_value=temp.parameter_matrix[temp.l,2]*sampling_rate.par
      if(temp.running_num_filters>1){
        temp.cutoff_value[2:temp.running_num_filters]=temp.cutoff_value/2
      }
      temp.PB_edge=temp.passband_edge*sampling_rate.par
      temp.SB_edge=temp.stopband_edge*sampling_rate.par
      temp.x_label<-"Frequency, in hertz"
      temp.y_label<-"Gain"
      multipage_plot_filter.function(temp.TF_frequency_list,temp.TF_values_list,x_label.par=temp.x_label,y_label.par=temp.y_label,
                                     title_strings.par=filter_labels.par,nominal_passband_frequency.par=passband_cutoffs.par[temp.j],
                                     passband_frequency.par=temp.cutoff_value,passband_edge.par=temp.PB_edge,
                                     stopband_edge.par=temp.SB_edge,fitting_log_frequencies.par=temp.fitting_frequencies_list,
                                     fitted_log_PTF_values.par=temp.fitting_PTF_values_list,filter_order.par=temp.parameter_matrix[,1],
                                     pdf_title.par=paste("Gain_Spectra_",passband_cutoffs.par[temp.j],"_Hz.pdf",sep=""),
                                     nums_nn_interpolation.par=temp.nums_nn_interpolation,decay_rates.par=temp.decay_rates,ise.par=temp.ise_values,
                                     include_reconstruction_numbers.par=TRUE)
    }
  }
  if(output_bool.par==TRUE){
    setwd(old_directory.par)
  }
  temp.list<-list(out.filter_TF_lists=temp.filter_TF_lists,
                  out.slepian_decimation_stats=temp.slepian_decimation_stats,
                  out.filtered_max_power_matrix=temp.filtered_max_power_matrix,
                  out.passband_edges=temp.passband_edges,
                  out.stopband_edges=temp.stopband_edges,
                  out.passband_ripples=temp.passband_ripples,
                  out.stopband_ripples=temp.stopband_ripples,
                  out.filter_object_lists=temp.filter_object_lists,
                  out.parameter_matrix_list=temp.parameter_matrix_list,
                  out.NW=temp.NW)
  return(temp.list)
}



IIR_direct_form_II_filtering.function<-function(b.par,a.par,ts.par,z_initial.par=NA){
  #Based on descriptions from the following website, and also from the one listed further below.
  #https://www.mathworks.com/help/matlab/ref/filter.html#bt_vs4t-1-zi
  #z is a reconstruction of the nonlinear part of the signal associated with ts.par
  #z_initial.par corresponds to the initial values of v in the latent signal given in the following reference.
  #https://ccrma.stanford.edu/~jos/filters/Direct_Form_II.html
  temp.N=length(ts.par)
  temp.AR_filter_size=length(a.par)
  temp.MA_filter_size=length(b.par)
  temp.num_z=max(temp.AR_filter_size,temp.MA_filter_size)-1
  if(is.na(z_initial.par)==TRUE){
    z_initial.par<-rep(0,temp.num_z)
  }
  temp.response_vector<-rep(0,temp.N)
  #Initialize the running latent vector.
  temp.running_z_vector<-z_initial.par
  for(temp.n in (temp.AR_filter_size+1):temp.N){
    temp.z_n=ts.par[temp.n]
    if(temp.AR_filter_size==1){
      temp.z_n=temp.z_n/a.par
    }
    else{
      temp.linear_term=sum(a.par[2:temp.AR_filter_size]*rev(temp.running_z_vector[temp.n-1:(temp.AR_filter_size-1)]))
      temp.z_n=ts.par[temp.n]-temp.linear_term
    }
    #Now, update the filter-response signal.
    temp.response_vector[temp.n]=b.par[1]*temp.z_n+sum(b.par[2:temp.AR_filter_size]*rev(temp.running_z_vector[temp.n-1:(temp.AR_filter_size-1)]))
    #Update the running latent vector for the next time index.
    temp.running_z_vector<-c(temp.running_z_vector[2:temp.num_z],temp.z_n)
  }
  temp.list<-list(out.response_vector=temp.response_vector,
                  out.z_final=temp.running_z_vector)
  return(temp.list)
}


filt_filt_normalization.function<-function(filter.par){
  #Normalize the filter to ensure that it has unit energy.
  temp.cleaned_ts<-TF_cleaning.function(filter.par,0)$out.TF
  temp.normalized_filter<-filter.par/sum(temp.cleaned_ts)
  temp.normalized_filter<-TF_cleaning.function(temp.normalized_filter,0)$out.TF
  return(temp.normalized_filter)
}


filter_sequence.function<-function(TF.par,N.par,normalization_bool.par=FALSE){
  #Normalize the time series to ensure that it has unit energy.
  temp.M2=length(TF.par)
  temp.M=2*(temp.M2-1)
  temp.TF_full<-c(TF.par,rev(TF.par[2:temp.M2]))
  temp.inverse_fft<-Re(fft(temp.TF_full,inverse=TRUE))/temp.M
  #If the filter is too long, then cut off the ends of the filter, which themselves are near to zero.
  if((3*temp.M)>N.par & N.par>100){
    temp.M=ceil(N.par/100)
    temp.M2=temp.M/2+1
  }
  temp.filter_sequence<-c(rev(temp.inverse_fft[2:temp.M2]),temp.inverse_fft[1:temp.M2])
  if(normalization_bool.par==TRUE){
    temp.filter_sequence<-filt_filt_normalization.function(temp.filter_sequence)
  }
  return(temp.filter_sequence)
}


matlab_validateinput.function<-function(x.par,r.par){
  #Validate 1st two input args: signal and decimation factor
  if(!length(x.par) || !length(which(x.par!=0))){
    stop("Invalid input, X.\n")
  }
  if(r.par<=0){
    stop("Invalid input, R.\n")
  }
}

matlab_filtmag_db.function<-function(b.par,a.par,f.par){
  #From decimate.m
  #FILTMAG_DB Find filter's magnitude response in decibels at given frequency.
  temp.nb=length(b.par)
  temp.na=length(a.par)
  temp.numerator<-exp(-1i*(1:temp.nb-1)*pi*f.par)*b.par
  temp.denominator<-exp(-1i*(1:temp.na-1)*pi*f.par)*a.par
  temp.H=20*log10(Mod(temp.numerator/temp.denominator))
  return(temp.H)
  
}

matlab_mirror_filter.function<-function(idata.par,nfilt.par,b.par,nd.par,pass_string.par){
  #Prepend sequence with mirror image of first points so that transients
  #can be eliminated.  Then do same thing at right end of data sequence.
  nfilt.par=nfilt.par+1
  #Mirror image of the first points.
  temp.mirrored_idata<-2*idata.par[1]-rev(idata.par[2:(nfilt.par+1)])
  temp.num_transient=length(temp.mirrored_idata)
  temp.idata<-c(temp.mirrored_idata,idata.par)
  #Construct a filter object using the parameter vectors, b.par (MA coefficients) and {1} (AR(1)).
  #temp.odata<-filter(b.par,1,temp.idata,pass_string.par)
  temp.IIR_object<-IIR_direct_form_II_filtering.function(b.par,1,temp.idata)
  temp.idata<-temp.IIR_object$out.response_vector
  temp.zi<-temp.IIR_object$out.z_final
  temp.IIR_object<-IIR_direct_form_II_filtering.function(b.par,1,temp.idata,temp.zi)
  temp.odata<-temp.IIR_object$out.response_vector
  temp.zf<-temp.IIR_object<-out.z_final
  #Retain only the non-transient filtered data.
  temp.idata=rep(0,2*nfilt.par)
  temp.idata<-2*idata.par[nd.par]-rev(idata.par[(nd.par-2*nfilt.par):(nd.par-1)])
  #temp.idata<-filter(b.par,1,temp.idata)
  temp.IIR_object<-IIR_direct_form_II_filtering.function(b.par,1,temp.idata,temp.zf)
  temp.idata<-temp.IIR_object$out.response_vector
  #Finally, select only every r'th point from the interior of the lowpass filtered sequence.
  temp.gd_object<-grpdelay(b.par,a=1,n=8)
  temp.group_delay=temp.gd_object$gd
  temp.index_sequence<-seq(from=round(temp.group_delay+1.25),to=nd.par,by=r.par)
  temp.odata<-temp.odata[temp.index_sequence]
  temp.lod=length(temp.odata)
  temp.nlen=temp.nout-temp.lod
  temp.nbeg=r.par-(nd.par-temp.index_sequence[length(temp.index_sequence)])
  temp.odata<-c(temp.odata,temp.idata[seq(from=temp.nbeg,to=temp.nbeg+temp.nlen*r.par-1,by=r.par)])
  return(temp.odata)
}


kramer_filtfilt.function<-function(filter_object.par,ts.par,first_frequency.par,last_frequency.par,sampling_frequency.par){
  temp.N=length(ts.par)
  temp.ts1<-filter(filter_object.par,ts.par)
  temp.cosine_sequence<-c()
  #Forward pass.
  if(first_frequency.par>0){
    temp.cosine_sequence<-2*cos(pi*(first_frequency.par+last_frequency.par)/sampling_frequency.par*(1:temp.N-1))
    temp.ts1<-temp.ts1*temp.cosine_sequence
  }
  #if(FALSE){
  temp.ts1<-rev(temp.ts1)
  #Reverse pass.
  temp.ts2<-filter(filter_object.par,temp.ts1)
  if(first_frequency.par>0){
    temp.ts2<-temp.ts2*temp.cosine_sequence
  }
  temp.ts2<-rev(temp.ts2)
  #}#endif
  return(temp.ts2)
}


matlab_decimate.function<-function(idata.par,r.par,nfilt.par=NA,option.par=NA,pass_string.par="low"){
  #cat("r.par = ",r.par,"\n")
  #From Matlab decimate.m, but without some of the error-handling code because here a lot of the code is not user-specified in the application of interest.
  #idata.par the input data.
  #R.par the factor by which to downsample.
  #nfilt.par the filter type ('f' or 'F' for FIR, and 'i' or 'I' for IIR), or alternatively a specification of whether the filter is FIR or IIR.
  
  #The following comments are from decimate.m
  #DECIMATE Resample data at a lower rate after lowpass filtering.
  #   Y = DECIMATE(X,R) resamples the sequence in vector X at 1/R times the
  #   original sample rate.  The resulting resampled vector Y is R times
  #   shorter, i.e., LENGTH(Y) = CEIL(LENGTH(X)/R). By default, DECIMATE
  #   filters the data with an 8th order Chebyshev Type I lowpass filter with
  #   cutoff frequency .8*(Fs/2)/R, before resampling.
  #
  #   Y = DECIMATE(X,R,N) uses an N'th order Chebyshev filter.  For N greater
  #   than 13, DECIMATE will produce a warning regarding the unreliability of
  #   the results.  See NOTE below.
  #
  #   Y = DECIMATE(X,R,'FIR') uses a 30th order FIR filter generated by
  #   FIR1(30,1/R) to filter the data.
  #
  #   Y = DECIMATE(X,R,N,'FIR') uses an Nth FIR filter.
  #
  #   Note: For better results when R is large (i.e., R > 13), it is
  #   recommended to break R up into its factors and calling DECIMATE several
  #   times.
  #
  #   EXAMPLE: Decimate a signal by a factor of four
  #   t = 0:.00025:1;  # Time vector
  #   x = sin(2*pi*30*t) + sin(2*pi*60*t);
  #   y = decimate(x,4);
  #   subplot(1,2,1);
  #   stem(x(1:120)), axis([0 120 -2 2])   # Original signal
  #   title('Original Signal')
  #   subplot(1,2,2);
  #   stem(y(1:30))                        # Decimated signal
  #   title('Decimated Signal')
  #
  #   See also DOWNSAMPLE, INTERP, RESAMPLE, FILTFILT, FIR1, CHEBY1.
  #   Author(s): L. Shure, 6-4-87
  #              L. Shure, 12-11-88, revised
  #   Copyright 1988-2010 The MathWorks, Inc.
  #   References:
  #    [1] "Programs for Digital Signal Processing", IEEE Press
  #         John Wiley & Sons, 1979, Chap. 8.3.
  #Validate required inputs.
  matlab_validateinput.function(idata.par,r.par);
  temp.filter_object<-c()
  temp.odata<-c()
  if(floor(r.par)==1){
    temp.odata=idata.par;
  }
  temp.fopt=1;
  #The default filter has order 8.
  if(is.na(nfilt.par)==TRUE & is.na(option.par)==TRUE){
    nfilt.par=8
    temp.filter_type_string<-"Chebyshev Type I"
  }
  else{
    if(is.character(nfilt.par)==TRUE){
      #Initialize the parameter determining the type of filter to be used (0 for FIR, 1 for IIR).
      if(nfilt.par[1]=='f' || nfilt.par[1]=='F'){
        temp.fopt=0
        temp.filter_type_string<-"FIR"
      }
      else if(nfilt.par[1]=='i' || nfilt.par[1]=='I'){
        temp.fopt=1
        temp.filter_type_string<-"Chebyshev Type I"
      }
      else{
        stop("Error: Invalid ennumeration.\n")
      }
      #When the option parameter (an integer)) for the filter order is specified, set the filter order to this option.
      if(!is.na(option.par)){
        nfilt.par=option.par
      }
      else{
        #Choose a 30th-order FIR filter if temp.fopt=0 and an 8'th-order IIR filter if temp.fopt=1.
        nfilt.par=8*temp.fopt+30*(1-temp.fopt)
      }
    }
    else{
      if(!is.na(nfilt.par) & !is.na(option.par)){
        if(option.par[1]=='f' || option.par[1]=='F'){
          temp.fopt=0
        }
        else if(option.par[1] == 'i' || option.par[1] == 'I'){
          temp.fopt=1
        }
      }
      else{
        stop("Error: Invalide enumeration.\n")
      }
    }
  }
  #cat("nfilt.par = ",nfilt.par,"\n")
  #temp.nd is the dimension of the input data vector.
  temp.nd=length(idata.par)
  temp.nout=ceil(temp.nd/r.par)
  temp.filter_specification_string<-""
  temp.bandwidth_parameter<-""
  if(!temp.fopt){
    #FIR filter.
    #Construct a filter function containing the MA coefficients.
    temp.b<-fir1(nfilt.par,1/r.par,pass_string.par)
    temp.filter_object<-temp.b
    temp.filter_specification_string<-paste("FIR",nfilt.par,sep="")
    temp.bandwidth_parameter=1/r.par
  }
  else{
    #IIR filter
    temp.rip=0.05	# passband ripple in dB
    temp.cheby1_object<-cheby1(nfilt.par,temp.rip,0.8/r.par,pass_string.par)
    temp.a<-temp.cheby1_object$a
    temp.b<-temp.cheby1_object$b
    temp.num_b=length(temp.b)
    temp.H=matlab_filtmag_db.function(temp.b,temp.a,0.8/r.par)
    while((length(which(temp.b==0))==temp.num_b || (abs(temp.H+temp.rip)>1e-6)) & nfilt.par>1){
      nfilt.par=nfilt.par-1
      if(!nfilt.par){
        break
      }
      temp.cheby1_object<-cheby1(nfilt.par,temp.rip,0.8/r.par,pass_string.par)
      temp.a<-temp.cheby1_object$a
      temp.b<-temp.cheby1_object$b
    }
    if(!nfilt.par){
      stop("Error: Invalid range.\n")
    }
    temp.filter_object<-temp.cheby1_object
    temp.filter_specification_string<-paste("Cheby",nfilt.par,sep="")
    temp.bandwidth_parameter=0.8/r.par
  }
  temp.filter_type_string<-paste(temp.filter_type_string,", order = ",nfilt.par,sep="")
  if(temp.fopt==1 && nfilt.par>13){
    warning("For filter orders greater than 13, DECIMATE will produce unreliable results.\n")
    temp.filter_type_string<-paste(temp.filter_type_string,", unreliable results in Matlab 'decimate' function",sep="")
  }
  temp.list<-list(out.filter_object=temp.filter_object,
                  out.filter_type_string=temp.filter_type_string,
                  out.filter_specification_string=temp.filter_specification_string,
                  out.bandwidth_parameter=temp.bandwidth_parameter)
  return(temp.list)
}


#Inverse FFT to obtain the filter from a given transfer function.
decimation.function<-function(ts.par,filter.par,first_frequency.par,last_frequency.par,old_sampling_rate.par=1,new_sampling_rate.par=1,times.par=NA,
                              sequence_bool.par=FALSE,string.par=""){
  temp.filter_size=0
  temp.filter_energy=1
  if(sequence_bool.par==TRUE){
    temp.filter_size=max(1,length(filter.par))
    temp.filter_energy=crossprod(filter.par)
  }
  temp.N=length(ts.par)
  #Set the step size to be the minimum value such that information from the pass band is retrieved.
  temp.new_step_size=floor(old_sampling_rate.par/new_sampling_rate.par)
  #If the new step size leads to the number of samples being below min.record_size, then the spectral analysis will yield low-resolution results which contain
  #less information than is available from the filtered data because N is small.  So keep N>=min.record_size
  temp.N=length(ts.par)
  temp.num_steps_decimated=(temp.N-temp.N%%temp.new_step_size)/temp.new_step_size
  if(temp.num_steps_decimated<min.record_size){
    temp.new_step_size=max(floor(old_sampling_rate.par/new_sampling_rate.par*temp.num_steps_decimated/min.record_size),1)
  }
  temp.indices<-1:temp.N
  temp.decimated_ts<-rep(0,temp.N)
  if(first_frequency.par>0){
    temp.cosine_sequence<-2*cos(pi*(first_frequency.par+last_frequency.par)/old_sampling_rate.par*(1:temp.filter_size-1))
    filter.par<-filter.par*temp.cosine_sequence
    #Only output the normalized filter sequence if it requires normalization.
    #i.e., no problem with the denominator sum being too small in magnitude (means that the current normalization should be sufficient compared with
    #normalizing the filter one time too many and resulting in a worse filter-output reconstruction).
    temp.trial_filter<-filt_filt_normalization.function(filter.par)
    temp.filter_object<-filter.function(ts.par,temp.trial_filter,times.par=times.par,step_size.par=temp.new_step_size)
    temp.trial_filtered_ts<-temp.filter_object$out.filtered_ts
    if(max(abs(temp.trial_filtered_ts))<(5*max(abs(ts.par)))){
      filter.par<-temp.trial_filter
      string.par<-paste(string.par,", 2nd normalization",sep="")
    }
  }
  temp.filter_object<-filter.function(ts.par,filter.par,times.par=times.par,step_size.par=temp.new_step_size)
  temp.decimated_ts<-temp.filter_object$out.filtered_ts
  temp.indices<-temp.filter_object$out.indices
  temp.indices2<-seq(from=1,to=length(temp.indices),by=temp.new_step_size)
  temp.decimated_ts<-temp.decimated_ts[temp.indices2]
  temp.list<-list(out.decimated_ts=temp.decimated_ts)
  temp.times<-c()
  if(!is.na(times.par)){
    temp.times<-times.par[temp.indices]
    temp.times<-temp.times[temp.indices2]
    temp.list<-list(out.decimated_ts=temp.decimated_ts,
                    out.times=temp.times,
                    out.indices=temp.indices,
                    output.string=string.par)
  }
  return(temp.list)
}


implement_Cheby1.function<-function(ts.par,cutoff.par,sampling_rate.par){
  temp.string<-"low"
  temp.q=sampling_rate.par/(2*cutoff.par)
  #Replicating the same filter used in the R function called "decimate".  This is the same filter used in the code for Martinet et al. (2017).
  #Seizure-Waves/modeling/run_seizing_cortical_field.m
  #https://github.com/Mark-Kramer/Seizure-Waves/blob/master/modeling/run_seizing_cortical_field.m
  #IIR filter
  temp.rip=0.05	# passband ripple in dB
  temp.cheby1_object<-cheby1(nfilt.par,temp.rip,0.8/r.par,pass_string.par)
  temp.a<-temp.cheby1_object$a
  temp.b<-temp.cheby1_object$b
  temp.num_b=length(temp.b)
  temp.H=matlab_filtmag_db.function(temp.b,temp.a,0.8/r.par)
  while((length(which(temp.b==0))==temp.num_b || (abs(temp.H+temp.rip)>1e-6)) & nfilt.par>1){
    nfilt.par=nfilt.par-1
    if(!nfilt.par){
      break
    }
    temp.cheby1_object<-cheby1(nfilt.par,temp.rip,0.8/r.par,pass_string.par)
    temp.a<-temp.cheby1_object$a
    temp.b<-temp.cheby1_object$b
  }
  if(!nfilt.par){
    stop("Error: Invalid range.\n")
  }
  temp.filter_object<-temp.cheby1_object
  
}


bandpass_filter.function<-function(times.par,ts.par,passband.par,harmonic_reconstructions.par=NA,significant_frequencies.par=NA,
                                   harmonic_reconstruction_indices.par=NA,
                                   filter.par=NA,filter_object_list.par=NA,parameter_matrix_list.par=NA,
                                   sampling_rate.par=1,new_sampling_rate.par=1,passband_cutoffs.par=passband.cutoffs,
                                   bandpass_specification.par="Marshall",original_sampling_bool.par=FALSE,filter_type_thresholds.par=c(50,1e3),
                                   min_record_size.par=1e3,invert_bool.par=FALSE){
  if(bandpass_specification.par!="Marshall"){
    filter.par=NA
  }
  temp.filter_specification_string<-""
  temp.num_cutoffs_parameter=length(passband_cutoffs.par)
  temp.N=length(ts.par)
  temp.first_frequency=passband.par[1]
  temp.last_frequency=passband.par[2]
  temp.TF<-c()
  temp.TF_frequencies<-c()
  if(length(harmonic_reconstructions.par)>0){
    if(!is.na(harmonic_reconstructions.par)){
      #Subtract out the harmonic elements.
      temp.num_sections<-length(harmonic_reconstructions.par)
      for(temp.i in 1:temp.num_sections){
        temp.indices<-harmonic_reconstruction_indices.par[[temp.i]]
        temp.significant_frequencies<-significant_frequencies.par[[temp.i]]
        temp.harmonic_reconstructions<-harmonic_reconstructions.par[[temp.i]]
        temp.num_significant=1
        if(is.matrix(temp.harmonic_reconstructions)==TRUE){
          temp.num_significant=ncol(temp.harmonic_reconstructions)
        }
        for(temp.j in 1:temp.num_significant){
          temp.significant_frequency=temp.significant_frequencies[temp.j]
          if(temp.significant_frequency<temp.first_frequency || temp.significant_frequency>temp.last_frequency){
            if(is.matrix(temp.harmonic_reconstructions)==TRUE){
              ts.par[temp.indices]<-ts.par[temp.indices]-temp.harmonic_reconstructions[,temp.j]
            }
            else{
              ts.par[temp.indices]<-ts.par[temp.indices]-temp.harmonic_reconstructions
            }
          }
        }
      }
    }
  }
  temp.cutoff=temp.last_frequency-temp.first_frequency
  if(temp.first_frequency>0){
    temp.cutoff=temp.cutoff/2
  }
  temp.new_sampling_rate=0
  temp.index1=0
  temp.num_indices1=0
  temp.min_index1=0
  temp.max_index1=0
  temp.new_sampling_rate0=0
  temp.bandwidth_parameter=0
  temp.indices1<-c()
  temp.decimated_series_times<-c()
  temp.decimated_series<-c()
  temp.filter_type_string<-""
  temp.filter_sequence1=0
  if(temp.last_frequency==(sampling_rate.par/2)){
    temp.new_sampling_rate=sampling_rate.par
  }
  if(!temp.first_frequency & temp.last_frequency==(sampling_rate.par/2)){
    temp.decimated_series_times<-times.par
    temp.decimated_series<-ts.par
    temp.indices1<-1:temp.N
    temp.num_indices1=length(temp.indices1)
    temp.min_index1=min(temp.indices1)
    temp.max_index1=max(temp.indices1)
  }
  else{
    temp.first_band_frequencies<-c(0,passband_cutoffs.par)
    temp.last_band_frequencies<-c(passband_cutoffs.par,sampling_rate.par/2)
    temp.index1=0
    for(temp.i in 1:(temp.num_cutoffs_parameter+1)){
      if(temp.cutoff>temp.first_band_frequencies[temp.i] & temp.cutoff<=temp.last_band_frequencies[temp.i]){
        temp.index1=which(passband_cutoffs.par==temp.last_band_frequencies[temp.i])
      }
    }
    temp.filter_sequence1<-c()
    temp.filter_sequence_bandpass<-c()
    temp.filter_object<-c()
    temp.filter_object1<-c()
    temp.filter_object2<-c()
    temp.butterworth_parameter_matrix=0
    if(!is.na(filter.par)){
      if(length(temp.index1)>0){
        if(temp.index1>0 & temp.index1<=length(filter_object_list.par)){
          temp.filter_sequence1<-filter.par[[temp.index1]]
          temp.filter_object<-filter_object_list.par[[temp.index1]]
          temp.butterworth_parameter_matrix<-parameter_matrix_list.par[[temp.index1]]
        }
        else{
          temp.filter_sequence1=0
        }
      }
      else{
        temp.filter_sequence1=0
      }
    }
    else if(bandpass_specification.par!="Marshall"){
      #Integer factor to downsample by.
      temp.string<-"low"
      temp.q=sampling_rate.par/(2*temp.cutoff)
      if(bandpass_specification.par=="Kramer"){
        #Replicating the same filter used in the R function called "decimate".  This is the same filter used in the code for Martinet et al. (2017).
        #Seizure-Waves/modeling/run_seizing_cortical_field.m
        #https://github.com/Mark-Kramer/Seizure-Waves/blob/master/modeling/run_seizing_cortical_field.m
        temp.matlab_decimate_object<-matlab_decimate.function(ts.par,temp.q,pass_string.par=temp.string)
        temp.filter_object<-temp.matlab_decimate_object$out.filter_object
        temp.filter_type_string<-temp.matlab_decimate_object$out.filter_type_string
        temp.filter_specification_string<-temp.matlab_decimate_object$out.filter_specification_string
        temp.bandwidth_parameter=temp.matlab_decimate_object$out.bandwidth_parameter
      }
      else if(bandpass_specification.par=="Martinet"){
        #Use the method of Martinet et al. (2017) of a 1000th-order FIR decimation filter.
        temp.filter_order_fir=1e3
        temp.filter_object<-fir1(temp.filter_order_fir,1/temp.q,temp.string)
        temp.filter_type_string<-paste("FIR, order = ",temp.filter_order_fir,sep="")
        temp.bandwidth_parameter=1/temp.q
      }
      else if(bandpass_specification.par=="Schevon"){
        #From Schevon et al. (2012).
        temp.filter_order_fir=500
        temp.filter_object<-fir1(temp.filter_order_fir,1/temp.q,temp.string)
        temp.filter_type_string<-paste("FIR, order = ",temp.filter_order_fir,sep="")
        temp.bandwidth_parameter=1/temp.q
      }
      else if(bandpass_specification.par=="Schlafly"){
        #From the function called "filter" in Schlafly's code.
        #https://github.com/eschlaf2/waveProp/blob/master/analysis/MEA.m
        temp.running_last_frequency=temp.cutoff
        if(temp.running_last_frequency>(sampling_rate.par/2/1.1)){
          temp.running_last_frequency=(sampling_rate.par/2-1)/1.1
          #cat("Setting temp.running_last_frequency to ",temp.running_last_frequency,"\n")
        }
        temp.filter_order_fir=150
        temp.q=sampling_rate.par/(2*temp.running_last_frequency)
        temp.filter_object<-fir1(temp.filter_order_fir,1/temp.q,temp.string)
        temp.bandwidth_parameter=1/temp.q
        temp.filter_type_string<-paste("FIR, order = ",temp.filter_order_fir,sep="")
      }
      temp.TF_object<-freqz(temp.filter_object)
      temp.TF_frequencies<-temp.TF_object$f/pi*sampling_rate.par
      temp.TF<-temp.TF_object$h
      temp.TF<-Mod(temp.TF)^2
      temp.TF_cleaning_object<-TF_cleaning.function(temp.TF,0)
      temp.TF<-temp.TF_cleaning_object$out.TF
      temp.filter_sequence1<-filter_sequence.function(temp.TF,temp.N,normalization_bool.par=TRUE)
    }
    temp.bandwidth_parameter=temp.bandwidth_parameter*sampling_rate.par
    temp.new_sampling_rate=sampling_rate.par
    temp.test_N=temp.N
    if(!original_sampling_bool.par & !temp.first_frequency){
      if(new_sampling_rate.par>1){
        temp.new_sampling_rate=new_sampling_rate.par
        temp.test_step_size=ceil(sampling_rate.par/new_sampling_rate.par)
        temp.test_indices<-seq(from=1,to=temp.N,by=temp.test_step_size)
        temp.test_N=length(temp.test_indices)
      }
      else{
        temp.new_sampling_rate=2*temp.last_frequency
      }
      temp.new_sampling_rate=max(temp.new_sampling_rate,temp.new_sampling_rate*min_record_size.par/temp.test_N)
    }
    cat(bandpass_specification.par," decimated\n")
    temp.indices_decimation<-c()
    temp.indices1<-1:temp.N
    temp.decimated_series_times<-times.par
    temp.decimated_series<-ts.par
    if(bandpass_specification.par=="Marshall"){
      if(temp.last_frequency<=filter_type_thresholds.par[1] || (typeof(temp.filter_object)!="list" & length(temp.filter_object)>1)){
        temp.decimation_object1<-decimation.function(ts.par,temp.filter_sequence1,temp.first_frequency,temp.last_frequency,
                                                     old_sampling_rate.par=sampling_rate.par,
                                                     new_sampling_rate.par=sampling_rate.par,times.par=times.par,sequence_bool.par=TRUE,
                                                     string.par=temp.filter_type_string)
        temp.decimated_series_times<-temp.decimation_object1$out.times
        temp.decimated_series<-temp.decimation_object1$out.decimated_ts
        temp.indices1<-temp.decimation_object1$out.indices
        temp.filter_type_string<-paste("Slepian, order = ",length(temp.filter_sequence1),",\nInverse FFT",sep="")
        temp.string<-temp.decimation_object1$output.string
        if(temp.string!=""){
          temp.filter_type_string<-paste(temp.filter_type_string,temp.string,sep="")
        }
      }
      else{
        if(length(temp.filter_object)==2){
          temp.ar_coefficients<-temp.filter_object$a
          temp.ma_coefficients<-temp.filter_object$b
          temp.filter_type_string<-paste("Butterworth, order = ",temp.butterworth_parameter_matrix[2,1],
                                         ", ARMA(",length(temp.ar_coefficients),",",length(temp.ma_coefficients),")",sep="")
        }
        else{
          temp.filter_type_string<-paste("Butterworth, order = ",temp.butterworth_parameter_matrix[1,1],sep="")
          temp.bandwidth_parameter=2*temp.butterworth_parameter_matrix[1,2]*sampling_rate.par
        }
        if(!temp.first_frequency & (typeof(temp.filter_object)=="list" || length(temp.filter_object)==1)){
          temp.flag=FALSE
          #try({
          #  temp.decimated_series<-filtfilt(temp.filter_object,ts.par)
          #  temp.filter_type_string<-paste(temp.filter_type_string,",\n filtfilt",sep="")
          #  temp.flag=TRUE
          #},silent=TRUE)
          if(!temp.flag){
            temp.filter_type_string<-paste(temp.filter_type_string,",\nInverse FFT",sep="")
            temp.decimation_object1<-decimation.function(ts.par,temp.filter_sequence1,temp.first_frequency,temp.last_frequency,
                                                         old_sampling_rate.par=sampling_rate.par,
                                                         new_sampling_rate.par=sampling_rate.par,times.par=times.par,sequence_bool.par=TRUE,
                                                         string.par=temp.filter_type_string)
            temp.decimated_series_times<-temp.decimation_object1$out.times
            temp.decimated_series<-temp.decimation_object1$out.decimated_ts
            temp.indices1<-temp.decimation_object1$out.indices
            temp.filter_type_string<-temp.decimation_object1$output.string
          }
        }
        else{
          temp.filter_type_string<-paste(temp.filter_type_string,",\nInverse FFT",sep="")
          temp.decimation_object1<-decimation.function(ts.par,temp.filter_sequence1,temp.first_frequency,temp.last_frequency,
                                                       old_sampling_rate.par=sampling_rate.par,
                                                       new_sampling_rate.par=sampling_rate.par,times.par=times.par,sequence_bool.par=TRUE,
                                                       string.par=temp.filter_type_string)
          temp.decimated_series_times<-temp.decimation_object1$out.times
          temp.decimated_series<-temp.decimation_object1$out.decimated_ts
          temp.indices1<-temp.decimation_object1$out.indices
          temp.filter_type_string<-temp.decimation_object1$output.string
        }
      }
    }
    else{
      if(bandpass_specification.par=="Kramer"){
        temp.ar_coefficients<-temp.filter_object$a
        temp.ma_coefficients<-temp.filter_object$b
        temp.filter_type_string<-paste(temp.filter_type_string,", ARMA(",length(temp.ar_coefficients),",",length(temp.ma_coefficients),")",sep="")
      }
      else{
        temp.filter_type_string<-paste(temp.filter_type_string,", MA(",length(temp.filter_object),")",sep="")
      }
      temp.indices1<-1:temp.N
      temp.decimated_series_times<-times.par
      temp.decimated_series<-NA
      if(!temp.first_frequency){
        temp.decimated_series<-filtfilt(temp.filter_object,ts.par)
        temp.filter_type_string<-paste(temp.filter_type_string,",\n filtfilt",sep="")
      }
      else{
        temp.filter_type_string<-paste(temp.filter_type_string,",\nInverse FFT")
        temp.decimation_object1<-decimation.function(ts.par,temp.filter_sequence1,temp.first_frequency,temp.last_frequency,
                                                     old_sampling_rate.par=sampling_rate.par,
                                                     new_sampling_rate.par=sampling_rate.par,times.par=times.par,sequence_bool.par=TRUE,
                                                     string.par=temp.filter_type_string)
        temp.decimated_series_times<-temp.decimation_object1$out.times
        temp.decimated_series<-temp.decimation_object1$out.decimated_ts
        temp.indices1<-temp.decimation_object1$out.indices
        temp.filter_type_string<-temp.decimation_object1$output.string
      }
      if(is.null(temp.decimated_series)==TRUE || is.na(temp.decimated_series)==TRUE){
        temp.filter_type_string<-paste(temp.filter_type_string,",\nInverse FFT (NULL/NA handler)",sep="")
        temp.decimation_object1<-decimation.function(ts.par,temp.filter_sequence1,temp.first_frequency,temp.last_frequency.par,
                                                     old_sampling_rate.par=sampling_rate.par,
                                                     new_sampling_rate.par=sampling_rate.par,times.par=times.par,sequence_bool.par=TRUE,
                                                     string.par=temp.filter_type_string)
        temp.decimated_series_times<-temp.decimation_object1$out.times
        temp.decimated_series<-temp.decimation_object1$out.decimated_ts
        temp.indices1<-temp.decimation_object1$out.indices
        temp.filter_type_string<-temp.decimation_object1$output.string
      }
    }
    temp.TS_cleaning_object<-TF_cleaning.function(temp.decimated_series,0)
    temp.decimated_series<-temp.TS_cleaning_object$out.TF
    temp.num_indices1=length(temp.indices1)
    temp.min_index1=min(temp.indices1)
    temp.max_index1=max(temp.indices1)
  }#endif
  temp.N_filtered_series=length(temp.decimated_series)
  temp.indices<-1:temp.N_filtered_series
  if(FALSE){
    if(temp.first_frequency>0 || (!temp.first_frequency & bandpass_specification.par!="Marshall")){
      temp.new_sampling_rate=2*passband_cutoffs.par[temp.index1]
      temp.new_step_size=0
      if(temp.last_frequency==(sampling_rate.par/2) || (original_sampling_bool.par==TRUE)){
        temp.new_step_size=1
      }
      else{
        temp.new_step_size=max(1,floor(sampling_rate.par/temp.new_sampling_rate))
        temp.num_steps_decimated=(temp.N_filtered_series-temp.N_filtered_series%%temp.new_step_size)/temp.new_step_size
        if(temp.num_steps_decimated<min_record_size.par){
          temp.new_step_size=max(1,floor(sampling_rate.par/temp.new_sampling_rate*temp.num_steps_decimated/min_record_size.par))
        }
      }
      if(length(temp.N_filtered_series)>0 & length(temp.new_step_size)>0){
        if(temp.N_filtered_series>temp.new_step_size){
          temp.indices<-seq(from=1,to=temp.N_filtered_series,by=temp.new_step_size)
        }
      }
      else{
        temp.indices<-1:temp.N_filtered_series
      }
    }
  }#endif
  #if(temp.first_frequency>0){
    #First differences.
  #  temp.decimated_series<-c(0,temp.decimated_series[2:length(temp.decimated_series)]-0.85*temp.decimated_series[2:length(temp.decimated_series)-1])
  #}
  temp.decimated_series_times<-temp.decimated_series_times[temp.indices]
  temp.decimated_series<-temp.decimated_series[temp.indices]
  temp.TS_cleaning_object<-TF_cleaning.function(temp.decimated_series,0)
  temp.decimated_series<-temp.TS_cleaning_object$out.TF
  temp.ts_filter_indices<-ts.par[temp.indices1]
  temp.ts_filter_indices<-temp.ts_filter_indices[temp.indices]
  temp.list<-list(out.decimated_series_times=temp.decimated_series_times,
                  out.decimated_series=temp.decimated_series,
                  out.filter_type_string=temp.filter_type_string,
                  out.filter_specification_string=temp.filter_specification_string,
                  out.bandwidth_parameter=temp.bandwidth_parameter,
                  out.TF=temp.TF,
                  out.TF_frequencies=temp.TF_frequencies,
                  out.filter_sequence1=temp.filter_sequence1)
  return(temp.list)
}


marshall_section_filter.function<-function(times.par,ts.par,passband.par,frequencies.par,
                                           harmonic_reconstructions.par=NA,significant_frequencies.par=NA,harmonic_reconstruction_indices.par=NA,
                                           bandpass_specification.par="Marshall",filter_list.par=NA,filter_object_list.par=NA,parameter_vector.par=NA,
                                           filter_sequence.par=NA,
                                           sampling_rate.par=1,num_fitting_indices.par=10,
                                           filter_type_thresholds.par=NA,
                                           original_sampling_bool.par=FALSE,output_bool.par=FALSE){
  if(is.na(filter_type_thresholds.par)==TRUE){
    filter_type_thresholds.par<-c(sampling_rate.par,sampling_rate.par)
  }
  temp.N=length(times.par)
  temp.cutoff=passband.par[2]
  temp.passband_cutoff=temp.cutoff/sampling_rate.par
  temp.stopband_edge=0
  temp.passband_edge=0
  temp.TF_values<-c()
  temp.TF_frequencies<-c()
  if(is.na(filter_list.par)==TRUE){
    tic()
    cat("Time for filter computation = ")
    #Slepian filters.
    temp.filter_string<-"Slepian"
    temp.Slepian_lowpass_filter_object<-Slepian_lowpass_filter.function(frequencies.par,temp.cutoff,temp.N,sampling_rate.par=sampling_rate.par,
                                                                        num_fitting_indices.par=num_fitting_indices.par,output_bool.par=output_bool.par)
    temp.TF_values<-temp.Slepian_lowpass_filter_object$out.mt_frequency_response
    temp.TF_frequencies<-temp.Slepian_lowpass_filter_object$out.mt_frequencies*sampling_rate.par
    temp.N_filter=temp.Slepian_lowpass_filter_object$out.N_filter
    temp.NW=temp.Slepian_lowpass_filter_object$out.NW
    temp.K=temp.Slepian_lowpass_filter_object$out.K
    temp.stopband_edge<-temp.Slepian_lowpass_filter_object$out.stopband_edge
    temp.passband_edge=temp.Slepian_lowpass_filter_object$out.passband_edge
    temp.nums_nn_interpolation=temp.Slepian_lowpass_filter_object$out.nums_nn_interpolation
    temp.filter_sequence<-temp.Slepian_lowpass_filter_object$out.filter_sequence
    temp.mt_dec_TF_object<-temp.Slepian_lowpass_filter_object$out.mt_dec_TF_object
    #Read in the summary statistics of the fit of Slepian windows to the rectangle function.
    temp.Rsq_MT=temp.Slepian_lowpass_filter_object$out.Rsq
    temp.KS_percentile_MT=temp.Slepian_lowpass_filter_object$out.KS_percentile
    temp.TPT_percentile_MT=temp.Slepian_lowpass_filter_object$out.TPT_percentile
    #Initialize the input parameters for the function.
    filter_list.par<-list(temp.filter_sequence)
    filter_object_list.par<-list(temp.mt_dec_TF_object)
    parameter_vector.par<-c(temp.N_filter,temp.passband_cutoff)
    toc()
  }
  #Filtering.
  temp.bpf_object<-bandpass_filter.function(times.par,ts.par,passband.par,harmonic_reconstructions.par,significant_frequencies.par,
                                            harmonic_reconstruction_indices.par,
                                            filter_list.par,filter_object_list.par,parameter_vector.par,sampling_rate.par,
                                            new_sampling_rate.par=2*temp.cutoff,temp.cutoff,
                                            bandpass_specification.par=bandpass_specification.par,
                                            original_sampling_bool.par=original_sampling_bool.par,invert_bool.par=TRUE,
                                            filter_type_thresholds.par=filter_type_thresholds.par)
  temp.decimated_series_times<-temp.bpf_object$out.decimated_series_times
  temp.decimated_series<-temp.bpf_object$out.decimated_series
  temp.string<-temp.bpf_object$out.filter_type_string
  temp.filter_specification_string<-temp.bpf_object$out.filter_specification_string
  temp.bandwidth_parameter<-temp.bpf_object$out.bandwidth_parameter
  if(bandpass_specification.par!="Marshall"){
    temp.TF_values<-temp.bpf_object$out.TF
    temp.TF_frequencies<-temp.bpf_object$out.TF_frequencies
  }
  temp.filter_sequence<-temp.bpf_object$out.filter_sequence1
  temp.list<-list(out.decimated_series_times=temp.decimated_series_times,
                  out.decimated_series=temp.decimated_series,
                  out.string=temp.string,
                  out.filter_specification_string=temp.filter_specification_string,
                  out.bandwidth_parameter=temp.bandwidth_parameter,
                  out.TF_values=temp.TF_values,
                  out.TF_frequencies=temp.TF_frequencies,
                  out.filter_list=filter_list.par,
                  out.stopband_edge=temp.stopband_edge,
                  out.passband_edge=temp.passband_edge)
  if(is.na(filter_list.par)==TRUE){
    temp.list<-list.append(temp.list,
                           out.mt_frequency_response=temp.mt_frequency_response,
                           out.N_filter=temp.N_filter,
                           out.NW=temp.NW,
                           out.K=temp.K,
                           out.Rsq_MT=temp.Rsq_MT,
                           out.KS_percentile_MT=temp.KS_percentile_MT,
                           out.TPT_percentile_MT=temp.TPT_percentile_MT,
                           out.filter_object_list=filter_object_list.par,
                           out.parameter_vector=parameter_vector.par)
  }
  if(is.na(filter_sequence.par)==TRUE){
    temp.list<-list.append(temp.list,
                           out.filter_sequence=temp.filter_sequence)
  }
  return(temp.list)
}


marshall_section_filter_postprocessing.function<-function(ts.par,times.par,original_ts.par,original_times.par,frequencies.par,frequency_band.par,
                                                          NW.par=5,K.par=NA,sampling_rate.par=1,F_test_threshold.par=0.99,num_sections.par=2,
                                                          threshold_crossings_LB.par=3,old_directory.par="",specific_subdirectory_string.par="",
                                                          trial_filter_string.par="",energy_concentrations.par=NA,dpss.par=NA,slepian_functions.par=NA){
  temp.N_original=length(original_ts.par)
  temp.N=length(times.par)
  temp.N0=temp.N
  temp.K=K.par
  if(is.na(K.par)==TRUE){
    temp.K=2*NW.par-1
  }
  temp.F_threshold=qf(1-1/temp.N,2,2*temp.K-2)
  #Frequency-domain performance assessment.
  temp.specific_directory_string<-specific_subdirectory_string.par
  temp.method_directory_string<-paste(trial_filter_string.par,"_Method",sep="")
  temp.specific_directory_string<-paste(temp.specific_directory_string,"/",temp.method_directory_string,sep="")
  temp.residual_ts<-ts.par
  #Subtract periodic elements from the filtered (list element #2) time series.
  temp.filtering_algorithm_eigencoeff_harmonic_object<-filtering_algorithm_eigencoeff_harmonic.function(ts.par=ts.par,time_sequence.par=times.par,
                                                                                                        new_directory.par="",
                                                                                                        old_directory.par=old_directory.par,
                                                                                                        NW.par=NW.par,sampling_rate.par=sampling_rate.par,
                                                                                                        F_test_threshold.par=1-1/temp.N,
                                                                                                        num_sections.par=num_sections.par,
                                                                                                        threshold_crossings_LB.par=
                                                                                                          threshold_crossings_LB.par,
                                                                                                        demodulate_bool.par=FALSE,
                                                                                                        all_frequencies_bool.par=FALSE,
                                                                                                        dpss.par=dpss.par,
                                                                                                        energy_concentrations.par=energy_concentrations.par,
                                                                                                        slepian_functions.par=slepian_functions.par)
  temp.residual_ts<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.residual_ts
  temp.spectral_power_estimates<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.spectral_power_estimates
  temp.significant_frequencies_list<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.significant_frequencies_list
  ######################################################################################################################################################
  #Perform a basic multitaper spectral analysis on the time series whose harmonic elements specifically having stopband frequencies have been
  #subtracted out.
  ######################################################################################################################################################
  temp.harmonic_analysis_object<-harmonic_analysis.function(ts.par=temp.residual_ts,time_sequence.par=times.par,NW.par=NW.par,
                                                            jackknife.par=FALSE,plot.par=FALSE,measured_quantity.par=measure_quantity.string,
                                                            measured_units.par=measure_units.string,sampling_rate.par=sampling_rate.par,
                                                            spectral_power_bool.par=FALSE,F_test_threshold.par=1-1/temp.N,
                                                            threshold_crossings_LB.par=threshold_crossings_LB.par,num_sections.par=num_sections.par,
                                                            new_directory.par=temp.specific_directory_string,old_directory.par=old_directory.par,
                                                            reconstruction_bool.par=FALSE,ends_reconstruction_bool.par=TRUE,
                                                            demodulate_bool.par=FALSE,residual_bool.par=FALSE,ha_bool.par=TRUE,
                                                            all_frequencies_bool.par=FALSE,ha_bool_residual.par=FALSE,
                                                            num_diffs.par=TRUE,dpss.par=dpss.par,energy_concentrations.par=energy_concentrations.par,
                                                            slepian_functions.par=slepian_functions.par)
  temp.significant_frequencies<-temp.harmonic_analysis_object$out.significant_frequencies
  temp.F_statistic_spectrum<-temp.harmonic_analysis_object$out.F_statistics
  temp.M2=length(frequencies.par)
  temp.M=2*(temp.M2-1)
  temp.significant_frequency_indices<-c()
  #Only subtract out the periodic elements detected by the residual harmonic F-test if they lie inside the stopband, or else subtract the reconstructed
  #periodic element in the passband only if it is significant according to the F-test whose thresholds are considered for the original series.  This
  #is because the residual series for which a harmonic analysis is being considered is the one mentioned in the previous comment, with only those
  #periodic elements having been subtracted from it which lie inside the stopband.
  #Consider passband frequencies for obtaining the filtered version of the series.
  temp.plotting_significant_frequencies<-temp.significant_frequencies*sampling_rate.par
  temp.passband_significant_indices<-which(temp.plotting_significant_frequencies>=frequency_band.par[1] &
                                             temp.plotting_significant_frequencies<=frequency_band.par[2])
  temp.significant_frequency_indices_passband<-round(temp.significant_frequencies[temp.passband_significant_indices]*temp.M)
  temp.significant_frequency_indices_passband<-
    temp.significant_frequency_indices_passband[temp.significant_frequency_indices_passband>0 & temp.significant_frequency_indices_passband<=temp.M2]
  #Consider indices for the significant stopband frequencies.
  temp.stopband_significant_indices<-c(which(temp.plotting_significant_frequencies<=frequency_band.par[1]),
                                       which(temp.plotting_significant_frequencies>=frequency_band.par[2]))
  temp.significant_frequency_indices_stopband<-round(temp.significant_frequencies[temp.stopband_significant_indices]*temp.M)
  temp.significant_frequency_indices_stopband<-
    temp.significant_frequency_indices_stopband[temp.significant_frequency_indices_stopband>0 & temp.significant_frequency_indices_stopband<=temp.M2]
  #Add indices for the significant passband frequencies.
  temp.significant_F_statistic_indices<-which(temp.F_statistic_spectrum>temp.F_threshold)
  temp.significant_frequency_indices<-c(temp.significant_frequency_indices_stopband,temp.significant_F_statistic_indices)
  temp.significant_frequency_indices<-unique(temp.significant_frequency_indices)
  temp.all_significant_indices<-unique(c(temp.significant_frequency_indices,temp.significant_frequency_indices_passband))
  #Compute the residual eigencoefficients.
  temp.eigencoeffs<-temp.harmonic_analysis_object$out.eigencoeffs
  temp.slepian_functions<-temp.harmonic_analysis_object$out.slepian_functions
  temp.slepian_sequences<-temp.harmonic_analysis_object$out.slepian_sequences
  temp.residual_eigencoeffs<-residual_eigencoefficient_reconstruction.function(temp.eigencoeffs,temp.all_significant_indices,
                                                                               temp.slepian_functions,temp.N,
                                                                               energy_concentrations.par=energy_concentrations.par,NW.par=NW.par)
  setwd(old_directory.par)
  #Correlation analysis.
  temp.M=nrow(temp.residual_eigencoeffs)
  temp.zero_index=temp.M/2
  temp.M2=temp.zero_index+1
  temp.plotting_frequencies0<-frequencies.par*sampling_rate.par
  temp.band_indices<-which(temp.plotting_frequencies0<frequency_band.par[2])
  temp.num_band_indices=length(temp.band_indices)
  temp.plotting_frequencies<-temp.plotting_frequencies0[temp.band_indices]
  temp.passband_indices<-temp.zero_index+temp.band_indices-1
  #Filtered, residual process.
  temp.residual_spectral_powers<-multitaper.regularized_spectrum(temp.residual_eigencoeffs,frequencies.par,energy_concentrations.par)
  #Whitening analysis.
  temp.prewhitening_object<-prewhitening_coefficients.function(temp.residual_spectral_powers,frequencies.par,temp.N,NW.par=NW.par,
                                                               sampling_rate.par=sampling_rate.par)
  temp.residual_prewhitened_spectral_powers<-temp.prewhitening_object$out.prewhitened_spectrum
  #Energy.
  temp.full_energy=sum(temp.residual_prewhitened_spectral_powers)
  temp.stopband_energy=(temp.full_energy-sum(temp.residual_prewhitened_spectral_powers[temp.band_indices]))/temp.full_energy*100
  #Whitening.
  temp.ar_coefficients<-temp.prewhitening_object$out.ar_coefficients
  temp.ar_order=temp.prewhitening_object$out.ar_order
  temp.times<-original_times.par[(temp.N_original-temp.N+1):temp.N_original-(temp.N_original-temp.N)/2]
  temp.filter_object<-filter.function(ts.par=temp.residual_ts,filter.par=temp.ar_coefficients,times.par=temp.times)
  temp.indices<-temp.filter_object$out.indices
  temp.whitened_series<-temp.residual_ts[temp.indices]-temp.filter_object$out.filtered_ts
  temp.times<-temp.filter_object$out.times
  temp.times0<-temp.times
  temp.whitened_series0<-temp.whitened_series
  temp.reconstructed_series<-temp.whitened_series
  temp.whitened_periodic<-rep(0,length(temp.whitened_series))
  temp.whitened_reconstruction<-temp.residual_ts[temp.indices]-temp.filter_object$out.filtered_ts
  temp.bb_reconstruction<-temp.whitened_reconstruction
  if(length(temp.significant_frequency_indices_stopband)>0){
    #Buys-Baillot filter to remove any last periodic elements.
    temp.buys_baillot_reconstruction_object<-buys_baillot_reconstruction.function(ts.par=temp.whitened_series,
                                                                                  times.par=temp.times,frequencies.par=frequencies.par,
                                                                                  significant_indices.par=temp.significant_frequency_indices_stopband,
                                                                                  sampling_rate.par=sampling_rate.par,verbose_bool.par=FALSE)
    temp.reconstructed_series<-temp.buys_baillot_reconstruction_object$out.bb_reconstruction
    temp.whitened_series<-temp.buys_baillot_reconstruction_object$out.bb_whitened_series
    temp.times<-temp.buys_baillot_reconstruction_object$out.times
    #Reconstruct the periodic elements to obtain the final filtered form of the series when dealing with bandpass filters with high-frequency lower cutoff.
    temp.buys_baillot_reconstruction_object<-buys_baillot_reconstruction.function(ts.par=temp.whitened_series,
                                                                                  times.par=temp.times,frequencies.par=frequencies.par,
                                                                                  significant_indices.par=temp.all_significant_indices,
                                                                                  sampling_rate.par=sampling_rate.par,verbose_bool.par=FALSE)
    temp.bb_indices<-temp.buys_baillot_reconstruction_object$out.bb_indices
    temp.whitened_periodic<-temp.buys_baillot_reconstruction_object$out.bb_whitened_series
    temp.times<-temp.buys_baillot_reconstruction_object$out.times
    temp.bb_reconstruction<-temp.whitened_reconstruction[temp.bb_indices]-temp.whitened_periodic
  }
  temp.list<-list(out.times=temp.times,
                  out.bb_reconstruction=temp.bb_reconstruction,
                  out.slepian_functions=temp.slepian_functions,
                  out.slepian_sequences=temp.slepian_sequences)
  return(temp.list)
}


marshall_section_filter_harmonic.function<-function(section_times.par,section_ts.par,frequency_band.par,NW.par=5,sampling_rate.par=1,
                                                    M_exponent.par=1,K.par=NA,
                                                    F_test_threshold.par=0.999,num_sections.par=2,threshold_crossings_LB.par=3,
                                                    first_time.par=0,num_fitting_indices.par=10,filter_type_thresholds.par=c(50,1e3),
                                                    bandpass_specification.par="Marshall",
                                                    filter_list.par=NA,filter_object_list.par=NA,parameter_vector.par=NA,
                                                    filter_sequence.par=NA,original_sampling_bool.par=FALSE,
                                                    abscissa_quantity.par="Measured value",abscissa_units.par="units",
                                                    ordinates_quantity.par="Measured value",ordinates_units.par="units",
                                                    old_directory.par="",new_directory.par,plot_bool.par=FALSE,output_bool.par=FALSE,
                                                    specific_subdirectory_string.par="",whitening_bool.par=FALSE,harmonic_bool.par=FALSE,
                                                    eigenvalues.par=NA,dpss.par=NA,slepian_functions.par=NA,decimation_dpss.par=NA,
                                                    decimation_slepian_functions.par=NA,differencing_bool.par=FALSE){
  temp.N=length(section_ts.par)
  temp.frequencies<-c()
  temp.energy_concentrations<-c()
  temp.dpss<-c()
  temp.slepian_functions<-c()
  temp.harmonic_reconstructions_list=NA
  temp.harmonic_reconstruction_indices_list=NA
  temp.significant_frequencies_list=NA
  if(harmonic_bool.par==TRUE){
    #Harmonic analysis, both for reconstruction and also to subtract out the periodic elements whose frequencies lie in the stopband.
    temp.filtering_algorithm_eigencoeff_harmonic_object<-filtering_algorithm_eigencoeff_harmonic.function(ts.par=section_ts.par,
                                                                                                          time_sequence.par=section_times.par,
                                                                                                          new_directory.par=new_directory.par,
                                                                                                          old_directory.par=old_directory.par,
                                                                                                          NW.par=NW.par,
                                                                                                          sampling_rate.par=sampling_rate.par,
                                                                                                          F_test_threshold.par=F_test_threshold.par,
                                                                                                          num_sections.par=num_sections.par,
                                                                                                          threshold_crossings_LB.par=threshold_crossings_LB.par,
                                                                                                          all_frequencies_bool.par=FALSE,
                                                                                                          first_time.par=first_time.par,
                                                                                                          demodulate_bool.par=FALSE,
                                                                                                          frequency_band.par=frequency_band.par,
                                                                                                          dpss.par=dpss.par,
                                                                                                          energy_concentrations.par=eigenvalues.par,
                                                                                                          slepian_functions.par=slepian_functions.par)
    temp.K=temp.filtering_algorithm_eigencoeff_harmonic_object$out.K
    temp.M=temp.filtering_algorithm_eigencoeff_harmonic_object$out.M
    temp.M2=temp.filtering_algorithm_eigencoeff_harmonic_object$out.M2
    temp.frequencies<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.frequencies
    temp.energy_concentrations<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.energy_concentrations
    temp.dpss<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.dpss
    temp.slepian_functions<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.slepian_functions
    temp.ts_eigencoeffs<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.ts_eigencoeffs
    temp.harmonic_reconstructions_list<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.harmonic_reconstructions_list
    temp.harmonic_reconstruction_indices_list<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.harmonic_reconstruction_indices_list
    temp.significant_frequencies_list<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.significant_frequencies_list
  }
  else if(whitening_bool.par==TRUE || is.na(eigenvalues.par)==TRUE){
    temp.multitaper_parameters_object<-multitaper_parameters.function(N.par=temp.N,NW.par=NW.par,sampling_rate.par=sampling_rate.par,
                                                                      M_exponent.par=M_exponent.par,verbose.par=FALSE)
    temp.M=temp.multitaper_parameters_object$out.M
    temp.M2=temp.M/2+1
    temp.frequencies=temp.multitaper_parameters_object$out.frequencies
    if(is.na(K.par)==TRUE){
      K.par=2*NW.par-1
    }
    temp.dpss_matrix_object<-dpss.matrix(temp.N,NW.par,K.par)
    temp.energy_concentrations<-temp.dpss_matrix_object$out.eigenvalues
    temp.dpss<-temp.dpss_matrix_object$out.dpss
    temp.slepian_functions<-Slepian.functions(temp.dpss,temp.M)
  }
  else if(!is.na(eigenvalues.par)){
    temp.energy_concentrations<-eigenvalues.par
    temp.dpss<-dpss.par
    temp.slepian_functions<-slepian_functions.par
  }
  #The filtering step.
  if(differencing_bool.par==TRUE){
    temp.N=length(section_ts.par)
    section_ts.par<-c(0,section_ts.par[2:temp.N]-section_ts.par[1:(temp.N-1)])
  }
  temp.marshall_section_filter_object<-marshall_section_filter.function(times.par=section_times.par,ts.par=section_ts.par,
                                                                        passband.par=frequency_band.par,temp.frequencies,temp.harmonic_reconstructions_list,
                                                                        temp.significant_frequencies_list,
                                                                        temp.harmonic_reconstruction_indices_list,
                                                                        bandpass_specification.par=bandpass_specification.par,
                                                                        filter_list.par=filter_list.par,filter_object_list.par=filter_object_list.par,
                                                                        parameter_vector.par=parameter_vector.par,filter_sequence.par=filter_sequence.par,
                                                                        sampling_rate.par=sampling_rate.par,
                                                                        num_fitting_indices.par=num_fitting_indices.par,
                                                                        filter_type_thresholds.par=filter_type_thresholds.par,
                                                                        original_sampling_bool.par=original_sampling_bool.par,output_bool.par=output_bool.par)
  temp.bandwidth_parameter<-temp.marshall_section_filter_object$out.bandwidth_parameter
  temp.decimated_series_times<-temp.marshall_section_filter_object$out.decimated_series_times
  temp.decimated_series<-temp.marshall_section_filter_object$out.decimated_series
  temp.string<-temp.marshall_section_filter_object$out.string
  temp.filter_specification_string<-temp.marshall_section_filter_object$out.filter_specification_string
  temp.bandwidth_parameter<-temp.marshall_section_filter_object$out.bandwidth_parameter
  temp.TF_values<-temp.marshall_section_filter_object$out.TF_values
  temp.TF_frequencies<-temp.marshall_section_filter_object$out.TF_frequencies
  temp.filter_sequence<-temp.marshall_section_filter_object$out.filter_sequence
  temp.filter_list<-temp.marshall_section_filter_object$out.filter_list
  temp.stopband_edge=temp.marshall_section_filter_object$out.stopband_edge
  temp.passband_edge=temp.marshall_section_filter_object$out.passband_edge
  temp.mt_frequency_response<-c()
  temp.N_filter=0
  temp.filter_list<-c()
  temp.filter_object_list<-c()
  temp.parameter_vector<-c()
  temp.NW=0
  temp.K=0
  temp.Rsq_MT=0
  temp.KS_percentile_MT=0
  temp.TPT_percentile_MT=0
  if(is.na(filter_list.par)==TRUE){
    temp.mt_frequency_response<-temp.marshall_section_filter_object$out.mt_frequency_response
    temp.N_filter=temp.marshall_section_filter_object$out.N_filter
    temp.filter_list<-temp.marshall_section_filter_object$out.filter_list
    temp.filter_object_list<-temp.marshall_section_filter_object$out.filter_object_list
    temp.parameter_vector<-temp.marshall_section_filter_object$out.parameter_vector
    temp.NW=temp.marshall_section_filter_object$out.NW
    temp.K=temp.marshall_section_filter_object$out.K
    temp.Rsq_MT<-temp.marshall_section_filter_object$out.Rsq_MT
    temp.KS_percentile_MT<-temp.marshall_section_filter_object$out.KS_percentile_MT
    temp.TPT_percentile_MT<-temp.marshall_section_filter_object$out.TPT_percentile_MT
  }
  #Postprocessing.
  temp.N_decimated=length(temp.decimated_series_times)
  temp.times<-temp.decimated_series_times
  temp.sampling_rate_decimation=sampling_rate.par*temp.N_decimated/length(section_times.par)
  temp.decimation_dpss<-c()
  temp.decimation_slepian_functions<-c()
  if(whitening_bool.par==TRUE){
    temp.F_test_threshold=1-1/temp.N_decimated
    temp.marshall_section_filter_postprocessing_object<-
      marshall_section_filter_postprocessing.function(ts.par=temp.decimated_series,times.par=temp.decimated_series_times,
                                                      original_ts.par=section_ts.par,original_times.par=section_times.par,
                                                      energy_concentrations.par=temp.energy_concentrations,
                                                      frequencies.par=temp.frequencies,
                                                      frequency_band.par=frequency_band.par,NW.par=NW.par,
                                                      sampling_rate.par=temp.sampling_rate_decimation,
                                                      F_test_threshold.par=temp.F_test_threshold,
                                                      num_sections.par=num_sections.par,
                                                      threshold_crossings_LB.par=threshold_crossings_LB.par,
                                                      old_directory.par=old_directory.par,
                                                      specific_subdirectory_string.par=specific_subdirectory_string.par,
                                                      trial_filter_string.par=bandpass_specification.par,
                                                      dpss.par=decimation_dpss.par,slepian_functions.par=decimation_slepian_functions.par)
    temp.times<-temp.marshall_section_filter_postprocessing_object$out.times
    temp.decimated_series<-temp.marshall_section_filter_postprocessing_object$out.bb_reconstruction
    temp.decimation_dpss<-temp.marshall_section_filter_postprocessing_object$out.slepian_sequences
    temp.decimation_slepian_functions<-temp.marshall_section_filter_postprocessing_object$out.slepian_functions
  }
  #else if(differencing_bool.par==TRUE){
  #  temp.decimation_size=length(temp.decimated_series)
  #  temp.decimated_series<-temp.decimated_series[2:temp.decimation_size]#-temp.decimated_series[1:(temp.decimation_size-1)]
  #  temp.times<-temp.times[2:temp.decimation_size]
  #}
  if(plot_bool.par==TRUE){
    temp.x_list<-list((section_times.par-section_times.par[1])*60,(temp.times-section_times.par[1])*60)
    temp.y_list<-list(section_ts.par,temp.decimated_series)
    plot.graph(temp.x_list,temp.y_list,pdf_title.par=paste("Comparison_",frequency_band.par[1],"_",frequency_band.par[2],"_",
                                                           bandpass_specification.par,".pdf",sep=""),
               x_label.par=paste(abscissa_quantity.par,", in ",abscissa_units.par," since ",round(first_time.par/60,3)," min",sep=""),
               y_label.par=paste(ordinates_quantity.par,", in ",ordinates_units.par,sep=""),col.par=c("grey80",1))
  }
  temp.list<-list(out.decimated_series_times=temp.times,
                  out.decimated_series=temp.decimated_series,
                  out.string=temp.string,
                  out.filter_specification_string=temp.filter_specification_string,
                  out.energy_concentrations=temp.energy_concentrations,
                  out.filter_list=temp.filter_list,
                  out.dpss=temp.dpss,
                  out.slepian_functions=temp.slepian_functions,
                  out.stopband_edge=temp.stopband_edge,
                  out.passband_edge=temp.passband_edge)
  if(is.na(filter_list.par)==TRUE){
    temp.list<-list.append(temp.list,
                           out.mt_frequency_response=temp.mt_frequency_response,
                           out.N_filter=temp.N_filter,
                           out.NW=temp.NW,
                           out.K=temp.K,
                           out.Rsq_MT=temp.Rsq_MT,
                           out.KS_percentile_MT=temp.KS_percentile_MT,
                           out.TPT_percentile_MT=temp.TPT_percentile_MT,
                           out.filter_list=filter_list.par,
                           out.filter_object_list=filter_object_list.par,
                           out.parameter_vector=parameter_vector.par)
  }
  if(is.na(filter_sequence.par)==TRUE){
    temp.list<-list.append(temp.list,
                           out.bandwidth_parameter=temp.bandwidth_parameter,
                           out.TF_values=temp.TF_values,
                           out.TF_frequencies=temp.TF_frequencies,
                           out.filter_sequence=temp.filter_sequence)
  }
  if(whitening_bool.par==TRUE){
    temp.list<-list.append(temp.list,
                           out.decimation_dpss=temp.decimation_dpss,
                           out.decimation_slepian_functions=temp.decimation_slepian_functions)
  }
  return(temp.list)
}


decimation_filter_diagnostics.function<-function(frequencies.par,TF.par,cutoff.par,sampling_rate.par=1){
  temp.mod_TF<-Mod(TF.par[frequencies.par>cutoff.par])
  temp.mod_TF[!temp.mod_TF]<-min(temp.mod_TF[temp.mod_TF!=0])
  temp.log_PTF<-10*log10(temp.mod_TF)
  temp.log_frequencies<-10*log10(frequencies.par[frequencies.par>cutoff.par])
  temp.num_training=length(temp.log_frequencies)
  temp.new_num_training=100
  temp.step_size=max(1,floor(temp.num_training/temp.new_num_training))
  cat("temp.num_training = ",temp.num_training,", temp.step_size = ",temp.step_size,"\n")
  temp.downsampled_indices<-seq(from=1,to=temp.num_training,by=temp.step_size)
  temp.log_PTF<-temp.log_PTF[temp.downsampled_indices]
  temp.log_frequencies<-temp.log_frequencies[temp.downsampled_indices]
  temp.num_training=length(temp.log_PTF)
  #Determine the decay rate.
  temp.lm_object<-lm(temp.log_PTF~temp.log_frequencies)
  temp.coefficients<-temp.lm_object$coefficients
  temp.decay_rate=temp.coefficients[2]
  temp.fitted_values<-temp.lm_object$fitted.values
  temp.residuals<-temp.lm_object$residuals
  temp.residual_analysis_object<-residual_analysis.function(temp.fitted_values,temp.residuals,TPT_threshold.par=TPT_threshold.par)
  temp.Rsq=temp.residual_analysis_object$out.Rsq
  if(temp.Rsq<0){
    temp.Rsq=0
  }
  temp.KS_percentile=temp.residual_analysis_object$out.KS_percentile
  temp.TPT_percentile=temp.residual_analysis_object$out.TPT_percentile
  #Determine the peak sidelobe.
  temp.index_sequence<-1:temp.num_training
  temp.sums<-sapply(temp.index_sequence,running.sum,temp.log_PTF)
  temp.first_diffs<-temp.sums[2:temp.num_training]-temp.sums[1:(temp.num_training-1)]
  temp.N_first<-length(temp.first_diffs)
  temp.second_diffs<-temp.first_diffs[2:temp.N_first]-temp.first_diffs[1:(temp.N_first-1)]
  temp.N_second=length(temp.second_diffs)
  temp.threshold.diff=0
  temp.where_optimal<-which(temp.second_diffs>temp.threshold.diff)
  temp.peak_sidelobe_frequency=0
  temp.maximum=0
  temp.optimal_index=1
  if(length(temp.where_optimal)>0){
    for(temp.i in 1:length(temp.where_optimal)){
      temp.index=temp.where_optimal[temp.i]
      if(temp.index<(temp.N_second-1)){
        if(temp.second_diffs[temp.index+1]<=0){
          temp.optimal_index=temp.index+2
          break
        }
      }
    }
    temp.peak_sidelobe_frequency=10^(temp.log_frequencies[temp.optimal_index]/10)*sampling_rate.par
    temp.maximum=10^(temp.log_PTF[temp.optimal_index]/20)
  }
  #Integrated squared error.
  temp.PB_TF_indices<-which(frequencies.par<=cutoff.par)
  temp.SB_TF_indices<-which(frequencies.par>cutoff.par)
  temp.ise=crossprod(1-TF.par[temp.PB_TF_indices])
  temp.ise=temp.ise+crossprod(TF.par[temp.SB_TF_indices])
  temp.list<-list(out.decay_rate=temp.decay_rate,
                  out.Rsq=temp.Rsq,
                  out.KS_percentile=temp.KS_percentile,
                  out.TPT_percentile=temp.TPT_percentile,
                  out.peak_sidelobe_frequency=temp.peak_sidelobe_frequency,
                  out.maximum=temp.maximum,
                  out.fitted_values=temp.fitted_values,
                  out.log_frequencies=temp.log_frequencies,
                  out.ise=temp.ise)
  return(temp.list)
}



filter_diagnostic_analysis.function<-function(TF_frequencies_list.par,TF_values_list.par,frequency_band.par,filter_change_points.par,filter_labels.par,
                                              bandwidths.par,filter_orders.par,sampling_rate.par=1,plot_bool.par=FALSE,verbose_bool.par=FALSE){
  temp.cutoff=frequency_band.par[2]
  if(frequency_band.par[1]>0){
    temp.cutoff=(temp.cutoff-frequency_band.par[1])/2
  }
  temp.num_filters=length(TF_frequencies_list.par)
  temp.decay_rates<-rep(0,temp.num_filters)
  temp.nums_nn_interpolation<-temp.decay_rates
  temp.ise_values<-temp.decay_rates
  temp.title_strings<-c()
  temp.title_strings_output<-c()
  temp.fitting_frequencies_list<-list()
  temp.fitting_PTF_values_list<-list()
  for(temp.i in 1:temp.num_filters){
    temp.TF_frequencies<-TF_frequencies_list.par[[temp.i]]
    temp.TF_values<-TF_values_list.par[[temp.i]]
    temp.TF_cleaning_object<-TF_cleaning.function(temp.TF_values,0)
    temp.TF_values<-temp.TF_cleaning_object$out.TF
    temp.nums_nn_interpolation[temp.i]=temp.TF_cleaning_object$out.nums_nn_interpolation
    temp.decimation_filter_diagnostics_object<-decimation_filter_diagnostics.function(frequencies.par=temp.TF_frequencies,TF.par=temp.TF_values,
                                                                                      cutoff.par=temp.cutoff,sampling_rate.par=sampling_rate.par)
    temp.decay_rates[temp.i]=temp.decimation_filter_diagnostics_object$out.decay_rate
    temp.ise_values[temp.i]=temp.decimation_filter_diagnostics_object$out.ise
    temp.fitting_frequencies_list[[temp.i]]<-temp.decimation_filter_diagnostics_object$out.log_frequencies
    temp.fitting_PTF_values_list[[temp.i]]<-temp.decimation_filter_diagnostics_object$out.fitted_values
    if(temp.i==1){
      temp.title_strings[temp.i]<-paste("[0,",round(filter_change_points.par[temp.i]/60,3),"] min\t",filter_labels.par[temp.i],sep="")
    }
    else{
      temp.title_strings[temp.i]<-
        paste("[",round(filter_change_points.par[temp.i-1]/60,3),",",round(filter_change_points.par[temp.i]/60,3),"] min\t",filter_labels.par[temp.i],sep="")
    }
    temp.title_strings_output[temp.i]<-str_replace(temp.title_strings[temp.i],"\n"," ")
  }
  if(plot_bool.par==TRUE){
    temp.x_label<-"Frequency, in hertz"
    temp.y_label<-"Gain"
    multipage_plot_filter.function(TF_frequencies_list.par,TF_values_list.par,x_label.par=temp.x_label,y_label.par=temp.y_label,
                                   title_strings.par=temp.title_strings,nominal_passband_frequency.par=temp.cutoff,
                                   passband_frequency.par=temp.cutoff,passband_edge.par=temp.cutoff,
                                   stopband_edge.par=temp.cutoff,fitting_log_frequencies.par=temp.fitting_frequencies_list,
                                   fitted_log_PTF_values.par=temp.fitting_PTF_values_list,filter_order.par=filter_orders.par,
                                   pdf_title.par=paste("Gain_Spectra_",temp.cutoff,"_Hz.pdf",sep=""),
                                   nums_nn_interpolation.par=temp.nums_nn_interpolation,decay_rates.par=temp.decay_rates,ise.par=temp.ise_values,
                                   include_reconstruction_numbers.par=TRUE)
  }
  if(verbose_bool.par==TRUE){
    sink(paste("Filter_Summaries_",temp.cutoff,"_Hz.txt",sep=""), append=FALSE, split=FALSE)
    cat("section_ti\tsection_tf\tbandwidth\tdecay_rate\tise_value\tnum_interpolations\tdetails\n")
    for(temp.i in 1:temp.num_filters){
      temp.ti=0
      temp.tf=round(filter_change_points.par[temp.i]/60,3)
      if(temp.i>1){
        temp.ti=round(filter_change_points.par[temp.i-1]/60,3)
      }
      cat(temp.ti,"\t",temp.tf,"\t",bandwidths.par[temp.i],"\t",temp.decay_rates[temp.i],"\t",temp.ise_values[temp.i],"\t",
          temp.nums_nn_interpolation[temp.i],"\t",temp.title_strings_output[temp.i],"\n")
    }
    sink()
  }
}


marshall_filter.function<-function(time_sequence.par,ts_values.par,trial_N.par,N.par,section_N.par,changepoint_times.par,
                                   first_time.par=0,sampling_period.par=1,
                                   frequency_band.par,filter_types.par,sampling_rate.par=1,
                                   F_test_threshold.par=0.999,num_sections.par=2,threshold_crossings_LB.par=3,
                                   filter_type_thresholds.par=filter_type_thresholds.par,
                                   abscissa_quantity.par="Measured quantity",abscissa_units.par="units",ordinates_quantity.par="Measured quantity",
                                   ordinates_units.par="units", old_directory.par="",new_directory.par="",output_bool.par=FALSE,
                                   specific_subdirectory_string.par="",whitening_bool.par=FALSE,harmonic_bool.par=FALSE,
                                   differencing_bool.par=FALSE,original_sampling_bool.par=FALSE,plot_sections_bool.par=FALSE,
                                   filter_diagnostics_bool.par=FALSE,plot_bool.par=FALSE,verbose.par=FALSE){
  temp.filter_change_points<-first_time.par+changepoint_times.par
  temp.num_change_points=length(temp.filter_change_points)
  temp.section_times_list<-list()
  temp.section_ts_list<-list()
  temp.counter=1
  temp.filter_counter=1
  temp.running_indices<-1:trial_N.par
  temp.running_max_index=trial_N.par
  temp.section_times<-time_sequence.par[temp.running_indices]
  temp.section_ts<-ts_values.par[temp.running_indices]
  temp.filter_list=NA
  temp.filter_object_list=NA
  temp.parameter_vector=NA
  temp.filter_sequence=NA
  temp.energy_concentrations=NA
  temp.dpss=NA
  temp.slepian_functions=NA
  temp.decimation_dpss=NA
  temp.decimation_slepian_functions=NA
  temp.new_filter_bool=FALSE
  temp.running_filter_type_strings<-c()
  temp.running_filter_string<-filter_types.par[1]
  temp.cumulative_section_time=0
  temp.filter_labels<-c()
  temp.bandwidths<-c()
  temp.filter_orders<-c()
  temp.stopband_edges<-c()
  temp.passband_edges<-c()
  temp.TF_frequencies_list<-list()
  temp.TF_values_list<-list()
  if(plot_sections_bool.par==TRUE){
    temp.section_directory_string<-paste("Reconstruction_",frequency_band.par[1],"_",frequency_band.par[2],"_Section_",trial_section.index,sep="")
    dir.create(temp.section_directory_string,showWarnings=FALSE)
  }
  temp.running_filter_counter=1
  while(temp.running_max_index<=N.par){
    if(verbose.par==TRUE){
      cat(temp.running_max_index," out of ",N.par,"\n")
    }
    if(temp.counter>1 & temp.running_filter_counter<=temp.num_change_points){
      if(temp.section_times[1]>temp.filter_change_points[temp.running_filter_counter]){
        temp.running_filter_string<-filter_types.par[temp.running_filter_counter+1]
        temp.running_filter_counter=temp.running_filter_counter+1
      }
    }
    if(!(temp.running_filter_string %in% temp.running_filter_type_strings)){
      temp.new_filter_bool=TRUE
      temp.running_filter_type_strings<-c(temp.running_filter_type_strings,temp.running_filter_string)
    }
    if(temp.new_filter_bool==TRUE){
      temp.filter_sequence=NA
      temp.dpss=NA
      temp.slepian_functions=NA
      temp.decimation_dpss=NA
      temp.decimation_slepian_functions=NA
    }
    temp.marshall_section_filter_harmonic_object<-marshall_section_filter_harmonic.function(section_times.par=temp.section_times,
                                                                                            section_ts.par=temp.section_ts,
                                                                                            frequency_band.par=frequency_band.par,NW.par=NW.par,
                                                                                            sampling_rate.par=sampling_rate.par,M_exponent.par=1,
                                                                                            F_test_threshold.par=F_test_threshold.par,
                                                                                            num_sections.par=num_sections.par,
                                                                                            threshold_crossings_LB.par=threshold_crossings_LB.par,
                                                                                            first_time.par=first_time.par,
                                                                                            num_fitting_indices.par=num_fitting_indices.par,
                                                                                            filter_type_thresholds.par=filter_type_thresholds.par,
                                                                                            bandpass_specification.par=temp.running_filter_string,
                                                                                            filter_list.par=temp.filter_list,
                                                                                            filter_object_list.par=temp.filter_object_list,
                                                                                            parameter_vector.par=temp.parameter_vector,
                                                                                            filter_sequence.par=temp.filter_sequence,
                                                                                            original_sampling_bool.par=original_sampling_bool.par,
                                                                                            abscissa_quantity.par=abscissa_quantity.par,
                                                                                            abscissa_units.par=abscissa_units.par,
                                                                                            ordinates_quantity.par=ordinates_quantity.par,
                                                                                            ordinates_units.par=ordinates_units.par,
                                                                                            old_directory.par=old_directory.par,
                                                                                            new_directory.par=new_directory.par,
                                                                                            plot_bool.par=FALSE,output_bool.par=FALSE,
                                                                                            specific_subdirectory_string.par=
                                                                                              specific_subdirectory_string.par,
                                                                                            whitening_bool.par=whitening_bool.par,
                                                                                            harmonic_bool.par=harmonic_bool.par,
                                                                                            differencing_bool.par=differencing_bool.par,
                                                                                            eigenvalues.par=temp.energy_concentrations,
                                                                                            dpss.par=temp.dpss,
                                                                                            slepian_functions.par=temp.slepian_functions,
                                                                                            decimation_dpss.par=temp.decimation_dpss,
                                                                                            decimation_slepian_functions.par=
                                                                                              temp.decimation_slepian_functions)
    temp.decimated_series_times<-temp.marshall_section_filter_harmonic_object$out.decimated_series_times
    temp.decimated_series<-temp.marshall_section_filter_harmonic_object$out.decimated_series
    if(temp.counter==1){
      temp.energy_concentrations<-temp.marshall_section_filter_harmonic_object$out.energy_concentrations
      temp.filter_list<-temp.marshall_section_filter_harmonic_object$out.filter_list
      temp.filter_object_list<-temp.marshall_section_filter_harmonic_object$out.filter_object_list
      temp.parameter_vector<-temp.marshall_section_filter_harmonic_object$out.parameter_vector
    }
    if(temp.counter==1 || temp.new_filter_bool==TRUE){
      temp.filter_sequence<-temp.marshall_section_filter_harmonic_object$out.filter_sequence
      temp.filter_string<-temp.marshall_section_filter_harmonic_object$out.string
      temp.filter_labels[temp.filter_counter]<-temp.filter_string
      temp.bandwidths[temp.filter_counter]=temp.marshall_section_filter_harmonic_object$out.bandwidth_parameter
      temp.TF_frequencies<-temp.marshall_section_filter_harmonic_object$out.TF_frequencies
      temp.TF_values<-temp.marshall_section_filter_harmonic_object$out.TF_values
      temp.filter_orders[temp.filter_counter]=length(temp.filter_sequence)
      temp.stopband_edges[temp.filter_counter]<-temp.marshall_section_filter_harmonic_object$out.stopband_edge
      temp.passband_edges[temp.filter_counter]<-temp.marshall_section_filter_harmonic_object$out.passband_edge
      temp.TF_frequencies_list[[temp.filter_counter]]<-temp.TF_frequencies
      temp.TF_values_list[[temp.filter_counter]]<-temp.TF_values
      temp.dpss<-temp.marshall_section_filter_harmonic_object$out.dpss
      temp.slepian_functions<-temp.marshall_section_filter_harmonic_object$out.slepian_functions
      temp.decimation_dpss<-temp.marshall_section_filter_harmonic_object$out.decimation_dpss
      temp.decimation_slepian_functions<-temp.marshall_section_filter_harmonic_object$out.decimation_slepian_functions
      temp.new_filter_bool=FALSE
      temp.filter_counter=temp.filter_counter+1
    }
    temp.current_section_size=length(temp.decimated_series_times)
    if(temp.counter==1){
      temp.decimated_series<-temp.decimated_series[1:floor(temp.current_section_size/2)]
      temp.decimated_series_times<-temp.decimated_series_times[1:floor(temp.current_section_size/2)]
    }
    else{
      temp.max_previous_time=max(temp.section_times_list[[temp.counter-1]])
      temp.start_index=min(which(temp.decimated_series_times>temp.max_previous_time))
      temp.decimated_series<-temp.decimated_series[temp.start_index+1:min(floor(trial_N.par/2),temp.current_section_size-temp.start_index+1)-1]
      temp.decimated_series_times<-temp.decimated_series_times[temp.start_index+1:min(floor(trial_N.par/2),temp.current_section_size-temp.start_index+1)-1]
    }
    temp.section_times_list[[temp.counter]]<-temp.decimated_series_times
    temp.section_ts_list[[temp.counter]]<-temp.decimated_series
    temp.section_size=length(temp.decimated_series_times)
    temp.start_index=0
    if(temp.counter>1){
      temp.max_previous_time=max(temp.section_times_list[[temp.counter-1]])
      temp.start_index=min(which(time_sequence.par>temp.max_previous_time))-1
    }
    temp.running_indices<-temp.start_index+floor(temp.section_size/2)+1:trial_N.par
    temp.first_index=max(1,min(temp.running_indices))
    temp.running_max_index=max(temp.running_indices)
    temp.running_indices<-temp.first_index:temp.running_max_index
    #Reconstruction, full scale.
    if(plot_sections_bool.par==TRUE){
      temp.plotting_section_times<-temp.section_times
      temp.plotting_section_ts_values<-temp.section_ts
      temp.x_list<-list((temp.plotting_section_times-time_sequence.par[1])*60,(temp.section_times_list[[temp.counter]]-time_sequence.par[1])*60)
      temp.y_list<-list((temp.plotting_section_ts_values-mean(temp.plotting_section_ts_values))/sqrt(var(temp.plotting_section_ts_values)),
                        (temp.section_ts_list[[temp.counter]]-mean(temp.section_ts_list[[temp.counter]]))/sqrt(var(temp.section_ts_list[[temp.counter]])))
      plot.graph(temp.x_list,temp.y_list,pdf_title.par=paste(temp.section_directory_string,"/Reconstruction_",frequency_band.par[1],"_",frequency_band.par[2],"_",
                                                             temp.running_filter_string,"_Section_",temp.counter,".pdf",sep=""),
                 x_label.par=paste(measured_abscissa.string,", in seconds since ",round(first.time/60,3)," min",sep=""),
                 y_label.par=paste(measure_quantity.string,", in standardized units of ",measure_units.string,sep=""),lwd.par=c(3,1),col.par=c("grey90",1))
    }
    temp.section_times<-time_sequence.par[temp.running_indices]
    temp.section_ts<-ts_values.par[temp.running_indices]
    temp.counter=temp.counter+1
  }
  temp.full_decimated_ts_times<-unlist(temp.section_times_list)
  temp.full_decimated_ts_values<-unlist(temp.section_ts_list)
  if(plot_bool.par==TRUE){
    #Comparison plot.
    temp.plotting_filter_times<-(temp.full_decimated_ts_times-time_sequence.par[1])
    temp.plotting_ts_values<-temp.full_decimated_ts_values
    temp.x_list<-list(temp.plotting_filter_times)
    temp.y_list<-list(temp.plotting_ts_values)
    plot.graph(temp.x_list,temp.y_list,pdf_title.par=paste("Comparison_",frequency_band.par[1],"_",frequency_band.par[2],"_Hz.pdf",sep=""),
               x_label.par=paste(abscissa_quantity.par,", in seconds since ",round(first_time.par/60,3)," min",sep=""),
               y_label.par=paste(ordinates_quantity.par,", in ",ordinates_units.par,sep=""),lwd=1,col.par=1)
  }
  #Filter diagnostic analysis.
  filter_diagnostic_analysis.function(TF_frequencies_list.par=temp.TF_frequencies_list,TF_values_list.par=temp.TF_values_list,
                                      frequency_band.par=frequency_band.par,filter_change_points.par=temp.filter_change_points,
                                      filter_labels.par=temp.filter_labels,bandwidths.par=temp.bandwidths,filter_orders.par=temp.filter_orders,
                                      sampling_rate.par=sampling_rate.par,plot_bool.par=plot_bool.par,verbose_bool.par=verbose.par)
  #Output the filtered time series.
  sink(paste(frequency_band.par[1],"_",frequency_band.par[2],"_Hz_Demodulate.txt",sep=""), append=FALSE, split=FALSE)
  cat("time_index\ttime\tts_value\n")
  for(temp.i in 1:length(temp.plotting_filter_times)){
    cat(temp.i,"\t",temp.plotting_filter_times[temp.i],"\t",temp.plotting_ts_values[temp.i],"\n")
  }
  sink()
  temp.list<-list(out.full_decimated_ts_times=temp.full_decimated_ts_times,
                  out.full_decimated_ts_values=temp.full_decimated_ts_values,
                  out.TF_frequencies_list=temp.TF_frequencies_list,
                  out.TF_values_list=temp.TF_values_list,
                  out.filter_orders=temp.filter_orders,
                  out.stopband_edges=temp.stopband_edges,
                  out.passband_edges=temp.passband_edges)
  return(temp.list)
}



bp_exploratory_analysis.function<-function(bifrequency_spectrum_vector.par,frequencies.par,row_indices_vector.par,column_indices_vector.par,
                                           first_frequencies.par,second_frequencies.par,
                                           passband_cutoffs.par,N.par,M.par,sampling_rate.par=1,num_fitting_indices.par=10,filters_bool.par=FALSE,
                                           filter_labels.par=c("Slepian","Butterworth","Chebyshev_I","Chebyshev_II"),
                                           old_directory.par="",verbose.par=FALSE){
  if(verbose.par==TRUE){
    tic()
  }
  #Extract passband and stopband energies to help with parameter selection for the decimation-filter design.
  temp.all_passbands<-second_frequencies.par-first_frequencies.par
  temp.all_passbands<-temp.all_passbands[temp.all_passbands<(sampling_rate.par/2)]
  for(temp.i in 1:length(temp.all_passbands)){
    if(first_frequencies.par[temp.i]>0){
      #if(second_frequencies.par[temp.i]==(sampling_rate.par/2)){
      #  temp.all_passbands[temp.i]=first_frequencies.par[temp.i]
      #}
      #else{
      temp.all_passbands[temp.i]=temp.all_passbands[temp.i]/2
      #}
    }
  }
  temp.all_passbands<-unique(temp.all_passbands)
  temp.num_passbands=length(temp.all_passbands)
  temp.decimation_energies_object<-decimation_energies.function(bifrequency_spectrum_vector.par,frequencies,row_indices_vector.par,
                                                                column_indices_vector.par,temp.all_passbands,M.par,sampling_rate.par=sampling_rate.par,
                                                                "Decimation_Energies_Raw.txt",verbose.par=verbose.par)
  temp.stopband_min_powers<-temp.decimation_energies_object$out.stopband_min_powers
  temp.stopband_min_optimal_indices<-temp.decimation_energies_object$out.min_optimal_indices
  temp.stopband_min_optimal_frequencies<-frequencies.par[temp.stopband_min_optimal_indices]
  temp.stopband.max_powers<-temp.decimation_energies_object$out.stopband_max_powers
  temp.stopband_max_optimal_indices<-temp.decimation_energies_object$out.max_optimal_indices
  temp.stopband_max_optimal_frequencies<-frequencies.par[temp.stopband_max_optimal_indices]
  temp.list<-list(out.stopband_min_powers=temp.stopband_min_powers,
                  out.stopband_min_optimal_indices=temp.stopband_min_optimal_indices,
                  out.stopband_min_optimal_frequencies=temp.stopband_min_optimal_frequencies,
                  out.stopband.max_powers=temp.stopband.max_powers,
                  out.stopband_max_optimal_indices=temp.stopband_max_optimal_indices,
                  out.stopband_max_optimal_frequencies=temp.stopband_max_optimal_frequencies,
                  out.all_passbands=temp.all_passbands)
  if(filters_bool.par==TRUE){
    #Decimation filter selection.  The choice of established decimation filters is from "Comparison with other linear filters" on the page,
    #https://en.wikipedia.org/wiki/Butterworth_filter
    #and the filters listed on that page are what one would expect to use based on Blackman & Tukey and from ELEC 421.
    #The values are fairly rigid, obtain NA's or PTF<PTF.cutoff only before the end of the passband.
    #These values have been computed using trial and error with the code below.
    temp.TF_object<-transfer_function.function(passband_cutoffs.par=temp.all_passbands,frequencies.par=frequencies.par,
                                               stopband_min_powers.par=temp.stopband_min_powers,
                                               stopband_max_powers.par=temp.stopband.max_powers,
                                               stopband_max_optimal_indices.par=temp.stopband_max_optimal_indices,
                                               sampling_rate.par=sampling_rate.par,N.par=N.par,M.par=M.par,
                                               num_fitting_indices.par=num_fitting_indices.par,
                                               filter_labels.par=filter_labels.par,old_directory.par=old_directory.par,
                                               output_bool.par=TRUE,plot_bool.par=FALSE)
    temp.filter_TF_lists<-temp.TF_object$out.filter_TF_lists
    temp.filter_object_lists<-temp.TF_object$out.filter_object_lists
    temp.parameter_matrix_list<-temp.TF_object$out.parameter_matrix_list
    temp.NW<-temp.TF_object$out.NW
    temp.list<-list(out.filter_TF_lists=temp.filter_TF_lists,
                    out.stopband_min_powers=temp.stopband_min_powers,
                    out.stopband_min_optimal_indices=temp.stopband_min_optimal_indices,
                    out.stopband_min_optimal_frequencies=temp.stopband_min_optimal_frequencies,
                    out.stopband.max_powers=temp.stopband.max_powers,
                    out.stopband_max_optimal_indices=temp.stopband_max_optimal_indices,
                    out.stopband_max_optimal_frequencies=temp.stopband_max_optimal_frequencies,
                    out.filter_object_lists=temp.filter_object_lists,
                    out.all_passbands=temp.all_passbands,
                    out.parameter_matrix_list=temp.parameter_matrix_list,
                    out.NW=temp.NW)
  }
  if(verbose.par==TRUE){
    cat("Exploratory filter analysis:")
    toc()
  }
  return(temp.list)
}


bp_filter.function<-function(passband_cutoffs.par,frequencies.par,passband_cutoffs2.par,stopband_min_powers.par=NA,
                             stopband_max_powers.par=NA,stopband_max_optimal_indices.par=NA,
                             sampling_rate.par,N.par,M.par,num_fitting_indices.par=10,filter_type_thresholds.par=c(50,1e3),old_directory.par="",
                             stats_bool.par=FALSE,verbose.par=FALSE){
  #Compute the decimated versions of the voltage series using the selected filters.
  if(verbose.par==TRUE){
    tic()
  }
  temp.cutoffs2<-c()
  if(is.matrix(passband_cutoffs2.par)==TRUE){
    temp.cutoffs2<-passband_cutoffs2.par[,2]
    temp.cutoffs2<-unique(temp.cutoffs2)
  }
  else{
    temp.cutoffs2<-passband_cutoffs2.par
  }
  temp.num_passbands=length(passband_cutoffs.par)
  temp.filter_strings<-c("Slepian","Butterworth","Chebyshev_I")
  temp.filter_labels<-rep("",temp.num_passbands)
  #Keep the filter as flexible as possible based on the stop-band information considered,
  #since the filters not explored in detail might have some extra mass in the stop band which is difficult to attenuate.
  #Choose the maximum of both the minimum and maximum powers from the low- and high-frequency bands.
  temp.max_low_frequency_cutoff_min_power=0
  temp.max_low_frequency_cutoff_max_power=0
  temp.max_low_frequency_cutoff_max_optimal_indices<-rep(1,2)
  if(min(temp.cutoffs2)<=filter_type_thresholds.par[1] & !is.na(stopband_min_powers.par)){
    temp.max_low_frequency_cutoff_min_power=max(Mod(stopband_min_powers.par[temp.cutoffs2<=filter_type_thresholds.par[1]]))
    temp.max_low_frequency_cutoff_max_power=max(Mod(stopband_max_powers.par[temp.cutoffs2<=filter_type_thresholds.par[1]]))
    temp.max_low_frequency_cutoff_max_optimal_indices<-
      stopband_max_optimal_indices.par[min(which(Mod(stopband_max_powers.par)==temp.max_low_frequency_cutoff_max_power)),]
  }
  temp.max_high_frequency_cutoff_min_power=0
  temp.max_high_frequency_cutoff_max_power=0
  temp.max_high_frequency_cutoff_max_optimal_indices<-rep(1,2)
  if(max(temp.cutoffs2)>filter_type_thresholds.par[2] & !is.na(stopband_min_powers.par)){
    temp.max_high_frequency_cutoff_min_power=max(Mod(stopband_min_powers.par[temp.cutoffs2>filter_type_thresholds.par[2]]))
    temp.max_high_frequency_cutoff_max_power=max(Mod(stopband_max_powers.par[temp.cutoffs2>filter_type_thresholds.par[2]]))
    temp.max_high_frequency_cutoff_max_optimal_indices<-
      stopband_max_optimal_indices.par[min(which(Mod(stopband_max_powers.par)==temp.max_high_frequency_cutoff_max_power)),]
  }
  temp.stopband_min_powers<-rep(0,temp.num_passbands)
  temp.stopband_max_powers<-rep(0,temp.num_passbands)
  temp.stopband_max_optimal_indices<-matrix(0,nrow=temp.num_passbands,ncol=2)
  for(temp.j in 1:temp.num_passbands){
    temp.cutoff=passband_cutoffs.par[temp.j]
    if(temp.cutoff<=filter_type_thresholds.par[1]){
      temp.filter_labels[temp.j]<-temp.filter_strings[1]
      temp.stopband_min_powers[temp.j]=temp.max_low_frequency_cutoff_min_power
      temp.stopband_max_powers[temp.j]=temp.max_low_frequency_cutoff_max_power
      temp.stopband_max_optimal_indices[temp.j,]<-temp.max_low_frequency_cutoff_max_optimal_indices
    }
    else{
      if(temp.cutoff<=filter_type_thresholds.par[2]){
        temp.filter_labels[temp.j]<-temp.filter_strings[3]
      }
      else if(temp.cutoff>filter_type_thresholds.par[2]){
        temp.filter_labels[temp.j]<-temp.filter_strings[3]
      }
      temp.stopband_min_powers[temp.j]=temp.max_high_frequency_cutoff_min_power
      temp.stopband_max_powers[temp.j]=temp.max_high_frequency_cutoff_max_power
      temp.stopband_max_optimal_indices[temp.j,]<-temp.max_high_frequency_cutoff_max_optimal_indices
    }
  }
  temp.TF_object<-transfer_function.function(passband_cutoffs.par=passband_cutoffs.par,frequencies.par=frequencies.par,
                                             stopband_min_powers.par=temp.stopband_min_powers,
                                             stopband_max_powers.par=temp.stopband_max_powers,
                                             stopband_max_optimal_indices.par=temp.stopband_max_optimal_indices,
                                             sampling_rate.par=sampling_rate.par,N.par=N.par,M.par=M.par,num_fitting_indices.par=num_fitting_indices.par,
                                             filter_labels.par=temp.filter_strings,old_directory.par=old_directory.par,
                                             output_bool.par=FALSE,plot_bool.par=FALSE)
  temp.filter_TF_lists<-temp.TF_object$out.filter_TF_lists
  temp.filter_object_lists<-temp.TF_object$out.filter_object_lists
  temp.parameter_matrix_list<-temp.TF_object$out.parameter_matrix_list
  temp.NW<-temp.TF_object$out.NW
  temp.filter_indices<-rep(1,temp.num_passbands)
  for(temp.j in 1:temp.num_passbands){
    temp.filter_indices[temp.j]=which(temp.filter_strings==temp.filter_labels[temp.j])
  }
  temp.filter_list<-list()
  temp.TF_values_list<-list()
  temp.TF_frequencies_list<-list()
  temp.filter_object_list<-list()
  for(temp.j in 1:temp.num_passbands){
    temp.cutoff=passband_cutoffs.par[temp.j]
    cat(temp.j,": temp.cutoff = ",temp.cutoff,"\n")
    temp.matrix_list<-temp.filter_TF_lists[[temp.j]]
    temp.filter_index=temp.filter_indices[temp.j]
    cat("temp.filter_index = ",temp.filter_index,"\n")
    temp.cutoff=passband_cutoffs.par[temp.j]
    temp.matrix<-temp.matrix_list[[temp.filter_index]]
    temp.TF<-temp.matrix[,2]
    temp.TF_values_list[[temp.j]]<-temp.TF
    temp.TF_frequencies_list[[temp.j]]<-temp.matrix[,1]
    temp.filter_sequence<-filter_sequence.function(temp.TF,N.par,normalization_bool.par=TRUE)
    temp.filter_list[[temp.j]]<-temp.filter_sequence
    temp.filter_object_list[[temp.j]]<-temp.filter_object_lists[[temp.j]][[temp.filter_index]]
  }
  temp.list<-list(out.filter_list=temp.filter_list,
                  out.filter_object_list=temp.filter_object_list,
                  out.parameter_matrix_list=temp.parameter_matrix_list,
                  out.NW=temp.NW,
                  out.TF_values_list=temp.TF_values_list,
                  out.TF_frequencies_list=temp.TF_frequencies_list)
  if(verbose.par==TRUE){
    cat("bp_filter: ")
    toc()
  }
  return(temp.list)
}


add_demodulates.function<-function(previous_time_sequence.par,previous_voltage_series.par,current_time_sequence.par,current_voltage_series.par){
  temp.previous_end_times<-c(min(previous_time_sequence.par),max(previous_time_sequence.par))
  temp.current_end_times<-c(min(current_time_sequence.par),max(current_time_sequence.par))
  temp.max_start_time=max(c(temp.previous_end_times[1],temp.current_end_times[1]))
  temp.min_end_time=max(c(temp.previous_end_times[2],temp.current_end_times[2]))
  temp.summed_series_times<-
    current_time_sequence.par[which(current_time_sequence.par>=temp.max_start_time & current_time_sequence.par<=temp.min_end_time)]
  temp.summed_series<-
    previous_voltage_series.par[which(previous_time_sequence.par>=temp.max_start_time & previous_time_sequence.par<=temp.min_end_time)]+
    current_voltage_series.par[which(current_time_sequence.par>=temp.max_start_time & current_time_sequence.par<=temp.min_end_time)]
  temp.list<-list(out.summed_series_times=temp.summed_series_times,
                  out.summed_series=temp.summed_series)
  return(temp.list)
}


bp_filter_comparison.function<-function(times.par,ts.par,harmonic_reconstructions.par=NA,significant_frequencies.par=NA,
                                        harmonic_reconstruction_indices.par=NA,
                                        bands_matrix.par,filter_list.par,filter_object_list.par,parameter_matrix_list.par,
                                        sampling_rate.par,passband_cutoffs.par,measured_abscissa.par="Time",measure_quantity.par="Voltage",
                                        x_units.par="seconds",y_units.par="volts",pdf_title.par="Reconstructed_Voltage_Demodulate",
                                        reconstruction_bool.par=FALSE,plot_bool.par=FALSE,verbose.par=FALSE,old_directory.par="",
                                        filter_type_thresholds.par=c(50,1e3),original_sampling_bool.par=FALSE){
  if(is.null(harmonic_reconstruction_indices.par)==TRUE){
    harmonic_reconstruction_indices.par<-c(1)
  }
  temp.num_passbands=nrow(bands_matrix.par)
  temp.all_band_separations<-rep(0,temp.num_passbands-1)
  for(temp.i in 2:temp.num_passbands){
    temp.first_frequency_left_band=bands_matrix.par[temp.i-1]
    temp.first_frequency_right_band=bands_matrix.par[temp.i]
    temp.all_band_separations[temp.i-1]<-abs(temp.first_frequency_right_band-temp.first_frequency_left_band)
  }
  temp.unique_band_separations<-unique(temp.all_band_separations)
  temp.num_unique=length(temp.unique_band_separations)
  temp.reconstruction_bool=reconstruction_bool.par
  if(temp.num_unique==1 & temp.num_passbands>1){
    temp.reconstruction_bool=TRUE
  }
  temp.original_series_list<-list()
  temp.original_series_times_list<-list()
  temp.decimated_series_times_list<-list()
  temp.decimated_series_list<-list()
  temp.kramer_decimated_series_list<-list()
  temp.kramer_decimated_series_times_list<-list()
  temp.martinet_decimated_series_list<-list()
  temp.martinet_decimated_series_times_list<-list()
  temp.schevon_decimated_series_list<-list()
  temp.schevon_decimated_series_times_list<-list()
  temp.schlafly_decimated_series_list<-list()
  temp.schlafly_decimated_series_times_list<-list()
  temp.strings<-rep(0,temp.num_passbands)
  temp.filter_parameter_strings<-c()
  temp.Kramer_strings<-temp.strings
  temp.Martinet_strings<-temp.Kramer_strings
  temp.Schevon_strings<-temp.strings
  temp.Schlafly_strings<-temp.strings
  temp.title_strings<-rep("",temp.num_passbands)
  for(temp.j in 1:temp.num_passbands){
    if(verbose.par==TRUE){
      cat(temp.j," out of ",temp.num_passbands,"\n")
    }
    temp.passband<-bands_matrix.par[temp.j,]
    temp.title_strings[temp.j]<-paste("[",temp.passband[1],",",temp.passband[2],") ",abbreviated_frequency_units.string,sep="")
    temp.bpf_object<-bandpass_filter.function(times.par,ts.par,temp.passband,harmonic_reconstructions.par,significant_frequencies.par,
                                              harmonic_reconstruction_indices.par,
                                              filter_list.par,filter_object_list.par,parameter_matrix_list.par,sampling_rate.par,
                                              new_sampling_rate.par=2*temp.passband[2],passband_cutoffs.par,
                                              original_sampling_bool.par=original_sampling_bool.par,invert_bool.par=TRUE,
                                              filter_type_thresholds.par=filter_type_thresholds.par)
    temp.decimated_series_times<-temp.bpf_object$out.decimated_series_times
    temp.decimated_series<-temp.bpf_object$out.decimated_series
    temp.string<-temp.bpf_object$out.filter_type_string
    temp.Marshall_bandwidth_parameter<-temp.bpf_object$out.bandwidth_parameter
    if(!temp.reconstruction_bool || temp.j==1){
      temp.decimated_series_times_list[[temp.j]]<-temp.decimated_series_times
      temp.decimated_series_list[[temp.j]]<-temp.decimated_series
      temp.strings[temp.j]<-paste(temp.title_strings[temp.j],", ",temp.string,sep="")
    }
    else{
      temp.summed_demodulate_object<-add_demodulates.function(previous_time_sequence.par=temp.decimated_series_times_list[[temp.j-1]],
                                                              previous_voltage_series.par=temp.decimated_series_list[[temp.j-1]],
                                                              current_time_sequence.par=temp.decimated_series_times,
                                                              current_voltage_series.par=temp.decimated_series)
      temp.decimated_series_times_list[[temp.j]]<-temp.summed_demodulate_object$out.summed_series_times
      temp.decimated_series_list[[temp.j]]<-temp.summed_demodulate_object$out.summed_series
    }
    #Implement the filter from "run_seizing_cortical_field.m"
    #https://github.com/Mark-Kramer/Seizure-Waves/blob/master/modeling/run_seizing_cortical_field.m.
    #The following description is provided of the "decimate" function used in the above Matlab code.
    #y = decimate(x,r) reduces the sample rate of x, the input signal, by a factor of r.
    #The decimated vector, y, is shortened by a factor of r so that length(y) = ceil(length(x)/r)
    #By default, decimate uses a lowpass Chebyshev Type I infinite impulse response (IIR) filter of order 8.
    temp.bpf_object<-bandpass_filter.function(times.par,ts.par,temp.passband,harmonic_reconstructions.par,significant_frequencies.par,
                                              harmonic_reconstruction_indices.par,
                                              filter_list.par,filter_object_list.par,parameter_matrix_list.par,sampling_rate.par,
                                              new_sampling_rate.par=2*temp.passband[2],
                                              passband_cutoffs.par,bandpass_specification.par="Kramer",
                                              original_sampling_bool.par=original_sampling_bool.par,invert_bool.par=TRUE,
                                              filter_type_thresholds.par=filter_type_thresholds.par)
    temp.decimated_series_times<-temp.bpf_object$out.decimated_series_times
    temp.decimated_series<-temp.bpf_object$out.decimated_series
    temp.string<-temp.bpf_object$out.filter_type_string
    temp.filter_specification_string<-temp.bpf_object$out.filter_specification_string
    temp.Kramer_bandwidth_parameter<-temp.bpf_object$out.bandwidth_parameter
    if(!temp.reconstruction_bool || temp.j==1){
      temp.kramer_decimated_series_times_list[[temp.j]]<-temp.decimated_series_times
      temp.kramer_decimated_series_list[[temp.j]]<-temp.decimated_series
      temp.Kramer_strings[temp.j]<-paste(temp.title_strings[temp.j],", ",temp.string,sep="")
    }
    else{
      temp.summed_demodulate_object<-add_demodulates.function(previous_time_sequence.par=temp.kramer_decimated_series_times_list[[temp.j-1]],
                                                              previous_voltage_series.par=temp.kramer_decimated_series_list[[temp.j-1]],
                                                              current_time_sequence.par=temp.decimated_series_times,
                                                              current_voltage_series.par=temp.decimated_series)
      temp.kramer_decimated_series_times_list[[temp.j]]<-temp.summed_demodulate_object$out.summed_series_times
      temp.kramer_decimated_series_list[[temp.j]]<-temp.summed_demodulate_object$out.summed_series
    }
    #The filter from Martinet et al. (2017).
    temp.bpf_object<-bandpass_filter.function(times.par,ts.par,temp.passband,harmonic_reconstructions.par,significant_frequencies.par,
                                              harmonic_reconstruction_indices.par,
                                              filter_list.par,filter_object_list.par,parameter_matrix_list.par,sampling_rate.par,
                                              new_sampling_rate.par=2*temp.passband[2],passband_cutoffs.par,
                                              bandpass_specification.par="Martinet",original_sampling_bool.par=original_sampling_bool.par,invert_bool.par=TRUE,
                                              filter_type_thresholds.par=filter_type_thresholds.par)
    temp.decimated_series_times<-temp.bpf_object$out.decimated_series_times
    temp.decimated_series<-temp.bpf_object$out.decimated_series
    temp.string<-temp.bpf_object$out.filter_type_string
    temp.Martinet_bandwidth_parameter<-temp.bpf_object$out.bandwidth_parameter
    if(!temp.reconstruction_bool || temp.j==1){
      temp.martinet_decimated_series_times_list[[temp.j]]<-temp.decimated_series_times
      temp.martinet_decimated_series_list[[temp.j]]<-temp.decimated_series
      temp.Martinet_strings[temp.j]<-paste(temp.title_strings[temp.j],", ",temp.string,sep="")
    }
    else{
      temp.summed_demodulate_object<-add_demodulates.function(previous_time_sequence.par=temp.martinet_decimated_series_times_list[[temp.j-1]],
                                                              previous_voltage_series.par=temp.martinet_decimated_series_list[[temp.j-1]],
                                                              current_time_sequence.par=temp.decimated_series_times,
                                                              current_voltage_series.par=temp.decimated_series)
      temp.martinet_decimated_series_times_list[[temp.j]]<-temp.summed_demodulate_object$out.summed_series_times
      temp.martinet_decimated_series_list[[temp.j]]<-temp.summed_demodulate_object$out.summed_series
    }
    #The filter from Schevon et al. (2012).
    temp.bpf_object<-bandpass_filter.function(times.par,ts.par,temp.passband,harmonic_reconstructions.par,significant_frequencies.par,
                                              harmonic_reconstruction_indices.par,
                                              filter_list.par,filter_object_list.par,parameter_matrix_list.par,sampling_rate.par,
                                              new_sampling_rate.par=2*temp.passband[2],passband_cutoffs.par,
                                              bandpass_specification.par="Schevon",original_sampling_bool.par=original_sampling_bool.par,invert_bool.par=TRUE,
                                              filter_type_thresholds.par=filter_type_thresholds.par)
    temp.decimated_series_times<-temp.bpf_object$out.decimated_series_times
    temp.decimated_series<-temp.bpf_object$out.decimated_series
    temp.string<-temp.bpf_object$out.filter_type_string
    temp.Schevon_bandwidth_parameter<-temp.bpf_object$out.bandwidth_parameter
    if(!temp.reconstruction_bool || temp.j==1){
      temp.schevon_decimated_series_times_list[[temp.j]]<-temp.decimated_series_times
      temp.schevon_decimated_series_list[[temp.j]]<-temp.decimated_series
      temp.Schevon_strings[temp.j]<-paste(temp.title_strings[temp.j],", ",temp.string,sep="")
    }
    else{
      temp.summed_demodulate_object<-add_demodulates.function(previous_time_sequence.par=temp.schevon_decimated_series_times_list[[temp.j-1]],
                                                              previous_voltage_series.par=temp.schevon_decimated_series_list[[temp.j-1]],
                                                              current_time_sequence.par=temp.decimated_series_times,
                                                              current_voltage_series.par=temp.decimated_series)
      temp.schevon_decimated_series_times_list[[temp.j]]<-temp.summed_demodulate_object$out.summed_series_times
      temp.schevon_decimated_series_list[[temp.j]]<-temp.summed_demodulate_object$out.summed_series
    }
    #Schafly's filter.
    temp.bpf_object<-bandpass_filter.function(times.par,ts.par,temp.passband,harmonic_reconstructions.par,significant_frequencies.par,
                                              harmonic_reconstruction_indices.par,
                                              filter_list.par,filter_object_list.par,parameter_matrix_list.par,sampling_rate.par,
                                              new_sampling_rate.par=2*temp.passband[2],passband_cutoffs.par,
                                              bandpass_specification.par="Schlafly",original_sampling_bool.par=original_sampling_bool.par,invert_bool.par=TRUE,
                                              filter_type_thresholds.par=filter_type_thresholds.par)
    temp.decimated_series_times<-temp.bpf_object$out.decimated_series_times
    temp.decimated_series<-temp.bpf_object$out.decimated_series
    temp.string<-temp.bpf_object$out.filter_type_string
    temp.Schlafly_bandwidth_parameter<-temp.bpf_object$out.bandwidth_parameter
    if(!temp.reconstruction_bool || temp.j==1){
      temp.schlafly_decimated_series_times_list[[temp.j]]<-temp.decimated_series_times
      temp.schlafly_decimated_series_list[[temp.j]]<-temp.decimated_series
      temp.Schlafly_strings[temp.j]<-paste(temp.title_strings[temp.j],", ",temp.string,sep="")
    }
    else{
      temp.summed_demodulate_object<-add_demodulates.function(previous_time_sequence.par=temp.schlafly_decimated_series_times_list[[temp.j-1]],
                                                              previous_voltage_series.par=temp.schlafly_decimated_series_list[[temp.j-1]],
                                                              current_time_sequence.par=temp.decimated_series_times,
                                                              current_voltage_series.par=temp.decimated_series)
      temp.schlafly_decimated_series_times_list[[temp.j]]<-temp.summed_demodulate_object$out.summed_series_times
      temp.schlafly_decimated_series_list[[temp.j]]<-temp.summed_demodulate_object$out.summed_series
    }
    #Store the original voltage series to assess the performance of the filter.
    temp.original_series_times_list[[temp.j]]<-times.par
    temp.original_series_list[[temp.j]]<-ts.par
  }
  if(plot_bool.par==TRUE){
    temp.all_decimated_series_min=min(c(min(unlist(temp.original_series_times_list)),
                                        min(unlist(temp.decimated_series_list)),
                                        min(unlist(temp.kramer_decimated_series_list)),
                                        min(unlist(temp.martinet_decimated_series_list)),
                                        min(unlist(temp.schevon_decimated_series_times_list)),
                                        min(unlist(temp.schlafly_decimated_series_times_list))
    ))
    temp.all_decimated_series_max=max(c(max(unlist(temp.original_series_times_list)),
                                        max(unlist(temp.decimated_series_list)),
                                        max(unlist(temp.kramer_decimated_series_list)),
                                        max(unlist(temp.martinet_decimated_series_list)),
                                        max(unlist(temp.schevon_decimated_series_list)),
                                        max(unlist(temp.schlafly_decimated_series_list))
    ))
    temp.bounds_all=c(temp.all_decimated_series_min,temp.all_decimated_series_max)
    temp.string<-"Demodulate_Reconstructions"
    dir.create(temp.string,showWarnings=FALSE)
    setwd(temp.string)
    temp.plotting_object<-plot_ts_data_and_reconstruction_overlay.function(temp.original_series_times_list,temp.original_series_list,
                                                                           temp.decimated_series_times_list,temp.decimated_series_list,temp.bounds_all,
                                                                           time_units.par=x_units.par,y_units.par=y_units.par,
                                                                           titles_sequence.par=temp.strings,
                                                                           pdf_title.par=paste(pdf_title.par,"_Marshall.pdf",sep=""),
                                                                           x_scale.par=1/60)
    temp.plotting_object<-plot_ts_data_and_reconstruction_overlay.function(temp.original_series_times_list,temp.original_series_list,
                                                                           temp.kramer_decimated_series_times_list,temp.kramer_decimated_series_list,
                                                                           temp.bounds_all,time_units.par=x_units.par,y_units.par=y_units.par,
                                                                           titles_sequence.par=temp.Kramer_strings,
                                                                           pdf_title.par=paste(pdf_title.par,"_Kramer.pdf",sep=""),
                                                                           x_scale.par=1/60)
    temp.plotting_object<-plot_ts_data_and_reconstruction_overlay.function(temp.original_series_times_list,temp.original_series_list,
                                                                           temp.martinet_decimated_series_times_list,temp.martinet_decimated_series_list,
                                                                           temp.bounds_all,time_units.par=x_units.par,y_units.par=y_units.par,
                                                                           titles_sequence.par=temp.Martinet_strings,
                                                                           pdf_title.par=paste(pdf_title.par,"_Martinet.pdf",sep=""),
                                                                           x_scale.par=1/60)
    temp.plotting_object<-plot_ts_data_and_reconstruction_overlay.function(temp.original_series_times_list,temp.original_series_list,
                                                                           temp.schevon_decimated_series_times_list,temp.schevon_decimated_series_list,
                                                                           temp.bounds_all,time_units.par=x_units.par,y_units.par=y_units.par,
                                                                           titles_sequence.par=temp.Schevon_strings,
                                                                           pdf_title.par=paste(pdf_title.par,"_Schevon.pdf",sep=""),
                                                                           x_scale.par=1/60)
    temp.plotting_object<-plot_ts_data_and_reconstruction_overlay.function(temp.original_series_times_list,temp.original_series_list,
                                                                           temp.schlafly_decimated_series_times_list,temp.schlafly_decimated_series_list,
                                                                           temp.bounds_all,time_units.par=x_units.par,y_units.par=y_units.par,
                                                                           titles_sequence.par=temp.Schlafly_strings,
                                                                           pdf_title.par=paste(pdf_title.par,"_Schlafly.pdf",sep=""),
                                                                           x_scale.par=1/60)
    setwd(old_directory.par)
  }
  temp.filter_parameter_strings<-list(paste(temp.strings,", ",temp.Marshall_bandwidth_parameter,sep=""),
                                      paste(temp.Kramer_strings,", ",temp.Kramer_bandwidth_parameter,sep=""),
                                      paste(temp.Martinet_strings,", ",temp.Martinet_bandwidth_parameter,sep=""),
                                      paste(temp.Schevon_strings,", ",temp.Schevon_bandwidth_parameter,sep=""),
                                      paste(temp.Schlafly_strings,", ",temp.Schlafly_bandwidth_parameter,sep=""))
  temp.list<-list(out.decimated_series_times_list=temp.decimated_series_times_list,
                  out.decimated_series_list=temp.decimated_series_list,
                  out.kramer_decimated_series_times_list=temp.kramer_decimated_series_times_list,
                  out.kramer_decimated_series_list=temp.kramer_decimated_series_list,
                  out.martinet_decimated_series_times_list=temp.martinet_decimated_series_times_list,
                  out.martinet_decimated_series_list=temp.martinet_decimated_series_list,
                  out.schevon_decimated_series_times_list=temp.schevon_decimated_series_times_list,
                  out.schevon_decimated_series_list=temp.schevon_decimated_series_list,
                  out.schlafly_decimated_series_times_list=temp.schlafly_decimated_series_times_list,
                  out.schlafly_decimated_series_list=temp.schlafly_decimated_series_list,
                  out.filter_specification_string=temp.filter_specification_string,
                  out.strings=temp.filter_parameter_strings)
  return(temp.list)
}


filtering_algorithm.function<-function(time_sequence.par,ts.par,harmonic_reconstructions.par=NA,significant_frequencies.par=NA,
                                       harmonic_reconstruction_indices.par=NA,
                                       bifrequency_spectrum_vector.par,frequencies.par,row_indices_vector.par,
                                       column_indices_vector.par,passband_cutoffs.par,passbands_first_frequency.par=NA,passbands_last_frequency.par=NA,
                                       passband_cutoffs2.par=NA,N.par,M.par=0,sampling_rate.par=1,
                                       filter_type_thresholds.par=c(50,1e3),num_fitting_indices.par=10,established_decimation_to_print.par=NA,
                                       filters_bool.par=FALSE,filter_labels.par=c("Slepian","Butterworth","Chebyshev_I"),
                                       filter_label_strings.par=c("Slepian","Butterworth","Chebyshev I","Elliptic"),
                                       measured_abscissa.par="Time",measure_quantity.par="Voltage",
                                       x_units.par="seconds",y_units.par="volts",pdf_title.par="Reconstructed_Voltage_Demodulate",
                                       new_directory.par="Bandpass_Filtering",old_directory.par="",
                                       select_filter.par=FALSE,output_bool.par=FALSE,plot_bool.par=FALSE,verbose.par=FALSE){
  temp.subDir_string<-paste(main_directory.string,new_directory.par,sep="")
  dir.create(temp.subDir_string,showWarnings=FALSE)
  setwd(temp.subDir_string)
  passband_cutoffs.par<-passband_cutoffs.par[passband_cutoffs.par<=(sampling_rate.par/2)]
  passband_cutoffs2.par<-passband_cutoffs2.par[passband_cutoffs2.par<=(sampling_rate.par/2)]
  temp.truncation_indices<-which(passbands_last_frequency.par<=(sampling_rate.par/2))
  passbands_last_frequency.par<-passbands_last_frequency.par[temp.truncation_indices]
  passbands_first_frequency.par<-passbands_first_frequency.par[temp.truncation_indices]
  if(!M.par){
    M.par=N.par
  }
  if(length(which(is.na(passband_cutoffs2.par)==TRUE))>0){
    passband_cutoffs2.par=passband_cutoffs.par
  }
  temp.num_established_decimation=0
  if(!is.na(established_decimation_to_print.par)){
    temp.num_valid_strings=length(established_decimation_to_print.par[established_decimation_to_print.par!=""])
    if(temp.num_valid_strings>0){
      temp.num_established_decimation=temp.num_valid_strings
    }
  }
  temp.num_passbands=length(passband_cutoffs.par)
  temp.passbands<-c()
  if(length(which(is.na(passbands_first_frequency.par)==TRUE))>0){
    temp.passbands<-matrix(0,nrow=temp.num_passbands,ncol=2)
    for(temp.i in 1:temp.num_passbands){
      temp.first_frequency=0
      temp.second_frequency=passband_cutoffs.par[temp.i]
      if(temp.num_passbands>1){
        if(temp.i>1){
          temp.first_frequency[temp.i]=passband_cutoffs.par[temp.i-1]
        }
      }
      temp.passbands[temp.i,]<-c(temp.first_frequency,temp.second_frequency)
    }
  }
  else{
    temp.passbands_first_frequency_list<-list()
    temp.passbands_last_frequency_list<-list()
    temp.num_passbands=length(passbands_first_frequency.par)
    for(temp.i in 1:temp.num_passbands){
      temp.first_frequencies<-passbands_first_frequency.par[temp.i]
      temp.last_frequencies<-passbands_last_frequency.par[temp.i]
      temp.all_first_frequencies<-as.numeric(unlist(temp.passbands_first_frequency_list))
      temp.all_last_frequencies<-as.numeric(unlist(temp.passbands_last_frequency_list))
      temp.first_previous_instances=which(temp.all_first_frequencies==0)
      temp.second_previous_instances=which(temp.all_last_frequencies==passbands_last_frequency.par[temp.i])
      temp.common_previous_instances<-intersect(temp.first_previous_instances,temp.second_previous_instances)
      if(!length(temp.common_previous_instances)){
        if(temp.first_frequencies!=0 & temp.last_frequencies!=(sampling_rate.par/2)){
          temp.first_frequencies<-c(temp.first_frequencies,0)
          temp.last_frequencies<-c(temp.last_frequencies,passbands_last_frequency.par[temp.i])
        }
      }
      temp.passbands_first_frequency_list[[temp.i]]<-temp.first_frequencies
      temp.passbands_last_frequency_list[[temp.i]]<-temp.last_frequencies
    }
    passbands_first_frequency.par<-as.numeric(unlist(temp.passbands_first_frequency_list))
    passbands_last_frequency.par<-as.numeric(unlist(temp.passbands_last_frequency_list))
    passbands_last_frequency.par<-passbands_last_frequency.par[order(passbands_first_frequency.par)]
    passbands_first_frequency.par<-sort(passbands_first_frequency.par)
    temp.unique_first_frequencies<-unique(passbands_first_frequency.par)
    for(temp.i in 1:length(temp.unique_first_frequencies)){
      temp.indices<-which(passbands_first_frequency.par==temp.unique_first_frequencies[temp.i])
      passbands_last_frequency.par[temp.indices]<-sort(passbands_last_frequency.par[temp.indices])
    }
    temp.num_passbands=length(passbands_first_frequency.par)
    temp.passbands<-matrix(0,nrow=temp.num_passbands,ncol=2)
    for(temp.i in 1:temp.num_passbands){
      temp.passbands[temp.i,]<-c(passbands_first_frequency.par[temp.i],passbands_last_frequency.par[temp.i])
    }
    temp.column1<-temp.passbands[,1]
    temp.column2<-temp.passbands[,2]
    temp.column2<-temp.column2[order(temp.column1)]
    temp.column1<-sort(temp.column1)
    temp.passbands[,1]<-temp.column1
    temp.passbands[,2]<-temp.column2
  }
  temp.passband_list<-list()
  temp.passband_list[[1]]<-temp.passbands[1,]
  temp.column1<-temp.passbands[,1]
  temp.column2<-temp.passbands[,2]
  temp.passband_counter=2
  for(temp.i in 2:nrow(temp.passbands)){
    temp.row<-temp.passbands[temp.i,]
    temp.previous_instance_indices_column1<-which(temp.column1[1:(temp.i-1)]==temp.row[1])
    temp.column2_frequencies<-temp.column2[temp.previous_instance_indices_column1]
    temp.previous_instance_indices_column2<-which(temp.column2_frequencies==temp.row[2])
    if(!length(temp.previous_instance_indices_column2)){
      temp.passband_list[[temp.passband_counter]]<-temp.row
      temp.passband_counter=temp.passband_counter+1
    }
  }
  temp.revised_num_passbands=length(temp.passband_list)
  temp.matrix<-matrix(0,nrow=temp.revised_num_passbands,ncol=2)
  for(temp.i in 1:temp.revised_num_passbands){
    temp.matrix[temp.i,]<-temp.passband_list[[temp.i]]
  }
  temp.passbands<-temp.matrix
  #Compute the relevant stopband statistics used to determine the data adaptive filter.  Also, assess the effects of aliasing using the
  #l_1-norm metric.
  temp.bp_exploratory_analysis_object<-bp_exploratory_analysis.function(bifrequency_spectrum_vector.par=bifrequency_spectrum_vector.par,
                                                                        frequencies.par=frequencies.par,row_indices_vector.par=row_indices_vector.par,
                                                                        column_indices_vector.par=column_indices_vector.par,
                                                                        first_frequencies.par=temp.passbands[,1],
                                                                        second_frequencies.par=temp.passbands[,2],
                                                                        passband_cutoffs.par=passband_cutoffs.par,N.par=N.par,M.par=M.par,
                                                                        sampling_rate.par=sampling_rate.par,
                                                                        num_fitting_indices.par=num_fitting_indices.par,
                                                                        filters_bool.par=filters_bool.par,filter_labels.par=filter_labels.par,
                                                                        old_directory.par=temp.subDir_string,verbose.par=FALSE)
  temp.stopband_min_powers<-temp.bp_exploratory_analysis_object$out.stopband_min_powers
  temp.stopband_max_powers<-temp.bp_exploratory_analysis_object$out.stopband.max_powers
  temp.stopband_max_optimal_indices<-temp.bp_exploratory_analysis_object$out.stopband_max_optimal_indices
  temp.all_passbands<-temp.bp_exploratory_analysis_object$out.all_passbands
  temp.NW<-temp.bp_exploratory_analysis_object$out.NW
  if(select_filter.par==TRUE & !is.na(filter_label_strings.par)){
    #Decimation filter selection.  The choice of established decimation filters is from "Comparison with other linear filters" on the page,
    #https://en.wikipedia.org/wiki/Butterworth_filter
    #and the filters listed on that page are what one would expect to use based on Blackman & Tukey and from ELEC 421.
    #The values are fairly rigid, obtain NA's or PTF<PTF.cutoff only before the end of the passband.
    #These values have been computed using trial and error with the code below.
    temp.string<-"Transfer_Function"
    dir.create(temp.string,showWarnings=FALSE)
    setwd(temp.string)
    temp.TF_object<-transfer_function.function(passband_cutoffs.par=temp.all_passbands,frequencies.par=frequencies.par,
                                               stopband_min_powers.par=temp.stopband_min_powers,
                                               stopband_max_powers.par=temp.stopband_max_powers,
                                               stopband_max_optimal_indices.par=temp.stopband_max_optimal_indices,
                                               sampling_rate.par=sampling_rate.par,N.par=N.par,M.par=M.par,
                                               num_fitting_indices.par=num_fitting_indices.par,
                                               filter_labels.par=filter_labels.par,old_directory.par=old_directory.par,
                                               output_bool.par=output_bool.par,plot_bool.par=plot_bool.par)
    setwd(old_directory.par)
  }
  #Compute the decimation filters for the considered pass bands.
  temp.bp_filter_object<-bp_filter.function(passband_cutoffs.par=temp.all_passbands,frequencies.par=frequencies.par,
                                            passband_cutoffs2.par=temp.passbands,
                                            stopband_min_powers.par=temp.stopband_min_powers,
                                            stopband_max_powers.par=temp.stopband_max_powers,
                                            stopband_max_optimal_indices.par=temp.stopband_max_optimal_indices,
                                            sampling_rate.par=sampling_rate.par,N.par=N.par,M.par=M.par,
                                            num_fitting_indices.par=num_fitting_indices.par,
                                            filter_type_thresholds.par=filter_type_thresholds.par,
                                            old_directory.par=old_directory.par,verbose.par=verbose.par)
  temp.filter_list<-temp.bp_filter_object$out.filter_list
  temp.filter_object_list<-temp.bp_filter_object$out.filter_object_list
  temp.parameter_matrix_list<-temp.bp_filter_object$out.parameter_matrix_list
  temp.NW<-temp.bp_filter_object$out.NW
  #Test some pass bands typically used in the literature.
  setwd("Bandpass_Filtering")
  temp.title_strings<-rep("",temp.num_passbands)
  temp.string<-"Demodulate_Methods_Comparison"
  dir.create(temp.string,showWarnings=FALSE)
  setwd(temp.string)
  cat("significant_frequencies.par\n")
  print(significant_frequencies.par)
  select_temp.bp_filter_comparison_object<-bp_filter_comparison.function(time_sequence.par,ts.par,harmonic_reconstructions.par,significant_frequencies.par,
                                                                         harmonic_reconstruction_indices.par,
                                                                         temp.passbands,temp.filter_list,temp.filter_object_list,temp.parameter_matrix_list,
                                                                         sampling_rate.par,passband_cutoffs.par,measured_abscissa.par=measured_abscissa.par,
                                                                         measure_quantity.par=measure_quantity.par,x_units.par=x_units.par,
                                                                         y_units.par=y_units.par,pdf_title.par=pdf_title.par,reconstruction_bool.par=FALSE,
                                                                         plot_bool.par=plot_bool.par,verbose.par=verbose.par,
                                                                         old_directory.par=old_directory.par,
                                                                         filter_type_thresholds.par=filter_type_thresholds.par)
  setwd(paste(old_directory.par,"/Bandpass_Filtering",sep=""))
  temp.decimated_series_times_list=select_temp.bp_filter_comparison_object$out.decimated_series_times_list
  temp.decimated_series_list=select_temp.bp_filter_comparison_object$out.decimated_series_list
  temp.kramer_decimated_series_times_list<-select_temp.bp_filter_comparison_object$out.kramer_decimated_series_times_list
  temp.kramer_decimated_series_list<-select_temp.bp_filter_comparison_object$out.kramer_decimated_series_list
  temp.martinet_decimated_series_times_list<-select_temp.bp_filter_comparison_object$out.martinet_decimated_series_times_list
  temp.martinet_decimated_series_list<-select_temp.bp_filter_comparison_object$out.martinet_decimated_series_list
  temp.schevon_decimated_series_times_list<-select_temp.bp_filter_comparison_object$out.schevon_decimated_series_times_list
  temp.schevon_decimated_series_list<-select_temp.bp_filter_comparison_object$out.schevon_decimated_series_list
  temp.schlafly_decimated_series_times_list<-select_temp.bp_filter_comparison_object$out.schlafly_decimated_series_times_list
  temp.schlafly_decimated_series_list<-select_temp.bp_filter_comparison_object$out.schlafly_decimated_series_list
  temp.strings<-select_temp.bp_filter_comparison_object$out.strings
  if(output_bool.par==TRUE){
    #Output each of the decimated series to file.
    #Create the working directory unless it already exists.
    dir.create("Decimated_Series",showWarnings=FALSE)
    #Set working directory, so that the plot will not be saved under the home directory; rather, it should be saved in the current, or working directory.
    temp.decimated_series_directory_string<-paste(temp.subDir_string,"/Decimated_Series",sep="")
    setwd(temp.decimated_series_directory_string)
    dir.create("Marshall",showWarnings=FALSE)
    #Set working directory, so that the plot will not be saved under the home directory; rather, it should be saved in the current, or working directory.
    setwd(temp.decimated_series_directory_string)
    for(temp.i in 1:length(temp.decimated_series_times_list)){
      temp.decimated_voltage_times<-temp.decimated_series_times_list[[temp.i]]
      temp.decimated_voltage_series<-temp.decimated_series_list[[temp.i]]
      temp.N_decimated=length(temp.decimated_voltage_series)
      sink(paste("Marshall/Decimated_Series_",2*temp.passbands[temp.i,1],"_",2*temp.passbands[temp.i,2],"_Hz_Sampling.txt",sep=""),
           append=FALSE, split=FALSE)
      cat("index\t",measured_abscissa.par,"\t",measure_quantity.par,"\n")
      for(temp.j in 1:temp.N_decimated){
        cat(temp.j,"\t",formatC(temp.decimated_voltage_times[temp.j],format="e",digits=8),"\t",temp.decimated_voltage_series[temp.j],"\n")
      }
      sink()
    }
    if(temp.num_established_decimation>0){
      for(temp.k in 1:temp.num_established_decimation){
        setwd(temp.decimated_series_directory_string)
        temp.string<-paste(established_decimation_to_print.par[temp.k],sep="")
        dir.create(temp.string,showWarnings=FALSE)
        setwd(temp.string)
        for(temp.i in 1:length(temp.decimated_series_times_list)){
          if(temp.string=="Kramer"){
            temp.times<-temp.kramer_decimated_series_times_list[[temp.i]]
            temp.series<-temp.kramer_decimated_series_list[[temp.i]]
          }
          else if(temp.string=="Martinet"){
            temp.times<-temp.martinet_decimated_series_times_list[[temp.i]]
            temp.series<-temp.martinet_decimated_series_list[[temp.i]]
          }
          else if(temp.string=="Schevon"){
            temp.times<-temp.schevon_decimated_series_times_list[[temp.i]]
            temp.series<-temp.schevon_decimated_series_list[[temp.i]]
          }
          else{
            temp.times<-temp.schlafly_decimated_series_times_list[[temp.i]]
            temp.series<-temp.schlafly_decimated_series_list[[temp.i]]
          }
          temp.N_series_decimated=length(temp.series)
          sink(paste("Decimated_Series_",2*temp.passbands[temp.i,1],"_",2*temp.passbands[temp.i,2],"_Hz_Sampling.txt",sep=""), append=FALSE, split=FALSE)
          cat("index\t",measured_abscissa.par,"\t",measure_quantity.par,"\n")
          for(temp.j in 1:temp.N_series_decimated){
            cat(temp.j,"\t",formatC(temp.times[temp.j],format="e",digits=8),"\t",temp.series[temp.j],"\n")
          }
          sink()
        }
      }
    }
    setwd(temp.subDir_string)
  }
  setwd(old_directory.par)
  temp.list<-list(out.decimated_series_times_list=temp.decimated_series_times_list,
                  out.decimated_series_list=temp.decimated_series_list,
                  out.kramer_decimated_series_times_list=temp.kramer_decimated_series_times_list,
                  out.kramer_decimated_series_list=temp.kramer_decimated_series_list,
                  out.martinet_decimated_series_times_list=temp.martinet_decimated_series_times_list,
                  out.martinet_decimated_series_list=temp.martinet_decimated_series_list,
                  out.schevon_decimated_series_times_list=temp.schevon_decimated_series_times_list,
                  out.schevon_decimated_series_list=temp.schevon_decimated_series_list,
                  out.schlafly_decimated_series_times_list=temp.schlafly_decimated_series_times_list,
                  out.schlafly_decimated_series_list=temp.schlafly_decimated_series_list,
                  out.stopband_min_powers=temp.stopband_min_powers,
                  out.stopband_max_powers=temp.stopband_max_powers,
                  out.stopband_max_optimal_indices=temp.stopband_max_optimal_indices,
                  out.NW=temp.NW)
  return(temp.list)
}


filtering_algorithm_eigencoeff_harmonic.function<-function(ts.par,time_sequence.par,new_directory.par="",old_directory.par="",NW.par=5,sampling_rate.par=1,
                                                           F_test_threshold.par=0.99,num_sections.par=2,threshold_crossings_LB.par=3,
                                                           all_frequencies_bool.par=FALSE,first_time.par=0,demodulate_bool.par=FALSE,
                                                           frequency_band.par=NA,dpss.par=NA,energy_concentrations.par=NA,slepian_functions.par=NA,
                                                           main_directory.par=main_directory.string,measured_quantity.par="",
                                                           method_directory_string.par=""){
  ######################################################################################################################################################
  #Perform a basic multitaper spectral analysis on the raw time series (a pilot analysis).
  ######################################################################################################################################################
  temp.N=length(ts.par)
  temp.K=0
  temp.M=0
  temp.M2=0
  temp.frequencies<-c()
  temp.energy_concentrations<-c()
  temp.ts_eigencoeffs<-c()
  temp.harmonic_reconstructions_list<-c()
  temp.harmonic_reconstruction_indices_list<-c()
  temp.significant_frequencies_list<-c()
  temp.residual_PSD<-c()
  temp.residual_ts<-ts.par
  temp.harmonic_analysis_object<-c()
  #try({
  temp.harmonic_analysis_object<-harmonic_analysis.function(ts.par=ts.par,time_sequence.par=time_sequence.par,NW.par=NW.par,
                                                            sampling_rate.par=sampling_rate.par,F_test_threshold.par=F_test_threshold.par,
                                                            ha_bool.par=FALSE,residual_bool.par=residual_eigencoeffs.bool,
                                                            threshold_crossings_LB.par=threshold_crossings_LB.par,num_sections.par=num_sections.par,
                                                            new_directory.par=new_directory.par,old_directory.par=old_directory.par,
                                                            reconstruction_bool.par=TRUE,spectral_power_bool.par=TRUE,
                                                            reconstruction_directory.par="",ends_reconstruction_bool.par=TRUE,
                                                            all_frequencies_bool.par=all_frequencies_bool.par,first_time.par=first_time.par,
                                                            demodulate_bool.par=demodulate_bool.par,frequency_band.par=frequency_band.par,
                                                            dpss.par=dpss.par,energy_concentrations.par=energy_concentrations.par,
                                                            slepian_functions.par=slepian_functions.par,
                                                            main_directory.par=main_directory.par,
                                                            measured_quantity.par=measured_quantity.par,
                                                            method_directory_string.par=method_directory_string.par)
  temp.K=temp.harmonic_analysis_object$out.K
  temp.M=temp.harmonic_analysis_object$out.M
  temp.M2=temp.harmonic_analysis_object$out.M2
  temp.slepian_functions<-temp.harmonic_analysis_object$out.slepian_functions
  temp.zero_index=temp.harmonic_analysis_object$out.zero_index
  temp.frequencies<-temp.harmonic_analysis_object$out.frequencies
  temp.spectral_power_estimates<-temp.harmonic_analysis_object$out.spectral_power_estimates
  temp.energy_concentrations<-temp.harmonic_analysis_object$out.energy_concentrations
  temp.dpss<-temp.harmonic_analysis_object$out.slepian_sequences
  temp.ts_eigencoeffs<-temp.harmonic_analysis_object$out.eigencoeffs
  temp.harmonic_reconstructions_list<-temp.harmonic_analysis_object$out.harmonic_reconstructions_list
  temp.harmonic_reconstruction_indices_list<-temp.harmonic_analysis_object$out.harmonic_reconstruction_indices_list
  temp.significant_frequency_indices<-round(temp.frequencies*temp.M)
  temp.significant_frequency_indices<-temp.significant_frequency_indices[temp.significant_frequency_indices>0 & temp.significant_frequency_indices<=temp.M2]
  temp.residual_eigencoefficients<-residual_eigencoefficient_reconstruction.function(temp.ts_eigencoeffs,
                                                                                     temp.significant_frequency_indices,temp.slepian_functions,
                                                                                     N.par=temp.N,energy_concentrations.par=temp.energy_concentrations,
                                                                                     NW.par=NW.par)
  temp.num_sections=length(temp.harmonic_reconstruction_indices_list)
  for(temp.i in 1:temp.num_sections){
    temp.indices<-temp.harmonic_reconstruction_indices_list[[temp.i]]
    temp.reconstruction<-temp.harmonic_reconstructions_list[[temp.i]]
    if(is.matrix(temp.reconstruction)==TRUE){
      temp.ncol_reconstruction_matrix=ncol(temp.reconstruction)
      if(temp.ncol_reconstruction_matrix>0){
        for(temp.j in 1:temp.ncol_reconstruction_matrix){
          temp.residual_ts[temp.indices]<-temp.residual_ts[temp.indices]-temp.reconstruction[,temp.j]
        }
      }
    }
    else{
      temp.residual_ts[temp.indices]<-temp.residual_ts[temp.indices]-temp.reconstruction
    }
  }
  temp.significant_frequencies_list<-temp.harmonic_analysis_object$out.significant_frequencies_list
  #},silent=T)
  setwd(old_directory.par)
  temp.list<-list(out.K=temp.K,
                  out.M=temp.M,
                  out.M2=temp.M2,
                  out.frequencies=temp.frequencies,
                  out.energy_concentrations=temp.energy_concentrations,
                  out.ts_eigencoeffs=temp.residual_eigencoefficients,
                  out.harmonic_reconstructions_list=temp.harmonic_reconstructions_list,
                  out.harmonic_reconstruction_indices_list=temp.harmonic_reconstruction_indices_list,
                  out.significant_frequencies_list=temp.significant_frequencies_list,
                  out.residual_ts=temp.residual_ts,
                  out.harmonic_analysis_object=temp.harmonic_analysis_object,
                  out.spectral_power_estimates=temp.spectral_power_estimates,
                  out.dpss=temp.dpss,
                  out.slepian_functions=temp.slepian_functions)
  return(temp.list)
}


filter_algorithm_filtering_step.function<-function(time_sequence.par,ts.par,frequency_band.par,harmonic_reconstructions_list.par,
                                                   significant_frequencies_list.par,harmonic_reconstruction_indices_list.par,
                                                   frequencies.par,N.par,M.par=NA,old_directory.par="",sampling_rate.par=1,
                                                   num_fitting_indices.par=10,filter_type_thresholds.par=NA){
  if(is.na(M.par)==TRUE){
    M.par=N.par
  }
  if(is.na(filter_type_thresholds.par)==TRUE){
    filter_type_thresholds.par<-c(sampling_rate.par,filter_type_thresholds.par)
  }
  #Create a band directory.
  temp.band_directory_string<-paste("Band_",frequency_band.par[1],"_",frequency_band.par[2],sep="")
  dir.create(temp.band_directory_string,showWarnings=FALSE)
  temp.working_directory_string<-paste(old_directory.par,"/",temp.band_directory_string,sep="")
  setwd(temp.working_directory_string)
  temp.frequency_bands_matrix<-matrix(0,nrow=1,ncol=2)
  temp.frequency_bands_matrix[1,]<-frequency_band.par
  #Compute the bandpass filters for the considered pass bands.
  temp.cutoff=frequency_band.par[2]
  if(frequency_band.par[1]>0){
    temp.cutoff=(frequency_band.par[2]-frequency_band.par[1])/2
  }
  temp.bp_filter_object<-bp_filter.function(passband_cutoffs.par=temp.cutoff,frequencies.par=frequencies.par,
                                            passband_cutoffs2.par=temp.cutoff,stopband_min_powers.par=NA,stopband_max_powers.par=NA,
                                            stopband_max_optimal_indices.par=NA,sampling_rate.par=sampling_rate.par,N.par=N.par,
                                            M.par=M.par,num_fitting_indices.par=num_fitting_indices.par,
                                            filter_type_thresholds.par=filter_type_thresholds.par,old_directory.par=old_directory.par,
                                            verbose.par=FALSE)
  temp.filter_list<-temp.bp_filter_object$out.filter_list
  temp.filter_object_list<-temp.bp_filter_object$out.filter_object_list
  temp.parameter_matrix_list<-temp.bp_filter_object$out.parameter_matrix_list
  temp.NW<-temp.bp_filter_object$out.NW
  temp.TF_values_list<-temp.bp_filter_object$out.TF_values_list
  temp.TF_frequencies_list<-temp.bp_filter_object$out.TF_frequencies_list
  #Pass the time series through each of the specified filters.
  temp.bp_filter_comparison_object<-bp_filter_comparison.function(times.par=time_sequence.par,ts.par=ts.par,
                                                                  harmonic_reconstructions.par=harmonic_reconstructions_list.par,
                                                                  significant_frequencies.par=significant_frequencies_list.par,
                                                                  harmonic_reconstruction_indices.par=harmonic_reconstruction_indices_list.par,
                                                                  bands_matrix.par=temp.frequency_bands_matrix,
                                                                  filter_list.par=temp.filter_list,filter_object_list.par=temp.filter_object_list,
                                                                  parameter_matrix_list.par=temp.parameter_matrix_list,
                                                                  sampling_rate.par=sampling_rate.par,passband_cutoffs.par=frequency_band.par[2],
                                                                  original_sampling_bool.par=TRUE,filter_type_thresholds.par=filter_type_thresholds.par)
  temp.filter_specification_string<-temp.bp_filter_comparison_object$out.filter_specification_string
  temp.strings<-temp.bp_filter_comparison_object$out.strings
  temp.trial_filtered_times_list<-list()
  temp.filtered_ts_list<-list()
  temp.trial_filtered_times_list[[1]]<-unlist(temp.bp_filter_comparison_object$out.decimated_series_times_list)
  temp.filtered_ts_list[[1]]<-unlist(temp.bp_filter_comparison_object$out.decimated_series_list)
  temp.trial_filtered_times_list[[2]]<-unlist(temp.bp_filter_comparison_object$out.kramer_decimated_series_times_list)
  temp.filtered_ts_list[[2]]<-unlist(temp.bp_filter_comparison_object$out.kramer_decimated_series_list)
  temp.trial_filtered_times_list[[3]]<-unlist(temp.bp_filter_comparison_object$out.martinet_decimated_series_times_list)
  temp.filtered_ts_list[[3]]<-unlist(temp.bp_filter_comparison_object$out.martinet_decimated_series_list)
  temp.trial_filtered_times_list[[4]]<-unlist(temp.bp_filter_comparison_object$out.schevon_decimated_series_times_list)
  temp.filtered_ts_list[[4]]<-unlist(temp.bp_filter_comparison_object$out.schevon_decimated_series_list)
  temp.trial_filtered_times_list[[5]]<-unlist(temp.bp_filter_comparison_object$out.schlafly_decimated_series_times_list)
  temp.filtered_ts_list[[5]]<-unlist(temp.bp_filter_comparison_object$out.schlafly_decimated_series_list)
  setwd(temp.working_directory_string)
  temp.list<-list(out.filter_list=temp.filter_list,
                  out.filter_object_list=temp.filter_object_list,
                  out.parameter_matrix_list=temp.parameter_matrix_list,
                  out.trial_filtered_times_list=temp.trial_filtered_times_list,
                  out.filtered_ts_list=temp.filtered_ts_list,
                  out.filter_specification_string=temp.filter_specification_string,
                  out.strings=temp.strings,
                  out.NW=temp.NW,
                  out.TF_values_list=temp.TF_values_list,
                  out.TF_frequencies_list=temp.TF_frequencies_list)
  return(temp.list)
}


marshall_filter_algorithm.function<-function(ts.par,time_sequence.par,frequency_band.par,new_directory.par="",old_directory.par="",NW.par=5,sampling_rate.par=1,
                                             F_test_threshold.par=0.99,num_sections.par=2,threshold_crossings_LB.par=3,num_fitting_indices.par=10,
                                             filter_type_thresholds.par=NA,all_frequencies_bool.par=FALSE,first_time.par=0,demodulate_bool.par=FALSE,
                                             main_directory.par=main_directory.string,measured_quantity.par=""){
  temp.N=length(ts.par)
  #Harmonic analysis.
  temp.filtering_algorithm_eigencoeff_harmonic_object<-filtering_algorithm_eigencoeff_harmonic.function(ts.par=ts.par,time_sequence.par=time_sequence.par,
                                                                                                        new_directory.par=new_directory.par,
                                                                                                        old_directory.par=old_directory.par,NW.par=NW.par,
                                                                                                        sampling_rate.par=sampling_rate.par,
                                                                                                        F_test_threshold.par=F_test_threshold.par,
                                                                                                        num_sections.par=num_sections.par,
                                                                                                        threshold_crossings_LB.par=threshold_crossings_LB.par,
                                                                                                        all_frequencies_bool.par=all_frequencies_bool.par,
                                                                                                        first_time.par=first_time.par,
                                                                                                        demodulate_bool.par=demodulate_bool.par,
                                                                                                        frequency_band.par=frequency_band.par,
                                                                                                        main_directory.par=main_directory.par,
                                                                                                        measured_quantity.par=measured_quantity.par)
  cat("End filtering_algorithm_eigencoeff_harmonic.function\n")
  temp.K=temp.filtering_algorithm_eigencoeff_harmonic_object$out.K
  temp.M=temp.filtering_algorithm_eigencoeff_harmonic_object$out.M
  temp.M2=temp.filtering_algorithm_eigencoeff_harmonic_object$out.M2
  temp.frequencies<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.frequencies
  temp.energy_concentrations<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.energy_concentrations
  temp.ts_eigencoeffs<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.ts_eigencoeffs
  temp.harmonic_reconstructions_list<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.harmonic_reconstructions_list
  temp.harmonic_reconstruction_indices_list<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.harmonic_reconstruction_indices_list
  temp.significant_frequencies_list<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.significant_frequencies_list
  temp.residual_ts<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.residual_ts
  #Filtering accounting for results of the harmonic analysis.
  temp.filter_algorithm_filtering_step_object<-filter_algorithm_filtering_step.function(time_sequence.par=time_sequence.par,ts.par=ts.par,
                                                                                        frequency_band.par=frequency_band.par,
                                                                                        harmonic_reconstructions_list.par=temp.harmonic_reconstructions_list,
                                                                                        significant_frequencies_list.par=temp.significant_frequencies_list,
                                                                                        harmonic_reconstruction_indices_list.par=
                                                                                          temp.harmonic_reconstruction_indices_list,
                                                                                        frequencies.par=temp.frequencies,N.par=temp.N,M.par=temp.M,
                                                                                        old_directory.par=old_directory.par,sampling_rate.par=sampling_rate.par,
                                                                                        num_fitting_indices.par=num_fitting_indices.par,
                                                                                        filter_type_thresholds.par=filter_type_thresholds.par)
  temp.filter_list<-temp.filter_algorithm_filtering_step_object$out.filter_list
  temp.filter_object_list<-temp.filter_algorithm_filtering_step_object$out.filter_object_list
  temp.parameter_matrix_list<-temp.filter_algorithm_filtering_step_object$out.parameter_matrix_list
  temp.trial_filtered_times_list<-temp.filter_algorithm_filtering_step_object$out.trial_filtered_times_list
  temp.filtered_ts_list<-temp.filter_algorithm_filtering_step_object$out.filtered_ts_list
  temp.filter_specification_string<-temp.filter_algorithm_filtering_step_object$out.filter_specification_string
  temp.strings<-temp.filter_algorithm_filtering_step_object$out.strings
  temp.NW<-temp.filter_algorithm_filtering_step_object$out.NW
  temp.list<-list(out.K=temp.K,
                  out.M=temp.M,
                  out.M2=temp.M2,
                  out.frequencies=temp.frequencies,
                  out.energy_concentrations=temp.energy_concentrations,
                  out.ts_eigencoeffs=temp.ts_eigencoeffs,
                  out.harmonic_reconstructions_list=temp.harmonic_reconstructions_list,
                  out.harmonic_reconstruction_indices_list=temp.harmonic_reconstruction_indices_list,
                  out.significant_frequencies_list=temp.significant_frequencies_list,
                  out.residual_ts=temp.residual_ts,
                  out.filter_list=temp.filter_list,
                  out.filter_object_list=temp.filter_object_list,
                  out.parameter_matrix_list=temp.parameter_matrix_list,
                  out.trial_filtered_times_list=temp.trial_filtered_times_list,
                  out.filtered_ts_list=temp.filtered_ts_list,
                  out.filter_specification_string=temp.filter_specification_string,
                  out.strings=temp.strings,
                  out.NW=temp.NW)
  return(temp.list)
}


eigencoefficients_correlation_comparison.function<-function(eigencoeff_list.par,energy_concentrations.par,frequencies.par,frequency_band.par,M.par,
                                                            sampling_rate.par=1,
                                                            pdf_title.par="",correlation_type.par="CCA",percentile_threshold.par=0.3,
                                                            abscissa_quantity.par="Measured quantity",abscissa_units.par="measured units",
                                                            ordinates_quantity.par="Measured quantity",ordinates_units.par="measured units",
                                                            correlation_pdf_title.par="",plot_bool.par=FALSE,smooth_image.par=FALSE,theta.par=0.9,
                                                            log_bool.par=FALSE,verbose.par=FALSE,downsample_bool.par=FALSE){
  temp.eigencoeffs1<-eigencoeff_list.par[[1]]
  temp.eigencoeffs2<-eigencoeff_list.par[[2]]
  temp.num_band_indices1=nrow(temp.eigencoeffs1)
  temp.num_band_indices2=nrow(temp.eigencoeffs2)
  if(downsample_bool.par==TRUE){
    temp.step_size=floor(temp.num_band_indices1/50)
    if(temp.num_band_indices1>50){
      temp.downsampled_indices<-seq(from=1,to=temp.num_band_indices1,by=temp.step_size)
      temp.downsampled_indices<-temp.downsampled_indices[1:50]
      temp.eigencoeffs1<-temp.eigencoeffs1[temp.downsampled_indices,]
      temp.eigencoeffs2<-temp.eigencoeffs2[temp.downsampled_indices,]
      frequencies.par<-frequencies.par[temp.downsampled_indices]
    }
    temp.num_band_indices1=nrow(temp.eigencoeffs1)
    temp.num_band_indices2=nrow(temp.eigencoeffs2)
  }
  temp.M2=M.par/2+1
  temp.index_bounds<-round(frequency_band.par/sampling_rate.par*M.par)
  temp.index_bounds[temp.index_bounds<1]<-1
  temp.index_bounds[temp.index_bounds>temp.M2]<-temp.M2
  temp.correlation_matrix<-matrix(0,nrow=temp.num_band_indices1,ncol=temp.num_band_indices2)
  temp.counter=1
  for(temp.m in 1:temp.num_band_indices1){
    if(temp.m>=temp.index_bounds[1] & temp.m<=temp.index_bounds[2]){
      if(verbose.par==TRUE){
        cat(temp.m," out of ",temp.num_band_indices1,"\n")
      }
      for(temp.n in 1:temp.num_band_indices2){
        if(temp.n>=temp.index_bounds[1] & temp.n<=temp.index_bounds[2]){
          temp.correlation_coefficient=0
          if(correlation_type.par=="PLS"){
            #Here, temp.eigencoeffs2 is a unitary transformation of temp.eigencoeffs1.
            temp.correlation_coefficient=total_PLS_test_statistic.function(temp.eigencoeffs1[temp.m,]/energy_concentrations.par,
                                                                           temp.eigencoeffs2[temp.n,]/energy_concentrations.par)
          }
          else if(correlation_type.par=="MLR"){
            #Here, temp.eigencoeffs1 is an estimator of temp.eigencoeffs2.
            temp.correlation_coefficient=total_MLR_test_statistic.function(temp.eigencoeffs2[temp.m,]/energy_concentrations.par,
                                                                           temp.eigencoeffs1[temp.n,]/energy_concentrations.par)
          }
          else{
            temp.correlation_coefficient=(-1)*log(1-total_CCA_test_statistic.function(temp.eigencoeffs1[temp.m,]/energy_concentrations.par,
                                                                                      temp.eigencoeffs2[temp.n,]/energy_concentrations.par))
          }
          temp.correlation_matrix[temp.m,temp.n]<-temp.correlation_coefficient
          temp.counter=temp.counter+1
        }
      }
    }
  }
  if(plot_bool.par==TRUE){
    temp.x_bounds<-frequency_band.par
    temp.y_bounds<-temp.x_bounds
    temp.heights_quantity<-""
    temp.heights_units<-"percentage points"
    temp.z_bounds<-c(percentile_threshold.par,1)
    if(correlation_type.par=="PLS"){
      temp.correlation_matrix<-temp.correlation_matrix*100
      temp.z_bounds<-temp.z_bounds*100
      temp.heights_quantity<-"PLS coefficient"
    }
    else if(correlation_type.par=="MLR"){
      temp.correlation_matrix<-temp.correlation_matrix*100
      temp.z_bounds<-temp.z_bounds*100
      temp.heights_quantity<-"Redundancy index"
    }
    else{
      temp.z_bounds<-(-1)*log(temp.z_bounds)
      temp.heights_quantity<-"Mutual information"
      temp.heights_units<-""
    }
    heat_map.function(frequencies.par,frequencies.par,temp.correlation_matrix,
                      abscissa_quantity.par=abscissa_quantity.par,abscissa_units.par=abscissa_units.par,
                      ordinates_quantity.par=abscissa_quantity.par,ordinates_units.par=abscissa_units.par,
                      heights_quantity.par=temp.heights_quantity,heights_units.par=temp.heights_units,
                      pdf_title.par=pdf_title.par,x_bounds.par=temp.x_bounds,y_bounds.par=temp.y_bounds,z_bounds.par=temp.z_bounds,
                      smooth_image.par=smooth_image.par,theta.par=theta.par,log_bool.par=log_bool.par)
  }
  temp.list<-list(out.correlation_matrix=temp.correlation_matrix,
                  out.frequencies=frequencies.par)
  return(temp.list)
}


eigencoefficients_filter_comparison.function<-function(ts_list.par,time_sequence_list.par,energy_concentrations.par,frequencies.par,frequency_band.par,
                                                       NW.par=5,residual_bools.par=NA,sampling_rate.par=1,F_test_threshold.par=0.99,
                                                       num_sections.par=2,threshold_crossings_LB.par=3,correlation_type.par="CCA",
                                                       old_directory.par="",specific_subdirectory_string.par="",method_directory_string.par="",
                                                       percentile_threshold.par=0.3,abscissa_scale.par=1,
                                                       abscissa_quantity.par="Measured quantity",abscissa_units.par="measured units",
                                                       ordinates_quantity.par="Measured quantity",ordinates_units.par="measured units",
                                                       measured_abscissa_string.par="Measured quantity",
                                                       time_units_string.par="measured units",time_units_string2.par="measured units",
                                                       ts_pdf_title.par="",correlation_pdf_title.par="",plot_ts_bool.par=FALSE,
                                                       plot_residual_spectrum_bool.par=FALSE,plot_bifrequency_map_bool.par=FALSE,smooth_image.par=FALSE,
                                                       theta.par=0.9,log_bool.par=FALSE,verbose.par=FALSE,demodulate_bool.par=FALSE,
                                                       ha_bool_residual.par=FALSE,all_frequencies_bool.par=FALSE,whitening_bool.par=FALSE,
                                                       num_differences.par=0,downsample_bool.par=FALSE){
  temp.length1=length(ts_list.par[[1]])
  temp.length2=length(ts_list.par[[2]])
  if(temp.length1>temp.length2){
    temp.common_N=min(temp.length1,temp.length2)
    temp.length_discrepancy=temp.length1-temp.length2
    temp.average_estimate=mean(ts_list.par[[2]])
    temp.filler_vector<-rep(temp.average_estimate,(temp.length_discrepancy-temp.length_discrepancy%%2)/2)
    temp.first_vector<-c(temp.filler_vector,ts_list.par[[2]])
    temp.second_length_discrepancy=temp.length1-length(temp.first_vector)
    if(temp.second_length_discrepancy>0){
      temp.second_vector<-c(temp.first_vector,rep(temp.average_estimate,temp.second_length_discrepancy))
      ts_list.par[[2]]<-temp.second_vector
    }
    time_sequence_list.par[[2]]<-time_sequence_list.par[[1]]
  }
  temp.N=length(time_sequence_list.par[[1]])
  temp.N0=temp.N
  temp.K=length(energy_concentrations.par)
  temp.F_threshold=qf(1-1/temp.N,2,2*temp.K-2)
  if(plot_ts_bool.par==TRUE){
    #Time-domain performance assessment.
    temp.plotting_times_list<-list(time_sequence_list.par[[1]]-time_sequence_list.par[[1]][1],time_sequence_list.par[[2]]-time_sequence_list.par[[1]][1])
    temp.plotting_ts_list<-list(ts_list.par[[1]],ts_list.par[[2]])
    plot.graph(temp.plotting_times_list,temp.plotting_ts_list,
               x_label.par=paste(measured_abscissa_string.par,", in ",time_units_string2.par," since ",round(time_sequence_list.par[[1]][1]*abscissa_scale.par,3),
                                 " ",time_units_string.par,sep=""),
               y_label.par=paste(ordinates_quantity.par,", in ",ordinates_units.par,sep=""),pdf_title.par=ts_pdf_title.par,
               col.par=c("grey80",1),lwd.par=c(4,1),lty.par=c(1,2))
  }
  #Frequency-domain performance assessment.
  temp.num_list_elements=length(ts_list.par)
  if(is.na(residual_bools.par)==TRUE){
    for(temp.i in 1:temp.num_list_elements){
      residual_bools.par[temp.i]=FALSE
    }
  }
  temp.residual_eigencoeff_list<-list()
  temp.eigencoeff_list<-list()
  temp.residual_spectral_power_list<-list()
  temp.residual_ts_list<-list()
  temp.spectral_power_sequences_list<-list()
  temp.original_spectral_power_sequences_list<-list()
  for(temp.i in 1:temp.num_list_elements){
    temp.specific_directory_string<-specific_subdirectory_string.par
    if(temp.i==2){
      temp.specific_directory_string<-paste(temp.specific_directory_string,"/",method_directory_string.par,sep="")
    }
    temp.ts<-ts_list.par[[temp.i]]
    temp.time_sequence<-time_sequence_list.par[[temp.i]]
    temp.N=length(temp.ts)
    temp.residual_ts<-temp.ts
    temp.spectral_power_estimates<-c()
    temp.significant_frequencies_list<-c()
    if(!residual_bools.par[temp.i]){
      #Subtract periodic elements from the original (list element #1) or the filtered (list element #2) time series.
      temp.filtering_algorithm_eigencoeff_harmonic_object<-filtering_algorithm_eigencoeff_harmonic.function(ts.par=temp.ts,time_sequence.par=temp.time_sequence,
                                                                                                            new_directory.par=temp.specific_directory_string,
                                                                                                            old_directory.par=old_directory.par,
                                                                                                            NW.par=NW.par,sampling_rate.par=sampling_rate.par,
                                                                                                            F_test_threshold.par=1-1/temp.N,
                                                                                                            num_sections.par=num_sections.par,
                                                                                                            threshold_crossings_LB.par=
                                                                                                              threshold_crossings_LB.par,
                                                                                                            demodulate_bool.par=demodulate_bool.par,
                                                                                                            all_frequencies_bool.par=all_frequencies_bool.par,
                                                                                                            method_directory_string.par=method_directory_string.par,
                                                                                                            measured_quantity.par=ordinates_quantity.par)
      temp.residual_ts<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.residual_ts
      temp.spectral_power_estimates<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.spectral_power_estimates
      temp.original_spectral_power_sequences_list[[temp.i]]<-temp.spectral_power_estimates
      temp.significant_frequencies_list<-temp.filtering_algorithm_eigencoeff_harmonic_object$out.significant_frequencies_list
    }
    temp.residual_ts_list[[temp.i]]<-temp.residual_ts
    ######################################################################################################################################################
    #Perform a basic multitaper spectral analysis on the time series whose harmonic elements specifically having stopband frequencies have been
    #subtracted out.
    ######################################################################################################################################################
    temp.harmonic_analysis_object<-harmonic_analysis.function(ts.par=temp.residual_ts,time_sequence.par=temp.time_sequence,NW.par=NW.par,
                                                              jackknife.par=FALSE,plot.par=FALSE,measured_quantity.par=measure_quantity.string,
                                                              measured_units.par=measure_units.string,sampling_rate.par=sampling_rate.par,
                                                              spectral_power_bool.par=TRUE,F_test_threshold.par=1-1/temp.N,
                                                              threshold_crossings_LB.par=threshold_crossings_LB.par,num_sections.par=num_sections.par,
                                                              new_directory.par=temp.specific_directory_string,old_directory.par=old_directory.par,
                                                              reconstruction_bool.par=FALSE,ends_reconstruction_bool.par=TRUE,
                                                              demodulate_bool.par=demodulate_bool.par,residual_bool.par=FALSE,ha_bool.par=TRUE,
                                                              all_frequencies_bool.par=all_frequencies_bool.par,ha_bool_residual.par=ha_bool_residual.par,
                                                              num_diffs.par=as.integer(residual_bools.par[temp.i]))
    temp.significant_frequencies<-temp.harmonic_analysis_object$out.significant_frequencies
    temp.F_statistic_spectrum<-temp.harmonic_analysis_object$out.F_statistics
    temp.M2=length(frequencies.par)
    temp.M=2*(temp.M2-1)
    temp.significant_frequency_indices<-c()
    #Only subtract out the periodic elements detected by the residual harmonic F-test if they lie inside the stopband, or else subtract the reconstructed
    #periodic element in the passband only if it is significant according to the F-test whose thresholds are considered for the original series.  This
    #is because the residual series for which a harmonic analysis is being considered is the one mentioned in the previous comment, with only those
    #periodic elements having been subtracted from it which lie inside the stopband.
    #Consider passband frequencies for obtaining the filtered version of the series.
    temp.plotting_significant_frequencies<-temp.significant_frequencies*sampling_rate.par
    temp.passband_significant_indices<-which(temp.plotting_significant_frequencies>=frequency_band.par[1] &
                                               temp.plotting_significant_frequencies<=frequency_band.par[2])
    temp.significant_frequency_indices_passband<-round(temp.significant_frequencies[temp.passband_significant_indices]*temp.M)
    temp.significant_frequency_indices_passband<-
      temp.significant_frequency_indices_passband[temp.significant_frequency_indices_passband>0 & temp.significant_frequency_indices_passband<=temp.M2]
    #Consider indices for the significant stopband frequencies.
    temp.stopband_significant_indices<-c(which(temp.plotting_significant_frequencies<=frequency_band.par[1]),
                                         which(temp.plotting_significant_frequencies>=frequency_band.par[2]))
    temp.significant_frequency_indices_stopband<-round(temp.significant_frequencies[temp.stopband_significant_indices]*temp.M)
    temp.significant_frequency_indices_stopband<-
      temp.significant_frequency_indices_stopband[temp.significant_frequency_indices_stopband>0 & temp.significant_frequency_indices_stopband<=temp.M2]
    #Add indices for the significant passband frequencies.
    temp.significant_F_statistic_indices<-which(temp.F_statistic_spectrum>temp.F_threshold)
    temp.significant_frequency_indices<-c(temp.significant_frequency_indices_stopband,temp.significant_F_statistic_indices)
    temp.significant_frequency_indices<-unique(temp.significant_frequency_indices)
    temp.all_significant_indices<-unique(c(temp.significant_frequency_indices,temp.significant_frequency_indices_passband))
    #Compute the residual eigencoefficients.
    temp.eigencoeffs<-temp.harmonic_analysis_object$out.eigencoeffs
    temp.slepian_functions<-temp.harmonic_analysis_object$out.slepian_functions
    temp.residual_eigencoeffs<-residual_eigencoefficient_reconstruction.function(temp.eigencoeffs,temp.all_significant_indices,
                                                                                 temp.slepian_functions,temp.N,
                                                                                 energy_concentrations.par=energy_concentrations.par,NW.par=NW.par)
    temp.residual_eigencoeff_list[[temp.i]]<-temp.residual_eigencoeffs
    temp.eigencoeff_list[[temp.i]]<-temp.eigencoeffs
    temp.spectral_powers<-c()
    if(residual_bools.par[temp.i]==TRUE){
      temp.spectral_powers<-temp.harmonic_analysis_object$out.power_spectrum
      temp.original_spectral_power_sequences_list[[temp.i]]<-temp.spectral_powers
    }
    else{
      temp.spectral_powers<-multitaper.regularized_spectrum(temp.residual_eigencoeffs,frequencies.par,energy_concentrations.par)
    }
    temp.spectral_power_sequences_list[[temp.i]]<-temp.spectral_powers
    setwd(old_directory.par)
  }
  #Correlation analysis.
  temp.M=nrow(temp.residual_eigencoeffs)
  temp.zero_index=temp.M/2
  temp.M2=temp.zero_index+1
  temp.plotting_frequencies0<-frequencies.par*sampling_rate.par
  temp.band_indices<-which(temp.plotting_frequencies0<frequency_band.par[2])
  temp.num_band_indices=length(temp.band_indices)
  temp.plotting_frequencies<-temp.plotting_frequencies0[temp.band_indices]
  temp.passband_indices<-temp.zero_index+temp.band_indices-1
  #Original process.
  temp.truth_original_spectral_powers<-multitaper.regularized_spectrum(temp.eigencoeff_list[[1]],frequencies.par,energy_concentrations.par)
  #Residual process.
  temp.truth_spectral_powers<-multitaper.regularized_spectrum(temp.residual_eigencoeff_list[[1]],frequencies.par,energy_concentrations.par)
  #Filtered process.
  temp.filtered_original_spectral_powers<-multitaper.regularized_spectrum(temp.eigencoeff_list[[2]],frequencies.par,energy_concentrations.par)
  #Filtered, residual process.
  temp.residual_spectral_powers<-multitaper.regularized_spectrum(temp.residual_eigencoeff_list[[2]],frequencies.par,energy_concentrations.par)
  #Energy.
  temp.full_energy=0
  temp.stopband_energy=0
  #Eigencoefficients from the passband for correlation analysis.
  temp.truth_eigencoeffs<-temp.residual_eigencoeff_list[[1]][temp.passband_indices,]
  temp.filtered_eigencoeffs<-temp.residual_eigencoeff_list[[2]][temp.passband_indices,]
  #Plot the residual spectra.
  temp.x_list<-c()
  temp.y_list<-c()
  temp.colours<-c()
  temp.x_list<-list(log10(temp.plotting_frequencies0[temp.plotting_frequencies0>0]),log10(temp.plotting_frequencies0[temp.plotting_frequencies0>0]),
                    log10(temp.plotting_frequencies0[temp.plotting_frequencies0>0]),log10(temp.plotting_frequencies0[temp.plotting_frequencies0>0]))
  temp.y_list<-list(log10(temp.truth_original_spectral_powers[temp.plotting_frequencies0>0]),
                    log10(temp.truth_spectral_powers[temp.plotting_frequencies0>0]),
                    log10(temp.filtered_original_spectral_powers[temp.plotting_frequencies0>0]),
                    log10(temp.residual_spectral_powers[temp.plotting_frequencies0>0]))
  temp.band_string<-paste("[",frequency_band.par[1],",",frequency_band.par[2],"] ",abscissa_units.par,sep="")
  plot.graph(temp.x_list,temp.y_list,x_label.par=paste(abscissa_quantity.par,", in ",abscissa_units.par,sep=""),
             y_label.par=paste(ordinates_quantity.par,", in squared ",ordinates_units.par," per ",abscissa_units.par,sep=""),
             pdf_title.par=paste("Residual_",ordinates_quantity.par,"_Spectrum.pdf",sep=""),
             vertical_line.par=log10(frequency_band.par),log_bool.par=TRUE,type=c("l","p","l","l"),lty.par=c(1,0,1,1),
             col.par=c("grey90","grey50","grey70",1),
             pch.par=c("",".","",""),cex.par=c(3,3,3,1),lwd.par=c(3,0,4,1))
  #Whitening analysis for high-frequency passbands.
  if(whitening_bool.par==TRUE){
    #Original process.
    temp.prewhitening_object<-prewhitening_coefficients.function(temp.truth_original_spectral_powers,frequencies.par,temp.N,NW.par=NW.par,
                                                                 sampling_rate.par=sampling_rate.par)
    temp.truth_original_prewhitened_spectral_powers<-temp.prewhitening_object$out.prewhitened_spectrum
    temp.buys_baillot_whitening_object<-buys_baillot_whitening.function(spectral_powers.par=temp.truth_original_prewhitened_spectral_powers,
                                                                        frequencies.par=frequencies.par,
                                                                        significant_indices.par=temp.all_significant_indices,
                                                                        N.par=temp.N)
    temp.truth_original_bb_whitened_spectral_powers<-temp.buys_baillot_whitening_object$out.bb_whitened_spectral_powers
    #Residual process.
    temp.prewhitening_object<-prewhitening_coefficients.function(temp.truth_spectral_powers,frequencies.par,N.par,NW.par=NW.par,
                                                                 sampling_rate.par=sampling_rate.par)
    temp.truth_prewhitened_spectral_powers<-temp.prewhitening_object$out.prewhitened_spectrum
    temp.num_intersection_truth_residual_prewhitened=length(intersect(temp.truth_prewhitened_spectral_powers,temp.truth_spectral_powers))
    temp.truth_bb_whitened_spectral_powers<-temp.truth_prewhitened_spectral_powers
    temp.num_intersection_truth_residual_buys_baillot=temp.M2
    if(temp.num_intersection_truth_residual_prewhitened>0){
      temp.buys_baillot_whitening_object<-buys_baillot_whitening.function(spectral_powers.par=temp.truth_prewhitened_spectral_powers,
                                                                          frequencies.par=frequencies.par,
                                                                          significant_indices.par=temp.all_significant_indices,
                                                                          N.par=temp.N)
      temp.truth_bb_whitened_spectral_powers<-temp.buys_baillot_whitening_object$out.bb_whitened_spectral_powers
      temp.num_intersection_truth_residual_buys_baillot=length(intersect(temp.truth_bb_whitened_spectral_powers,temp.truth_prewhitened_spectral_powers))
    }
    #Filtered process.
    temp.prewhitening_object<-prewhitening_coefficients.function(temp.filtered_original_spectral_powers,frequencies.par,N.par,NW.par=NW.par,
                                                                 sampling_rate.par=sampling_rate.par)
    temp.filtered_original_prewhitened_spectral_powers<-temp.prewhitening_object$out.prewhitened_spectrum
    temp.buys_baillot_whitening_object<-buys_baillot_whitening.function(spectral_powers.par=temp.filtered_original_prewhitened_spectral_powers,
                                                                        frequencies.par=frequencies.par,
                                                                        significant_indices.par=temp.all_significant_indices,
                                                                        N.par=temp.N)
    temp.filtered_original_bb_whitened_spectral_powers<-temp.buys_baillot_whitening_object$out.bb_whitened_spectral_powers
    #Filtered, residual process.
    temp.prewhitening_object<-prewhitening_coefficients.function(temp.residual_spectral_powers,frequencies.par,N.par,NW.par=NW.par,
                                                                 sampling_rate.par=sampling_rate.par)
    temp.residual_prewhitened_spectral_powers<-temp.prewhitening_object$out.prewhitened_spectrum
    temp.buys_baillot_whitening_object<-buys_baillot_whitening.function(spectral_powers.par=temp.residual_prewhitened_spectral_powers,
                                                                        frequencies.par=frequencies.par,
                                                                        significant_indices.par=temp.all_significant_indices,
                                                                        N.par=temp.N)
    temp.residual_bb_whitened_spectral_powers<-temp.buys_baillot_whitening_object$out.bb_whitened_spectral_powers
    #Plot the prewhitened spectra.
    temp.x_list<-c()
    temp.y_list<-c()
    temp.colours<-c()
    temp.x_list<-list(log10(temp.plotting_frequencies0[temp.plotting_frequencies0>0]),log10(temp.plotting_frequencies0[temp.plotting_frequencies0>0]),
                      log10(temp.plotting_frequencies0[temp.plotting_frequencies0>0]),log10(temp.plotting_frequencies0[temp.plotting_frequencies0>0]))
    temp.y_list<-list(log10(temp.truth_original_prewhitened_spectral_powers[temp.plotting_frequencies0>0]),
                      log10(temp.truth_prewhitened_spectral_powers[temp.plotting_frequencies0>0]),
                      log10(temp.filtered_original_prewhitened_spectral_powers[temp.plotting_frequencies0>0]),
                      log10(temp.residual_prewhitened_spectral_powers[temp.plotting_frequencies0>0]))
    temp.band_string<-paste("[",frequency_band.par[1],",",frequency_band.par[2],"] ",abscissa_units.par,sep="")
    plot.graph(temp.x_list,temp.y_list,x_label.par=paste(abscissa_quantity.par,", in ",abscissa_units.par,sep=""),
               y_label.par=paste(ordinates_quantity.par,", in squared ",ordinates_units.par," per ",abscissa_units.par,sep=""),
               pdf_title.par=paste("Whitened_Residual_",ordinates_quantity.par,"_Spectrum.pdf",sep=""),
               vertical_line.par=log10(frequency_band.par),log_bool.par=TRUE,type=c("l","p","l","l"),lty.par=c(1,0,1,1),col.par=c("grey90","grey50","grey70",1),
               pch.par=c("",".","",""),cex.par=c(3,3,3,1),lwd.par=c(3,0,4,1))
    #Extract the whitening transfer function for the correlation analysis.
    temp.whitening_transfer_function<-temp.buys_baillot_whitening_object$out.whitening_transfer_function
    #Energy.
    temp.full_energy=sum(temp.residual_prewhitened_spectral_powers)
    temp.stopband_energy=(temp.full_energy-sum(temp.residual_prewhitened_spectral_powers[temp.band_indices]))/temp.full_energy*100
    #Whiten the eigencoefficients for correlation analysis.
    for(temp.m in 1:length(temp.passband_indices)){
      temp.index=temp.passband_indices[temp.m]
      temp.truth_eigencoeffs[temp.m,]<-temp.residual_eigencoeff_list[[1]][temp.index,]*temp.whitening_transfer_function[temp.index-temp.zero_index+1]
      temp.filtered_eigencoeffs[temp.m,]<-temp.residual_eigencoeff_list[[2]][temp.index,]*temp.whitening_transfer_function[temp.index-temp.zero_index+1]
    }
    #Whitening
    temp.ar_coefficients<-temp.prewhitening_object$out.ar_coefficients
    temp.ar_order=temp.prewhitening_object$out.ar_order
    temp.times<-time_sequence_list.par[[2]]-time_sequence_list.par[[1]][1]
    #temp.times<-
    #  time_sequence_list.par[[1]][(temp.N0-length(temp.residual_ts_list[[2]])+1):temp.N0-(temp.N0-length(temp.residual_ts_list[[2]]))/2]-
    #  time_sequence_list.par[[1]][1]
    temp.filter_object<-filter.function(ts.par=temp.residual_ts_list[[2]],filter.par=temp.ar_coefficients,times.par=temp.times)
    temp.indices<-temp.filter_object$out.indices
    temp.whitened_series<-temp.residual_ts_list[[2]][temp.indices]-temp.filter_object$out.filtered_ts
    temp.times<-temp.filter_object$out.times
    temp.times0<-temp.times
    temp.whitened_series0<-temp.whitened_series
    temp.reconstructed_series<-temp.whitened_series
    temp.whitened_periodic<-rep(0,length(temp.whitened_series))
    temp.whitened_reconstruction<-ts_list.par[[2]][temp.indices]-temp.filter_object$out.filtered_ts
    temp.bb_reconstruction<-temp.whitened_reconstruction
    if(!residual_bools.par[temp.i] & length(temp.significant_frequency_indices_stopband)>0 & temp.num_intersection_truth_residual_prewhitened<temp.M2){
      #Buys-Baillot filter to remove any last periodic elements.
      temp.buys_baillot_reconstruction_object<-buys_baillot_reconstruction.function(ts.par=temp.whitened_series,
                                                                                    times.par=temp.times,frequencies.par=frequencies.par,
                                                                                    significant_indices.par=temp.significant_frequency_indices_stopband,
                                                                                    sampling_rate.par=sampling_rate.par,verbose_bool.par=FALSE)
      temp.reconstructed_series<-temp.buys_baillot_reconstruction_object$out.bb_reconstruction
      temp.whitened_series<-temp.buys_baillot_reconstruction_object$out.bb_whitened_series
      temp.times<-temp.buys_baillot_reconstruction_object$out.times
      #Reconstruct the periodic elements to obtain the final filtered form of the series when dealing with bandpass filters with high-frequency lower cutoff.
      temp.buys_baillot_reconstruction_object<-buys_baillot_reconstruction.function(ts.par=temp.whitened_series,
                                                                                    times.par=temp.times,frequencies.par=frequencies.par,
                                                                                    significant_indices.par=temp.all_significant_indices,
                                                                                    sampling_rate.par=sampling_rate.par,verbose_bool.par=FALSE)
      temp.bb_indices<-temp.buys_baillot_reconstruction_object$out.bb_indices
      temp.whitened_periodic<-temp.buys_baillot_reconstruction_object$out.bb_whitened_series
      temp.times_periodic<-temp.buys_baillot_reconstruction_object$out.times
      #Plot the Buys-Baillot-whitened spectra.
      temp.x_list<-c()
      temp.y_list<-c()
      temp.colours<-c()
      temp.x_list<-list(log10(temp.plotting_frequencies0[temp.plotting_frequencies0>0]),log10(temp.plotting_frequencies0[temp.plotting_frequencies0>0]),
                        log10(temp.plotting_frequencies0[temp.plotting_frequencies0>0]),log10(temp.plotting_frequencies0[temp.plotting_frequencies0>0]))
      temp.y_list<-list(log10(temp.truth_original_bb_whitened_spectral_powers[temp.plotting_frequencies0>0]),
                        log10(temp.truth_bb_whitened_spectral_powers[temp.plotting_frequencies0>0]),
                        log10(temp.filtered_original_bb_whitened_spectral_powers[temp.plotting_frequencies0>0]),
                        log10(temp.residual_bb_whitened_spectral_powers[temp.plotting_frequencies0>0]))
      temp.band_string<-paste("[",frequency_band.par[1],",",frequency_band.par[2],"] ",abscissa_units.par,sep="")
      try({
        plot.graph(temp.x_list,temp.y_list,x_label.par=paste(abscissa_quantity.par,", in ",abscissa_units.par,sep=""),
                   y_label.par=paste(ordinates_quantity.par,", in squared ",ordinates_units.par," per ",abscissa_units.par,sep=""),
                   pdf_title.par=paste("Buys_Baillot_Whitened_Residual_",ordinates_quantity.par,"_Spectrum.pdf",sep=""),
                   vertical_line.par=log10(frequency_band.par),log_bool.par=TRUE,type=c("l","p","l","l"),lty.par=c(1,0,1,1),col.par=c("grey90","grey50","grey70",1),
                   pch.par=c("",".","",""),cex.par=c(3,3,3,1),lwd.par=c(3,0,4,1))
      },silent=T)
      if(num_differences.par>0){
        #Plot the spectral-power estimates if differencing is required.
        temp.alpha=0.85
        temp.PTF<-1-2*temp.alpha*cos(2*pi*frequencies.par)+temp.alpha^2
        temp.differenced_truth_original_bb_whitened_spectral_powers<-temp.truth_original_bb_whitened_spectral_powers*temp.PTF
        temp.truth_differenced_bb_whitened_spectral_powers<-temp.truth_bb_whitened_spectral_powers*temp.PTF
        temp.differenced_filtered_original_bb_whitened_spectral_powers<-temp.filtered_original_bb_whitened_spectral_powers*temp.PTF
        temp.differenced_residual_bb_whitened_spectral_powers<-temp.residual_bb_whitened_spectral_powers*temp.PTF
        temp.x_list<-c()
        temp.y_list<-c()
        temp.colours<-c()
        temp.x_list<-list(log10(temp.plotting_frequencies0[temp.plotting_frequencies0>0]),log10(temp.plotting_frequencies0[temp.plotting_frequencies0>0]),
                          log10(temp.plotting_frequencies0[temp.plotting_frequencies0>0]),log10(temp.plotting_frequencies0[temp.plotting_frequencies0>0]))
        temp.y_list<-list(log10(temp.differenced_truth_original_bb_whitened_spectral_powers[temp.plotting_frequencies0>0]),
                          log10(temp.truth_differenced_bb_whitened_spectral_powers[temp.plotting_frequencies0>0]),
                          log10(temp.differenced_filtered_original_bb_whitened_spectral_powers[temp.plotting_frequencies0>0]),
                          log10(temp.differenced_residual_bb_whitened_spectral_powers[temp.plotting_frequencies0>0]))
        try({
          plot.graph(temp.x_list,temp.y_list,x_label.par=paste(abscissa_quantity.par,", in ",abscissa_units.par,sep=""),
                     y_label.par=paste(ordinates_quantity.par,", in squared ",ordinates_units.par," per ",abscissa_units.par,sep=""),
                     pdf_title.par=paste("Differenced_Buys_Baillot_Whitened_Residual_",ordinates_quantity.par,"_Spectrum.pdf",sep=""),
                     vertical_line.par=log10(frequency_band.par),log_bool.par=TRUE,type=c("l","p","l","l"),lty.par=c(1,0,1,1),
                     col.par=c("grey90","grey50","grey70",1),pch.par=c("",".","",""),cex.par=c(3,3,3,1),lwd.par=c(3,0,4,1))
        },silent=T)
      }
      #Plot the reconstructed series.
      temp.plotting_times_list<-list(temp.times_periodic)
      temp.bb_reconstruction<-temp.whitened_reconstruction[temp.bb_indices]-temp.whitened_periodic
      temp.plotting_ts_list<-list(temp.bb_reconstruction)
      plot.graph(temp.plotting_times_list,temp.plotting_ts_list,
                 x_label.par=paste(measured_abscissa_string.par,", in ",time_units_string.par," since ",round(time_sequence_list.par[[1]][1]/60,3),
                                   " minutes",sep=""),
                 y_label.par=paste(measure_quantity.string,", in ",measure_units.string,sep=""),pdf_title.par="Whitened_Bandpass_Series.pdf")
      #Plot the residuals.
      temp.plotting_times_list<-list(temp.times_periodic)
      temp.plotting_ts_list<-list(temp.whitened_periodic)
      plot.graph(temp.plotting_times_list,temp.plotting_ts_list,
                 x_label.par=paste(measured_abscissa_string.par,", in ",time_units_string.par," since ",round(time_sequence_list.par[[1]][1]/60,3),
                                   " minutes",sep=""),
                 y_label.par=paste(measure_quantity.string,", in ",measure_units.string,sep=""),pdf_title.par="Whitened_Bandpass_Series_Residuals.pdf")
    }
    if(plot_ts_bool.par==TRUE){
      #Time-domain performance assessment.
      temp.plotting_times_list<-list(temp.times)
      temp.plotting_ts_list<-list(temp.whitened_series)
      plot.graph(temp.plotting_times_list,temp.plotting_ts_list,
                 x_label.par=paste(measured_abscissa_string.par,", in ",time_units_string.par," since ",round(time_sequence_list.par[[1]][1]/60,3),
                                   " minutes",sep=""),
                 y_label.par=paste(measure_quantity.string,", in ",measure_units.string,sep=""),pdf_title.par=paste("Whitened_",ts_pdf_title.par,sep=""))
    }
    sink("Whitened_Filtered_Series.txt", append=FALSE, split=FALSE)
    cat(paste(paste(measured_abscissa_string.par,"\t",measure_quantity.string,"\n",sep="")))
    for(temp.n in 1:length(temp.times0)){
      cat(temp.times0[temp.n],"\t",temp.whitened_reconstruction[temp.n],"\n")
    }
    sink()
    sink("Buys_Baillot_Whitened_Filtered_Series.txt", append=FALSE, split=FALSE)
    cat(paste(paste(measured_abscissa_string.par,"\t",measure_quantity.string,"\n",sep="")))
    for(temp.n in 1:length(temp.times)){
      cat(temp.times[temp.n],"\t",temp.bb_reconstruction[temp.n],"\n")
    }
    sink()
  }
  else{
    #Energy.
    temp.full_energy=sum(temp.residual_spectral_powers)
    temp.stopband_energy=(temp.full_energy-sum(temp.residual_spectral_powers[temp.band_indices]))/temp.full_energy*100
  }
  #Output the original and the whitened series.
  sink("Time_Base.txt", append=FALSE, split=FALSE)
  cat("time_base\n")
  cat(round(time_sequence_list.par[[1]][1]/60,3))
  sink()
  sink("Original_Series.txt", append=FALSE, split=FALSE)
  cat(paste(paste(measured_abscissa_string.par,"\t",measure_quantity.string,"\n",sep="")))
  for(temp.n in 1:temp.N0){
    cat(time_sequence_list.par[[1]][temp.n]-time_sequence_list.par[[1]][1],"\t",ts_list.par[[1]][temp.n],"\n")
  }
  sink()
  temp.filtering_times<-time_sequence_list.par[[2]]-time_sequence_list.par[[1]][1]
  #temp.filtering_times<-time_sequence_list.par[[1]][(temp.N0-length(ts_list.par[[2]])+1):temp.N0-(temp.N0-length(ts_list.par[[2]]))/2]-
  #  time_sequence_list.par[[1]][1]
  sink("Filtered_Series.txt", append=FALSE, split=FALSE)
  cat(paste(paste(measured_abscissa_string.par,"\t",measure_quantity.string,"\n",sep="")))
  for(temp.n in 1:length(temp.filtering_times)){
    cat(temp.filtering_times[temp.n],"\t",ts_list.par[[2]][temp.n],"\n")
  }
  sink()
  temp.truth_eigencoeffs_sampled<-temp.truth_eigencoeffs[temp.band_indices,]
  temp.filtered_eigencoeffs_sampled<-temp.filtered_eigencoeffs[temp.band_indices,]
  temp.eigencoeff_list<-list(temp.truth_eigencoeffs_sampled,temp.filtered_eigencoeffs_sampled)
  cat("eigencoefficients_correlation_comparison.function\n")
  temp.eigencoefficients_correlation_comparison_object<-
    eigencoefficients_correlation_comparison.function(eigencoeff_list.par=temp.eigencoeff_list,
                                                      energy_concentrations.par=energy_concentrations.par,
                                                      frequencies.par=temp.plotting_frequencies[temp.band_indices],
                                                      frequency_band.par=frequency_band.par,
                                                      M.par=temp.M,sampling_rate.par=sampling_rate.par,
                                                      pdf_title.par=correlation_pdf_title.par,
                                                      correlation_type.par=correlation_type.par,
                                                      percentile_threshold.par=percentile_threshold.par,
                                                      abscissa_quantity.par=abscissa_quantity.par,
                                                      abscissa_units.par=abscissa_units.par,
                                                      ordinates_quantity.par=ordinates_quantity.par,
                                                      ordinates_units.par=ordinates_units.par,
                                                      correlation_pdf_title.par=correlation_pdf_title.par,
                                                      plot_bool.par=plot_bifrequency_map_bool.par,
                                                      smooth_image.par=smooth_image.par,theta.par=theta.par,
                                                      log_bool.par=log_bool.par,
                                                      verbose.par=verbose.par,downsample_bool.par=downsample_bool.par)
  cat("End eigencoefficients_correlation_comparison.function\n")
  temp.correlation_matrix<-temp.eigencoefficients_correlation_comparison_object$out.correlation_matrix
  temp.frequencies<-temp.eigencoefficients_correlation_comparison_object$out.frequencies
  temp.list<-list(out.residual_eigencoeff_list=temp.residual_eigencoeff_list,
                  out.plotting_frequencies=temp.plotting_frequencies,
                  out.correlation_matrix=temp.correlation_matrix,
                  out.spectral_power_sequences_list=temp.spectral_power_sequences_list,
                  out.stopband_energy=temp.stopband_energy,
                  out.frequencies=temp.frequencies)
  return(temp.list)
}


eigencoefficients_comparison_all_filters.function<-function(ts.par,ts_times.par,filtered_ts_list.par,time_sequence_list.par,energy_concentrations.par,
                                                            frequencies.par,frequency_band.par,
                                                            trial_filter_strings.par=c("Slepian","Chebyshev","FIR1000","FIR500","MixedFIR"),
                                                            NW.par=5,residual_bools.par=NA,sampling_rate.par=1,F_test_threshold.par=0.99,
                                                            num_sections.par=2,threshold_crossings_LB.par=3,correlation_type.par="CCA",
                                                            old_directory.par="",specific_subdirectory_string.par="",
                                                            percentile_threshold.par=0.3,threshold.par=0.5,
                                                            abscissa_scale.par=1,
                                                            abscissa_quantity.par="Measured quantity",abscissa_units.par="measured units",
                                                            ordinates_quantity.par="Measured quantity",ordinates_units.par="measured units",
                                                            measured_abscissa_string.par="Measured quantity",time_units_string.par="measured units",
                                                            time_units_string2.par="measured units",
                                                            plot_ts_bool.par=FALSE,plot_residual_spectrum_bool.par=FALSE,
                                                            plot_bifrequency_map_bool.par=FALSE,smooth_image.par=FALSE,
                                                            theta.par=0.9,log_bool.par=FALSE,verbose.par=FALSE,loop_verbose.par=FALSE,
                                                            demodulate_bool.par=FALSE,ha_bool_residual.par=FALSE,all_frequencies_bool.par=FALSE,
                                                            whitening_bool.par=FALSE,num_differences.par=0,
                                                            patient_index.par=1,electrode_index.par=1,downsample_bool.par=FALSE){
  temp.num_filters=length(filtered_ts_list.par)
  temp.maxima_matrix<-c()
  temp.num_rows=0
  temp.num_columns=0
  temp.optimal_filter_matrix<-c()
  temp.plotting_frequencies<-c()
  temp.stopband_energies<-c()
  temp.frequencies<-c()
  for(temp.i in 1:temp.num_filters){
    if(loop_verbose.par==TRUE){
      cat(temp.i," out of ",temp.num_filters,"\n")
    }
    temp.method_directory_string<-paste(trial_filter_strings.par[temp.i],"_Method",sep="")
    dir.create(temp.method_directory_string,showWarnings=FALSE)
    temp.working_directory_string<-paste(old_directory.par,"/",temp.method_directory_string,sep="")
    setwd(temp.working_directory_string)
    temp.filtered_ts<-filtered_ts_list.par[[temp.i]]
    temp.time_sequence<-time_sequence_list.par[[temp.i]]
    temp.ts_list<-list(ts.par,temp.filtered_ts)
    temp.time_sequence_list<-list(ts_times.par,temp.time_sequence)
    temp.comparison_object<-eigencoefficients_filter_comparison.function(ts_list.par=temp.ts_list,time_sequence_list.par=temp.time_sequence_list,
                                                                         energy_concentrations.par=energy.concentrations,frequencies.par=frequencies.par,
                                                                         frequency_band.par=frequency_band.par,
                                                                         NW.par=NW.par,residual_bools.par=residual_bools.par,sampling_rate.par=sampling_rate.par,
                                                                         F_test_threshold.par=F_test_threshold.par,num_sections.par=num_sections.par,
                                                                         threshold_crossings_LB.par=threshold_crossings_LB.par,
                                                                         correlation_type.par=correlation_type.par,
                                                                         old_directory.par=temp.working_directory_string,
                                                                         specific_subdirectory_string.par=specific_subdirectory_string.par,
                                                                         method_directory_string.par=temp.method_directory_string,
                                                                         percentile_threshold.par=percentile_threshold.par,
                                                                         abscissa_scale.par=abscissa_scale.par,
                                                                         abscissa_quantity.par=abscissa_quantity.par,abscissa_units.par=abscissa_units.par,
                                                                         ordinates_quantity.par=ordinates_quantity.par,ordinates_units.par=ordinates_units.par,
                                                                         measured_abscissa_string.par=measured_abscissa_string.par,
                                                                         time_units_string.par=time_units_string.par,
                                                                         ts_pdf_title.par=paste(trial_filter_strings.par[temp.i],"_Reconstructed_Section_",
                                                                                                ordinates_quantity.par,"_Series_Raw_",patient.string,"_",
                                                                                                patient_index.par,"_",electrode_string.uppercase,"_",
                                                                                                electrode_index.par,".pdf",sep=""),
                                                                         correlation_pdf_title.par=paste(trial_filter_strings.par[temp.i],"_",
                                                                                                         correlation_type.par,
                                                                                                         "_Coefficient_Map.pdf",sep=""),
                                                                         plot_ts_bool.par=plot_ts_bool.par,
                                                                         plot_residual_spectrum_bool.par=plot_residual_spectrum_bool.par,
                                                                         plot_bifrequency_map_bool.par=plot_bifrequency_map_bool.par,
                                                                         smooth_image.par=smooth_image.par,theta.par=theta.par,log_bool.par=log_bool.par,
                                                                         demodulate_bool.par=demodulate_bool.par,ha_bool_residual.par=ha_bool_residual.par,
                                                                         all_frequencies_bool.par=all_frequencies_bool.par,
                                                                         whitening_bool.par=whitening_bool.par,num_differences.par=num_differences.par,
                                                                         downsample_bool.par=downsample_bool.par)
    temp.correlation_matrix<-temp.comparison_object$out.correlation_matrix
    temp.frequencies<-temp.comparison_object$out.frequencies
    temp.stopband_energy<-temp.comparison_object$out.stopband_energy
    temp.stopband_energies[temp.i]=temp.stopband_energy
    if(temp.i==1){
      temp.plotting_frequencies<-temp.comparison_object$out.plotting_frequencies
      temp.maxima_matrix<-temp.correlation_matrix
      temp.num_rows=nrow(temp.correlation_matrix)
      temp.num_columns=ncol(temp.correlation_matrix)
      temp.optimal_filter_matrix<-matrix(0,nrow=temp.num_rows,ncol=temp.num_columns)
      temp.optimal_filter_matrix[temp.maxima_matrix>threshold.par]<-1
    }
    else{
      for(temp.j in 1:temp.num_rows){
        for(temp.k in 1:temp.num_columns){
          try({
            if(temp.correlation_matrix[temp.j,temp.k]>threshold.par){
              if(temp.correlation_matrix[temp.j,temp.k]>temp.maxima_matrix[temp.j,temp.k]){
                temp.maxima_matrix[temp.j,temp.k]=temp.correlation_matrix[temp.j,temp.k]
                temp.optimal_filter_matrix[temp.j,temp.k]=temp.i
              }
            }
          },silent=T)
        }
      }
    }
    setwd(old_directory.par)
  }
  temp.list<-list(out.maxima_matrix=temp.maxima_matrix,
                  out.optimal_filter_matrix=temp.optimal_filter_matrix,
                  out.stopband_energies=temp.stopband_energies,
                  out.frequencies=temp.frequencies)
  return(temp.list)
}


ordered_correlation_maps_analysis.function<-function(frequencies.par,maxima_matrices_list.par,optimal_maps_list.par,passband_frequencies.par,
                                                     clipping_threshold.par=90,
                                                     correlation_types.par=c("PLS","MLR"),measured_quantity.par="Measured quantity",
                                                     measurement_units.par="units",
                                                     filter_strings.par=c("Slepian","Chebyshev","FIR1000","FIR500","MixedFIR"),
                                                     support_curves.par=c("diagonal","diagonal")){
  temp.num_frequencies=length(frequencies.par)
  temp.x_bounds<-c(min(frequencies.par),max(max(frequencies.par),passband_frequencies.par[2]))
  temp.y_bounds<-temp.x_bounds
  temp.num_maps=length(optimal_maps_list.par)
  temp.lwd_vector<-c(1,rep(1,temp.num_maps-1))
  #"Differences" is used in the object names for the case of support_curve_orientation.par="diagonal" when only rotational correlations are considered,
  #though for high-frequency passbands the horizontal and vertical bands
  temp.frequency_diffs<-frequencies.par
  if(support_curves.par[1]=="diagonal"){
    temp.frequency_diffs<-c((-1)*rev(frequencies.par[2:temp.num_frequencies]),frequencies.par)
  }
  temp.num_frequency_diffs=length(temp.frequency_diffs)
  temp.ACS_sums_list<-list()
  for(temp.l in 1:length(correlation_types.par)){
    temp.matrix<-maxima_matrices_list.par[[temp.l]]
    temp.optimal_matrix<-optimal_maps_list.par[[temp.l]]
    temp.num_classes=length(unique(as.vector(temp.optimal_matrix)))
    temp.ACS_sums_matrix<-matrix(0,nrow=temp.num_frequency_diffs,ncol=temp.num_classes)
    pdf(paste(correlation_types.par[temp.l],"_Filter_Order_Map.pdf",sep=""),width=8,height=6)
    par(mar=c(5.1, 8.1, 5.1, 8.1))
    plot(0,0,xlab=paste(measured_quantity.par,", in ",measurement_units.par,sep=""),ylab=paste(measured_quantity.par,", in ",measurement_units.par,sep=""),
         main="",xlim=temp.x_bounds,ylim=temp.y_bounds,pch=".",lab=c(10,10,7))
    temp.counter=1
    for(temp.i in 1:temp.num_frequencies){
      for(temp.j in 1:temp.num_frequencies){
        if(temp.matrix[temp.i,temp.j]>clipping_threshold.par){
          temp.filter_index=temp.optimal_matrix[temp.i,temp.j]
          if(support_curves.par[temp.l]=="diagonal"){
            temp.diff_index1=which(temp.frequency_diffs==(frequencies.par[temp.i]-temp.num_frequencies+frequencies.par[temp.j]))
            temp.diff_index2=which(temp.frequency_diffs==(frequencies.par[temp.i]-frequencies.par[temp.j]))
            temp.ACS_sums_matrix[temp.diff_index1,temp.filter_index]=temp.ACS_sums_matrix[temp.diff_index1,temp.filter_index]+1
            temp.ACS_sums_matrix[temp.diff_index2,temp.filter_index]=temp.ACS_sums_matrix[temp.diff_index2,temp.filter_index]+1
          }
          else{
            if(support_curves.par[temp.l]=="horizontal"){
              temp.ACS_sums_matrix[temp.j,temp.filter_index]=temp.ACS_sums_matrix[temp.j,temp.filter_index]+1
            }
            else if(support_curves.par[temp.l]=="vertical"){
              temp.ACS_sums_matrix[temp.i,temp.filter_index]=temp.ACS_sums_matrix[temp.i,temp.filter_index]+1
            }
          }
          temp.point_style=19
          temp.cex=0.75
          temp.lwd=temp.lwd_vector[temp.filter_index]
          if(temp.filter_index>1){
            temp.point_style=temp.filter_index
            temp.cex=0.5
          }
          lines(frequencies.par[temp.i],frequencies.par[temp.j],type="p",pch=temp.point_style,
                col=temp.filter_index,lwd=temp.lwd,cex=temp.cex)
        }
        temp.counter=temp.counter+1
      }
    }
    par(xpd=TRUE)
    legend(x=passband_frequencies.par[2]+(passband_frequencies.par[2]-passband_frequencies.par[1])*5/passband_frequencies.par[2],
           y=passband_frequencies.par[1]+(passband_frequencies.par[2]-passband_frequencies.par[1])*
             (passband_frequencies.par[2]/2+5)/passband_frequencies.par[2],c(filter_strings.par),
           bg="white",pch=c(19,2:temp.num_maps),col=1:temp.num_classes,lwd=temp.lwd_vector)
    dev.off()
    temp.ACS_sums_list[[temp.l]]<-temp.ACS_sums_matrix
  }
  temp.list<-list(out.frequency_diffs=temp.frequency_diffs,
                  out.ACS_sums_list=temp.ACS_sums_list)
  return(temp.list)
}


correlation_maps_boxplots.function<-function(frequency_diffs_list.par,ACS_sums_list.par,correlation_strings.par,filter_strings.par,N.par,M.par=NA,NW.par=5,
                                             abscissa_string.par="Measured units",abscissa_units.par="units",
                                             plot.par=FALSE,verbose.par=FALSE){
  if(is.na(M.par)==TRUE){
    M.par=N.par
  }
  temp.num_list_elements=length(ACS_sums_list.par)
  temp.peak_statistics_list<-list()
  for(temp.l in 1:temp.num_list_elements){
    if(verbose.par==TRUE){
      sink(paste(correlation_strings.par[temp.l],"_Box_Plots_Passband.txt",sep=""), append=FALSE, split=FALSE)
    }
    temp.matrix<-ACS_sums_list.par[[temp.l]]
    temp.num_ACS_columns=ncol(temp.matrix)
    temp.frequency_diffs_list<-list()
    temp.ACS_sums_list<-list()
    temp.frequency_diffs<-frequency_diffs_list.par
    temp.running_peak_statistics_list<-list()
    for(temp.i in 1:temp.num_ACS_columns){
      temp.summed_support_coefficients<-temp.matrix[,temp.i]
      temp.summed_support_coefficients[is.na(temp.summed_support_coefficients)==TRUE]<-0
      temp.frequency_diffs_list[[temp.i]]<-temp.frequency_diffs
      temp.smoothed_summed_support_coefficients<-temp.summed_support_coefficients
      temp.num_sums=length(temp.smoothed_summed_support_coefficients)
      for(temp.k in 1:temp.num_sums){
        temp.min_index=max(1,temp.k-10)
        temp.max_index=min(temp.num_sums,temp.k+10)
        temp.smoothed_summed_support_coefficients[temp.k]=mean(temp.summed_support_coefficients[temp.min_index:temp.max_index])
      }
      temp.ACS_sums_list[[temp.i]]<-temp.smoothed_summed_support_coefficients
      temp.local_maxima_object<-local_maxima_second_derivative_test.function(abscissa.par=temp.frequency_diffs,
                                                                             function_values.par=temp.smoothed_summed_support_coefficients,
                                                                             histogram_bin_width.par=0)
      temp.optimal_frequencies<-temp.local_maxima_object$out.local_optimal_abscissa
      temp.num_optimal=length(temp.optimal_frequencies)
      temp.peak_heights<-rep(0,temp.num_optimal)
      for(temp.k in 1:temp.num_optimal){
        temp.optimal_frequency=temp.optimal_frequencies[temp.k]
        temp.peak_heights[temp.k]<-temp.smoothed_summed_support_coefficients[temp.frequency_diffs==temp.optimal_frequency]
      }
      temp.min=0
      temp.median=0
      temp.sd=0
      temp.min_offset=0
      temp.max_offset=0
      temp.median_offset=0
      temp.offset_sd=0
      temp.max=0
      temp.num_nonzero=length(which(temp.peak_heights>0))
      if(temp.num_nonzero>0){
        temp.nonzero_heights<-temp.peak_heights[temp.peak_heights>0]
        temp.optimal_nonzero<-temp.optimal_frequencies[temp.peak_heights>0]
        try({
          if(temp.num_nonzero>1){
            temp.greater_heights<-temp.peak_heights[temp.peak_heights>1]
            temp.optimal_greater<-temp.optimal_frequencies[temp.peak_heights>1]
            temp.num_greater=length(temp.greater_heights)
            if(temp.num_greater>1){
              temp.min=min(temp.greater_heights)
              temp.median=median(temp.greater_heights)
              temp.sd=sqrt(var(temp.greater_heights))
              temp.min_offset=min(temp.optimal_greater)
              temp.max_offset=max(temp.optimal_greater)
              temp.median_offset=median(temp.optimal_greater)
              temp.offset_sd=sqrt(var(temp.optimal_greater))
            }
            else{
              temp.min=min(temp.nonzero_heights)
              temp.median=median(temp.nonzero_heights)
              temp.sd=sqrt(var(temp.nonzero_heights))
              temp.min_offset=min(temp.optimal_nonzero)
              temp.max_offset=max(temp.optimal_nonzero)
              temp.median_offset=median(temp.optimal_nonzero)
              temp.offset_sd=sqrt(var(temp.optimal_nonzero))
            }
          }
          else{
            temp.median=median(temp.peak_heights)
            temp.sd=sqrt(var(temp.peak_heights))
            temp.min_offset=min(temp.optimal_frequencies)
            temp.max_offset=max(temp.optimal_frequencies)
            temp.median_offset=median(temp.optimal_frequencies)
            temp.offset_sd=sqrt(var(temp.optimal_frequencies))
          }
          temp.max=max(temp.peak_heights)
        },silent=T)
      }
      temp.running_peak_statistics_list[[temp.i]]<-c(temp.min,max(temp.min,temp.median-temp.sd),temp.median,temp.median+temp.sd,temp.max,temp.min_offset,
                                                     max(temp.min_offset,temp.median_offset-temp.offset_sd),temp.median_offset,temp.median_offset+temp.offset_sd,
                                                     temp.max_offset)
    }
    if(verbose.par==TRUE){
      cat("filter\tmin\tsd_minus\tmedian\tsd_plus\tmax\tmin_offset\toffset_sd_minus\tmedian_offset\toffset_sd_plus\tmax_offset\n")
      for(temp.i in 1:temp.num_ACS_columns){
        temp.peak_statistics<-temp.running_peak_statistics_list[[temp.i]]
        cat(filter_strings.par[temp.i],"\t")
        for(temp.j in 1:length(temp.peak_statistics)){
          cat(temp.peak_statistics[temp.j],"\t")
        }
        cat("\n")
      }
      sink()
    }
    if(plot.par==TRUE){
      temp.heights_quantity<-""
      temp.heights_units<-"percentage points"
      if(correlation_strings.par[temp.l]=="PLS"){
        temp.heights_quantity<-"PLS correlation coefficient"
      }
      else if(correlation_strings.par[temp.l]=="MLR"){
        temp.heights_quantity<-"Redundancy index"
      }
      else{
        temp.heights_quantity<-"Mutual information"
        temp.heights_units<-""
      }
      plot.graph(temp.frequency_diffs_list,temp.ACS_sums_list,x_label.par=paste(abscissa_string.par," offset, in ",abscissa_units.par,sep=""),
                 y_label.par=paste(temp.heights_quantity,", level crossings summed over support line",sep=""),
                 pdf_title.par=paste("Summed_",correlation_strings.par[temp.l],"_Mass_ACS.pdf",sep=""),col=1:temp.num_ACS_columns,
                 type.par=rep("o",temp.num_ACS_columns),pch.par=1:temp.num_ACS_columns)
    }
  }
}


correlation_maps_analysis.function<-function(maxima_matrices_list.par,optimal_maps_list.par,frequencies.par,frequency_band.par,N.par,M.par=NA,NW.par=5,
                                             sampling_rate.par=1,clipping_threshold.par=90,
                                             correlation_types.par=c("PLS","MLR"),measured_quantity.par="Measured units",measurement_units.par="units",
                                             filter_strings.par=c("Slepian","Chebyshev","FIR1000","FIR500","MixedFIR"),plot.par=FALSE,
                                             verbose.par=FALSE,support_curves.par=c("diagonal","diagonal"),downsample_bool.par=FALSE){
  temp.plotting_frequencies<-frequencies.par*sampling_rate.par
  temp.plotting_frequencies<-
    temp.plotting_frequencies[temp.plotting_frequencies>=frequency_band.par[1] & temp.plotting_frequencies<frequency_band.par[2]]
  if(downsample_bool.par==TRUE){
    temp.num_frequencies=length(temp.plotting_frequencies)
    if(temp.num_frequencies>50){
      temp.step_size=floor(temp.num_frequencies/50)
      temp.sampling_indices<-seq(from=1,to=temp.num_frequencies,by=temp.step_size)
      temp.plotting_frequencies<-temp.plotting_frequencies[temp.sampling_indices]
      temp.plotting_frequencies<-temp.plotting_frequencies[1:50]
    }
  }
  temp.ordered_correlation_maps_analysis_object<-ordered_correlation_maps_analysis.function(frequencies.par=temp.plotting_frequencies,
                                                                                            maxima_matrices_list.par=maxima_matrices_list.par,
                                                                                            optimal_maps_list.par=optimal_maps_list.par,
                                                                                            passband_frequencies.par=frequency_band.par,
                                                                                            clipping_threshold.par=clipping_threshold.par,
                                                                                            correlation_types.par=correlation_types.par,
                                                                                            measured_quantity.par=measured_quantity.par,
                                                                                            measurement_units.par=measurement_units.par,
                                                                                            filter_strings.par=filter_strings.par,
                                                                                            support_curves.par=support_curves.par)
  temp.frequency_diffs_list<-temp.ordered_correlation_maps_analysis_object$out.frequency_diffs
  temp.ACS_sums_list<-temp.ordered_correlation_maps_analysis_object$out.ACS_sums_list
  correlation_maps_boxplots.function(frequency_diffs_list.par=temp.frequency_diffs_list,ACS_sums_list.par=temp.ACS_sums_list,
                                     correlation_strings.par=correlation_types.par,filter_strings.par=filter_strings.par,
                                     N.par=N.par,M.par=M.par,NW.par=NW.par,
                                     abscissa_string.par=measured_quantity.par,abscissa_units.par=measurement_units.par,
                                     plot.par=plot.par,verbose.par=verbose.par)
}















