#Francois Marshall, Boston University
#Header file for presenting output of results.
###################################################################################################################

create_and_set_directory.function<-function(directory_title.par,specific_subdirectory_string.par,revised_specific_directory_string.par,
                                            working_directory_string.par,update_specific_directory_bool.par=FALSE){
  temp.revised_specific_directory_string<-paste(specific_subdirectory_string.par,directory_title.par,sep="")
  dir.create(directory_title.par,showWarnings=FALSE)
  temp.working_directory_string<-paste(working_directory_string.par,directory_title.par,sep="")
  cat("directory_title.par\n")
  print(directory_title.par)
  cat("temp.working_directory_string\n")
  print(temp.working_directory_string)
  setwd(temp.working_directory_string)
  temp.list<-list(out.working_directory_string=temp.working_directory_string)
  if(update_specific_directory_bool.par==TRUE){
    temp.list<-list.append(temp.list,
                           out.revised_specific_directory_string=temp.revised_specific_directory_string)
  }
  return(temp.list)
}


create_and_set_multiple_directories.function<-function(directory_strings.par,specific_subdirectory_string.par,working_directory_string.par){
  temp.revised_specific_directory_string<-""
  temp.working_directory_string<-""
  for(temp.i in 1:length(directory_strings.par)){
    if(temp.i==1){
      temp.specific_subdirectory_string<-specific_subdirectory_string.par
      temp.working_directory_string<-working_directory_string.par
    }
    patient_directory.object<-create_and_set_directory.function(directory_title.par=paste(directory_strings.par[temp.i],"/",sep=""),
                                                                specific_subdirectory_string.par=temp.specific_subdirectory_string,
                                                                working_directory_string.par=temp.working_directory_string,
                                                                update_specific_directory_bool.par=TRUE)
    temp.revised_specific_directory_string<-patient_directory.object$out.revised_specific_directory_string
    temp.working_directory_string<-patient_directory.object$out.working_directory_string
    temp.specific_subdirectory_string<-temp.revised_specific_directory_string
  }
  temp.list<-list(out.revised_specific_subdirectory_string=temp.revised_specific_directory_string,
                  out.working_directory_string=temp.working_directory_string,
                  out.specific_subdirectory_string=temp.specific_subdirectory_string)
  return(temp.list)
}




























