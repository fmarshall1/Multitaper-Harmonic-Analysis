#Francois Marshall, Boston University
#Header file for presenting output of results.
###################################################################################################################

round_general.function<-function(value.par,digits.par=2){
  value.par=scientific(value.par,digits=digits.par)
  return(value.par)
}

result.significant_figures<-function(result.par,uncertainty.par){
  temp.uncertainty=signif(uncertainty.par,1)
  temp.power_of_ten=0
  temp.log_uncertainty=log10(abs(temp.uncertainty))
  if(temp.log_uncertainty<0){
    temp.power_of_ten=floor(temp.log_uncertainty)
  }
  else{
    temp.power_of_ten=ceiling(temp.log_uncertainty)
  }
  temp.result=round(result.par,-temp.power_of_ten)
  temp.list<-list(temp.result,temp.uncertainty)
  return(temp.list)
}

round.results<-function(results.par,uncertainties.par){
  temp.N_results=length(results.par)
  temp.rounded_results<-rep(0,temp.N_results)
  temp.rounded_uncertainites<-rep(0,temp.N_results)
  for(i in 1:temp.N_results){
    temp.result_object<-result.significant_figures(results.par[i],uncertainties.par[i])
    temp.rounded_results[i]=temp.result_object[[1]]
    temp.rounded_uncertainites[i]=temp.result_object[[2]]
  }
  temp.list<-list(temp.rounded_results,temp.rounded_uncertainites)
  return(temp.list)
}

output.table<-function(matrix.par,labels.par,title.par="Output"){
  temp.num_rows=nrow(matrix.par)
  temp.num_items=ncol(matrix.par)
  sink(paste(title.par,".txt",sep=""), append=FALSE, split=FALSE)
  for(temp.i in 1:temp.num_items){
    cat(labels.par[temp.i],"\t")
  }
  cat("\n")
  for(temp.i in 1:temp.num_rows){
    for(temp.j in 1:temp.num_items){
      cat(matrix.par[temp.i,temp.j],"\t")
    }
    cat("\n")
  }
  sink()
}



output_list.function<-function(list.par,title.par="Output"){
  sink(paste(title.par,".txt",sep=""), append=FALSE, split=FALSE)
  #Determine the number of columns.
  temp.num_list_elements=length(list.par)
  temp.na_bool_vector=rep(FALSE,temp.num_list_elements)
  for(temp.i in 1:temp.num_list_elements){
    if(is.na(list.par[[temp.i]])==TRUE){
      temp.na_bool_vector[temp.i]=TRUE
    }
  }
  temp.max_size=0
  for(temp.i in 1:temp.num_list_elements){
    if(!temp.na_bool_vector[temp.i]){
      temp.num_item_elements=length(list.par[[temp.i]])
      if(temp.num_item_elements>temp.max_size){
        temp.max_size=temp.num_item_elements
      }
    }
  }
  #Labels at the top of the text file.
  cat("list_item","\t")
  for(temp.i in 1:temp.max_size){
    cat(paste("vector_item_",temp.i,sep=""),"\t")
  }
  cat("\n")
  for(temp.i in 1:temp.num_list_elements){
    temp.num_item_elements=length(list.par[[temp.i]])
    temp.list_element<-list.par[[temp.i]]
    if(!temp.na_bool_vector[temp.i]){
      cat(paste("list_item_",temp.i,sep=""),"\t")
      for(temp.j in 1:temp.max_size){
        
        if(temp.j<=temp.num_item_elements){
          cat(temp.list_element[temp.j],"\t")
        }
        else{
          cat(0,"\t")
        }
      }
    }
    cat("\n")
  }
  sink()
}











