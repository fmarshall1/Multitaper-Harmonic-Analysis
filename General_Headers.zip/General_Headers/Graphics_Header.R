#Francois Marshall, Boston University
#Header file for presenting plots.

###################################################################################################################

#https://www.dataanalytics.org.uk/make-transparent-colors-in-r/
t_col <- function(color, percent = 50, name = NULL) {
  #      color = color name
  #    percent = % transparency
  #       name = an optional name for the color
  
  ## Get RGB values for named color
  rgb.val <- col2rgb(color)
  
  ## Make new color using input color as base and alpha set by transparency
  t.col <- rgb(rgb.val[1], rgb.val[2], rgb.val[3],
               max = 255,
               alpha = (100 - percent) * 255 / 100,
               names = name)
  
  ## Save the color
  invisible(t.col)
}


#https://www.datacamp.com/community/tutorials/support-vector-machines-r
make.grid<-function(x, n = 75) {
  grange = apply(x, 2, range)
  x1 = seq(from = grange[1,1], to = grange[2,1], length = n)
  x2 = seq(from = grange[1,2], to = grange[2,2], length = n)
  expand.grid(X1 = x1, X2 = x2)
}


#Plot a typical graph.
plotting.sampled_vector<-function(x_plotting.par,num_samples.par=5000){
  temp.original_length=length(x_plotting.par)
  temp.num_samples=temp.original_length
  if(num_samples.par<temp.original_length){
    temp.num_samples=num_samples.par
  }
  temp.step_size=floor(temp.original_length/temp.num_samples)
  temp.sampling_vector<-seq(from=1,to=temp.original_length,by=temp.step_size)
  return(x_plotting.par[temp.sampling_vector])
}


legend.function<-function(x_values.par,y_values.par,title.par="",labels.par="",lty.par=NA,lwd.par=NA,bg.par=NA,legend_plot_bool.par=FALSE,
                          col.par=NA,pch.par=NA,cex.par=NA){
  temp.num_labels=length(labels.par)
  temp.lwd<-rep(1,temp.num_labels)
  if(!is.na(lwd.par)){
    temp.lwd<-lwd.par
  }
  if(!is.na(pch.par) & is.na(cex.par)==TRUE){
    cex.par<-rep(1,length(pch.par))
  }
  temp.location_string="topright"
  x_values.par<-TF_cleaning.function(x_values.par)$out.TF
  y_values.par<-TF_cleaning.function(y_values.par)$out.TF
  temp.median_x=median(x_values.par)
  temp.median_y=median(y_values.par)
  temp.min_y=min(y_values.par)
  temp.max_y=max(y_values.par)
  if(max(y_values.par[x_values.par<temp.median_x])<temp.median_y){
    temp.location_string="topleft"
  }
  else if(min(y_values.par[x_values.par>temp.median_x])<=temp.median_y){
    temp.location_string="topright"
  }
  else if(min(y_values.par[x_values.par<temp.median_x])>temp.median_y){
    temp.location_string="bottomleft"
  }
  else if(min(y_values.par[x_values.par>temp.median_x])>temp.median_y){
    temp.location_string="bottomright"
  }
  else{
    temp.max_y=temp.max_y+0.1*(temp.max_y-temp.min_y)
  }
  if(legend_plot_bool.par==TRUE){
    if(!is.na(lty.par)){
      if(!is.na(col.par)){
        if(!is.na(pch.par)){
          if(!is.na(bg.par)){
            legend(temp.location_string,title=title.par,legend=labels.par,lty=lty.par,lwd=temp.lwd,bg=bg.par,col=col.par,pch=pch.par,pt.cex=3*cex.par)
          }
          else{
            legend(temp.location_string,title=title.par,legend=labels.par,lty=lty.par,lwd=temp.lwd,col=col.par,pch=pch.par,pt.cex=3*cex.par)
          }
        }
        else{
          if(!is.na(bg.par)){
            legend(temp.location_string,title=title.par,legend=labels.par,lty=lty.par,lwd=temp.lwd,bg=bg.par,col=col.par)
          }
          else{
            legend(temp.location_string,title=title.par,legend=labels.par,lty=lty.par,lwd=temp.lwd,col=col.par)
          }
        }
      }
      else{
        if(!is.na(pch.par)){
          if(!is.na(bg.par)){
            legend(temp.location_string,title=title.par,legend=labels.par,lty=lty.par,lwd=temp.lwd,bg=bg.par,pch=pch.par,pt.cex=3*cex.par)
          }
          else{
            legend(temp.location_string,title=title.par,legend=labels.par,lty=lty.par,lwd=temp.lwd,pch=pch.par,pt.cex=3*cex.par)
          }
        }
        else{
          if(!is.na(bg.par)){
            legend(temp.location_string,title=title.par,legend=labels.par,lty=lty.par,lwd=temp.lwd,bg=bg.par)
          }
          else{
            legend(temp.location_string,title=title.par,legend=labels.par,lty=lty.par,lwd=temp.lwd)
          }
        }
      }
    }
    else{
      if(!is.na(col.par)){
        if(!is.na(pch.par)){
          if(!is.na(bg.par)){
            legend(temp.location_string,title=title.par,legend=labels.par,lwd=temp.lwd,bg=bg.par,col=col.par,pch=pch.par,pt.cex=3*cex.par)
          }
          else{
            legend(temp.location_string,title=title.par,legend=labels.par,lwd=temp.lwd,col=col.par,pch=pch.par,pt.cex=3*cex.par)
          }
        }
        else{
          if(!is.na(bg.par)){
            legend(temp.location_string,title=title.par,legend=labels.par,lwd=temp.lwd,bg=bg.par,col=col.par)
          }
          else{
            legend(temp.location_string,title=title.par,legend=labels.par,lwd=temp.lwd,col=col.par)
          }
        }
      }
      else{
        if(!is.na(pch.par)){
          if(!is.na(bg.par)){
            legend(temp.location_string,title=title.par,legend=labels.par,lwd=temp.lwd,bg=bg.par,pch=pch.par,pt.cex=3*cex.par)
          }
          else{
            legend(temp.location_string,title=title.par,legend=labels.par,lwd=temp.lwd,pch=pch.par,pt.cex=3*cex.par)
          }
        }
        else{
          if(!is.na(bg.par)){
            legend(temp.location_string,title=title.par,legend=labels.par,lwd=temp.lwd,bg=bg.par)
          }
          else{
            legend(temp.location_string,title=title.par,legend=labels.par,lwd=temp.lwd)
          }
        }
      }
    }
  }
  return(temp.max_y)
}


plot.graph<-function(x_list.par,y_list.par,x_label.par="",y_label.par="",plot_title.par="",pdf_title.par="",plotting_LB.par=NA,plotting_UB.par=NA,
                     lwd.par=NA,col.par=NA,legend_labels.par=NA,legend_title.par="",vertical_line.par=NA,horizontal_line.par=NA,lty.par=NA,
                     min_y.par=NA,max_y.par=NA,log_bool.par=FALSE,type.par=NA,pch.par=NA,cex.par=NA,numeric_list.par=NA,
                     plotting_LB_x.par=NA,plotting_UB_x.par=NA,shade_intervals.par=NA){
  temp.num_list_entries=length(x_list.par)
  temp.colours<-rep(1,temp.num_list_entries)
  if(!is.na(col.par)){
    temp.colours<-col.par
  }
  temp.lty<-rep(1,temp.num_list_entries)
  if(!is.na(lty.par)){
    temp.lty<-lty.par
  }
  temp.type<-rep("l",temp.num_list_entries)
  if(!is.na(type.par)){
    temp.type<-type.par
  }
  temp.lwd<-rep(1,temp.num_list_entries)
  if(!is.na(lwd.par)){
    temp.lwd<-lwd.par
  }
  for(temp.i in 1:temp.num_list_entries){
    temp.size=length(x_list.par[[temp.i]])
    if(temp.size>1e3){
      temp.lwd[temp.i]=1e3/temp.size
    }
  }
  temp.pch<-rep(1,temp.num_list_entries)
  if(!is.na(pch.par)){
    temp.pch<-pch.par
  }
  temp.cex<-rep(1,temp.num_list_entries)
  if(!is.na(cex.par)){
    temp.cex<-cex.par
  }
  temp.numeric<-rep(NA,temp.num_list_entries)
  temp.numeric_na_bool=TRUE
  for(temp.i in 1:temp.num_list_entries){
    if(!is.na(numeric_list.par)){
      if(!is.na(numeric_list.par[[temp.i]])){
        temp.numeric_na_bool=FALSE
      }
    }
  }
  if(!temp.numeric_na_bool){
    temp.numeric<-numeric_list.par
  }
  temp.all_x<-unlist(x_list.par)
  temp.all_y<-unlist(y_list.par)
  temp.x_bounds=c(plotting_LB_x.par,plotting_UB_x.par)
  if(is.na(plotting_LB_x.par)==TRUE || (!plotting_LB_x.par & !plotting_UB_x.par)){
    temp.x_bounds[1]=min(temp.all_x)
  }
  if(is.na(plotting_UB_x.par)==TRUE || (!plotting_LB_x.par & !plotting_UB_x.par)){
    temp.x_bounds[2]=max(temp.all_x)
  }
  temp.y_bounds=c(plotting_LB.par,plotting_UB.par)
  if(is.na(plotting_LB.par)==TRUE || (!plotting_LB.par & !plotting_UB.par)){
    temp.y_bounds[1]=min(temp.all_y)
  }
  if(is.na(plotting_UB.par)==TRUE || (!plotting_LB.par & !plotting_UB.par)){
    temp.y_bounds[2]=max(temp.all_y)
  }
  temp.plotting_indices<-1:temp.num_list_entries
  if(!is.na(legend_labels.par) & !temp.y_bounds[2]){
    temp.y_bounds[2]=legend.function(unlist(x_list.par),unlist(y_list.par),title.par=legend_title.par,labels.par=legend_labels.par,
                                     lty.par=temp.lty,lwd.par=temp.lwd,pch.par=pch.par,cex.par=cex.par)
  }
  if(!is.na(min_y.par) & !is.na(max_y.par)){
    temp.original_diff=temp.y_bounds[2]-temp.y_bounds[1]
    temp.new_diff=max_y.par-min_y.par
    temp.diff_ratio=max(temp.new_diff/temp.original_diff,temp.original_diff/temp.new_diff)
    if(temp.diff_ratio<20){
      temp.y_bounds[1]=min(temp.y_bounds[1],min_y.par)
      temp.y_bounds[2]=max(temp.y_bounds[2],max_y.par)
    }
  }
  pdf(paste(pdf_title.par),width=8,height=6)
  par(mgp=c(2,1,0))
  if(!log_bool.par){
    plot(0,0,xlab=paste(x_label.par),ylab=paste(y_label.par),main=paste(plot_title.par),xlim=c(temp.x_bounds[1],temp.x_bounds[2]),
         ylim=c(temp.y_bounds[1],temp.y_bounds[2]),pch=".",lab=c(10,10,7))
  }
  else{
    par(mar=c(7.1, 7.1, 4.1, 2.1))
    par(mgp=c(5,1,0))
    plot(0,0,xlab=paste(x_label.par),ylab=paste(y_label.par),main=paste(plot_title.par),xlim=c(temp.x_bounds[1],temp.x_bounds[2]),
         ylim=c(temp.y_bounds[1],temp.y_bounds[2]),pch=".",lab=c(10,10,7),xaxt="n",yaxt="n")
    log_axis.function(temp.x_bounds[1],temp.x_bounds[2])
    log_axis.function(temp.y_bounds[1],temp.y_bounds[2],y_axis.par=TRUE)
  }
  grid()
  minor.tick(10,10)
  if(!is.na(shade_intervals.par)){
    temp.num_vertical_lines=length(shade_intervals.par)
    if(temp.num_vertical_lines>1){
      for(temp.i in seq(from=1,to=temp.num_vertical_lines,by=2)){
        if(temp.i<temp.num_vertical_lines){
          temp.left_bound=shade_intervals.par[temp.i]
          temp.right_bound=shade_intervals.par[temp.i+1]
          temp.range_diff=temp.y_bounds[2]-temp.y_bounds[1]
          temp.edge_LB<-temp.y_bounds[1]-0.1*temp.range_diff
          temp.edge_UB<-temp.y_bounds[2]+0.1*temp.range_diff
          temp.left_horizontal_edges<-rep(temp.left_bound,2)
          temp.right_horizontal_edges<-rep(temp.right_bound,2)
          temp.vertical_edges<-c(temp.edge_LB,temp.edge_UB)
          polygon(c(temp.left_horizontal_edges,rev(temp.right_horizontal_edges)),c(temp.vertical_edges,rev(temp.vertical_edges)),col="grey95",border=NA)
        }
      }
    }
  }
  if(!is.na(horizontal_line.par)){
    abline(h=horizontal_line.par,lwd=2)
  }
  if(!is.na(vertical_line.par)){
    for(temp.i in 1:length(vertical_line.par)){
      abline(v=vertical_line.par[temp.i],lwd=2)
    }
  }
  for(temp.i in temp.plotting_indices){
    temp.x_plotting<-x_list.par[[temp.i]]
    temp.y_plotting<-y_list.par[[temp.i]]
    if(!is.na(temp.numeric[[temp.i]])){
      for(temp.j in 1:length(temp.x_plotting)){
        text(temp.x_plotting[temp.j],temp.y_plotting[temp.j],label=temp.numeric[[temp.i]][temp.j])
      }
    }
    else{
      lines(temp.x_plotting,temp.y_plotting,type=temp.type[temp.i],pch=temp.pch[temp.i],cex=temp.cex[temp.i],
            lwd=temp.lwd[temp.i],col=temp.colours[temp.i],lty=temp.lty[temp.i])
    }
  }
  if(!is.na(legend_labels.par)){
    legend.function(unlist(temp.x_plotting),unlist(temp.y_plotting),title.par=legend_title.par,labels.par=legend_labels.par,
                    lty.par=temp.lty,legend_plot_bool.par=TRUE,col.par=col.par,lwd.par=temp.lwd,
                    pch.par=pch.par,cex.par=cex.par)
  }
  dev.off()
}


plot_graph.linear_trend<-function(x.par,y.par,linear_trend.par,x_label.par="",y_label.par="",plot_title.par="",pdf_title.par="",
                                  plotting_LB.par=0,plotting_UB.par=0){
  temp.num_list_entries=length(x.par)
  temp.x_bounds=c(min(x.par),max(x.par))
  temp.y_bounds=c(plotting_LB.par,plotting_UB.par,linear_trend.par[,2])
  if(!plotting_LB.par & !plotting_UB.par){
    temp.y_bounds=c(min(c(y.par,linear_trend.par[,2])),max(c(y.par,linear_trend.par[,2])))
  }
  pdf(paste(pdf_title.par),width=8,height=6)
  par(mgp=c(2,1,0))
  plot(0,0,xlab=paste(x_label.par),ylab=paste(y_label.par),main=paste(plot_title.par),xlim=c(temp.x_bounds[1],temp.x_bounds[2]),
       ylim=c(temp.y_bounds[1],temp.y_bounds[2]),pch=".",lab=c(10,10,7))
  grid()
  minor.tick(10,10)
  lines(x.par,y.par,type="p",pch=19)
  lines(linear_trend.par[,1],linear_trend.par[,2],col=2,lwd=2)
  dev.off()
}


plot_graph.confidence_intervals<-function(x.par,y.par,y_LB.par,y_UB.par,x_label.par="",y_label.par="",plot_title.par="",pdf_title.par="",log_bool.par=FALSE){
  temp.x_bounds=c(min(x.par),max(x.par))
  temp.y_bounds=c(min(y_LB.par),max(y_UB.par))
  pdf(paste(pdf_title.par),width=8,height=6)
  par(mgp=c(2,1,0))
  if(log_bool.par==TRUE){
    par(mar=c(7.1, 7.1, 4.1, 2.1))
    par(mgp=c(5,1,0))
    plot(0,0,xlab=paste(x_label.par),ylab=paste(y_label.par),main=paste(plot_title.par),xlim=c(temp.x_bounds[1],temp.x_bounds[2]),
         ylim=c(temp.y_bounds[1],temp.y_bounds[2]),pch=".",lab=c(10,10,7),xaxt="n",yaxt="n")
    log_axis.function(temp.x_bounds[1],temp.x_bounds[2])
    log_axis.function(temp.y_bounds[1],temp.y_bounds[2],y_axis.par=TRUE)
  }
  else{
    plot(0,0,xlab=paste(x_label.par),ylab=paste(y_label.par),main=paste(plot_title.par),xlim=c(temp.x_bounds[1],temp.x_bounds[2]),
         ylim=c(temp.y_bounds[1],temp.y_bounds[2]),pch=".",lab=c(10,10,7))
  }
  grid()
  minor.tick(10,10)
  lines(x.par,y_LB.par,pch=".",col="grey")
  lines(x.par,y_UB.par,pch=".",col="grey")
  polygon(c(x.par,rev(x.par)),c(y_LB.par,rev(y_UB.par)),col="grey50",border=NA)
  lines(x.par,y.par)
  dev.off()
}


plot_graph.min_median_max_multiple<-function(x.par,y.par,x_label.par,y_label.par,plot_title.par,pdf_title.par=""){
  temp.x_bounds=c(min(x.par),max(x.par))
  temp.num_items=length(y.par)
  pdf(paste(pdf_title.par),width=8,height=6)
  par(mgp=c(2,1,0))
  for(temp.j in 1:temp.num_items){
    temp.matrix<-y.par[[temp.j]]
    temp.LB_vector<-temp.matrix[,1]
    temp.y_plotting<-temp.matrix[,2]
    temp.UB_vector<-temp.matrix[,3]
    temp.LB_vector[!temp.LB_vector]<-temp.y_plotting[!temp.LB_vector]
    temp.nonzero_indices<-which(temp.y_plotting!=0)
    temp.num_nonzero=length(temp.nonzero_indices)
    temp.arrows_LB<-rep(0,length(temp.y_plotting))
    temp.arrows_UB<-temp.arrows_LB
    temp.arrows_x<-temp.arrows_LB
    temp.plotting_y<-temp.arrows_LB
    if(temp.num_nonzero!=0){
      temp.arrows_x<-x.par[temp.nonzero_indices]
      temp.arrows_LB<-temp.LB_vector[temp.nonzero_indices]
      temp.arrows_UB<-temp.UB_vector[temp.nonzero_indices]
      temp.plotting_y<-temp.y_plotting[temp.nonzero_indices]
    }
    temp.y_bounds=c(min(temp.arrows_LB),max(temp.arrows_UB))
    plot(0,0,xlab=x_label.par[temp.j],ylab=y_label.par[temp.j],main=paste(plot_title.par[temp.j]),
         xlim=c(temp.x_bounds[1],temp.x_bounds[2]),ylim=c(temp.y_bounds[1],temp.y_bounds[2]),pch=".",lab=c(10,10,7))
    grid()
    minor.tick(10,10)
    arrows(x0=temp.arrows_x,y0=temp.arrows_LB,x1=temp.arrows_x,y1=temp.arrows_UB,code=3,angle=90,length=0.05,lwd=2)
    lines(temp.arrows_x,temp.plotting_y,type="p",pch=19)
  }
  dev.off()
}


log_axis.function<-function(temp.lower_x.par,temp.upper_x.par,y_axis.par=FALSE){
  temp.min_x_exponent=floor(temp.lower_x.par)-1
  temp.max_x_exponent=ceil(temp.upper_x.par)+1
  temp.exponent_diff=temp.max_x_exponent-temp.min_x_exponent
  temp.x_axis_locations<-c(temp.min_x_exponent+1:(temp.exponent_diff+1)-1)
  temp.num_x_labels=length(temp.x_axis_locations)
  temp.x_axis_locations<-c(unique(round(temp.x_axis_locations)))
  temp.x_axis_labels<-formatC(10^temp.x_axis_locations,format="e",digits=0)
  temp.num_labels=length(temp.x_axis_labels)
  if(temp.num_labels>10){
    temp.step_size=floor(temp.num_labels/10)
    temp.index_sequence<-seq(from=1,to=temp.num_labels,by=temp.step_size)
    temp.x_axis_locations<-temp.x_axis_locations[temp.index_sequence]
    temp.x_axis_labels<-temp.x_axis_labels[temp.index_sequence]
  }
  if(!y_axis.par){
    axis(1,at=temp.x_axis_locations,labels=temp.x_axis_labels,las=2)
  }
  else{
    axis(2,at=temp.x_axis_locations,labels=temp.x_axis_labels,las=2)
  }
}


log_spectral_power_plot.function<-function(log_frequencies.par,log_power_spectrum.par,x_bounds.par,y_bounds.par,ordinate_quantity.par,
                                           measured_quantity.par="",units.par1="units",units.par2="units",cepstral_bool.par=FALSE){
  temp.y_string<-paste(measured_quantity.par," spectral power, in squared ",units.par2," per ",units.par1,sep="")
  temp.units_string<-"hertz"
  if(cepstral_bool.par==TRUE){
    temp.y_string<-paste(measured_quantity.par," cepstral power, in quad ",units.par2," per ",temp.units_string,sep="")
  }
  par(mar=c(7.1, 7.1, 4.1, 2.1))
  par(mgp=c(5,1,0))
  plot(0,0,xlab=paste(ordinate_quantity.par,", in ",units.par1,sep=""),
       ylab=temp.y_string,main="",xlim=x_bounds.par,ylim=y_bounds.par,pch=".",lab=c(10,10,7),xaxt="n",yaxt="n")
  grid()
  minor.tick(10,10)
  log_axis.function(x_bounds.par[1],x_bounds.par[2])
  log_axis.function(y_bounds.par[1],y_bounds.par[2],y_axis.par=TRUE)
  lines(log_frequencies.par,log_power_spectrum.par)
}



colour_scatter_plot.function<-function(x.par,y.par,z.par,plot_title.par="",x_bounds.par=NA,y_bounds.par=NA,z_bounds.par=NA,ordinate_quantity.par,
                                       measured_quantity.par="Measured quantity",units.par1="units",units.par2="units",pdf_title.par="Scatter_plot.pdf",
                                       threshold_height.par=NA,passband_cutoffs.par=NA,log_bool.par=FALSE){
  if(is.na(x_bounds.par)==TRUE){
    x_bounds.par<-c(min(x.par),max(x.par))
  }
  if(is.na(y_bounds.par)==TRUE){
    y_bounds.par<-c(min(y.par),max(y.par))
  }
  if(is.na(z_bounds.par)==TRUE){
    z_bounds.par<-c(min(z.par),max(z.par))
  }
  temp.indices<-intersect(which(x.par>=x_bounds.par[1] & x.par<=x_bounds.par[2]),which(y.par>=y_bounds.par[1] & y.par<=y_bounds.par[2]))
  temp.indices<-sort(unique(temp.indices))
  x.par<-x.par[temp.indices]
  y.par<-y.par[temp.indices]
  z.par<-z.par[temp.indices]
  z.par0<-z.par
  if(log_bool.par==TRUE){
    z.par[z.par>0]<-log10(z.par[z.par>0])
  }
  #https://stackoverflow.com/questions/9946630/colour-points-in-a-plot-differently-depending-on-a-vector-of-values
  #Create a function to generate a continuous color palette
  temp.num_levels=50
  temp.red_blue_palette<-colorRampPalette(c('light grey','black'))
  if(z_bounds.par[1]>0){
    temp.red_blue_palette<-colorRampPalette(c('white','black'))
  }
  temp.z<-z.par-min(z.par)
  temp.colours<-temp.red_blue_palette(temp.num_levels)[as.numeric(cut(((temp.z)),breaks=round(temp.num_levels)))]
  if(!is.na(threshold_height.par)){
    temp.colours<-temp.red_blue_palette(temp.num_levels)[as.numeric(cut(((temp.z)),
                                                                        breaks=round(temp.num_levels)))]
  }
  pdf(paste(pdf_title.par),width=8,height=6)
  plot(0,0,xlab=paste(ordinate_quantity.par,", in ",units.par1,sep=""),ylab=paste("Frequency offset, in ",units.par1,sep=""),
       main=plot_title.par,xlim=x_bounds.par,ylim=y_bounds.par,pch=".",lab=c(10,10,7))
  if(!length(which(is.na(passband_cutoffs.par)==TRUE))){
    for(temp.i in 1:length(passband_cutoffs.par)){
      temp.x_PB_left<-rep(-passband_cutoffs.par[temp.i],2)
      temp.y_PB_left<-c(-passband_cutoffs.par[temp.i],passband_cutoffs.par[temp.i])-temp.x_PB_left
      segments(temp.x_PB_left[1],temp.y_PB_left[1],temp.x_PB_left[2],temp.y_PB_left[2],lty=temp.i)
      temp.x_PB_right<-rep(passband_cutoffs.par[temp.i],2)
      temp.y_PB_right<-temp.y_PB_left+temp.x_PB_left-temp.x_PB_right
      segments(temp.x_PB_right[1],temp.y_PB_right[1],temp.x_PB_right[2],temp.y_PB_right[2],lty=temp.i)
      temp.x_PB_top<-c(-passband_cutoffs.par[temp.i],passband_cutoffs.par[temp.i])
      temp.y_PB_top<-rep(passband_cutoffs.par[temp.i],2)-temp.x_PB_top
      segments(temp.x_PB_top[1],temp.y_PB_top[1],temp.x_PB_top[2],temp.y_PB_top[2],lty=temp.i)
      temp.x_PB_bottom<-temp.x_PB_top
      temp.y_PB_bottom<-rep(-passband_cutoffs.par[temp.i],2)-temp.x_PB_bottom
      segments(temp.x_PB_bottom[1],temp.y_PB_bottom[1],temp.x_PB_bottom[2],temp.y_PB_bottom[2],lty=temp.i)
    }
  }
  lines(x.par,y.par,type="p",pch=".",col=temp.colours,cex=5)
  dev.off()
}


heat_map.function<-function(x.par,y.par,matrix.par,x_bounds.par=NA,y_bounds.par=NA,z_bounds.par=NA,abscissa_quantity.par="Measured quantity",
                            abscissa_units.par="units",ordinates_quantity.par="Measured quantity",ordinates_units.par="units",
                            heights_quantity.par="Measured quantity",heights_units.par="units",pdf_title.par="",smooth_image.par=FALSE,theta.par=0,
                            log_bool.par=FALSE){
  if(log_bool.par==TRUE){
    matrix.par<-10*log10(matrix.par)
  }
  temp.num_columns=ncol(matrix.par)
  temp.num_rows=nrow(matrix.par)
  temp.x_bounds<-c(min(x.par),max(x.par))
  temp.y_bounds<-c(min(y.par),max(y.par))
  temp.z_bounds<-c(min(matrix.par),max(matrix.par))
  if(!is.na(x_bounds.par)){
    temp.x_bounds<-x_bounds.par
  }
  if(!is.na(y_bounds.par)){
    temp.y_bounds<-y_bounds.par
  }
  if(!is.na(z_bounds.par)){
    temp.z_bounds<-z_bounds.par
    if(log_bool.par==TRUE){
      temp.z_bounds<-10*log10(temp.z_bounds)
    }
  }
  matrix.par<-t(matrix.par)
  temp.look<-matrix.par
  if(smooth_image.par==TRUE){
    temp.look<-image.smooth(x=t(matrix.par),dx=x.par[2]-x.par[1],dy=y.par[2]-y.par[1],theta=theta.par)
  }
  pdf(paste(pdf_title.par),width=8,height=6)
  par(mar=c(5.1, 4.1, 4.1, 3.1))
  mgp=c(2,1,0)
  #The gray scale coding below is from https://stackoverflow.com/questions/29699796/how-to-plot-matrix-as-is-in-r-using-grayscale
  if(smooth_image.par==TRUE){
    image.plot(temp.look,xlab=paste(abscissa_quantity.par," in ",abscissa_units.par,sep=""),
               ylab=paste(ordinates_quantity.par," in ",ordinates_units.par,sep=""),xlim=temp.x_bounds,ylim=temp.y_bounds,zlim=temp.z_bounds,
               col=rev(grey(seq(temp.z_bounds[1]/temp.z_bounds[2],1,length=length(matrix.par)))))
  }
  else{
    if(temp.z_bounds[1]>=0){
      image.plot(x.par,y.par,t(matrix.par),xlab=paste(abscissa_quantity.par," in ",abscissa_units.par,sep=""),
                 ylab=paste(ordinates_quantity.par," in ",ordinates_units.par,sep=""),xlim=temp.x_bounds,ylim=temp.y_bounds,zlim=temp.z_bounds,
                 col=rev(grey(seq(temp.z_bounds[1]/temp.z_bounds[2],1,length=length(matrix.par)))))
    } else{
      image.plot(x.par,y.par,t(matrix.par),xlab=paste(abscissa_quantity.par," in ",abscissa_units.par,sep=""),
                 ylab=paste(ordinates_quantity.par," in ",ordinates_units.par,sep=""),xlim=temp.x_bounds,ylim=temp.y_bounds,zlim=temp.z_bounds,
                 col=rev(grey(seq(0,1,length=length(matrix.par)))))
    }
  }
  if(log_bool.par==TRUE){
    title(ylab=paste(heights_quantity.par," in decibel ",heights_units.par,sep=""),line=-30.5)
  }
  else{
    title(ylab=paste(heights_quantity.par," in ",heights_units.par,sep=""),line=-30.5)
  }
  dev.off()
}



multipage_plot_comparison.function<-function(x_plotting_list.par,y_plotting_list.par,x_plotting_list2.par=NA,y_plotting_list2.par=NA,bounds_all.par=NA,
                                             x_label.par="",y_label.par="",title_strings.par=NA,
                                             pdf_title.par="Multiplot.pdf",no_comparison_bool.par=FALSE,vertical_line.par=NA,
                                             num_samples.par=1e3,shade_intervals.par=NA,types.par=NA){
  temp.num_plots<-length(x_plotting_list.par)
  if(is.na(title_strings.par)==TRUE){
    title_strings.par<-rep("",temp.num_plots)
  }
  if(!is.na(x_plotting_list2.par)){
    temp.all_x_values<-c(unlist(x_plotting_list.par),unlist(x_plotting_list2.par))
    temp.all_y_values<-c(unlist(y_plotting_list.par),unlist(y_plotting_list2.par))
  }
  else{
    temp.all_x_values<-c(unlist(x_plotting_list.par))
    temp.all_y_values<-c(unlist(y_plotting_list.par))
  }
  temp.min_x=0
  temp.max_x=0
  temp.min_y=0
  temp.max_y=0
  if(!no_comparison_bool.par){
    temp.min_x=min(temp.all_x_values)
    temp.max_x=max(temp.all_x_values)
    temp.min_y=min(temp.all_y_values)
    temp.max_y=max(temp.all_y_values)
  }
  pdf(pdf_title.par,width=8,height=6)
  for(temp.i in 1:temp.num_plots){
    temp.x_plotting<-x_plotting_list.par[[temp.i]]
    temp.y_plotting<-y_plotting_list.par[[temp.i]]
    if(no_comparison_bool.par==TRUE){
      temp.min_x=min(temp.x_plotting)
      temp.max_x=max(temp.x_plotting)
      temp.min_y=min(temp.y_plotting)
      temp.max_y=max(temp.y_plotting)
    }
    temp.x_plotting2<-c()
    temp.y_plotting2<-c()
    if(!is.na(x_plotting_list2.par)){
      temp.x_plotting2<-x_plotting_list2.par[[temp.i]]
      temp.y_plotting2<-y_plotting_list2.par[[temp.i]]
      if(no_comparison_bool.par==TRUE){
        temp.min_x=min(c(temp.x_plotting,temp.x_plotting2))
        temp.max_x=max(c(temp.x_plotting,temp.x_plotting2))
        temp.min_y=min(c(temp.y_plotting,temp.y_plotting2))
        temp.max_y=max(c(temp.y_plotting,temp.y_plotting2))
      }
    }
    temp.running_y_min=temp.min_y
    temp.running_y_max=temp.max_y
    temp.trial_min_y=min(c(temp.y_plotting,temp.y_plotting2))
    if(abs(temp.running_y_min)>(3*abs(temp.trial_min_y))){
      temp.running_y_min=temp.trial_min_y
    }
    temp.trial_max_y=max(c(temp.y_plotting,temp.y_plotting2))
    if(abs(temp.running_y_max)>(3*abs(temp.trial_max_y))){
      temp.running_y_max=temp.trial_max_y
    }
    if(!is.na(bounds_all.par) || no_comparison_bool.par==TRUE){
      temp.running_y_min=bounds_all.par[1]
      temp.running_y_max=bounds_all.par[2]
    }
    temp.x_plotting<-plotting.sampled_vector(temp.x_plotting,num_samples.par)
    temp.y_plotting<-plotting.sampled_vector(temp.y_plotting,num_samples.par)
    if(is.na(bounds_all.par)==TRUE){
      temp.running_y_min=min(temp.y_plotting)
      temp.running_y_max=max(temp.y_plotting)
    }
    plot(0,0,xlab=x_label.par,ylab=y_label.par,main=paste(title_strings.par[temp.i],sep=""),xlim=c(temp.min_x,temp.max_x),
         ylim=c(temp.running_y_min,temp.running_y_max),pch=".",lab=c(10,10,7))
    grid()
    minor.tick(10,10)
    if(is.na(x_plotting_list2.par)==TRUE){
      temp.colour=1
    }
    else{
      temp.colour="grey75"
    }
    if(!is.na(shade_intervals.par)){
      temp.num_vertical_lines=length(shade_intervals.par)
      if(temp.num_vertical_lines>1){
        for(temp.i in seq(from=1,to=temp.num_vertical_lines,by=2)){
          if(temp.i<temp.num_vertical_lines){
            temp.left_bound=shade_intervals.par[temp.i]
            temp.right_bound=shade_intervals.par[temp.i+1]
            temp.range_diff=temp.running_y_max-temp.running_y_min
            temp.edge_LB<-temp.running_y_min-0.1*temp.range_diff
            temp.edge_UB<-temp.running_y_max+0.1*temp.range_diff
            temp.left_horizontal_edges<-rep(temp.left_bound,2)
            temp.right_horizontal_edges<-rep(temp.right_bound,2)
            temp.vertical_edges<-c(temp.edge_LB,temp.edge_UB)
            polygon(c(temp.left_horizontal_edges,rev(temp.right_horizontal_edges)),c(temp.vertical_edges,rev(temp.vertical_edges)),col="grey95",border=NA)
          }
        }
      }
    }
    if(!is.na(vertical_line.par)){
      abline(v=vertical_line.par)
      temp.num_vertical_lines=length(shade_intervals.par)
    }
    if(!is.na(types.par)){
      lines(temp.x_plotting,temp.y_plotting,col=temp.colour,type=types.par[1])
    } else{
      lines(temp.x_plotting,temp.y_plotting,col=temp.colour)
    }
    temp.lwd=1
    if(!is.na(x_plotting_list2.par)){
      if(length(temp.x_plotting2)<100){
        temp.lwd=2
      }
      temp.x_plotting2<-plotting.sampled_vector(temp.x_plotting2,num_samples.par)
      temp.y_plotting2<-plotting.sampled_vector(temp.y_plotting2,num_samples.par)
      if(!is.na(types.par)){
        lines(temp.x_plotting2,temp.y_plotting2,type=types.par[2])
      } else{
        lines(temp.x_plotting2,temp.y_plotting2)
      }
    }
  }
  dev.off()
}


multipage_plot_filter.function<-function(x_plotting_list.par,y_plotting_list.par,x_label.par,y_label.par,title_strings.par,
                                         nominal_passband_frequency.par=0,passband_edge.par=0,stopband_edge.par=0,fitting_log_frequencies.par,
                                         fitted_log_PTF_values.par,filter_order.par=0,passband_frequency.par=0,pdf_title.par="Multiplot_Filter.pdf",
                                         nums_nn_interpolation.par,decay_rates.par,ise.par,include_reconstruction_numbers.par=FALSE){
  temp.frequency_values<-unlist(x_plotting_list.par)
  temp.mod_y_plotting<-Mod(unlist(y_plotting_list.par))
  temp.mod_y_plotting<-temp.mod_y_plotting[temp.frequency_values>0]
  temp.min_y=log10(min(temp.mod_y_plotting[temp.mod_y_plotting>0]))
  temp.max_y=log10(max(temp.mod_y_plotting[temp.mod_y_plotting>0]))
  temp.mod_y_plotting[temp.mod_y_plotting<=0]<-1e-12*min(temp.mod_y_plotting[temp.mod_y_plotting>0])
  temp.frequency_values<-temp.frequency_values[temp.frequency_values>0]
  temp.min_x=log10(min(temp.frequency_values))
  temp.max_x=log10(max(temp.frequency_values))
  temp.num_plots<-length(x_plotting_list.par)
  pdf(pdf_title.par,width=8,height=6)
  for(temp.i in 1:temp.num_plots){
    cat(temp.i," out of ",temp.num_plots,"\n")
    temp.x_plotting<-x_plotting_list.par[[temp.i]]
    temp.y_plotting<-Mod(y_plotting_list.par[[temp.i]])
    temp.y_plotting<-log10(temp.y_plotting[temp.x_plotting>0])
    temp.x_plotting<-log10(temp.x_plotting[temp.x_plotting>0])
    if(temp.i==temp.num_plots){
      par(mar=c(5.1,5.1,5.1,4.1))
      par(mgp=c(4,1,0))
      if(include_reconstruction_numbers.par==TRUE){
        plot(0,0,xlab=x_label.par,ylab=y_label.par,main=paste(title_strings.par[temp.i],", order = ",filter_order.par[temp.i],", decay rate = ",
                                                              formatC(decay_rates.par[temp.i],format="e",digits=0),
                                                              " dB gain / dB Hz\nISE = ",formatC(ise.par[temp.i],format="e",digits=0),
                                                              ", reconstructions: ",nums_nn_interpolation.par[temp.i],
                                                              sep=""),
             xlim=c(temp.min_x,temp.max_x),ylim=c(temp.min_y,temp.max_y),pch=".",lab=c(10,10,7),xaxt="n",yaxt="n")
      }
      else{
        plot(0,0,xlab=x_label.par,ylab=y_label.par,main=paste(title_strings.par[temp.i],", order = ",filter_order.par[temp.i],", decay rate = ",
                                                              formatC(decay_rates.par[temp.i],format="e",digits=0),
                                                              " dB gain / dB Hz\nISE = ",formatC(ise.par[temp.i],format="e",digits=0),sep=""),
             xlim=c(temp.min_x,temp.max_x),ylim=c(temp.min_y,temp.max_y),pch=".",lab=c(10,10,7),xaxt="n",yaxt="n")
      }
    }
    else{
      par(mar=c(5.1,5.1,5.1,4.1))
      par(mgp=c(4,1,0))
      plot(0,0,xlab=x_label.par,ylab=y_label.par,main=paste(title_strings.par[temp.i],", order = ",filter_order.par[temp.i], ", decay rate = ",
                                                            formatC(decay_rates.par[temp.i],format="e",digits=0),
                                                            " dB gain / dB Hz\nISE = ",formatC(ise.par[temp.i],format="e",digits=0),", reconstructions: ",
                                                            nums_nn_interpolation.par[temp.i],sep=""),
           xlim=c(temp.min_x,temp.max_x),ylim=c(temp.min_y,temp.max_y),pch=".",lab=c(10,10,7),xaxt="n",yaxt="n")
    }
    grid()
    minor.tick(10,10)
    log_axis.function(temp.min_x,temp.max_x)
    log_axis.function(temp.min_y,temp.max_y,y_axis.par=TRUE)
    temp.edges_x<-log10(c(passband_edge.par,stopband_edge.par))
    temp.diff=temp.max_y-temp.min_y
    temp.edges_LB<-rep(temp.min_y-0.1*temp.diff,2)
    temp.edges_UB<-rep(temp.max_y+0.1*temp.diff,2)
    polygon(c(temp.edges_x,rev(temp.edges_x)),c(temp.edges_LB,rev(temp.edges_UB)),col="grey75",border=NA)
    abline(v=log10(nominal_passband_frequency.par),lwd=2)
    abline(v=log10(passband_frequency.par[temp.i]),lwd=2,lty=2)
    abline(h=0)
    lines(temp.x_plotting,temp.y_plotting)
    lines(fitting_log_frequencies.par[[temp.i]]/10,fitted_log_PTF_values.par[[temp.i]]/10,lwd=2,col="grey50")
  }
  dev.off()
}



row_plot_setup.function<-function(column_index.par,num_columns.par,plotting_x_bounds.par,plotting_y_bounds.par,
                                  bottom_margin.par,top_margin.par,x_positions.par,x_labels.par,y_positions.par,y_labels.par,column_title.par="",
                                  row_title.par="",column_title_string_vector.par=NA,column_title_colours.par=NA){
  temp.num_right_of_plot=num_columns.par-1
  # bottom, left, top, and right
  if(column_index.par==1){
    par(mar=c(bottom_margin.par,4.1-4.1/temp.num_right_of_plot,top_margin.par,4.1-4.1/temp.num_right_of_plot))
    plot(0,0,xlab="",ylab="",main=column_title.par,
         xlim=plotting_x_bounds.par,ylim=plotting_y_bounds.par,pch=".",lab=c(10,10,7),xaxt="n",yaxt="n")
    if(!is.na(column_title_string_vector.par)){
      multicolor.title(column_title_string_vector.par,column_title_colours.par,collapse=" ",cex.main=par()$cex.main*3/num_columns.par)
    }
    #1=below, 2=left, 3=above and 4=right
    axis(side=2,at=y_positions.par,labels=y_labels.par,cex.axis=1.5)
  }
  else if(column_index.par==num_columns.par){
    par(mar=c(bottom_margin.par,0,top_margin.par,4.1))
    plot(0,0,xlab="",ylab="",main=column_title.par,xlim=plotting_x_bounds.par,ylim=plotting_y_bounds.par,pch=".",lab=c(10,10,7),xaxt="n",yaxt="n")
    # add a title for the right axis
    if(!is.na(column_title_string_vector.par)){
      multicolor.title(column_title_string_vector.par,column_title_colours.par,collapse=" ",cex.main=par()$cex.main*3/num_columns.par)
    }
    mtext(row_title.par,side=4,line=1,cex.lab=1,las=2)
  }
  else{
    par(mar=c(bottom_margin.par,4.1-4.1/temp.num_right_of_plot,top_margin.par,4.1-4.1/temp.num_right_of_plot))
    plot(0,0,xlab="",ylab="",main=column_title.par,xlim=plotting_x_bounds.par,ylim=plotting_y_bounds.par,pch=".",lab=c(10,10,7),xaxt="n",yaxt="n")
    if(!is.na(column_title_string_vector.par)){
      multicolor.title(column_title_string_vector.par,column_title_colours.par,collapse=" ",cex.main=par()$cex.main*3/num_columns.par)
    }
  }
  if(!is.na(x_positions.par)){
    axis(side=1,at=x_positions.par,labels=x_labels.par,cex.axis=1.5)
  }
  if(!is.na(y_positions.par)){
    axis(side=2,at=y_positions.par,labels=y_labels.par,cex.axis=1.5)
  }
}


array_plot_setup.function<-function(row_index.par,column_index.par,num_rows.par,num_columns.par,
                                    plotting_x_bounds.par,plotting_y_bounds.par,x_positions.par,x_labels.par,y_positions.par,y_labels.par,
                                    measured_abscissa_string.par="",measure_units_string.par="",column_title.par="",row_title.par="",
                                    column_title_string_vector.par=NA,column_title_colours.par=NA){
  temp.x_positions=NA
  temp.x_labels<-NA
  if(row_index.par==1){
    temp.bottom_margin=3.6/2
    temp.top_margin=3.6
  }
  else if(row_index.par==num_rows.par){
    temp.bottom_margin=3.6
    temp.top_margin=3.6/2
    temp.x_positions<-x_positions.par
    temp.x_labels<-x_labels.par
  }
  else{
    temp.bottom_margin=(1-1/(num_rows.par-2))*3.6+3.6/4
    temp.top_margin=temp.bottom_margin
  }
  row_plot_setup.function(column_index.par=column_index.par,num_columns.par=num_columns.par,
                          plotting_x_bounds.par=plotting_x_bounds.par,plotting_y_bounds.par=plotting_y_bounds.par,
                          bottom_margin.par=temp.bottom_margin,top_margin.par=temp.top_margin,
                          x_positions.par=x_positions.par,x_labels.par=temp.x_labels,y_positions.par=y_positions.par,y_labels.par=y_labels.par,
                          column_title.par=column_title.par,row_title.par=row_title.par,
                          column_title_string_vector.par=column_title_string_vector.par,column_title_colours.par=column_title_colours.par)
}


two_dimensional_box_plot.function<-function(x_vectors_list.par,y_vectors_list.par,colour_vector.par=NA,colour_weights.par=NA,
                                            relative_x_bool.par=FALSE,relative_y_bool.par=FALSE){
  temp.num_plot_types=length(x_vectors_list.par)
  temp.num_classes=nrow(x_vectors_list.par[[1]])
  if(is.na(colour_vector.par)==TRUE){
    colour_vector.par<-1:temp.num_classes
  }
  temp.x_conversion_factor=1
  temp.max_x=0
  temp.running_max_x=0
  for(temp.i in 1:temp.num_plot_types){
    temp.x_vectors<-x_vectors_list.par[[temp.i]]
    temp.running_max_x=max(temp.x_vectors)
    if(temp.max_x<temp.running_max_x){
      temp.max_x=temp.running_max_x
    }
  }
  temp.min_x=0
  temp.running_min_x=temp.max_x
  for(temp.i in 1:temp.num_plot_types){
    temp.x_vectors<-x_vectors_list.par[[temp.i]]
    temp.running_min_x=min(temp.x_vectors)
    if(temp.min_x>temp.running_min_x){
      temp.min_x=temp.running_min_x
    }
  }
  if(relative_x_bool.par==TRUE){
    temp.x_conversion_factor=100/(temp.max_x-temp.min_x)
  }
  temp.y_conversion_factor=1
  temp.max_y=0
  temp.running_max_y=0
  for(temp.i in 1:temp.num_plot_types){
    temp.y_vectors<-y_vectors_list.par[[temp.i]]
    temp.running_max_y=max(temp.y_vectors)
    if(temp.max_y<temp.running_max_y){
      temp.max_y=temp.running_max_y
    }
  }
  temp.min_y=0
  temp.running_min_y=temp.max_y
  for(temp.i in 1:temp.num_plot_types){
    temp.y_vectors<-y_vectors_list.par[[temp.i]]
    temp.running_min_y=min(temp.y_vectors)
    if(temp.min_y>temp.running_min_y){
      temp.min_y=temp.running_min_y
    }
  }
  if(relative_y_bool.par==TRUE){
    temp.y_conversion_factor=100/(temp.max_y-temp.min_y)
  }
  for(temp.i in 1:temp.num_plot_types){
    temp.x_vectors<-x_vectors_list.par[[temp.i]]
    temp.x_vectors[temp.x_vectors>temp.max_x]<-temp.max_x
    temp.y_vectors<-y_vectors_list.par[[temp.i]]
    for(temp.k in 1:temp.num_classes){
      temp.mycol=colour_vector.par[temp.k]
      #if(!is.na(colour_weights.par)){
      #  temp.percentile=100
      #  if(temp.num_classes>1){
      #    temp.percentile=(colour_weights.par[temp.k]-min(colour_weights.par))/sum(colour_weights.par-min(colour_weights.par))*100
      #  }
      #  temp.mycol<-t_col(temp.mycol,perc=temp.percentile,name=paste("lt.",temp.k,sep=""))
      #}
      temp.x0=temp.min_x+(temp.x_vectors[temp.k,3]-temp.min_x)*temp.x_conversion_factor
      temp.y0=temp.min_y+(temp.y_vectors[temp.k,2]-temp.min_y)*temp.y_conversion_factor
      temp.x1=temp.min_x+(temp.x_vectors[temp.k,3]-temp.min_x)*temp.x_conversion_factor
      temp.y1=temp.min_y+(temp.y_vectors[temp.k,4]-temp.min_y)*temp.y_conversion_factor
      segments(temp.x0,temp.y0,temp.x1,temp.y1,col=temp.mycol,lty=temp.i,lwd=3)
      temp.x0=temp.min_x+(temp.x_vectors[temp.k,2]-temp.min_x)*temp.x_conversion_factor
      temp.y0=temp.min_y+(temp.y_vectors[temp.k,3]-temp.min_y)*temp.y_conversion_factor
      temp.x1=temp.min_x+(temp.x_vectors[temp.k,4]-temp.min_x)*temp.x_conversion_factor
      temp.y1=temp.min_y+(temp.y_vectors[temp.k,3]-temp.min_y)*temp.y_conversion_factor
      segments(temp.x0,temp.y0,temp.x1,temp.y1,col=temp.mycol,lty=temp.i,lwd=3)
      temp.x_indices<-c(1,5,rep(3,2))
      temp.y_indices<-c(rep(3,2),1,5)
      lines(temp.min_x+(temp.x_vectors[temp.k,temp.x_indices]-temp.min_x)*temp.x_conversion_factor,
            temp.min_y+(temp.y_vectors[temp.k,temp.y_indices]-temp.min_y)*temp.y_conversion_factor,type="p",col=temp.mycol,pch=temp.i)
      #Horizontal lines adjoining the extrema of the coefficients and the 33 and 66 percentiles.
      temp.x_indices<-c(1:2,4:5)
      temp.y_indices<-rep(3,4)
      for(temp.l in 1:2){
        temp.running_x_indices<-temp.x_indices[(temp.l-1)*2+1:2]
        temp.running_y_indices<-temp.y_indices[(temp.l-1)*2+1:2]
        lines(temp.min_x+(temp.x_vectors[temp.k,temp.running_x_indices]-temp.min_x)*temp.x_conversion_factor,
              temp.min_y+(temp.y_vectors[temp.k,temp.running_y_indices]-temp.min_y)*temp.y_conversion_factor,col=temp.mycol,lty=3)
      }
      #Vertical lines adjoining the extrema of the frequencies and the 33 and 66 percentiles.
      temp.x_indices<-rep(3,4)
      temp.y_indices<-c(1:2,4:5)
      for(temp.l in 1:2){
        temp.running_x_indices<-temp.x_indices[(temp.l-1)*2+1:2]
        temp.running_y_indices<-temp.y_indices[(temp.l-1)*2+1:2]
        lines(temp.min_x+(temp.x_vectors[temp.k,temp.running_x_indices]-temp.min_x)*temp.x_conversion_factor,
              temp.min_y+(temp.y_vectors[temp.k,temp.running_y_indices]-temp.min_y)*temp.y_conversion_factor,col=temp.mycol,lty=3)
      }
    }
  }
}


two_dimensional_box_plot_alternative.function<-function(x_vectors_list.par,y_vectors_list.par,colour_vector.par=NA,colour_weights.par=NA,
                                                        relative_x_bool.par=FALSE,relative_y_bool.par=FALSE){
  temp.num_plot_types=length(x_vectors_list.par)
  temp.num_classes=nrow(x_vectors_list.par[[1]])
  if(is.na(colour_vector.par)==TRUE){
    colour_vector.par<-1:temp.num_classes
  }
  temp.x_conversion_factor=1
  temp.y_conversion_factor=1
  temp.max_x=0
  temp.running_max_x=0
  for(temp.i in 1:temp.num_plot_types){
    temp.x_vectors<-x_vectors_list.par[[temp.i]]
    temp.running_max_x=max(temp.x_vectors)
    if(temp.max_x<temp.running_max_x){
      temp.max_x=temp.running_max_x
    }
  }
  temp.min_x=0
  temp.running_min_x=temp.max_x
  for(temp.i in 1:temp.num_plot_types){
    temp.x_vectors<-x_vectors_list.par[[temp.i]]
    temp.running_min_x=min(temp.x_vectors)
    if(temp.min_x>temp.running_min_x){
      temp.min_x=temp.running_min_x
    }
  }
  if(relative_x_bool.par==TRUE){
    temp.x_conversion_factor=100/(temp.max_x-temp.min_x)
  }
  temp.max_y=0
  temp.running_max_y=0
  for(temp.i in 1:temp.num_plot_types){
    temp.y_vectors<-y_vectors_list.par[[temp.i]]
    temp.running_max_y=max(temp.y_vectors)
    if(temp.max_y<temp.running_max_y){
      temp.max_y=temp.running_max_y
    }
  }
  temp.min_y=0
  temp.running_min_y=temp.max_y
  for(temp.i in 1:temp.num_plot_types){
    temp.y_vectors<-y_vectors_list.par[[temp.i]]
    temp.running_min_y=min(temp.y_vectors)
    if(temp.min_y>temp.running_min_y){
      temp.min_y=temp.running_min_y
    }
  }
  if(relative_y_bool.par==TRUE){
    temp.y_conversion_factor=0.5/(temp.max_y-temp.min_y)
  }
  for(temp.i in 1:temp.num_plot_types){
    temp.x_vectors<-x_vectors_list.par[[temp.i]]
    temp.x_vectors[temp.x_vectors>temp.max_x]<-temp.max_x
    temp.y_vectors<-y_vectors_list.par[[temp.i]]
    for(temp.k in 1:temp.num_classes){
      temp.mycol=colour_vector.par[temp.k]
      #if(!is.na(colour_weights.par)){
        #temp.percentile=100
        #if(temp.num_classes>1){
        #  temp.percentile=(colour_weights.par[temp.k]-min(colour_weights.par))/sum(colour_weights.par-min(colour_weights.par))*100
        #}
        #temp.mycol<-t_col(temp.mycol,perc=temp.percentile,name=paste("lt.",temp.k,sep=""))
      #}
      if(temp.k<temp.num_classes){
        abline(v=temp.k+0.5)
      }
      temp.x0=temp.min_x+(temp.x_vectors[temp.k,2]-temp.min_x)*temp.x_conversion_factor
      temp.y0=temp.k
      temp.x1=temp.min_x+(temp.x_vectors[temp.k,4]-temp.min_x)*temp.x_conversion_factor
      temp.y1=temp.k
      temp.delta_y=(temp.y_vectors[temp.k,4]-temp.y_vectors[temp.k,2])*temp.y_conversion_factor/2
      if(temp.i==1){
        temp.y0=temp.y0-0.25
        temp.y1=temp.y1-0.25
      }
      else{
        temp.y0=temp.y0+0.25
        temp.y1=temp.y1+0.25
      }
      temp.y21=temp.y0-temp.delta_y
      temp.y22=temp.y1+temp.delta_y
      temp.left_horizontal_edges<-rep(temp.y21,2)
      temp.right_horizontal_edges<-rep(temp.y22,2)
      temp.vertical_edges<-c(temp.x0,temp.x1)
      polygon(c(temp.left_horizontal_edges,rev(temp.right_horizontal_edges)),c(temp.vertical_edges,rev(temp.vertical_edges)),col=temp.mycol)
      temp.x_indices<-c(1,5)
      temp.y_indices<-c(rep(3,2),1,5)
      temp.plotting_x_values<-rep(temp.k,2)
      if(temp.i==1){
        temp.plotting_x_values<-temp.plotting_x_values-0.25
      }
      else{
        temp.plotting_x_values<-temp.plotting_x_values+0.25
      }
      lines(temp.plotting_x_values,
            temp.min_x+(temp.x_vectors[temp.k,temp.x_indices]-temp.min_x)*temp.x_conversion_factor,type="p",col=temp.mycol,pch=temp.i)
      #Vertical lines adjoining the extrema of the frequencies and the 33 and 66 percentiles.
      temp.y_indices<-c(1:2,4:5)
      temp.x_indices<-c(1:2,4:5)
      temp.plotting_x_values<-rep(temp.k,2)
      if(temp.i==1){
        temp.plotting_x_values<-temp.plotting_x_values-0.25
      }
      else{
        temp.plotting_x_values<-temp.plotting_x_values+0.25
      }
      for(temp.l in 1:2){
        temp.running_x_indices<-temp.x_indices[(temp.l-1)*2+1:2]
        temp.running_y_indices<-temp.y_indices[(temp.l-1)*2+1:2]
        lines(temp.plotting_x_values,
              temp.min_x+(temp.x_vectors[temp.k,temp.running_x_indices]-temp.min_x)*temp.x_conversion_factor,col=temp.mycol,lty=3)
      }
    }
  }
}


plot_ts_reconstructions_array.function<-function(ts_times_list.par,ts_list.par,reconstruction_times_list.par,reconstruction_list.par,
                                                 colour_vector.par=NA,colour_weights.par=NA){
  temp.num_reconstructions=length(reconstruction_list.par)
  for(temp.i in 1:temp.num_reconstructions){
    temp.mycol=colour_vector.par[temp.i]
    if(!is.na(colour_weights.par)){
      temp.mycol<-t_col(temp.mycol,perc=(colour_weights.par[temp.i]-min(colour_weights.par))/sum(colour_weights.par-min(colour_weights.par))*100,
                        name=paste("lt.",temp.i,sep=""))
    }
    if(temp.i==1){
      temp.times_original<-ts_times_list.par[[1]]
      lines(temp.times_original,ts_list.par[[temp.i]],type="p",pch=".",cex=temp.num_reconstructions+6,col="grey80")
      temp.times_reconstruction<-reconstruction_times_list.par[[1]]
      lines(temp.times_reconstruction,reconstruction_list.par[[1]],col=temp.mycol,lty=colour_vector.par[temp.i],lwd=3)
    }
    else{
      temp.times_reconstruction<-reconstruction_times_list.par[[temp.i]]
      lines(temp.times_reconstruction,reconstruction_list.par[[temp.i]],col=temp.mycol,lty=colour_vector.par[temp.i],lwd=3)
    }
  }
}


multipage_three_dimensional_overlay_scatter_plots.function<-function(x_matrix.par,
                                                                     y_matrix1.par,z_matrix1.par,
                                                                     y_matrix2.par,z_matrix2.par,
                                                                     abscissa_quantity_string.par="",abscissa_units_string.par="",
                                                                     ordinates1_quantity_string.par="",ordinates1_units_string.par="",
                                                                     ordinates2_quantity_string.par="",ordinates2_units_string.par="",
                                                                     plot_title_string.par="",
                                                                     pdf_title.par=""){
  temp.num_rows=nrow(x_matrix.par)
  temp.num_columns=ncol(x_matrix.par)
  temp.abscissum_string<-paste(abscissa_quantity_string.par,", in ",abscissa_units_string.par,sep="")
  temp.ordinates1_string<-paste(ordinates1_quantity_string.par,", in ",ordinates1_units_string.par,sep="")
  temp.ordinates2_string<-paste(ordinates2_quantity_string.par,", in ",ordinates2_units_string.par,sep="")
  temp.min_x=min(x_matrix.par)
  temp.max_x=max(x_matrix.par)
  temp.min_y=min(min(y_matrix1.par),min(y_matrix2.par))
  temp.max_y=max(max(y_matrix1.par),max(y_matrix2.par))
  temp.min_z=min(min(z_matrix1.par),min(z_matrix2.par))
  temp.max_z=max(max(z_matrix1.par),max(z_matrix2.par))
  pdf(pdf_title.par,width=8,height=6)
  for(temp.k in 1:temp.num_columns){
    #Set the plot boundaries.
    scatter3D(x=c(temp.min_x,temp.max_x),y=c(temp.min_y,temp.max_y),z=c(temp.min_z,temp.max_z),
              main=plot_title_string.par,
              phi=0,bty="g",type="p",ticktype="detailed",pch=1,cex=0.5,col=1,
              xlim=c(temp.min_x,temp.max_x),ylim=c(temp.min_y,temp.max_y),ylim=c(temp.min_z,temp.max_z),
              xlab=temp.abscissum_string,ylab=temp.ordinates1_string,zlab=temp.ordinates2_string)
    #Add axes to the plot.
    scatter3D(x=c(temp.min_x,temp.max_x),y=c(0,0),z=c(0,0),
              add=TRUE,
              phi=0,bty="g",type="l",ticktype="detailed",lwd=2,col=3,
              xlim=c(temp.min_x,temp.max_x),ylim=c(temp.min_y,temp.max_y),ylim=c(temp.min_z,temp.max_z),
              xlab=temp.abscissum_string,ylab=temp.ordinates1_string,zlab=temp.ordinates2_string)
    scatter3D(x=c(0,0),y=c(temp.min_y,temp.max_y),z=c(0,0),
              add=TRUE,
              phi=0,bty="g",type="l",ticktype="detailed",lwd=2,col=3,
              xlim=c(temp.min_x,temp.max_x),ylim=c(temp.min_y,temp.max_y),ylim=c(temp.min_z,temp.max_z),
              xlab=temp.abscissum_string,ylab=temp.ordinates1_string,zlab=temp.ordinates2_string)
    scatter3D(x=c(0,0),y=c(0,0),z=c(temp.min_z,temp.max_z),
              add=TRUE,
              phi=0,bty="g",type="l",ticktype="detailed",lwd=2,col=3,
              xlim=c(temp.min_x,temp.max_x),ylim=c(temp.min_y,temp.max_y),ylim=c(temp.min_z,temp.max_z),
              xlab=temp.abscissum_string,ylab=temp.ordinates1_string,zlab=temp.ordinates2_string)
    #Add the points.
    scatter3D(x=x_matrix.par[,temp.k],y=y_matrix2.par[,temp.k],z=z_matrix2.par[,temp.k],
              add=TRUE,
              phi=0,bty="g",type="p",ticktype="detailed",pch=19,cex=4,col=2,
              xlim=c(temp.min_x,temp.max_x),ylim=c(temp.min_y,temp.max_y),ylim=c(temp.min_z,temp.max_z),
              xlab=temp.abscissum_string,ylab=temp.ordinates1_string,zlab=temp.ordinates2_string)
    scatter3D(x=x_matrix.par[,temp.k],y=y_matrix1.par[,1],z=z_matrix1.par[,1],
              add=TRUE,
              phi=0,bty="g",type="p",ticktype="detailed",pch=19,cex=4,col=1,
              xlim=c(temp.min_x,temp.max_x),ylim=c(temp.min_y,temp.max_y),ylim=c(temp.min_z,temp.max_z),
              xlab=temp.abscissum_string,ylab=temp.ordinates1_string,zlab=temp.ordinates2_string)
    #Straight lines adjoining the points from origin.
    for(temp.l in 1:temp.num_rows){
      scatter3D(x=c(0,x_matrix.par[temp.l,temp.k]),y=c(0,y_matrix1.par[temp.l,temp.k]),
                z=c(0,z_matrix1.par[temp.l,temp.k]),
                add=TRUE,
                phi=0,bty="g",type="l",ticktype="detailed",pch=19,lwd=4,col=1,
                xlim=c(temp.min_x,temp.max_x),ylim=c(temp.min_y,temp.max_y),ylim=c(temp.min_z,temp.max_z),
                xlab=temp.abscissum_string,ylab=temp.ordinates1_string,zlab=temp.ordinates2_string)
    }
    #Straight lines adjoining the points from origin.
    for(temp.l in 1:temp.num_rows){
      scatter3D(x=c(0,x_matrix.par[temp.l,temp.k]),y=c(0,y_matrix2.par[temp.l,temp.k]),
                z=c(0,z_matrix2.par[temp.l,temp.k]),
                add=TRUE,
                phi=0,bty="g",type="l",ticktype="detailed",pch=19,lwd=4,col=2,
                xlim=c(temp.min_x,temp.max_x),ylim=c(temp.min_y,temp.max_y),ylim=c(temp.min_z,temp.max_z),
                xlab=temp.abscissum_string,ylab=temp.ordinates1_string,zlab=temp.ordinates2_string)
    }
    #Straight lines between point pairs.
    for(temp.l in 1:temp.num_rows){
      scatter3D(x=rep(x_matrix.par[temp.l,temp.k],2),y=c(y_matrix2.par[temp.l,temp.k],y_matrix1.par[temp.l,temp.k]),
                z=c(z_matrix2.par[temp.l,temp.k],z_matrix1.par[temp.l,temp.k]),
                add=TRUE,
                phi=0,bty="g",type="l",ticktype="detailed",pch=19,lwd=4,col=4,
                xlim=c(temp.min_x,temp.max_x),ylim=c(temp.min_y,temp.max_y),ylim=c(temp.min_z,temp.max_z),
                xlab=temp.abscissum_string,ylab=temp.ordinates1_string,zlab=temp.ordinates2_string)
    }
  }
  dev.off()
}

















