#Francois Marshall, Boston University
#Header file for time-series analysis.

###################################################################################################################
#Diagnositic statistics.

ar_AICC<-function(xt_par,n_par,p_par){
  sigma2=var(xt_par)
  ln_L=-n_par/2*log(2*pi)-n_par/2*log(sigma2)-sum((xt_par-mean(xt_par))^2)/(2*sigma2)
  return(-2*ln_L+2*(p_par+1)*n_par/(n_par-p_par-2))
}


###################################################################################################################
#ARMA parameter properties.

test_ARMA_roots.function<-function(phi.par=0,theta.par=0){
  temp.SC_causal_string<-"Indeterminite"
  temp.SC_invertible_string<-"Indeterminite"
  temp.SC_causal_bool=NA
  temp.SC_invertible_bool=NA
  if(phi.par!=1){
    try({
      temp.SC_causal_bool=arma.Schur_Cohn_tests(phi.par=phi.par,theta.par=0)
    },silent=T)
    if(!is.na(temp.SC_invertible_bool) & temp.SC_causal_bool==1){
      temp.SC_causal_string<-"Causal"
    }
  }
  else{
    temp.SC_causal_string<-"Causal"
  }
  if(theta.par!=1){
    try({
      temp.SC_invertible_bool=arma.Schur_Cohn_tests(phi.par=-theta.par,theta.par=0)
    },silent=T)
    if(!is.na(temp.SC_invertible_bool) & temp.SC_invertible_bool==1){
      temp.SC_invertible_string<-"Invertible"
    }
  }
  else{
    temp.SC_invertible_string<-"Invertible"
  }
  temp.list<-c(out.SC_causal_bool=temp.SC_causal_bool,
               out.SC_invertible_bool=temp.SC_invertible_bool,
               out.SC_causal_string=temp.SC_causal_string,
               out.SC_invertible_string=temp.SC_invertible_string)
  return(temp.list)
}

quadratic_AR_one_PSD_bound.function<-function(index.par=1,phi_values.par){
  temp.phi=0
  if(length(phi_values.par)>1){
    temp.phi=phi_values.par[index.par]
  }
  else{
    temp.phi=phi_values.par
  }
  temp.a=(temp.phi-1)^2+1
  temp.bound=sqrt(temp.a/2)/(2*pi)
  return(temp.bound)
}


max_sin.function<-function(index.par,frequencies.par){
  temp.angular_frequency<-2*pi*frequencies.par[index.par]
  temp.max_sine=1
  if(temp.angular_frequency>pi){
    temp.principal_alias=temp.angular_frequency-floor(temp.angular_frequency/(2*pi))*(2*pi)
    if(temp.principal_alias<(-pi/2)){
      temp.max_sine=(-1)*sin(temp.principal_alias)
    }
  }
  return(temp.max_sine)
}


max_in_intervals.function<-function(index.par,x.par,intervals.par,optimal_values.par,values.par){
  temp.x=x.par[index.par]
  temp.num_intervals=nrow(intervals.par)
  temp.interval_index=1
  for(temp.i in 2:temp.num_intervals){
    if(!temp.x){
      if(!intervals.par[temp.i,1] & !intervals.par[temp.i,2]){
        temp.optimal_x=0
      }
    }
    else if(temp.x==0.5){
      if(intervals.par[temp.i,1]==0.5 & intervals.par[temp.i,2]==0.5){
        temp.optimal_x=0.5
      }
    }
    else if(temp.x>=intervals.par[temp.i,1] & temp.x<intervals.par[temp.i,2]){
      temp.interval_index=temp.i
    }
  }
  temp.optimal_x=intervals.par[temp.interval_index,2]
  temp.max=0
  if(temp.interval_index>1 & temp.optimal_x<temp.x){
    temp.max=max(optimal_values.par[2:temp.interval_index])
  }
  else{
    temp.max=values.par[index.par]
  }
  return(temp.max)
}


quadratic_AR_one_PSD_condition.function<-function(frequencies.par,spectrum.par,num_phi_values.par=25,first.phi=0,last.phi=1,sampling_rate.par=1,
                                                  measured_quantity.par="Measured quantity",measured_units.par="units",
                                                  measured,units.par="cycles per sample",plot_bool.par=FALSE){
  #For different phi, plot the maximum frequency radii of convergence.
  temp.indices<-1:num_phi_values.par
  temp.phi_step=(last.phi-first.phi)/num_phi_values.par
  temp.phi_values<-(temp.indices-1)*temp.phi_step+temp.phi_step+first.phi
  temp.phi_values<-temp.phi_values[temp.phi_values>0]
  num_phi_values.par=length(temp.phi_values)
  temp.phi_values<-temp.phi_values[temp.phi_values!=0]
  num_phi_values.par=length(temp.phi_values)
  temp.indices<-1:num_phi_values.par
  temp.bounds<-sapply(temp.indices,quadratic_AR_one_PSD_bound.function,temp.phi_values)*sampling_rate.par/2
  temp.max_bound=max(temp.bounds)
  temp.phi_list<-list(temp.phi_values)
  temp.bound_list<-list(temp.bounds)
  temp.num_list_elements=length(temp.phi_values)
  if(plot_bool.par==TRUE){
    plot.graph(temp.phi_list,temp.bound_list,x_label.par="AR(1) coefficient",y_label.par=paste("Radius of convergence, in ",units.par,sep=""),
               plot_title.par="",pdf_title.par="AR1_Quadratic_PSD_Condition.pdf",plotting_LB.par=0,plotting_UB.par=0,lwd.par=3)
    temp.labels<-c("coefficient","bound")
    temp.output_matrix<-matrix(0,nrow=temp.num_list_elements,ncol=2)
    temp.output_matrix[,1]<-temp.phi_values
    temp.output_matrix[,2]<-temp.bounds
    output.table(matrix.par=temp.output_matrix,labels.par=temp.labels,title.par="AR1_Quadratic_PSD_Condition")
  }
  #For each frequency, plot the maximum numerical error of the MacLaurin approximation.
  temp.M2=length(frequencies.par)
  temp.log_spectrum<-log10(spectrum.par[2:temp.M2])
  temp.frequency_indices<-1:temp.M2
  temp.max_sine_values<-sapply(temp.frequency_indices,max_sin.function,frequencies.par)
  temp.frequency_list<-list(frequencies.par*sampling_rate.par)
  temp.cos_MacLaurin_bounds_list<-list()
  temp.plotting_cos_MacLaurin_bounds_list<-list()
  temp.PSD_list<-list()
  temp.num_plotting_phi=5
  temp.phi_step_size=ceil(num_phi_values.par/temp.num_plotting_phi)
  temp.plotting_phi_indices<-c(seq(from=1,to=num_phi_values.par,by=temp.phi_step_size),num_phi_values.par)
  temp.num_plotting_phi=temp.num_plotting_phi+1
  temp.counter=1
  temp.plotting_counter=1
  for(temp.i in 1:num_phi_values.par){
    temp.phi=temp.phi_values[temp.i]
    temp.cos_MacLaurin_bounds<-8*pi^3/3*abs(temp.phi)*frequencies.par^3*temp.max_sine_values
    temp.PSD_values<-(1-temp.phi*cos(2*pi*frequencies.par))^2+temp.phi^2*(sin(2*pi*frequencies.par))^2
    temp.PSD_list[[temp.counter]]<-1/temp.PSD_values
    temp.relative_cos_MacLaurin_bounds<-rep(0,temp.M2)
    if(temp.counter<temp.num_plotting_phi){
      temp.relative_cos_MacLaurin_bounds[1]=0
    }
    temp.relative_cos_MacLaurin_bounds[2:temp.M2]=temp.cos_MacLaurin_bounds[2:temp.M2]/temp.PSD_values[2:temp.M2]*100
    if(temp.i %in% temp.plotting_phi_indices){
      temp.frequency_list[[temp.plotting_counter]]<-temp.frequency_list[[1]]
      temp.plotting_cos_MacLaurin_bounds_list[[temp.plotting_counter]]<-temp.relative_cos_MacLaurin_bounds
      temp.plotting_counter=temp.plotting_counter+1
    }
    temp.cos_MacLaurin_bounds_list[[temp.counter]]<-temp.relative_cos_MacLaurin_bounds
    temp.counter=temp.counter+1
  }
  temp.labels<-c("frequency")
  for(temp.i in 1:length(temp.plotting_phi_indices)){
    temp.labels<-c(temp.labels,temp.phi_values[temp.plotting_phi_indices][temp.i])
  }
  if(plot_bool.par==TRUE){
    temp.num_list_elements=length(temp.plotting_cos_MacLaurin_bounds_list)
    temp.max_y=max(unlist(temp.plotting_cos_MacLaurin_bounds_list))
    plot.graph(temp.frequency_list,temp.plotting_cos_MacLaurin_bounds_list,x_label.par=paste("Frequency, in ",units.par,sep=""),
               y_label.par="Upper bound on percentage absolute additive error",
               plot_title.par="",pdf_title.par="AR1_Maclaurin_Cosine.pdf",plotting_LB.par=0,plotting_UB.par=temp.max_y,lwd.par=3,
               legend_labels.par=temp.phi_values[temp.plotting_phi_indices],
               legend_title.par="AR(1) coefficient",horizontal_line.par=100,lty.par=1:temp.num_list_elements,col.par=1:temp.num_list_elements)
    temp.output_matrix<-matrix(0,nrow=temp.M2,ncol=temp.num_list_elements+1)
    temp.output_matrix[,1]<-temp.frequency_list[[1]]
    for(temp.i in 1:temp.num_list_elements){
      temp.output_matrix[,temp.i+1]<-temp.plotting_cos_MacLaurin_bounds_list[[temp.i]]
    }
    output.table(matrix.par=temp.output_matrix,labels.par=temp.labels,title.par="AR1_Maclaurin_Cosine")
  }
  #Determine the errors for the logarithm expansion.
  temp.ln_MacLaurin_bounds_list<-list()
  temp.plotting_ln_MacLaurin_bounds_list<-list()
  temp.counter=1
  temp.plotting_counter=1
  temp.truncated_frequency_list<-list()
  for(temp.i in 1:num_phi_values.par){
    temp.phi=temp.phi_values[temp.i]
    temp.a=8*pi^2*temp.phi
    temp.maxima<-16*pi^2/temp.a*abs(temp.phi)*frequencies.par^2#*(1+2*log(abs(frequencies.par)))
    temp.MacLaurin_ln_upper_bounds<-
      (temp.maxima[2:temp.M2]+32*pi^2/temp.a*abs(temp.phi)*(log(frequencies.par[2:temp.M2]))^2)*frequencies.par[2:temp.M2]^2
    temp.MacLaurin_ln_upper_bounds<-(exp(temp.MacLaurin_ln_upper_bounds)-1)*100
    temp.plotting_frequencies<-temp.frequency_list[[1]][2:temp.M2]
    temp.MacLaurin_ln_upper_bounds[which(is.infinite(temp.MacLaurin_ln_upper_bounds)==TRUE)]<-0
    temp.MacLaurin_ln_upper_bounds[abs(temp.MacLaurin_ln_upper_bounds)>200]<-0
    if(temp.i %in% temp.plotting_phi_indices){
      temp.truncated_frequency_list[[temp.plotting_counter]]<-temp.plotting_frequencies
      temp.plotting_cos_MacLaurin_bounds_list[[temp.plotting_counter]]<-temp.MacLaurin_ln_upper_bounds
      temp.plotting_counter=temp.plotting_counter+1
    }
    temp.ln_MacLaurin_bounds_list[[temp.counter]]<-temp.MacLaurin_ln_upper_bounds
    temp.counter=temp.counter+1
  }
  if(plot_bool.par==TRUE){
    temp.num_list_elements=length(temp.plotting_cos_MacLaurin_bounds_list)
    plot.graph(temp.truncated_frequency_list,temp.plotting_cos_MacLaurin_bounds_list,x_label.par=paste("Frequency, in ",units.par,sep=""),
               y_label.par="Upper bound on absolute multiplicative error, % difference",
               plot_title.par="",pdf_title.par="AR1_Maclaurin_Ln.pdf",plotting_LB.par=0,plotting_UB.par=0,lwd.par=3,
               legend_labels.par=temp.phi_values[temp.plotting_phi_indices],
               legend_title.par="AR(1) coefficient",horizontal_line.par=0,lty.par=1:temp.num_list_elements,col.par=1:temp.num_list_elements)
    temp.output_matrix<-matrix(0,nrow=length(temp.truncated_frequency_list[[1]]),ncol=temp.num_list_elements+1)
    temp.output_matrix[,1]<-temp.truncated_frequency_list[[1]]
    for(temp.i in 1:temp.num_list_elements){
      temp.output_matrix[,temp.i+1]<-temp.plotting_cos_MacLaurin_bounds_list[[temp.i]]
    }
    temp.labels<-c("frequency",temp.phi_values[temp.plotting_phi_indices])
    output.table(matrix.par=temp.output_matrix,labels.par=temp.labels,title.par="AR1_Maclaurin_Ln")
  }
  #Compare the numerical AR(1)/ARIMA(0,1,0) estimates with the multitaper spectral-power estimates.
  temp.log_spectrum<-log10(spectrum.par)[2:temp.M2]
  temp.nearest_PTF_values<-c()
  temp.nearest_PTF_estimates<-c()
  temp.running_net_diff=0
  temp.optimal_phi=0
  temp.counter=1
  for(temp.i in 1:num_phi_values.par){
    temp.phi=temp.phi_values[temp.i]
    temp.a=8*pi^2*temp.phi
    if(temp.a>0){
      temp.PTF_estimates<-(-1)*(log(temp.a)+8*pi^2/temp.a*temp.phi*(1+2*log(abs(frequencies.par[2:temp.M2]))))
    }
    else{
      temp.PTF_estimates<-rep(1,temp.M2-1)
    }
    temp.PTF_estimates<-temp.PTF_estimates*log10(exp(1))
    temp.PSD_values<-temp.PSD_list[[temp.counter]]
    temp.PSD_values<-log10(temp.PSD_values[2:temp.M2])
    temp.PTF_estimates<-temp.PTF_estimates-median(temp.PSD_values)+median(temp.log_spectrum)
    temp.truncated_PSD_values<-temp.PSD_values-median(temp.PSD_values)+median(temp.log_spectrum)
    temp.net_diff_current=sum((temp.log_spectrum[(frequencies.par*sampling_rate.par)<temp.max_bound]-
                                    temp.PSD_values[(frequencies.par*sampling_rate.par)<temp.max_bound])^2)
    if(!temp.running_net_diff || temp.net_diff_current<temp.running_net_diff){
      temp.running_net_diff=temp.net_diff_current
      temp.nearest_PTF_values<-temp.truncated_PSD_values
      temp.nearest_PTF_estimates<-temp.PTF_estimates
      temp.optimal_phi=temp.phi
    }
    temp.counter=temp.counter+1
  }
  temp.log_frequencies_list<-list()
  for(temp.i in 1:3){
    temp.log_frequencies_list[[temp.i]]<-log10(temp.truncated_frequency_list[[1]])
  }
  temp.plotting_list<-list(temp.log_spectrum,temp.nearest_PTF_values,temp.nearest_PTF_estimates)
  temp.phi_string<-c()
  if(temp.optimal_phi==1){
    temp.phi_string<-"ARIMA(0,1,0)"
  }
  else{
    temp.phi_string<-paste("ARIMA(1,0,0),phi=",temp.optimal_phi,sep="")
  }
  if(plot_bool.par==TRUE){
    #try({
      plot.graph(temp.log_frequencies_list,temp.plotting_list,
                 x_label.par=paste("Frequency, in ",units.par,sep=""),
                 y_label.par=paste(measured_quantity.par," spectral power, in squared ",measured_units.par," per ",units.par,sep=""),
                 plot_title.par="",pdf_title.par="AR1_Linear.pdf",plotting_LB.par=0,plotting_UB.par=0,lwd.par=3,
                 legend_labels.par=c("Multitaper",temp.phi_string,"Linear"),
                 legend_title.par="Spectral-power estimates",col.par=c("grey75","black","black"),log_bool.par=TRUE,
                 lty.par=c(1,1,2))
    #},silent=T)
  }
  temp.list<-list(out.nearest_PTF_estimates=temp.nearest_PTF_estimates)
  return(temp.list)
  
}





###################################################################################################################
#Functions required for robust pre-whitening.

Durbin_Levinson<-function(rho_par,P){
  #cat("Durbin-Levinson P = ",P,":\n\n")
  temp_alphas<-rep(0,P)
  temp_alphas[1]=rho_par[2]
  phi=temp_alphas[1]
  sigma2=1-phi^2
  if(P>1){
    for(i in seq(from=2,to=P,by=1)){
      current_ar=sum(temp_alphas[1:(i-1)]*rho_par[(i-1):1])
      phi=(rho_par[i]-current_ar)/sigma2
      temp_alphas[1:(i-1)]<-temp_alphas[1:(i-1)]-phi*temp_alphas[(i-1):1]
      temp_alphas[i]=phi
      sigma2=sigma2*(1-phi^2)
      #cat(i,"\n",temp_alphas,"\n\n")
    }
  }
  #cat("\n\n")
  return(temp_alphas)
}

Ap_f<-function(f_par,alphas_par){
  temp_sum=as.complex(0)
  alphas_par<-c(-1,alphas_par)
  for(p in seq(from=1,to=length(alphas_par),by=1)){
    temp_argument=2*pi*f_par*(p-1)
    complex_exp=complex(real=cos(temp_argument),imaginary=-sin(temp_argument))
    temp_sum=temp_sum+alphas_par[p]*complex_exp
  }
  return(temp_sum)
}

Aq_f<-function(f_par,thetas_par){
  temp_sum=as.complex(0)
  thetas_par<-c(1,thetas_par)
  for(q in seq(from=1,to=length(thetas_par),by=1)){
    temp_argument=2*pi*f_par*(q-1)
    complex_exp=complex(real=cos(temp_argument),imaginary=-sin(temp_argument))
    temp_sum=temp_sum+thetas_par[q]*complex_exp
  }
  temp.ratio=1/temp_sum
  return(temp.ratio)
}

prediction_variance<-function(f_par,spectrum_par,alphas_par){
  temp.transfer_function<-Mod(Ap_f(f_par,alphas_par))^2
  return(2*mean(spectrum_par*temp.transfer_function))
}

innovations_variance<-function(spectrum_par){
  temp.M_2=length(spectrum_par)
  L=mean(log(c(rev(spectrum_par[2:temp.M_2]),spectrum_par[1:temp.M_2])))
  return(exp(L))
}

prediction_variance_corrected<-function(f_par,spectrum_par,alphas_par,dof_par){
  argument=(dof_par-1)/2
  log_bias=-log(argument)+digamma(argument)
  L=log(prediction_variance(f_par,spectrum_par,alphas_par))
  L=L-log_bias
  return(exp(L))
}

Parzen<-function(tau_par,T_par,innovations_par,prediction_par){
  return(1-innovations_par/prediction_par+tau_par/T_par)
}

durbin_levinson.ar_coefficients<-function(rho_par,P.par){
  temp_alphas<-rep(0,P.par)
  temp_alphas[1]=rho_par[2]
  phi=temp_alphas[1]
  temp.sigma2=1-phi^2
  if(P.par>1){
    for(k.plus_one in seq(from=2,to=P.par,by=1)){
      k=k.plus_one-1
      current_ar=sum(temp_alphas[1:k]*rho_par[k:1])
      phi=(rho_par[k.plus_one]-current_ar)/temp.sigma2
      temp_alphas[1:k]<-temp_alphas[1:k]-phi*temp_alphas[k:1]
      temp_alphas[k.plus_one]=phi
      temp.sigma2=temp.sigma2*(1-phi^2)
    }
  }
  return(temp_alphas)
}




###################################################################################################################
#Innovations algorithm.

innovations_algorithm.one_step_predictors<-function(ts.par,acvs_matrix.par){
  temp.num_lags=nrow(acvs_matrix.par)
  temp.final_n=temp.num_lags-1
  temp.ts<-ts.par[1:temp.final_n]
  temp.one_step_predictors=rep(0,temp.num_lags)
  temp.mse_vector<-temp.one_step_predictors
  temp.theta_matrix<-matrix(0,nrow=temp.final_n,ncol=temp.final_n)
  temp.one_step_predictors[1]=0
  temp.mse_vector[1]=acvs_matrix.par[1,1]
  if(temp.num_lags>1){
    for(temp.n in 1:temp.final_n){
      temp.j_indices<-c()
      if(temp.n==1){
        temp.theta_matrix[temp.n,temp.n]=(acvs_matrix.par[temp.n+1,1])/temp.mse_vector[1]
        temp.mse_vector[2]=acvs_matrix.par[temp.n+1,temp.n+1]-temp.theta_matrix[temp.n,temp.n]^2*temp.mse_vector[1]
        temp.j_indices=0
      }
      else{
        temp.theta_matrix[temp.n,temp.n]=acvs_matrix.par[temp.n+1,1]/temp.mse_vector[1]
        temp.max_k=temp.n-1
        temp.k_indices<-1:temp.max_k
        temp.theta_mse_sums<-rep(0,temp.max_k)
        for(temp.k in temp.k_indices){
          temp.j_indices<-1:temp.k-1
          temp.row_vector1<-temp.theta_matrix[temp.k,temp.k-temp.j_indices]
          temp.row_vector2<-temp.theta_matrix[temp.n,temp.n-temp.j_indices]
          temp.mse_values<-temp.mse_vector[temp.j_indices+1]
          temp.theta_mse_sums[temp.k]=sum(temp.row_vector1*temp.row_vector2*temp.mse_values)
        }
        temp.theta_matrix[temp.n,temp.n-temp.k_indices]<-(acvs_matrix.par[temp.n+1,temp.k_indices+1]-temp.theta_mse_sums)/temp.mse_vector[temp.k_indices+1]
        temp.j_indices<-1:temp.n-1
        temp.mse_vector[temp.n+1]=acvs_matrix.par[temp.n+1,temp.n+1]-crossprod(temp.theta_matrix[temp.n,temp.n-temp.j_indices]^2,temp.mse_vector[temp.j_indices+1])
      }
      temp.j_indices<-1:temp.n
      temp.one_step_predictors[temp.n+1]=sum(temp.theta_matrix[temp.n,temp.j_indices]*(temp.ts[temp.n+1-temp.j_indices]-temp.one_step_predictors[temp.n+1-temp.j_indices]))
    }
  }
  temp.list<-list(predictor.output=temp.one_step_predictors,mse.output=temp.mse_vector)
  return(temp.list)
}



innovations_algorithm.moving_average<-function(acvs.par,q.par=0,num.iterations=0){
  temp.first_covariance=acvs.par[1]
  if(temp.first_covariance<=0){
    cat("ERROR: acvs.par must be positive.\n")
    stopifnot(temp.first_covariance>0)
  }
  temp.num_lags=length(acvs.par)
  temp.final_n=temp.num_lags-1
  if(!q.par){
    q.par=temp.final_n
  }
  if(num.iterations>0){
    temp.final_n=num.iterations
    q.par=temp.final_n
  }
  temp.previous_mse=1
  temp.last_n=temp.final_n
  temp.mse_vector<-rep(0,temp.num_lags)
  temp.theta_matrix<-matrix(0,nrow=temp.final_n,ncol=temp.final_n)
  temp.mse_vector[1]=acvs.par[1]
  for(temp.n in 1:temp.final_n){
    if(temp.previous_mse>=0){
      temp.j_indices<-c()
      if(temp.n==1){
        temp.theta_matrix[temp.n,temp.n]=acvs.par[temp.n+1]/temp.mse_vector[1]
        temp.mse_vector[2]=acvs.par[1]-temp.theta_matrix[temp.n,temp.n]^2*temp.mse_vector[1]
        temp.j_indices=0
      }
      else{
        temp.theta_matrix[temp.n,temp.n]=acvs.par[temp.n+1]/temp.mse_vector[1]
        temp.max_k=temp.n-1
        temp.k_indices<-1:temp.max_k
        temp.theta_mse_sums<-rep(0,temp.max_k)
        for(temp.k in temp.k_indices){
          temp.j_indices<-1:temp.k-1
          temp.row_vector1<-temp.theta_matrix[temp.k,temp.k-temp.j_indices]
          temp.row_vector2<-temp.theta_matrix[temp.n,temp.n-temp.j_indices]
          temp.mse_values<-temp.mse_vector[temp.j_indices+1]
          temp.theta_mse_sums[temp.k]=sum(temp.row_vector1*temp.row_vector2*temp.mse_values)
        }
        temp.theta_matrix[temp.n,temp.n-temp.k_indices]<-(acvs.par[temp.n-temp.k_indices+1]-temp.theta_mse_sums)/temp.mse_vector[temp.k_indices+1]
        temp.j_indices<-1:temp.n-1
        temp.mse_vector[temp.n+1]=acvs.par[1]-crossprod(temp.theta_matrix[temp.n,temp.n-temp.j_indices]^2,temp.mse_vector[temp.j_indices+1])
      }
      temp.j_indices<-1:(temp.n-1)
      temp.previous_mse=temp.mse_vector[temp.n]
    }
    else{
      cat("Error at temp.n = ",temp.n-1,": temp.mse_vector = ",temp.previous_mse,".  Exiting loop.\n")
      temp.last_n=temp.n-1
      if(q.par==temp.final_n){
        q.par=temp.last_n
      }
      break
    }
  }
  temp.mse_vector<-temp.mse_vector[1:temp.last_n]
  temp.theta_matrix<-temp.theta_matrix[1:temp.last_n,1:temp.last_n]
  temp.list<-list(mse.output=temp.mse_vector,theta_matrix.output=temp.theta_matrix)
  return(temp.list)
}


prewhitening_coefficients.function<-function(spectral_power_estimates.par,frequencies.par,N.par,NW.par=5,sampling_rate.par=1,plot_acvs_bool.par=FALSE,
                                             prewhitening_verbose_bool.par=FALSE){
  temp.mt_acvs_object<-multitaper_acvs_analysis.function(spectral_power_estimates.par,NW.par=NW.par,
                                                         sampling_rate.par=sampling_rate.par,plot_bool.par=plot_acvs_bool.par)
  temp.mt_autocorrelation_coefficients<-temp.mt_acvs_object$out.autocorrelation_coefficient_sequence
  temp.prewhitening_object<-prewhitening_algorithm.function(spectral_power_estimates.par,temp.mt_autocorrelation_coefficients,frequencies.par,N.par,
                                                            verbose.par=prewhitening_verbose_bool.par)
  temp.ar_coefficients<-temp.prewhitening_object$out.alphas
  temp.ar_order<-temp.prewhitening_object$out.ar_order
  temp.prewhitened_spectrum<-temp.prewhitening_object$out.prewhitened_spectrum
  temp.list<-list(out.ar_coefficients=temp.ar_coefficients,
                  out.ar_order=temp.ar_order,
                  out.prewhitened_spectrum=temp.prewhitened_spectrum)
  return(temp.list)
}





prewhitening.power_transfer_function<-function(f_par,alphas_par){
  temp.TF<-Ap_f(f_par,alphas_par)
  temp.transfer_function<-Mod(temp.TF)^2
  temp.list<-list(out.TF=temp.TF,
                  out.transfer_function=temp.transfer_function)
  return(temp.list)
}

prewhitened_spectrum<-function(f_par,spectrum_par,alphas_par){
  temp.prewhitening_PTF_object<-prewhitening.power_transfer_function(f_par,alphas_par)
  temp.transfer_function<-temp.prewhitening_PTF_object$out.transfer_function
  temp.prewhitened_spectrum<-spectrum_par*temp.transfer_function
  return(temp.prewhitened_spectrum)
}

prewhitening_algorithm.function<-function(spectral_powers.par,multitaper_autocorrelations.par,frequencies.par,N.par,verbose.par=FALSE){
  #Order selection.
  temp.num_p=10
  temp.innovations_variance=innovations_variance(spectral_powers.par)
  temp.Parzen_criteria<-rep(0,temp.num_p)
  temp.dynamic_ranges<-rep(0,temp.num_p)
  if(verbose.par==TRUE){
    sink("Prewhitening_Statistics.txt", append=FALSE, split=FALSE)
    cat("Order\tPrediction_variance\tParzen_criterion\tDynamic_range\n")
  }
  for(temp.tau in seq(from=1,to=temp.num_p,by=1)){
    temp.alphas<-durbin_levinson.ar_coefficients(multitaper_autocorrelations.par,temp.tau)
    temp.prewhitened_spectrum<-prewhitened_spectrum(frequencies.par,spectral_powers.par,temp.alphas)
    temp.prediction_variance=prediction_variance_corrected(frequencies.par,spectral_powers.par,temp.alphas,N.par)
    temp.normalized_prewhitened_spectrum<-temp.prewhitened_spectrum/temp.prediction_variance
    temp.Parzen_criteria[temp.tau]=Parzen(temp.tau,N.par,temp.innovations_variance,temp.prediction_variance)
    temp.dynamic_ranges[temp.tau]=log10(max(temp.normalized_prewhitened_spectrum)/min(temp.normalized_prewhitened_spectrum))
    if(verbose.par==TRUE){
      cat(temp.tau,"\t",temp.prediction_variance,"\t",temp.Parzen_criteria[temp.tau],"\t",temp.dynamic_ranges[temp.tau],"\n")
    }
  }
  if(verbose.par==TRUE){
    sink()
  }
  temp.min_Parzen=min(temp.Parzen_criteria)
  temp.ar_order=min(which(temp.Parzen_criteria==temp.min_Parzen))
  temp.alphas<-durbin_levinson.ar_coefficients(multitaper_autocorrelations.par,temp.ar_order)
  temp.prewhitening_PTF_object<-prewhitening.power_transfer_function(frequencies.par,temp.alphas)
  temp.prewhitening_tf<-temp.prewhitening_PTF_object$out.TF
  temp.prewhitening_ptf<-temp.prewhitening_PTF_object$out.PTF
  temp.prewhitened_spectrum<-prewhitened_spectrum(frequencies.par,spectral_powers.par,temp.alphas)
  temp.prediction_variance=prediction_variance_corrected(frequencies.par,spectral_powers.par,temp.alphas,N.par)
  temp.normalized_prewhitened_spectrum<-temp.prewhitened_spectrum/temp.prediction_variance
  temp.dynamic_range=log10(max(temp.prewhitened_spectrum)/min(temp.prewhitened_spectrum))
  if(verbose.par==TRUE){
    sink("AR_Coefficients.txt", append=FALSE, split=FALSE)
    cat("coefficient\n")
    for(temp.i in 1:temp.ar_order){
      cat(temp.alphas[temp.i],"\n")
    }
    sink()
    sink("Innovation_Variance.txt", append=FALSE, split=FALSE)
    cat("innovation_variance\tprediction_variance\tdynamic_range\tparzen_metric\n")
    cat(temp.innovations_variance,"\t",temp.prediction_variance,"\t",temp.dynamic_range,"\t",temp.min_Parzen,"\n")
    sink()
  }
  temp.list<-list(out.min_Parzen=temp.min_Parzen,
                  out.alphas=temp.alphas,
                  out.prewhitening_ptf=temp.prewhitening_ptf,
                  out.prewhitened_spectrum=temp.prewhitened_spectrum,
                  out.prediction_variance=temp.prediction_variance,
                  out.normalized_prewhitened_spectrum=temp.normalized_prewhitened_spectrum,
                  out.dynamic_range=temp.dynamic_range,
                  out.ar_order=temp.ar_order,
                  out.prewhitening_tf=temp.prewhitening_tf)
  return(temp.list)
}





















