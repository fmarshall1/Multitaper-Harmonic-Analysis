#Francois Marshall, Boston University
#Header file for general math functions.
###################################################################################################################

#Linear algebra.

inner.product<-function(ts1.par,ts2.par,tau.par=0){
  temp.N=length(ts1.par)
  temp.series1<-as.matrix(ts1.par[1:(temp.N-tau.par)])
  temp.series2<-as.matrix(ts2.par[(tau.par+1):temp.N])
  temp.series2_imaginary<-Im(temp.series2)
  temp.ss=0
  if(!length(which(temp.series2_imaginary!=0))){
    temp.series2<-Re(temp.series2)
    temp.ss=crossprod(temp.series1,temp.series2)
  }
  else{
    temp.ss=sum(temp.series1*Conj(temp.series2))
  }
  return(temp.ss)
}

inner_product.like_rows<-function(like_row.index,matrix1.par,matrix2.par){
  temp.row1<-matrix1.par[like_row.index,]
  temp.row2<-matrix2.par[like_row.index,]
  temp.inner_product=inner.product(temp.row1,temp.row2)
  return(temp.inner_product)
}


#Matrix operations.

hermitian.conjugate<-function(matrix.par){
  return(t(Conj(matrix.par)))
}

matrix.trace<-function(matrix.par){
  return(sum(diag(matrix.par)))
}


is.positive_definite<-function(matrix.par){
  #Return 1 is the matrix is positive definite, 2 if it is positive semi-definite, and 0 if it is negative definite.
  temp.rank=nrow(matrix.par)
  #Error handling for matrices which R deems non-stationary.
  temp.eigenvalues<-eigen(matrix.par,symmetric=TRUE)$values
  temp.eigenvalues[temp.eigenvalues<.Machine$double.eps]<-0
  #Eigenvalues may not be real due to numerical error only; covariance matrices should be nearly positive definite,
  #but for this error term.
  temp.eigenvalues<-Re(temp.eigenvalues)
  temp.eigenvalues[abs(temp.eigenvalues)<.Machine$double.eps]<-0
  temp.positive_definite_bool=0
  temp.num_positive=length(which(temp.eigenvalues>0))
  temp.num_non_negative=length(which(temp.eigenvalues>=0))
  if(temp.num_positive==temp.rank){
    temp.positive_definite_bool=1
  }
  else if(temp.num_non_negative==temp.rank){
    temp.positive_definite_bool=2
  }
  else{
    temp.positive_definite_bool=0
  }
  return(temp.positive_definite_bool)
}



complex.cholesky_square_root<-function(matrix.par){
  temp.rank=nrow(matrix.par)
  temp.matrix<-matrix(0,nrow=temp.rank,ncol=temp.rank)
  for(i in 1:(temp.rank-1)){
    temp.matrix[i,i]=sqrt(Mod(matrix.par[i,i]))
    temp.matrix[i,(i+1):temp.rank]<-matrix.par[i,(i+1):temp.rank]/temp.matrix[i,i]
    temp.matrix[(i+1):temp.rank,i]<-Conj(temp.matrix[i,(i+1):temp.rank]/temp.matrix[i,i])
    temp.matrix[(i+1):temp.rank,(i+1):temp.rank]<-matrix.par[(i+1):temp.rank,(i+1):temp.rank]-Conj(temp.matrix[(i+1):temp.rank,i])%*%t(temp.matrix[i,(i+1):temp.rank])
  }
  return(temp.matrix)
}

matrix.square_root<-function(matrix.par,minus.par=FALSE,is.symmetric=FALSE,verbose.par=FALSE){
  temp.square_root<-diag(rep(1,nrow(matrix.par)))
  #temp.positive_definite_identifier=is.positive_definite(matrix.par)
  #if(temp.positive_definite_identifier==1){
  #Cholesky decomposition.
  #  cat("Cholesky\n")
  #  temp.square_root<-complex.cholesky_square_root(matrix.par)
  #}
  #else if(temp.positive_definite_identifier==2){
  #Eigenvalue decomposition.
  if(verbose.par==TRUE){
    cat("Eigenvalue decomposition\n")
  }
  temp.eigen_object<-eigen(matrix.par)
  if(is.symmetric){
    temp.eigen_object<-eigen(matrix.par,symmetric=TRUE)
  }
  temp.eigenvalues<-temp.eigen_object$values
  temp.eigenvalues[temp.eigenvalues<0]<-.Machine$double.eps
  if(verbose.par==TRUE){
    cat("Eigenvalues:\n")
    print(temp.eigenvalues)
  }
  temp.eigenvectors_matrix<-temp.eigen_object$vectors
  temp.square_roots<-sqrt(temp.eigenvalues)
  if(minus.par){
    temp.singular_values_matrix<-diag(1/temp.square_roots)
  }
  else{
    temp.singular_values_matrix<-diag(temp.square_roots)
  }
  temp.square_root<-temp.eigenvectors_matrix%*%as.matrix(temp.singular_values_matrix)%*%hermitian.conjugate(temp.eigenvectors_matrix)
  #}
  if(verbose.par==TRUE){
    cat("temp.square_root:\n")
    print(temp.square_root)
  }
  return(temp.square_root)
}

singular_value.decomposition<-function(matrix.par){
  #Right eigenvectors.
  temp.squared_matrix<-(hermitian.conjugate(matrix.par)%*%matrix.par)
  temp.eigen_object<-eigen(temp.squared_matrix)
  temp.eigenvalues<-temp.eigen_object$values
  temp.eigenvectors<-temp.eigen_object$vectors
  temp.left_eigenvectors_matrix<-temp.eigenvectors
  #Left eigenvectors.
  temp.squared_matrix<-(matrix.par%*%hermitian.conjugate(matrix.par))
  temp.eigen_object<-eigen(temp.squared_matrix)
  temp.eigenvalues<-temp.eigen_object$values
  temp.eigenvalues[temp.eigenvalues<.Machine$double.eps]<-0
  temp.eigenvectors<-temp.eigen_object$vectors
  temp.right_eigenvectors_matrix<-temp.eigenvectors
  #Construct the singular-values matrix, and extract the singular values from it.
  temp.singular_values<-sqrt(temp.eigenvalues)
  temp.list<-list(u=temp.left_eigenvectors_matrix,d=temp.singular_values,v=temp.right_eigenvectors_matrix)
}

inverse.matrix_square_root<-function(matrix.par,is.symmetric=FALSE){
  temp.matrix<-matrix.square_root(matrix.par)
  temp.matrix<-solve(temp.matrix)
  return(temp.matrix)
}


#Compute the inverse square-root of the transpose a matrix.
inverse.matrix_transpose_square_root<-function(matrix.par,is.symmetric=FALSE,verbose.par=FALSE){
  temp.matrix<-matrix.square_root(matrix.par,is.symmetric=is.symmetric,verbose.par=verbose.par)
  temp.matrix<-t(temp.matrix)
  temp.matrix<-solve(temp.matrix)
  if(verbose.par==TRUE){
    cat("inverse.matrix_transpose_square_root:\n")
    print(temp.matrix)
  }
  return(temp.matrix)
}


#Compute the inverse square-root of the hermitian conjugate a matrix.
inverse.matrix_hermitian_square_root<-function(matrix.par,is.symmetric=FALSE,verbose.par=FALSE){
  temp.matrix<-matrix.square_root(matrix.par,is.symmetric=is.symmetric,verbose.par=verbose.par)
  temp.matrix<-hermitian.conjugate(temp.matrix)
  temp.matrix<-solve(temp.matrix)
  if(verbose.par==TRUE){
    cat("inverse.matrix_hermitian_square_root:\n")
    print(temp.matrix)
  }
  return(temp.matrix)
}






inverse_square_partitioned_matrix.function<-function(matrix.par){
  temp.rank=nrow(matrix.par)
  temp.halfway_index=(temp.rank-temp.rank%%2)/2
  temp.first_half_indices<-1:temp.halfway_index
  temp.A<-matrix.par[temp.first_half_indices,temp.first_half_indices]
  temp.B<-matrix.par[temp.first_half_indices,temp.first_half_indices+temp.halfway_index]
  temp.C<-matrix.par[temp.first_half_indices+temp.halfway_index,temp.first_half_indices]
  temp.D<-matrix.par[temp.first_half_indices+temp.halfway_index,temp.first_half_indices+temp.halfway_index]
  temp.D_inverse<-c()
  if(temp.rank==2){
    temp.D_inverse<-as.matrix(1/temp.D)
  }
  else{
    temp.D_inverse<-inv(temp.D)
  }
  temp.inverse_11<-c()
  temp.matrix<-temp.A-temp.B%*%temp.D_inverse%*%temp.C
  if(temp.rank==2){
    temp.inverse_11<-1/temp.matrix
  }
  else{
    temp.inverse_11<-inv(temp.matrix)
  }
  temp.inverse_12<-c()
  if(temp.rank==2){
    temp.inverse_12<-(-1/(temp.A-temp.B%*%temp.D_inverse%*%temp.C))%*%temp.B%*%temp.D_inverse
  }
  else{
    temp.inverse_12<-(-1)*inv(temp.A-temp.B%*%temp.D_inverse%*%temp.C)%*%temp.B%*%temp.D_inverse
  }
  temp.A_inverse<-c()
  if(temp.rank==2){
    temp.A_inverse<-as.matrix(1/temp.A)
  }
  else{
    temp.A_inverse<-inv(temp.A)
  }
  temp.inverse_21<-c()
  if(temp.rank==2){
    temp.inverse_21<-(-1/(temp.D-temp.C%*%temp.A_inverse%*%temp.B))%*%temp.C%*%temp.A_inverse
  }
  else{
    temp.inverse_21<-(-1)*inv(temp.D-temp.C%*%temp.A_inverse%*%temp.B)%*%temp.C%*%temp.A_inverse
  }
  temp.inverse_22<-c()
  if(temp.rank==2){
    temp.inverse_22<-1/(temp.D-temp.C%*%temp.A_inverse%*%temp.B)
  }
  else{
    temp.inverse_22<-inv(temp.D-temp.C%*%temp.A_inverse%*%temp.B)
  }
  temp.inverse<-matrix(0,nrow=temp.rank,ncol=temp.rank)
  temp.inverse[temp.first_half_indices,temp.first_half_indices]<-temp.inverse_11
  temp.inverse[temp.first_half_indices,temp.first_half_indices+temp.halfway_index]<-temp.inverse_12
  temp.inverse[temp.first_half_indices+temp.halfway_index,temp.first_half_indices]<-temp.inverse_21
  temp.inverse[temp.first_half_indices+temp.halfway_index,temp.first_half_indices+temp.halfway_index]<-temp.inverse_22
  return(temp.inverse)
}



determinant_partitioned_matrix.function<-function(matrix.par){
  temp.rank=nrow(matrix.par)
  temp.halfway_index=(temp.rank-temp.rank%%2)/2
  temp.first_half_indices<-1:temp.halfway_index
  temp.A<-matrix.par[temp.first_half_indices,temp.first_half_indices]
  temp.B<-matrix.par[temp.first_half_indices,temp.first_half_indices+temp.halfway_index]
  temp.C<-matrix.par[temp.first_half_indices+temp.halfway_index,temp.first_half_indices]
  temp.D<-matrix.par[temp.first_half_indices+temp.halfway_index,temp.first_half_indices+temp.halfway_index]
  temp.factor1<-Det(temp.A)
  temp.factor2<-0
  if(all(temp.B==0) || all(temp.C==0)){
    temp.factor2<-Det(temp.D)
  }
  else{
    temp.factor2<-Det(temp.D-temp.C%*%inv(temp.A)%*%temp.B)
  }
  temp.log_factor1=log(temp.factor1)
  temp.log_factor2=log(temp.factor2)
  temp.determinant=temp.log_factor1+temp.log_factor2
  return(temp.determinant)
}


determinant_large_square_partitioned_matrix.function<-function(matrix.par){
  temp.running_rank=nrow(matrix.par)
  temp.running_block_size1=(temp.running_rank-temp.running_rank%%2)/2
  temp.running_block_size2=temp.running_block_size1
  temp.running_matrix_list<-list()
  temp.running_matrix_list[[1]]<-matrix.par
  while(min(temp.running_block_size1,temp.running_block_size2)>3){
    temp.num_blocks=length(temp.running_matrix_list)
    temp.running_rank=nrow(temp.running_matrix_list[[1]])
    temp.running_block_size1=(temp.running_rank-temp.running_rank%%2)/2
    temp.indices1<-1:temp.running_block_size1
    temp.indices2<-(temp.running_block_size1+1):temp.running_rank
    temp.running_block_size2=length(temp.indices2)
    temp.buffer_list<-list()
    for(temp.j in 1:temp.num_blocks){
      temp.bigger_block<-temp.running_matrix_list[[temp.j]]
      temp.NW_block=temp.bigger_block[temp.indices1,temp.indices1]
      temp.NE_block=temp.bigger_block[temp.indices1,temp.indices2]
      temp.SW_block=temp.bigger_block[temp.indices2,temp.indices1]
      temp.SE_block=temp.bigger_block[temp.indices2,temp.indices2]
      temp.buffer_list[[(temp.j-1)*4+1]]=temp.NW_block
      temp.buffer_list[[(temp.j-1)*4+2]]=temp.NE_block
      temp.buffer_list[[(temp.j-1)*4+3]]=temp.SW_block
      temp.buffer_list[[(temp.j-1)*4+4]]=temp.SE_block
    }
    temp.running_matrix_list<-temp.buffer_list
  }
  temp.num_blocks=length(temp.running_matrix_list)/4
  temp.log_determinant=0
  for(temp.j in 1:temp.num_blocks){
    temp.NW_block=temp.running_matrix_list[[(temp.j-1)*4+1]]
    temp.NE_block=temp.running_matrix_list[[(temp.j-1)*4+2]]
    temp.SW_block=temp.running_matrix_list[[(temp.j-1)*4+3]]
    temp.SE_block=temp.running_matrix_list[[(temp.j-1)*4+4]]
    temp.SE_NW_Schur_complement=temp.SE_block-temp.SW_block%*%matrix.inverse(temp.NW_block)%*%temp.NE_block
    temp.block_log_determinant=Re(Det(temp.NW_block))*Re(Det(temp.SE_NW_Schur_complement))
    temp.log_determinant=temp.log_determinant+log(abs(temp.block_log_determinant))
  }
  return(temp.log_determinant)
}

















