#Francois Marshall, Boston University
#Main header file for multitaper spectral analysis.
###################################################################################################################

#The most resistant spectrum estimator with respect to changes in the locally-white assumption.
multitaper.regularized_spectrum<-function(eigencoefficients.par,frequencies.par,concentrations.par,plot.par=FALSE,measured_quantity.par="Measured value",
                                          measured_units.par="units",sampling_rate.par=1,plotting_LB.par=0,plotting_UB.par=0,cepstral_bool.par=FALSE){
  temp.M=nrow(eigencoefficients.par)
  temp.zero_index=temp.M/2
  temp.K=ncol(eigencoefficients.par)
  temp.NW=(temp.K-1)/2
  temp.units_string=abbreviated_frequency_units.string
  temp.abscissa_string<-"Frequency"
  if(cepstral_bool.par==TRUE){
    temp.units_string=abbreviated_time_units.string

    temp.abscissa_string<-"Quefrency"
  }
  temp.normalized_eigencoefficients<-eigencoefficients.par
  for(temp.k in 1:temp.K){
    temp.normalized_eigencoefficients[,temp.k]<-temp.normalized_eigencoefficients[,temp.k]/sqrt(concentrations.par[temp.k])
  }
  temp.cyclic_spectrum<-rowSums(Mod(temp.normalized_eigencoefficients)^2)/(2*temp.NW)
  temp.cyclic_spectrum<-temp.cyclic_spectrum[temp.zero_index:temp.M]
  if(plot.par==TRUE){
    #Compute the FFT-frequencies and the associated log-transformed frequencies.
    temp.log.frequencies<-log10(frequencies.par[frequencies.par>0]*sampling_rate.par)
    temp.list_cyclic_spectrum<-log10(Mod(temp.cyclic_spectrum[frequencies.par>0]))
    #Plot the spectral-power estimates.
    temp.second_title_substring<-"_Spectral_Power_Estimates.pdf"
    temp.PDF_title_string<-paste(measured_quantity.par,temp.second_title_substring,sep="")
    temp.lower_x=min(temp.log.frequencies)
    temp.upper_x=max(temp.log.frequencies)
    temp.lower_y=min(temp.list_cyclic_spectrum)
    temp.upper_y=max(temp.list_cyclic_spectrum)
    pdf(temp.PDF_title_string,width=8,height=6)
    log_spectral_power_plot.function(temp.log.frequencies,temp.list_cyclic_spectrum,c(temp.lower_x,temp.upper_x),c(temp.lower_y,temp.upper_y),
                                     ordinate_quantity.par=temp.abscissa_string,measured_quantity.par=str_remove(measured_quantity.par,"Residual_"),
                                     units.par1=temp.units_string,
                                     units.par2=measured_units.par,cepstral_bool.par=cepstral_bool.par)
    dev.off()
  }
  return(temp.cyclic_spectrum)
}




#Rotational correlation.

rotational_univariate_correlation_test_statistic.function<-function(variates1.par,variates2.par){
  temp.numerator<-Mod(sum(variates1.par*Conj(variates2.par)))^2
  temp.denominator1<-sum(Mod(variates1.par)^2)
  temp.denominator2<-sum(Mod(variates2.par)^2)
  temp.denominator<-temp.denominator1*temp.denominator2
  temp.coefficient=temp.numerator/temp.denominator
  return(temp.coefficient)
}

rotational_multivariate_correlation_prepare_statistics.function<-function(vector_1.par,vector_2.par){
  temp.num_samples=ncol(vector_1.par)
  temp.mean_vector1<-rowMeans(vector_1.par)
  temp.mean_vector2<-rowMeans(vector_2.par)
  temp.sample_covariance_matrix_12<-
    vector_1.par%*%hermitian.conjugate(vector_2.par)/temp.num_samples-temp.mean_vector1%*%hermitian.conjugate(temp.mean_vector2)
  temp.sample_covariance_matrix_11<-
    vector_1.par%*%hermitian.conjugate(vector_1.par)/temp.num_samples-temp.mean_vector1%*%hermitian.conjugate(temp.mean_vector1)
  temp.sample_covariance_matrix_22<-
    vector_2.par%*%hermitian.conjugate(vector_2.par)/temp.num_samples-temp.mean_vector2%*%hermitian.conjugate(temp.mean_vector2)
  temp.list<-list(out.sample_covariance_matrix_12=temp.sample_covariance_matrix_12,
                  out.sample_covariance_matrix_11=temp.sample_covariance_matrix_11,
                  out.sample_covariance_matrix_22=temp.sample_covariance_matrix_22)
  return(temp.list)
}


rotational_CCA_test_statistic.function<-function(vector_1.par,vector_2.par){
  temp.dimension=length(vector_1.par)
  temp.test_statistic=0
  if((length(which(Re(vector_1.par)==0))<temp.dimension & length(which(Im(vector_1.par)==0))<temp.dimension) &
     (length(which(Re(vector_2.par)==0))<temp.dimension & length(which(Im(vector_2.par)==0))<temp.dimension)){
    temp.identity_matrix<-diag(rep(1,2))
    temp.num_samples=(temp.dimension-temp.dimension%%2)/2
    temp.vectors1<-matrix(0,nrow=2,ncol=temp.num_samples)
    temp.vectors2<-temp.vectors1
    for(temp.i in 1:temp.num_samples){
      temp.vectors1[,temp.i]<-c(vector_1.par[temp.i],vector_1.par[temp.i+temp.num_samples/2])
      temp.vectors2[,temp.i]<-c(vector_2.par[temp.i],vector_2.par[temp.i+temp.num_samples/2])
    }
    temp.matrices_object<-rotational_multivariate_correlation_prepare_statistics.function(temp.vectors1,temp.vectors2)
    temp.sample_covariance_matrix_12<-temp.matrices_object$out.sample_covariance_matrix_12
    temp.sample_covariance_matrix_11<-temp.matrices_object$out.sample_covariance_matrix_11
    temp.sample_covariance_matrix_22<-temp.matrices_object$out.sample_covariance_matrix_22
    try({
      if(length(intersect(vector_1.par,vector_2.par))!=temp.dimension){
        temp.matrix1<-matrix.inverse(temp.sample_covariance_matrix_11)
        temp.matrix2<-temp.sample_covariance_matrix_12
        temp.matrix3<-matrix.inverse(temp.sample_covariance_matrix_22)
        temp.matrix4<-hermitian.conjugate(temp.sample_covariance_matrix_12)
        temp.rotational_coherence_matrix<-temp.matrix1%*%temp.matrix2%*%temp.matrix3%*%temp.matrix4
        temp.l_n=Re(Det(temp.identity_matrix-temp.rotational_coherence_matrix))
        if(temp.l_n>0){
          temp.test_statistic=(-temp.num_samples)*log(temp.l_n)
        }
      }
    }, silent=TRUE)
  }
  return(temp.test_statistic)
}



total_multivariate_correlation_prepare_statistics.function<-function(vector_1.par,vector_2.par){
  temp.num_samples=0
  temp.dimension1=0
  if(is.matrix(vector_1.par)==TRUE){
    temp.num_samples=ncol(vector_1.par)
    temp.dimension1=nrow(vector_1.par)
  }
  else{
    temp.num_samples=length(vector_1.par)
    temp.dimension1=1
  }
  temp.dimension2=0
  if(is.matrix(vector_2.par)==TRUE){
    temp.dimension2=nrow(vector_2.par)
  }
  else{
    temp.dimension2=1
  }
  temp.vectors1<-matrix(0,nrow=2*temp.dimension1,ncol=temp.num_samples)
  temp.vectors2<-matrix(0,nrow=2*temp.dimension2,ncol=temp.num_samples)
  for(temp.k in 1:temp.num_samples){
    if(is.matrix(vector_1.par)==TRUE){
      temp.vectors1[,temp.k]<-c(vector_1.par[,temp.k],Conj(vector_1.par[,temp.k]))
      temp.vectors2[,temp.k]<-c(vector_2.par[,temp.k],Conj(vector_2.par[,temp.k]))
    }
    else{
      temp.vectors1[,temp.k]<-c(vector_1.par[temp.k],Conj(vector_1.par[temp.k]))
      temp.vectors2[,temp.k]<-c(vector_2.par[temp.k],Conj(vector_2.par[temp.k]))
    }
  }
  temp.mean_vector1<-rowMeans(temp.vectors1)
  temp.mean_vector2<-rowMeans(temp.vectors2)
  temp.sample_covariance_matrix_12<-
    temp.vectors1%*%hermitian.conjugate(temp.vectors2)/temp.num_samples-temp.mean_vector1%*%hermitian.conjugate(temp.mean_vector2)
  temp.sample_covariance_matrix_11<-
    temp.vectors1%*%hermitian.conjugate(temp.vectors1)/temp.num_samples-temp.mean_vector1%*%hermitian.conjugate(temp.mean_vector1)
  temp.sample_covariance_matrix_22<-
    temp.vectors2%*%hermitian.conjugate(temp.vectors2)/temp.num_samples-temp.mean_vector2%*%hermitian.conjugate(temp.mean_vector2)
  temp.list<-list(out.sample_covariance_matrix_12=temp.sample_covariance_matrix_12,
                  out.sample_covariance_matrix_11=temp.sample_covariance_matrix_11,
                  out.sample_covariance_matrix_22=temp.sample_covariance_matrix_22)
  return(temp.list)
}


total_CCA_test_statistic.function<-function(vector_1.par,vector_2.par){
  temp.dimension1=0
  if(is.matrix(vector_1.par)==TRUE){
    temp.dimension1=nrow(vector_1.par)
  } else{
    temp.dimension1=length(vector_1.par)
  }
  temp.dimension2=0
  if(is.matrix(vector_2.par)==TRUE){
    temp.dimension2=nrow(vector_2.par)
  } else{
    temp.dimension2=length(vector_2.par)
  }
  temp.test_statistic=0
  temp.rank=2*min(temp.dimension1,temp.dimension2)
  temp.identity_matrix<-diag(rep(1,temp.rank))
  temp.matrices_object<-total_multivariate_correlation_prepare_statistics.function(vector_1.par,vector_2.par)
  temp.sample_covariance_matrix_12<-temp.matrices_object$out.sample_covariance_matrix_12
  temp.sample_covariance_matrix_11<-temp.matrices_object$out.sample_covariance_matrix_11
  temp.sample_covariance_matrix_22<-temp.matrices_object$out.sample_covariance_matrix_22
  tryCatch({
    temp.matrix1<-inverse_square_partitioned_matrix.function(temp.sample_covariance_matrix_11)
    temp.matrix2<-temp.sample_covariance_matrix_12
    temp.matrix3<-inverse_square_partitioned_matrix.function(temp.sample_covariance_matrix_22)
    temp.matrix4<-hermitian.conjugate(temp.sample_covariance_matrix_12)
    temp.total_coherence_matrix<-temp.matrix1%*%temp.matrix2%*%temp.matrix3%*%temp.matrix4
    temp.l_n=Re(Det(temp.identity_matrix-temp.total_coherence_matrix))
    if(temp.l_n>=0){
      temp.test_statistic=1-sqrt(temp.l_n)
      temp.test_statistic=-log(1-temp.test_statistic)
    }
  }, error=function(e){})
  return(temp.test_statistic)
}



total_MLR_test_statistic.function<-function(vector_1.par,vector_2.par){
  temp.matrices_object<-total_multivariate_correlation_prepare_statistics.function(vector_1.par,vector_2.par)
  temp.sample_covariance_matrix_12<-temp.matrices_object$out.sample_covariance_matrix_12
  temp.sample_covariance_matrix_11<-temp.matrices_object$out.sample_covariance_matrix_11
  temp.sample_covariance_matrix_22<-temp.matrices_object$out.sample_covariance_matrix_22
  temp.test_statistic=0
  tryCatch({
    temp.matrix1<-temp.sample_covariance_matrix_12
    temp.matrix2<-solve(temp.sample_covariance_matrix_22)
    temp.matrix3<-hermitian.conjugate(temp.sample_covariance_matrix_12)
    temp.matrix4<-temp.sample_covariance_matrix_11
    temp.total_coherence_matrix<-temp.matrix1%*%temp.matrix2%*%temp.matrix3
    temp.test_statistic=Re(matrix.trace(temp.total_coherence_matrix)/matrix.trace(temp.matrix4))
  }, error=function(e){})
  return(temp.test_statistic)
}


total_PLS_test_statistic.function<-function(vector_1.par,vector_2.par){
  temp.matrices_object<-total_multivariate_correlation_prepare_statistics.function(vector_1.par,vector_2.par)
  temp.sample_covariance_matrix_12<-temp.matrices_object$out.sample_covariance_matrix_12
  temp.sample_covariance_matrix_11<-temp.matrices_object$out.sample_covariance_matrix_11
  temp.sample_covariance_matrix_22<-temp.matrices_object$out.sample_covariance_matrix_22
  temp.test_statistic=0
  tryCatch({
    temp.matrix1<-temp.sample_covariance_matrix_12
    temp.matrix2<-hermitian.conjugate(temp.sample_covariance_matrix_12)
    temp.matrix3<-temp.sample_covariance_matrix_11%*%hermitian.conjugate(temp.sample_covariance_matrix_11)
    temp.matrix4<-temp.sample_covariance_matrix_22%*%hermitian.conjugate(temp.sample_covariance_matrix_22)
    temp.total_coherence_matrix<-temp.matrix1%*%temp.matrix2
    temp.test_statistic=Re(matrix.trace(temp.total_coherence_matrix)/sqrt(matrix.trace(temp.matrix3)*matrix.trace(temp.matrix4)))
  }, error=function(e){})
  return(temp.test_statistic)
}


#Somerset 2017.
omsc_estimator_CDF.function<-function(x.par,c.par,nd.par){
  temp.b_parameter=1-nd.par
  temp.x_parameter=x.par*c.par
  temp.hypergeometric_factor_sequence<-rep(0,nd.par-2)
  temp.power_factor_sequence<-temp.hypergeometric_factor_sequence
  for(temp.m in 1:(nd.par-2)){
    temp.a_m_parameter=(-1)*(temp.m-1)
    temp.power_factor_sequence[temp.m]<-((1-x.par)/(1-temp.x_parameter))^(temp.m-1)
    temp.hypergeometric_factor_sequence[temp.m]=Re(genhypergeo(U=c(temp.a_m_parameter,temp.b_parameter),L=c(1),z=temp.x_parameter))
  }
  temp.hypergeometric_sum_factor=crossprod(temp.power_factor_sequence,temp.hypergeometric_factor_sequence)
  temp.first_factor=x.par*((1-c.par)/(1-temp.x_parameter))^nd.par
  temp.omsc_CDF_value=temp.first_factor*temp.hypergeometric_sum_factor
  return(temp.omsc_CDF_value)
}


omsc_estimator_expected_value.function<-function(x.par,c.par,nd.par){
  temp.first_factor=(1-c.par)^nd.par/nd.par
  temp.hypergeometric_factor=0
  try({
    temp.hypergeometric_factor=Re(genhypergeo(U=c(2,nd.par,nd.par),L=c(1+nd.par,1),z=c.par))
  }, silent=TRUE)
  temp.expected_value=temp.first_factor*temp.hypergeometric_factor
  return(temp.expected_value)
}


omsc_estimator_variance.function<-function(x.par,c.par,nd.par,omsc_expected_value.par){
  temp.first_factor=2*(1-c.par)^nd.par/nd.par/(nd.par+1)
  temp.hypergeometric_factor=0
  try({
    temp.hypergeometric_factor=Re(genhypergeo(U=c(3,nd.par,nd.par),L=c(2+nd.par,1),z=c.par))
  }, silent=TRUE)
  temp.second_moment=temp.first_factor*temp.hypergeometric_factor
  temp.variance=temp.second_moment-omsc_expected_value.par^2
  return(temp.variance)
}


omsc_estimate.function<-function(vector1.par,vector2.par){
  temp.numerator=sum(vector1.par*Conj(vector2.par))
  temp.denominator_factor1=sum(Mod(vector1.par)^2)
  temp.denominator_factor2=sum(Mod(vector2.par)^2)
  temp.denominator_factor=temp.denominator_factor1*temp.denominator_factor2
  temp.omsc_estimate=temp.numerator/sqrt(temp.denominator_factor)
  temp.omsc_estimate=Mod(temp.omsc_estimate)^2
  return(temp.omsc_estimate)
}

estimated_omsc_matrix.function<-function(eigencoefficient_matrix.par){
  temp.num_frequencies=nrow(eigencoefficient_matrix.par)
  temp.K=ncol(eigencoefficient_matrix.par)
  temp.omsc_estimate_matrix<-matrix(0,nrow=temp.num_frequencies,ncol=temp.num_frequencies)
  for(temp.l in 1:temp.num_frequencies){
    temp.eigencoefficient_vector_l<-eigencoefficient_matrix.par[temp.l,]
    for(temp.m in 1:temp.num_frequencies){
      temp.eigencoefficient_vector_m<-eigencoefficient_matrix.par[temp.m,]
      temp.omsc_estimate_lm=omsc_estimate.function(temp.eigencoefficient_vector_l,temp.eigencoefficient_vector_m)
      temp.omsc_estimate_matrix[temp.l,temp.m]=temp.omsc_estimate_lm
    }
  }
  return(temp.omsc_estimate_matrix)
}


omsc_test.function<-function(eigencoefficient_matrix.par,omsc_truth_matrix.par){
  temp.num_frequencies=nrow(eigencoefficient_matrix.par)
  temp.K=ncol(eigencoefficient_matrix.par)
  temp.estimated_omsc_matrix<-estimated_omsc_matrix.function(eigencoefficient_matrix.par)
  temp.bias_matrix<-matrix(0,nrow=temp.num_frequencies,ncol=temp.num_frequencies)
  temp.variance_matrix<-temp.bias_matrix
  for(temp.l in 1:temp.num_frequencies){
    for(temp.m in 1:temp.num_frequencies){
      temp.truth=omsc_truth_matrix.par[temp.l,temp.m]
      temp.estimated_omsc_lm=temp.estimated_omsc_matrix[temp.l,temp.m]
      temp.first_moment_lm=omsc_estimator_expected_value.function(x.par=temp.estimated_omsc_lm,c.par=temp.truth,nd.par=temp.K)
      temp.diff=0
      if(!is.na(temp.first_moment_lm)){
        temp.diff=temp.first_moment_lm-temp.truth
      }
      temp.bias_matrix[temp.l,temp.m]=temp.diff
      temp.variance_lm=omsc_estimator_variance.function(x.par=temp.estimated_omsc_lm,c.par=temp.truth,nd.par=temp.K,omsc_expected_value.par=temp.first_moment_lm)
      temp.variance_matrix[temp.l,temp.m]=temp.variance_lm
    }
  }
  temp.list<-list(out.estimated_omsc_matrix=temp.estimated_omsc_matrix,
                  out.bias_matrix=temp.bias_matrix,
                  out.variance_matrix=temp.variance_matrix)
  return(temp.list)
}








#The multitaper cyclic-spectrum estimate for the Loeve bifrequency plane.
multitaper.cyclic_bifrequency_spectrum<-function(eigencoefficients.par,frequencies.par,cyclic_frequency_indices.par,concentrations.par,plot.par=FALSE,
                                                 measured_quantity.par="Measured value",measured_units.par="units",sampling_rate.par=1,
                                                 pdf_title.par="Bifrequency_Spectrum.pdf",passband_cutoffs.par=NA,max_size.par=NA){
  temp.M=nrow(eigencoefficients.par)
  temp.zero_index=temp.M/2
  temp.M2=temp.zero_index+1
  if(!is.na(max_size.par)){
    if(temp.M>max_size.par){
      cyclic_frequency_indices.par<-seq(from=1,to=temp.M2,by=floor(temp.M/max_size.par))
    }
  }
  temp.num_cyclic_frequencies=length(cyclic_frequency_indices.par)
  temp.K=ncol(eigencoefficients.par)
  temp.NW=(temp.K-1)/2
  temp.normalized_eigencoefficients<-eigencoefficients.par
  for(temp.k in 1:temp.K){
    temp.normalized_eigencoefficients[,temp.k]<-temp.normalized_eigencoefficients[,temp.k]/sqrt(temp.M*concentrations.par[temp.k])
  }
  temp.bifrequency_spectrum_list<-list()
  temp.CCA_list<-list()
  temp.row_indices_list<-list()
  temp.column_indices_list<-list()
  for(temp.i in 1:temp.num_cyclic_frequencies){
    cat(temp.i," out of ",temp.num_cyclic_frequencies,"\n")
    temp.index=cyclic_frequency_indices.par[temp.i]
    temp.frequency_row_indices<-temp.index:(temp.zero_index+1)-1
    temp.frequency_column_indices<-1:(temp.zero_index-temp.index+2)-1
    temp.num_row_frequencies=length(temp.frequency_row_indices)
    temp.eigencoefficients1<-temp.normalized_eigencoefficients[temp.zero_index+temp.frequency_row_indices,]
    temp.eigencoefficients2<-temp.normalized_eigencoefficients[temp.zero_index+temp.frequency_column_indices,]
    temp.cyclic_spectrum<-rep(0,temp.num_row_frequencies)
    temp.CCA_spectrum<-temp.cyclic_spectrum
    for(temp.m in 1:temp.num_row_frequencies){
      temp.eigencoefficients_vector1<-c()
      temp.eigencoefficients_vector2<-c()
      if(!is.matrix(temp.eigencoefficients1)){
        temp.eigencoefficients_vector1<-temp.eigencoefficients1
        temp.eigencoefficients_vector2<-temp.eigencoefficients2
      }
      else{
        temp.eigencoefficients_vector1<-temp.eigencoefficients1[temp.m,]
        temp.eigencoefficients_vector2<-temp.eigencoefficients2[temp.m,]
      }
      temp.cyclic_spectrum[temp.m]<-sum(temp.eigencoefficients_vector1*Conj(temp.eigencoefficients_vector2))
      temp.CCA_spectrum[temp.m]<-total_CCA_test_statistic.function(temp.eigencoefficients_vector1,temp.eigencoefficients_vector2)
    }
    temp.cyclic_spectrum<-temp.cyclic_spectrum/2/NW.par
    temp.row_indices_list[[temp.i]]<-temp.frequency_row_indices+1
    temp.column_indices_list[[temp.i]]<-temp.frequency_column_indices+1
    temp.bifrequency_spectrum_list[[temp.i]]<-temp.cyclic_spectrum
    temp.CCA_list[[temp.i]]<-temp.CCA_spectrum
  }
  temp.all_bifrequency_spectrum<-unlist(temp.bifrequency_spectrum_list)
  temp.all_CCA_spectrum<-unlist(temp.CCA_list)
  if(plot.par==TRUE){
    temp.all_row_indices<-unlist(temp.row_indices_list)
    temp.all_column_indices<-unlist(temp.column_indices_list)
    if(length(temp.all_row_indices)>length(temp.all_column_indices)){
      temp.all_row_indices<-temp.all_row_indices[1:length(temp.all_column_indices)]
    }
    else if(length(temp.all_column_indices)>length(temp.all_row_indices)){
      temp.all_column_indices<-temp.all_column_indices[1:length(temp.all_row_indices)]
    }
    temp.x_frequencies<-frequencies.par[temp.all_column_indices]*sampling_rate.par
    temp.y_frequencies<-frequencies.par[temp.all_row_indices]*sampling_rate.par-temp.x_frequencies
    temp.x_frequencies<-temp.x_frequencies-min(temp.x_frequencies)
    temp.num_frequencies=length(temp.x_frequencies)
    temp.x_bounds<-c(min(temp.x_frequencies),max(temp.x_frequencies))
    temp.y_bounds<-c(min(temp.y_frequencies),max(temp.y_frequencies))
    temp.mod_spectrum<-Mod(temp.all_bifrequency_spectrum)
    temp.min_mod_power=formatC(min(temp.mod_spectrum),format="e",digits=2)
    temp.max_mod_power=formatC(max(temp.mod_spectrum),format="e",digits=2)
    temp.min_mutual_information=formatC(min(temp.all_CCA_spectrum),format="e",digits=2)
    temp.max_mutual_information=formatC(max(temp.all_CCA_spectrum),format="e",digits=2)
    if(!is.na(passband_cutoffs.par) & (passband_cutoffs.par[1]>0 || passband_cutoffs.par[2]<sampling_rate.par)){
      temp.x_bounds<-passband_cutoffs.par
      temp.y_bounds<-passband_cutoffs.par
      colour_scatter_plot.function(temp.x_frequencies,temp.y_frequencies,temp.mod_spectrum,
                                   plot_title.par=paste("Magnitude bifrequency density: [",temp.min_mod_power,",",temp.max_mod_power,"]",sep=""),
                                   temp.x_bounds,temp.y_bounds,
                                   ordinate_quantity.par="Frequency",measured_quantity.par=measured_quantity.par,units.par1=frequency_units.string,
                                   units.par2=measured_units.par,pdf_title.par=paste("Closeup_",pdf_title.par,sep=""),threshold_height.par=0,
                                   passband_cutoffs.par=passband_cutoffs.par,log_bool.par=TRUE)
      colour_scatter_plot.function(temp.x_frequencies,temp.y_frequencies,temp.all_CCA_spectrum,
                                   plot_title.par=paste("Mutual information: [",temp.min_mutual_information,",",temp.max_mutual_information,"]",sep=""),
                                   temp.x_bounds,temp.y_bounds,
                                   ordinate_quantity.par="Frequency",measured_quantity.par=measured_quantity.par,units.par1=frequency_units.string,
                                   units.par2=measured_units.par,pdf_title.par=paste("Closeup_CCA_",pdf_title.par,sep=""),threshold_height.par=0,
                                   passband_cutoffs.par=passband_cutoffs.par)
    }
    else{
      colour_scatter_plot.function(temp.x_frequencies,temp.y_frequencies,temp.mod_spectrum,
                                   plot_title.par=paste("Magnitude bifrequency density: [",temp.min_mod_power,",",temp.max_mod_power,"]",sep=""),
                                   temp.x_bounds,temp.y_bounds,
                                   ordinate_quantity.par="Frequency",measured_quantity.par=measured_quantity.par,units.par1=frequency_units.string,
                                   units.par2=measured_units.par,pdf_title.par=pdf_title.par,threshold_height.par=0,
                                   passband_cutoffs.par=passband_cutoffs.par,log_bool.par=TRUE)
      colour_scatter_plot.function(temp.x_frequencies,temp.y_frequencies,temp.all_CCA_spectrum,
                                   plot_title.par=paste("Mutual information: [",temp.min_mutual_information,",",temp.max_mutual_information,"]",sep=""),
                                   temp.x_bounds,temp.y_bounds,
                                   ordinate_quantity.par="Frequency",measured_quantity.par=measured_quantity.par,units.par1=frequency_units.string,
                                   units.par2=measured_units.par,pdf_title.par=paste("CCA_",pdf_title.par,sep=""),threshold_height.par=0,
                                   passband_cutoffs.par=passband_cutoffs.par)
    }
  }
  temp.list<-list(out.row_indices_list=temp.row_indices_list,
                  out.column_indices_list=temp.column_indices_list,
                  out.bifrequency_spectrum_list=temp.all_bifrequency_spectrum)
  return(temp.list)
}


multitaper_single_cyclic_correlation_entry<-function(row_index.par,column_index.par,matrix.par,cyclic_frequencies.par){
  temp.matrix_row<-matrix.par[row_index.par,column_index.par]
  temp.phases=atan2(Im(temp.matrix_row),Re(temp.matrix_row))
  temp.cosine_vector<-cos(2*pi*cyclic_frequencies.par*(row_index.par-1)+temp.phases)
  temp.cyclic_correlation<-2*sum(Mod(temp.matrix_row)*temp.cosine_vector)
  return(temp.cyclic_correlation)
}


multitaper_cyclic_correlation_sequence<-function(bifrequency_spectrum_vector.par,frequencies.par,
                                                 row_indices_vector.par,column_indices_vector.par,
                                                 spectrum_estimates.par,N.par,NW.par=5,sampling_rate.par=1,first_time.par=0,plot.par=FALSE,
                                                 measured_quantity.par="Measured value",measured_units.par="units",x_scale.par=1,y_scale.par=1,
                                                 pdf_title.par="Autocorrelation_Matrix.pdf",max_size.par=NA,verbose.par=FALSE,
                                                 selected_time_window_index.par=1){
  tic()
  temp.K=2*NW.par-1
  #Compute the different cyclic spectra.
  temp.index_differences<-row_indices_vector.par-column_indices_vector.par
  temp.cyclic_frequencies<-unique(frequencies.par[temp.index_differences+1])
  temp.cyclic_frequencies<-c(-rev(temp.cyclic_frequencies),0,temp.cyclic_frequencies)
  temp.unique_index_differences<-unique(temp.index_differences)
  temp.num_unique_diffs=length(temp.unique_index_differences)
  temp.unique_index_differences<-sort(temp.unique_index_differences)
  temp.unique_index_differences<-temp.unique_index_differences[1:temp.num_unique_diffs]
  temp.num_cyclic_spectrum_frequencies<-rep(0,temp.num_unique_diffs)
  temp.cyclic_spectra<-list()
  temp.num_cyclic_frequencies=2*temp.num_unique_diffs+1
  for(temp.i in 1:temp.num_unique_diffs){
    temp.index_diff=temp.unique_index_differences[temp.i]
    temp.cyclic_spectrum<-bifrequency_spectrum_vector.par[temp.index_differences==temp.index_diff]
    temp.num_cyclic_spectrum_frequencies[temp.i]=length(temp.cyclic_spectrum)
    temp.cyclic_spectra[[temp.i]]<-temp.cyclic_spectrum
  }
  temp.M2=max(temp.num_cyclic_spectrum_frequencies)
  temp.zero_index=temp.M2-1
  temp.M=2*(temp.M2-1)
  if(verbose.par==TRUE){
    cat("Sorting the cyclic-spectrum matrix.\n")
  }
  temp.cyclic_spectrum_matrix<-matrix(0,nrow=temp.M,ncol=temp.num_cyclic_frequencies)
  for(temp.i in 1:temp.num_unique_diffs){
    temp.cyclic_spectrum<-c()
    if(temp.i<=temp.num_unique_diffs){
      temp.cyclic_spectrum<-Conj(temp.cyclic_spectra[[temp.num_unique_diffs-temp.i+1]])
    }
    else if(temp.i==(temp.num_unique_diffs+1)){
      temp.cyclic_spectrum<-spectrum_estimates.par
    }
    else{
      temp.cyclic_spectrum<-temp.cyclic_spectra[[temp.i-temp.num_unique_diffs-1]]
    }
    temp.num_frequencies<-length(temp.cyclic_spectrum)
    temp.cyclic_spectrum_full<-c(temp.cyclic_spectrum,rep(0,temp.M2-temp.num_frequencies))
    temp.column_cyclic_spectrum<-c(rev(temp.cyclic_spectrum_full[2:temp.zero_index]),temp.cyclic_spectrum_full)
    temp.size_column_cyclic_spectrum=length(temp.column_cyclic_spectrum)
    temp.cyclic_spectrum_matrix[,temp.i]<-temp.column_cyclic_spectrum
  }
  if(!is.na(max_size.par)){
    temp.step_size_value=1
    if(max_size.par<=temp.M){
      temp.step_size_value=floor(temp.M/max_size.par)
    }
    temp.sampled_index_sequence<-seq(from=1,to=temp.M,by=temp.step_size_value)
    temp.M=length(temp.sampled_index_sequence)
    temp.M2=temp.M/2+1
    temp.cyclic_spectrum_matrix<-temp.cyclic_spectrum_matrix[temp.sampled_index_sequence,]
  }
  if(verbose.par==TRUE){
    cat("Cyclic spectra FFT:\n")
  }
  tic()
  temp.cyclic_spectrum_MT_parameter_object<-multitaper_parameters.function(temp.M,NW.par,K.par=temp.K,sampling_rate.par=sampling_rate.par,
                                                                           M_exponent.par=1,cepstral_bool.par=FALSE,verbose.par=FALSE)
  #temp.cyclic_spectrum_M<-temp.cyclic_spectrum_MT_parameter_object$out.M
  temp.cyclic_spectrum_M=temp.M
  if(verbose.par==TRUE){
    cat("M = ",temp.cyclic_spectrum_M,".\n")
    cat("Cyclic coefficients: ")
  }
  temp.cyclic_spectrum_dpss_object<-dpss.matrix(temp.M,NW.par,temp.K)
  temp.cyclic_spectrum_dpss<-temp.cyclic_spectrum_dpss_object$out.dpss
  temp.cyclic_spectrum_energy_concentrations<-temp.cyclic_spectrum_dpss_object$out.eigenvalues
  temp.cyclic_spectrum_slepian_functions<-Slepian.functions(temp.cyclic_spectrum_dpss,temp.M)
  temp.cyclic_coefficients_matrix<-matrix(0,nrow=temp.cyclic_spectrum_M,ncol=temp.num_cyclic_frequencies)
  for(temp.j in 1:temp.num_cyclic_frequencies){
    temp.ts<-(-1)*rev(temp.cyclic_spectrum_matrix[,temp.j])
    temp.eigencoefficients<-eigencoefficients(temp.ts,temp.cyclic_spectrum_dpss,temp.cyclic_spectrum_M)
    temp.cyclic_coefficients_matrix[,temp.j]<-spectral_process_reconstruction.function(temp.eigencoefficients,temp.cyclic_spectrum_slepian_functions,
                                                                                       temp.cyclic_spectrum_energy_concentrations)
    #temp.cyclic_coefficients_matrix[,temp.j]<-rowMeans(temp.eigencoefficients)
  }
  temp.cyclic_coefficients_matrix<-temp.cyclic_coefficients_matrix/temp.cyclic_spectrum_M
  toc()
  tic()
  temp.cyclic_ACVS_MT_parameter_object<-multitaper_parameters.function(temp.num_cyclic_frequencies,NW.par,K.par=temp.K,
                                                                       sampling_rate.par=1/sampling_rate.par,
                                                                       M_exponent.par=1,cepstral_bool.par=FALSE,verbose.par=FALSE)
  temp.cyclic_ACVS_M=temp.num_cyclic_frequencies
  if(verbose.par==TRUE){
    cat("M = ",temp.cyclic_ACVS_M,".\n")
    cat("Cyclic ACVS.\n")
  }
  temp.cyclic_ACVS_dpss_object<-dpss.matrix(temp.num_cyclic_frequencies,NW.par,temp.K)
  temp.cyclic_ACVS_dpss<-temp.cyclic_ACVS_dpss_object$out.dpss
  temp.cyclic_ACVS_energy_concentrations<-temp.cyclic_ACVS_dpss_object$out.eigenvalues
  temp.cyclic_ACVS_slepian_functions<-Slepian.functions(temp.cyclic_ACVS_dpss,temp.cyclic_ACVS_M)
  temp.cyclic_ACVS_matrix<-matrix(0,nrow=temp.cyclic_ACVS_M,ncol=temp.cyclic_spectrum_M)
  for(temp.j in 1:temp.cyclic_spectrum_M){
    temp.ts<-(-1)*rev(temp.cyclic_coefficients_matrix[temp.j,])
    temp.eigencoefficients<-eigencoefficients(temp.ts,temp.cyclic_ACVS_dpss,temp.cyclic_ACVS_M)
    temp.cyclic_ACVS_matrix[,temp.j]<-spectral_process_reconstruction.function(temp.eigencoefficients,temp.cyclic_ACVS_slepian_functions,
                                                                               temp.cyclic_ACVS_energy_concentrations)
  }
  temp.cyclic_ACVS_matrix<-Re(temp.cyclic_ACVS_matrix)
  temp.cyclic_ACVS_matrix<-temp.cyclic_ACVS_matrix[,temp.cyclic_spectrum_M/2+1:(temp.cyclic_spectrum_M/2+1)-1]
  toc()
  if(verbose.par==TRUE){
    cat("Cyclic-spectrum computations, total: ")
  }
  if(plot.par==TRUE){
    temp.x_units=time_units.string
    temp.first_x_units=time_units.string
    temp.num_columns=ncol(temp.cyclic_ACVS_matrix)
    cat("first_time.par = ",first_time.par,"\n")
    cat("selected_time_window_index.par = ",selected_time_window_index.par,"\n")
    cat("N.par = ",N.par,"\n")
    cat("sampling_rate.par = ",sampling_rate.par,"\n")
    temp.y_times<-(first_time.par+((selected_time_window_index.par-1)*N.par+1:temp.num_columns-1)/sampling_rate.par)
    temp.x_times<-(1:temp.cyclic_ACVS_M/2-1)/sampling_rate.par
    temp.x_bounds<-c(min(temp.x_times),max(temp.x_times))
    temp.y_bounds<-c(min(temp.y_times),max(temp.y_times))
    temp.x_indices<-1:(length(temp.x_times))#/2)#which(temp.x_times<(temp.x_bounds[2]-0.2*(temp.x_bounds[2]-temp.x_bounds[1])))
    temp.y_indices<-1:length(temp.y_times)#which(temp.y_times<(temp.y_bounds[2]-0.2*(temp.y_bounds[2]-temp.y_bounds[1])))
    temp.num_columns=length(temp.x_indices)
    temp.num_rows=length(temp.y_indices)
    temp.plotting_x_times<-temp.x_times
    temp.plotting_y_times<-temp.y_times
    temp.plotting_cyclic_ACVS_matrix<-abs(temp.cyclic_ACVS_matrix[temp.x_indices,temp.y_indices])
    temp.plotting_cyclic_ACVS_matrix[temp.plotting_cyclic_ACVS_matrix<0]<-
      10*log10(abs(temp.plotting_cyclic_ACVS_matrix[temp.plotting_cyclic_ACVS_matrix<0]))
    temp.plotting_cyclic_ACVS_matrix[temp.plotting_cyclic_ACVS_matrix>0]<-
      10*log10(abs(temp.plotting_cyclic_ACVS_matrix[temp.plotting_cyclic_ACVS_matrix>0]))
    temp.plotting_cyclic_ACVS_matrix[!temp.plotting_cyclic_ACVS_matrix]<-NA
    temp.look<-image.smooth(x=t(temp.plotting_cyclic_ACVS_matrix),theta=0.6)
    temp.x_locations<-seq(from=1,to=temp.num_columns,by=floor(temp.num_columns/10))
    temp.y_locations<-seq(from=1,to=temp.num_rows,by=floor(temp.num_rows/10))
    temp.first_plotting_time<-temp.plotting_y_times[1]
    pdf(paste(pdf_title.par),width=8,height=6)
    par(mar=c(5.1, 4.1, 4.1, 3.1))
    mgp=c(2,1,0)
    #The gray scale coding below is from https://stackoverflow.com/questions/29699796/how-to-plot-matrix-as-is-in-r-using-grayscale
    image.plot(temp.look,xlab=paste("Global time, in ",temp.x_units," beyond ",round(temp.first_plotting_time,2)," ",temp.first_x_units,sep=""),
               ylab=paste("Offset, in ",temp.x_units,sep=""),xaxt="n",yaxt="n",col=grey(seq(0,1,length=100)))
    axis(1,at=temp.y_locations,labels=round((temp.plotting_y_times[temp.y_locations]-temp.first_plotting_time)*60,2))
    axis(2,at=temp.x_locations,labels=round(temp.plotting_x_times[temp.x_locations],2))
    title(ylab="Normalized absolute autocorrelation, in dB",line=-30.5)
    dev.off()
  }
  toc()
  temp.list<-list(out.cyclic_spectrum_matrix=temp.cyclic_spectrum_matrix,
                  out.cyclic_ACVS_matrix=temp.cyclic_ACVS_matrix)
  return(temp.list)
}


cyclic_ACVS_analysis.function<-function(eigencoeffs.par,frequencies.par,cepstrum_frequency_indices.par,energy_concentrations.par,N.par,sampling_rate.par=1,
                                        measured_quantity.par="",measured_units.par="",max_size_Loeve.par=2e3,max_size_ACVF.par=1e3,first_time.par=0,
                                        plot_bool.par=FALSE,verbose_bool.par=FALSE){
  if(verbose_bool.par==TRUE){
    tic()
  }
  temp.bifrequency_object<-multitaper.cyclic_bifrequency_spectrum(eigencoeffs.par,frequencies.par,cepstrum_frequency_indices.par,energy_concentrations.par,
                                                                  measured_quantity.par=measured_quantity.par,measured_units.par=measured_units.par,
                                                                  sampling_rate.par=sampling_rate.par,max_size.par=max_size_Loeve.par)
  temp.row_indices_list<-temp.bifrequency_object$out.row_indices_list
  temp.row_indices_vector<-unlist(temp.row_indices_list)
  temp.column_indices_list<-temp.bifrequency_object$out.column_indices_list
  temp.column_indices_vector<-unlist(temp.column_indices_list)
  temp.bifrequency_spectrum_list<-temp.bifrequency_object$out.bifrequency_spectrum_list
  temp.bifrequency_spectrum_vector<-unlist(temp.bifrequency_spectrum_list)
  #Covariance matrix.
  temp.cyclic_correlation_object<-multitaper_cyclic_correlation_sequence(bifrequency_spectrum_vector.par=temp.bifrequency_spectrum_vector,
                                                                         frequencies.par=frequencies.par,row_indices_vector.par=temp.row_indices_vector,
                                                                         column_indices_vector.par=temp.column_indices_vector,
                                                                         spectrum_estimates.par=spectral_power.estimates,N.par=N.par,NW.par=NW.par,
                                                                         plot.par=plot_bool.par,measured_quantity.par="Autocorrelation",
                                                                         measured_units.par="correlation units",
                                                                         sampling_rate.par=sampling_rate.par,first_time.par=first_time.par,
                                                                         pdf_title.par="Autocorrelation_Matrix.pdf",max_size.par=max_size_ACVF.par,
                                                                         verbose.par=verbose_bool.par)
  temp.cyclic_spectrum_matrix<-temp.cyclic_correlation_object$out.cyclic_spectrum_matrix
  temp.cyclic_ACVS_matrix<-temp.cyclic_correlation_object$out.cyclic_ACVS_matrix
  if(verbose_bool.par==TRUE){
    cat("Total time to compute ACVS: ")
    toc()
  }
  temp.list<-list(out.cyclic_spectrum_matrix=temp.cyclic_spectrum_matrix,
                  out.cyclic_ACVS_matrix=temp.cyclic_ACVS_matrix)
  return(temp.list)
}


cyclostationary_analysis.function<-function(eigencoeffs.par,energy_concentrations.par,extracted_frequency_indices.par=NA,N.par,sampling_rate.par=1,
                                            max_size_Loeve.par=2e3,max_size_ACVF.par=1e3,first_time.par=0,
                                            measured_quantity.par="",measured_units.par="",
                                            bifrequency_plot_bool.par=FALSE,cyclic_ACVS_plot_bool.par=FALSE,frequencies.par,band_frequency_first.par,
                                            cutoff.par,old_directory.par=""){
  temp.directory_string<-"Cyclostationary_Analysis"
  dir.create(temp.directory_string,showWarnings=FALSE)
  temp.working_directory_string<-paste(old_directory.par,"/",temp.directory_string,"/",sep="")
  setwd(temp.working_directory_string)
  temp.M=nrow(eigencoeffs.par)
  temp.M2=temp.M/2+1
  #Compute and plot the bifrequency spectrum.
  if(is.na(extracted_frequency_indices.par)==TRUE){
    extracted_frequency_indices.par<-1:temp.M2
  }
  temp.bifrequency_object<-multitaper.cyclic_bifrequency_spectrum(eigencoeffs.par,frequencies.par,extracted_frequency_indices.par,
                                                                  energy_concentrations.par,
                                                                  plot.par=bifrequency_plot_bool.par,measured_quantity.par=measured_quantity.par,
                                                                  measured_units.par=measured_units.par,sampling_rate.par=sampling_rate.par,
                                                                  pdf_title.par="Loeve_Bifrequency_Spectrum.pdf",max_size.par=max_size_Loeve.par)
  if(band_frequency_first.par>0 || cutoff.par<sampling_rate.par){
    #Plot the bifrequency spectrum zoomed in for the relevant passband.
    temp.bifrequency_object<-multitaper.cyclic_bifrequency_spectrum(eigencoeffs.par,frequencies.par,extracted_frequency_indices.par,
                                                                    energy_concentrations.par,
                                                                    plot.par=bifrequency_plot_bool.par,measured_quantity.par=measured_quantity.par,
                                                                    measured_units.par=measured_units.par,sampling_rate.par=sampling_rate.par,
                                                                    pdf_title.par="Loeve_Bifrequency_Spectrum.pdf",
                                                                    passband_cutoffs.par=c(band_frequency_first.par,cutoff.par),
                                                                    max_size.par=max_size_Loeve.par)
  }
  #Compute the ACVS map with appropriate, user-specified downsampling to make the computations manageable.
  #The ACVS map plots the ACVS sequences assuming that only a subselection of the cyclic spectra contribute.
  temp.cyclic_ACVS_object<-cyclic_ACVS_analysis.function(eigencoeffs.par,frequencies.par,extracted_frequency_indices.par,energy_concentrations.par,
                                                         N.par=N.par,sampling_rate.par,
                                                         measured_quantity.par=measured_quantity.par,measured_units.par=measured_units.par,
                                                         max_size_Loeve.par=max_size_Loeve.par,max_size_ACVF.par=max_size_ACVF.par,
                                                         first_time.par=first_time.par,
                                                         plot_bool.par=cyclic_ACVS_plot_bool.par,verbose_bool.par=TRUE)
  temp.cyclic_ACVS_matrix<-temp.cyclic_ACVS_object$out.cyclic_ACVS_matrix
  setwd(old_directory.par)
  return(temp.cyclic_ACVS_matrix)
}


#Use this estimator if the spectrum is locally white.  The most basic adaptive weighting is used.
multitaper.weighted_spectrum<-function(eigenspectra.par,concentrations.par){
  temp.K=ncol(eigenspectra.par)
  for(k in 1:temp.K){
    eigenspectra.par[,k]<-concentrations.par[k]*eigenspectra.par[,k]
  }
  temp.spectrum<-rowSums(eigenspectra.par)
  temp.spectrum<-temp.spectrum/sum(concentrations.par)
  return(temp.spectrum)
}

#Most simple approximation, only useful for exploratory analysis.
multitaper.average_spectrum<-function(eigenspectra.par){
  temp.means<-rep(0,nrow(eigenspectra.par))
  if(ncol(eigenspectra.par)>1){
    temp.means<-rowMeans(eigenspectra.par)
  }
  else{
    temp.means=eigenspectra.par[,1]
  }
  return(temp.means)
}

log_spectrum.bias<-function(dof.par){
  temp.m=dof.par/2
  temp.bias=digamma(temp.m)-log(temp.m)
  return(temp.bias)
}

multitaper_ACVS.function<-function(spectral_powers.par,NW.par,sampling_rate.par=1){
  temp.K=2*NW.par-1
  temp.M2=length(spectral_powers.par)
  #cat("temp.M2=",temp.M2,"\n")
  temp.zero_index=temp.M2-1
  temp.M=2*(temp.M2-1)
  temp.cyclic_ACVS_MT_parameter_object<-multitaper_parameters.function(temp.M,NW.par,K.par=temp.K,
                                                                       sampling_rate.par=1/sampling_rate.par,
                                                                       M_exponent.par=1,cepstral_bool.par=FALSE,verbose.par=FALSE)
  temp.ACVS_M=temp.cyclic_ACVS_MT_parameter_object$out.M
  temp.cyclic_ACVS_dpss_object<-dpss.matrix(temp.M,NW.par,temp.K)
  temp.cyclic_ACVS_dpss<-temp.cyclic_ACVS_dpss_object$out.dpss
  temp.energy_concentrations<-temp.cyclic_ACVS_dpss_object$out.eigenvalues
  temp.fft<-c(spectral_powers.par,rev(spectral_powers.par[2:temp.zero_index]))
  temp.ts<-rev(temp.fft)
  temp.eigencoefficients<-eigencoefficients(temp.ts,temp.cyclic_ACVS_dpss,temp.ACVS_M)/temp.ACVS_M
  temp.ACVS<-spectral_process_reconstruction.function(temp.eigencoefficients,temp.cyclic_ACVS_dpss,temp.energy_concentrations)
  #temp.ACVS<-rowMeans(temp.eigencoefficients)
  temp.ACVS<-Re(temp.ACVS)
  return(temp.ACVS)
}


impropriety_analysis.function<-function(eigencoefficients.par,frequencies.par,energy_concentrations.par,N_samples.par,sampling_rate.par=1,
                                        abscissa_measurement.par="",abscissa_units.par="",plot_bool.par=FALSE,
                                        percentiles.par=c(0.1,0.25,0.5,0.75,0.9)){
  temp.percentiles<-c(percentiles.par,1-1/N_samples.par)
  temp.num_percentiles=length(temp.percentiles)
  temp.M=nrow(eigencoefficients.par)
  temp.K=ncol(eigencoefficients.par)
  temp.zero_index=temp.M/2
  temp.M2=temp.zero_index+1
  temp.normalized_eigencoefficients<-eigencoefficients.par
  for(temp.k in 1:temp.K){
    temp.normalized_eigencoefficients[,temp.k]<-temp.normalized_eigencoefficients[,temp.k]/energy_concentrations.par[temp.k]
  }
  temp.normalized_eigencoefficients<-temp.normalized_eigencoefficients[temp.zero_index+1:temp.M2-1,]
  temp.CCA_spectrum<-rep(0,temp.M2)
  for(temp.m in 1:temp.M2){
    temp.eigencoefficients_vector<-c()
    if(!is.matrix(temp.normalized_eigencoefficients)){
      temp.eigencoefficients_vector<-temp.normalized_eigencoefficients
    }
    else{
      temp.eigencoefficients_vector<-temp.normalized_eigencoefficients[temp.m,]
    }
    temp.CCA_spectrum[temp.m]=rotational_univariate_correlation_test_statistic.function(temp.eigencoefficients_vector,Conj(temp.eigencoefficients_vector))
  }
  temp.CCA_spectrum[is.infinite(temp.CCA_spectrum)==TRUE]<-1e-12
  if(plot_bool.par==TRUE){
    plot.graph(list((frequencies.par*sampling_rate.par)),list((temp.CCA_spectrum*100)),pdf_title.par="Impropriety_Statistic_Spectrum.pdf",
               x_label.par=paste(abscissa_measurement.par,", in ",abscissa_units.par,sep=""),y_label.par="Sphericity statistic")
  }
  sink("Impropriety_Tests_Summary_Statistics.txt", append=FALSE, split=FALSE)
  cat("percentage_point\tcrossings_fraction\n")
  for(temp.i in 1:temp.num_percentiles){
    temp.num_crossings=length(which(temp.CCA_spectrum>=temp.percentiles[temp.i]))
    cat(round(temp.percentiles[temp.i]*100,ceil(-log10(1-temp.percentiles[temp.i]))),"\t",
        round(temp.num_crossings/temp.M2*100,ceil(-log10(1-temp.num_crossings/temp.M2))),"\n")
  }
  sink()
  temp.list<-list(out.CCA_spectrum=temp.CCA_spectrum)
  return(temp.list)
}













