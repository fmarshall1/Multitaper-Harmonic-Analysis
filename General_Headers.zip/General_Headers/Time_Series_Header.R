#Francois Marshall, Boston University
#Header file for time-series analysis.
###################################################################################################################

###################################################################################################################
#Define some global variables.
starting.directory<<-paste(main_directory.string,"General_Headers/",sep="")

###################################################################################################################
#Load basic source files.
source(paste(starting.directory,"Library_Upload_Header.R",sep=""))
source(paste(starting.directory,"Result_Presentation_Header.R",sep=""))
source(paste(starting.directory,"Directory_Header.R",sep=""))
source(paste(starting.directory,"Graphics_Header.R",sep=""))
source(paste(starting.directory,"Linear_Algebra_Header.R",sep=""))
source(paste(starting.directory,"Statistics_Header.R",sep=""))
source(paste(starting.directory,"RNG.R",sep=""))
source(paste(starting.directory,"Numerical_Methods.R",sep=""))
source(paste(starting.directory,"Multitaper_Header.R",sep=""))
source(paste(starting.directory,"ARMA_Modelling_Header.R",sep=""))
source(paste(starting.directory,"Cyclostationary_Modelling_Header.R",sep=""))
source(paste(starting.directory,"Interpolation.R",sep=""))
source(paste(starting.directory,"Neuroscience_Header.R",sep=""))


###################################################################################################################
#Basic time-series input and plotting.

TS_data_upload_text.function<-function(file_name.par="",ts_parameters_file.par="",time_window_index.par=1,record_size.par=NA,x_measurement.par="Time",
                                       y_measurement.par="Measured quantity",time_units.par="units",y_units.par="units",pdf_title.par="Time_series.pdf",
                                       x_scale.par=1,y_scale.par=1,plot.par=FALSE,num_plotting.par=0,header.par=FALSE,
                                       abbreviated_time_units_string.par=NA){
  print(paste(main_directory.string,source.directory,file_name.par,sep=""))
  if(is.na(abbreviated_time_units_string.par)==TRUE){
    abbreviated_time_units_string.par=time_units.par
  }
  temp.file_object<-read.table(paste(main_directory.string,source.directory,file_name.par,sep=""),header=header.par)
  temp.time_sequence<-c()
  temp.voltage_series<-c()
  temp.first_time=0
  temp.N_samples=0
  if(ts_parameters_file.par!=""){
    #Read in the start time.
    temp.first_time_file_object<-read.table(paste(main_directory.string,source.directory,ts_parameters_file.par,sep=""),header=FALSE)
    temp.column<-temp.first_time_file_object[[1]]
    temp.first_time=temp.column[1]
    temp.sampling_rate=temp.column[2]
    temp.voltage_series<-temp.file_object[[1]]
    temp.N_samples=length(temp.voltage_series)
    temp.time_sequence<-temp.first_time+(1:temp.N_samples-1)/temp.sampling_rate
  }
  else if(length(temp.file_object)>2){
    temp.time_sequence<-temp.file_object[[2]]
    temp.first_time=temp.time_sequence[1]
    temp.sampling_rate=1/(temp.time_sequence[2]-temp.time_sequence[1])
    temp.voltage_series<-temp.file_object[[3]]
    temp.N_samples=length(temp.voltage_series)
  }
  else if(length(temp.file_object)>1){
    temp.time_sequence<-temp.file_object[[1]]
    temp.sampling_rate=1/(temp.time_sequence[2]-temp.time_sequence[1])
    temp.voltage_series<-temp.file_object[[2]]
    temp.N_samples=length(temp.voltage_series)
  }
  if(is.na(record_size.par)==TRUE){
    record_size.par=temp.N_samples
  }
  temp.truncated_times<-c()
  temp.truncated_voltages<-c()
  if(!num_plotting.par){
    num_plotting.par=temp.N_samples
  }
  temp.sampled_times<-plotting.sampled_vector(temp.time_sequence,num_samples.par=num_plotting.par)
  temp.sampled_voltages<-plotting.sampled_vector(temp.voltage_series,num_samples.par=num_plotting.par)
  temp.record_size=0
  if(record_size.par!=temp.N_samples){
    temp.sampled_times<-temp.time_sequence
    temp.sampled_voltages<-temp.voltage_series
    temp.record_size=record_size.par
  }
  if(plot.par==TRUE){
    temp.plot_object<-plot_ts.function(temp.sampled_times,temp.sampled_voltages,time_window_index.par=time_window_index.par,
                                       record_size.par=temp.record_size,
                                       x_measurement.par=x_measurement.par,y_measurement.par=y_measurement.par,time_units.par=time_units.par,
                                       y_units.par=y_units.par,pdf_title.par=pdf_title.par,x_scale.par=x_scale.par,y_scale.par=y_scale.par,
                                       first_x_units.par=abbreviated_time_units_string.par)
    temp.truncated_times<-temp.plot_object$out.truncated_times
    temp.truncated_voltages<-temp.plot_object$out.truncated_voltage_series
  }
  else{
    temp.record_size=record_size.par
    if(!temp.record_size){
      temp.record_size=length(temp.sampled_voltages)
    }
    temp.time_indices<-(time_window_index.par-1)*temp.record_size+1:temp.record_size
    temp.truncated_times<-temp.sampled_times[temp.time_indices]
    temp.truncated_voltages<-temp.sampled_voltages[temp.time_indices]
  }
  temp.sampling_period=1/temp.sampling_rate
  temp.list<-list(out.voltage_series=temp.voltage_series,
                  out.time_sequence=temp.time_sequence,
                  out.truncated_times=temp.truncated_times,
                  out.truncated_voltages=temp.truncated_voltages,
                  out.N_samples=temp.N_samples,
                  out.sampling_rate=temp.sampling_rate,
                  out.sampling_period=temp.sampling_period,
                  out.first_time=temp.first_time)
  return(temp.list)
}


TS_data_upload_text_decimation.function<-function(file_name.par,ts_parameters_file.par="",
                                                  time_window_index.par=1,
                                                  record_size.par=0,x_measurement.par=measured_abscissa.string,
                                                  y_measurement.par=measure_quantity.string,
                                                  time_units.par=time_units.string,y_units.par=measure_units.string,
                                                  pdf_title.par="Time_series.pdf",
                                                  x_scale.par=plotting.time_scale,y_scale.par=1,plot.par=TRUE,
                                                  num_plotting.par=0,
                                                  working_directory_string.par="",
                                                  header.par=header.bool,output_bool.par=TRUE,
                                                  step_size.par=1){
  if(plot.par==TRUE || output_bool.par==TRUE){
    dir.create("Decimation",showWarnings=FALSE)
    setwd("Decimation")
  }
  #Read in the time-series data.
  temp.TS_data_upload_text_object<-TS_data_upload_text.function(file_name.par=file_name.par,
                                                                ts_parameters_file.par=ts_parameters_file.par,time_window_index.par=time_window_index.par,
                                                                record_size.par=record_size.par,x_measurement.par=x_measurement.par,
                                                                y_measurement.par=y_measurement.par,
                                                                time_units.par=time_units.par,y_units.par=y_units.par,
                                                                pdf_title.par=pdf_title.par,
                                                                x_scale.par=x_scale.par,y_scale.par=y_scale.par,plot.par=plot.par,
                                                                num_plotting.par=num_plotting.par,header.par=header.bool)
  temp.ts<-temp.TS_data_upload_text_object$out.truncated_voltages
  temp.time_sequence<-temp.TS_data_upload_text_object$out.truncated_times
  temp.sampling_rate=temp.TS_data_upload_text_object$out.sampling_rate
  temp.sampling_period=1/temp.sampling_rate
  temp.N=length(temp.ts)
  if(output_bool.par==TRUE){
    sink("Basic_Time_Series_Parameters.txt", append=FALSE, split=FALSE)
    cat("Raw data statistics:\n")
    cat("The record size is N = ",temp.N,"\n")
    cat("The sampling rate is f_{Nyquist} = ",paste(round_general.function(temp.sampling_rate),sep=""),frequency_units.string,"\n")
    cat("The sampling period is Delta t = ",paste(round_general.function(temp.sampling_period),sep=""),"min\n\n\n")
    sink()
  }
  setwd(working_directory_string.par)
  if(step_size.par>1){
    dir.create("Decimation",showWarnings=FALSE)
    setwd("Decimation")
    temp.quick_decimation_object<-quick_decimation.function(times.par=temp.time_sequence,ts.par=temp.ts,step_size.par=step_size.par,plot_bool.par=TRUE)
    temp.time_sequence<-temp.quick_decimation_object$out.decimated_times
    temp.ts<-temp.quick_decimation_object$out.decimation_ts
    temp.N=length(temp.ts)
    temp.sampling_period=temp.time_sequence[2]-temp.time_sequence[1]
    temp.sampling_rate=1/temp.sampling_period
    if(output_bool.par==TRUE){
      sink("Time_Series_Decimation_Parameters.txt", append=FALSE, split=FALSE)
      cat("Decimated data statistics:\n")
      cat("The new record size is N = ",temp.N,"\n")
      cat("The new sampling rate is f_{Nyquist} = ",paste(round_general.function(temp.sampling_rate),sep=""),frequency_units.string,"\n")
      cat("The new sampling period is Delta t = ",paste(round_general.function(temp.sampling_period*x_scale.par),sep="")," ",time_units.par,"\n")
      sink()
    }
    setwd(working_directory_string.par) 
  }
  temp.list<-list(out.times=temp.time_sequence,
                  out.ts=temp.ts,
                  out.N=temp.N,
                  out.sampling_period=temp.sampling_period,
                  out.sampling_rate=temp.sampling_rate)
  return(temp.list)
}

TS_data_upload_csv.function<-function(file_name.par="",column_index.par=1,time_window_index.par=1,sampling_period.par=1,
                                      record_size.par=0,x_measurement.par="Time",y_measurement.par="Voltage",time_units.par="units",
                                      y_units.par="units",pdf_title.par="Time series",x_scale.par=1,y_scale.par=1,plot.par=FALSE,
                                      verbose.par=TRUE,num_plotting.par=0){
  if(verbose.par==TRUE){
    cat("Read CSV: ")
    tic()
  }
  temp.csv_file_object<-read.csv(paste(main_directory.string,source.directory,"1_Data/Datasets/",file_name.par,sep=""))
  voltage_series.par<-temp.csv_file_object[[column_index.par]]
  temp.N_samples=length(voltage_series.par)
  if(!num_plotting.par){
    num_plotting.par=temp.N_samples
  }
  temp.time_sequence<-first.time+(1:temp.N_samples-1)*sampling_period.par
  temp.sampled_times<-plotting.sampled_vector(temp.time_sequence,num_samples.par=num_plotting.par)
  temp.sampled_voltages<-plotting.sampled_vector(voltage_series.par,num_samples.par=num_plotting.par)
  if(plot.par==TRUE){
    temp.plot_object<-plot_ts.function(temp.sampled_times,temp.sampled_voltages,time_window_index.par=time_window_index.par,
                                       record_size.par=record_size.par,x_measurement.par=x_measurement.par,
                                       y_measurement.par=y_measurement.par,time_units.par=time_units.par,y_units.par=y_units.par,
                                       pdf_title.par=pdf_title.par,x_scale.par=x_scale.par,y_scale.par=y_scale.par)
    temp.truncated_times<-temp.plot_object$out.truncated_times
    temp.truncated_voltages<-temp.plot_object$out.truncated_voltage_series
  }
  else{
    temp.record_size=record_size.par
    if(!temp.record_size){
      temp.record_size=length(ts.par)
    }
    temp.time_indices<-(time_window_index.par-1)*temp.record_size+1:temp.record_size
    temp.truncated_times<-temp.time_sequence[temp.time_indices]
    temp.truncated_voltage_series<-voltage_series.par[temp.time_indices]
  }
  if(verbose.par==TRUE){
    toc()
  }
  temp.list<-list(out.voltage_series=voltage_series.par,
                  out.time_sequence=temp.time_sequence,
                  out.truncated_times=temp.truncated_times,
                  out.truncated_voltages=temp.truncated_voltages,
                  out.N_samples=temp.N_samples)
  return(temp.list)
}


plot_ts.function<-function(times.par,ts.par,time_window_index.par=1,record_size.par=0,x_measurement.par="Time",y_measurement.par="State",
                           time_units.par="seconds",y_units.par="state units",pdf_title.par="",x_scale.par=NA,y_scale.par=1,
                           first_x_units.par="minutes"){
    temp.x_units=time_units.par
    temp.first_x_units=first_x_units.par
  temp.record_size=record_size.par
  if(!temp.record_size){
    temp.record_size=length(ts.par)
  }
  temp.time_indices<-(time_window_index.par-1)*temp.record_size+1:temp.record_size
  temp.truncated_times<-times.par[temp.time_indices]
  temp.truncated_voltage_series<-ts.par[temp.time_indices]
  temp.plotting_truncated_times<-list()
  temp.first_plotting_time=round_general.function(temp.truncated_times[1]*plotting.time_scale)
  temp.plotting_truncated_times[[1]]<-((temp.truncated_times)*x_scale.par-temp.truncated_times[1]*x_scale.par)
  temp.plotting_truncated_voltages<-list()
  temp.plotting_truncated_voltages[[1]]<-temp.truncated_voltage_series*y_scale.par
  plot.graph(temp.plotting_truncated_times,temp.plotting_truncated_voltages,x_label.par=paste(x_measurement.par,", in ",temp.x_units," beyond ",
                                                                                              temp.first_plotting_time," ",first_time_units.string,sep=""),
             y_label.par=paste(y_measurement.par,", in ",y_units.par,sep=""),pdf_title.par=pdf_title.par)
  temp.list<-list(out.truncated_times=temp.truncated_times,
                  out.truncated_voltage_series=temp.truncated_voltage_series)
  return(temp.list)
}

plot_series_epochs.function<-function(time_sequence.par,voltage_series.par,epoch_start_times.par,epoch_end_times.par,epoch_strings.par,
                                      N.par,num_series.par,measured_abscissa.par="Measured value",measured_value.par="Measured value",
                                      abscissa_units.par="seconds",ordinate_units.par="state units",num_plotting.par=0,x_scale.par=NA,y_scale.par=1,
                                      first_x_units.par="minutes"){
  #Initialize the scale factors.
  temp.reciprocal_scale=1/x_scale.par
  if(is.na(x_scale.par)==TRUE){
    temp.reciprocal_scale=60
    x_scale.par=1/temp.reciprocal_scale
  }
  temp.x_units=abscissa_units.par
  temp.first_x_units=first_x_units.par
  if(temp.reciprocal_scale!=60){
    temp.x_units="time units"
    temp.first_x_units="base-time units"
  }
  temp.num_epochs=length(epoch_start_times.par)
  temp.epoch_intervals<-matrix(0,nrow=temp.num_epochs,ncol=2)
  for(temp.i in 1:temp.num_epochs){
    temp.epoch_intervals[temp.i,]<-c(epoch_start_times.par[temp.i],epoch_end_times.par[temp.i])
  }
  temp.section_times_list<-list()
  temp.section_ts_list<-list()
  for(temp.j in 1:num_series.par){
    temp.times<-time_sequence.par[(temp.j-1)*N.par+1:N.par]
    temp.first_plotting_time=round(temp.times[1],3)
    temp.times<-(temp.times-temp.first_plotting_time)*temp.reciprocal_scale
    temp.voltage_series<-voltage_series.par[(temp.j-1)*N.par+1:N.par]
    temp.sampled_times<-plotting.sampled_vector(temp.times,num_samples.par=num_plotting.par)
    temp.sampled_voltages<-plotting.sampled_vector(temp.voltage_series,num_samples.par=num_plotting.par)
    #Plot the pre-recruitment window, where the term for the time window in question is based on the slideshow.
    if(temp.j==1){
      pdf(paste(measured_value.par,"_Series_Raw_Sections.pdf"),width=8,height=6)
    }
    temp.x_plotting<-temp.sampled_times
    temp.lower_x=min(temp.x_plotting)
    temp.upper_x=max(temp.x_plotting)
    temp.y_plotting<-temp.sampled_voltages
    temp.lower_y=min(temp.y_plotting)
    temp.upper_y=max(temp.y_plotting)
    par(mgp=c(2,1,0))
    temp.plot_title<-c()
    for(temp.i in 1:temp.num_epochs){
      if(temp.lower_x>=temp.epoch_intervals[temp.i,1] & temp.upper_x<=temp.epoch_intervals[temp.i,1]){
        temp.plot_title<-epoch_strings.par[temp.i]
      }
    }
    plot(0,0,xlab=paste(measured_abscissa.par,", in ",temp.x_units," beyond ",temp.first_plotting_time," ",
                        temp.first_x_units,sep=""),ylab=paste(measured_value.par,", in ",ordinate_units.par,sep=""),
         main=temp.plot_title,xlim=c(temp.lower_x,temp.upper_x),ylim=c(temp.lower_y,temp.upper_y),pch=".",lab=c(10,10,7))
    grid()
    minor.tick(10,10)
    lines(temp.x_plotting,temp.y_plotting)
    temp.section_times_list[[temp.j]]<-temp.x_plotting
    temp.section_ts_list[[temp.j]]<-temp.y_plotting
  }
  dev.off()
  temp.list<-list(out.section_times_list=temp.section_times_list,
                  out.section_ts_list=temp.section_ts_list)
  return(temp.list)
}


plot_ts_data_and_reconstruction_overlay.function<-function(times_list.par,ts_list.par,reconstruction_times_list.par,reconstructed_ts_list.par,
                                                           all_bounds.par,x_measurement.par="Time",y_measurement.par="State",time_units.par="time units",
                                                           y_units.par="state units",titles_sequence.par=NA,pdf_title.par="Overlay_TS_Reconstruction",
                                                           x_scale.par=1,y_scale.par=1){
  temp.num_list_elements=length(times_list.par)
  if(is.na(titles_sequence.par)==TRUE){
    titles_sequence.par=rep("",temp.num_list_elements)
  }
  temp.x_units=time_units.par
  temp.first_x_units=y_units.par
  temp.first_plotting_time=round(times_list.par[[1]][1]*x_scale.par,3)
  temp.first_reconstruction_plotting_time=round(reconstruction_times_list.par[[1]][1]*x_scale.par,3)
  temp.first_plotting_time=min(temp.first_plotting_time,temp.first_reconstruction_plotting_time)
  temp.plotting_truncated_times_list<-list()
  temp.plotting_reconstruction_times_list<-list()
  for(temp.i in 1:temp.num_list_elements){
    temp.truncated_times<-times_list.par[[temp.i]]
    temp.plotting_truncated_times_list[[temp.i]]<-((temp.truncated_times)*x_scale.par-temp.first_plotting_time)*60
    temp.truncated_times<-reconstruction_times_list.par[[temp.i]]
    temp.ts<-reconstructed_ts_list.par[[temp.i]]
    temp.plotting_reconstruction_times_list[[temp.i]]<-((temp.truncated_times)*x_scale.par-temp.first_plotting_time)*60
  }
  multipage_plot_comparison.function(temp.plotting_truncated_times_list,ts_list.par,temp.plotting_reconstruction_times_list,reconstructed_ts_list.par,
                                     all_bounds.par,paste(x_measurement.par,", in ",temp.x_units," beyond ",temp.first_plotting_time," ",
                                                           temp.first_x_units,sep=""),
                                     paste(y_measurement.par,", in ",y_units.par,sep=""),title_strings.par=titles_sequence.par,
                                     pdf_title.par=pdf_title.par)
  temp.list<-list(out.truncated_times=temp.plotting_truncated_times_list,
                  out.truncated_voltage_series=ts_list.par)
  return(temp.list)
}








###################################################################################################################
#Autocorrelation functions.

unbiased.ACVF<-function(ts1.par,ts2.par,tau.par){
  temp.N=length(ts1.par)
  return(inner.product(ts1.par,ts2.par,tau.par)/(temp.N-tau.par))
}

unbiased.ACF<-function(ts1.par,ts2.par,tau.par){
  numerator.product<-unbiased.ACVF(ts1.par,ts2.par,tau.par)
  temp.N=length(ts1.par)
  temp.series1<-as.matrix(ts1.par[1:(temp.N-tau.par)])
  temp.series2<-as.matrix(ts2.par[(tau.par+1):temp.N])
  denominator.acvf<-sqrt(unbiased.ACVF(temp.series1,temp.series1,0)*unbiased.ACVF(temp.series2,temp.series2,0))
  return(numerator.product/denominator.acvf)
}

Bartlett.ACVF<-function(ts1.par,ts2.par,tau.par){
  temp.N=length(ts1.par)
  return(inner.product(ts1.par,ts2.par,tau.par)/temp.N)
}

Bartlett.ACF<-function(ts1.par,ts2.par,tau.par){
  numerator.product<-Bartlett.ACVF(ts1.par,ts2.par,tau.par)
  temp.N=length(ts1.par)
  temp.series1<-ts1.par[1:(temp.N-tau.par)]
  temp.series2<-ts2.par[(tau.par+1):temp.N]
  denominator.acvf<-sqrt(unbiased.ACVF(temp.series1,temp.series1,0)*unbiased.ACVF(temp.series2,temp.series2,0))
  return(numerator.product/denominator.acvf)
}

Toeplitz.autocovariance_matrix<-function(acvs.par){
  temp.n=length(acvs.par)
  temp.autocovariance_matrix<-matrix(0,nrow=temp.n,ncol=temp.n)
  temp.indices<-1:temp.n
  for(k in 1:temp.n){
    cat(k," out of ",temp.n,"\n")
    temp.lags<-abs(temp.indices[k]-temp.indices)+1
    temp.autocovariance_matrix[,k]<-acvs.par[temp.lags]
  }
  return(temp.autocovariance_matrix)
}








###################################################################################################################
#Interpolation.
source(paste(starting.directory,"Interpolation.R",sep=""))
source(paste(starting.directory,"Outliers.R",sep=""))


###################################################################################################################
#Filtering.
filter_single_point.function<-function(index.par,ts.par,filter.par,symmetric_bool.par=TRUE){
  temp.N=length(ts.par)
  temp.filter_size=length(filter.par)
  if(symmetric_bool.par==TRUE){
    temp.half_filter_size=(temp.filter_size-1)/2
    temp.first_index=max(1,index.par-temp.half_filter_size)
    temp.last_index=min(index.par+temp.half_filter_size,temp.N)
    temp.filter_first_index<-temp.half_filter_size+1-(index.par-temp.first_index)
    temp.filter_last_index<-temp.half_filter_size+1+(temp.last_index-index.par)
  }
  else{
    temp.first_index=max(1,index.par-temp.filter_size)
    temp.last_index=index.par
    temp.filter_first_index=1
    temp.filter_last_index=temp.filter_size
  }
  temp.ts_indices<-temp.first_index:temp.last_index
  temp.filter_indices<-temp.filter_first_index:temp.filter_last_index
  temp.filtered_value<-sum(ts.par[temp.ts_indices]*filter.par[temp.filter_indices])
  return(temp.filtered_value)
}

filter.function<-function(ts.par,filter.par,times.par=NA,step_size.par=1,symmetric_bool.par=TRUE){
  temp.N=length(ts.par)
  temp.filter_size=length(filter.par)
  temp.half_filter_size=(temp.filter_size-1)/2
  temp.first_index=0
  temp.last_index=0
  if(!symmetric_bool.par){
    temp.first_index=temp.filter_size+1
    temp.last_index=temp.N-temp.filter_size
  }
  else{
    temp.first_index=temp.half_filter_size+1
    temp.last_index=temp.N-temp.half_filter_size
  }
  temp.last_index=max(temp.first_index+1,temp.last_index)
  temp.indices<-seq(from=temp.first_index,to=temp.last_index,by=step_size.par)
  temp.filtered_ts<-sapply(temp.indices,filter_single_point.function,ts.par,filter.par,symmetric_bool.par)
  temp.list<-list(out.decimated_ts=temp.filtered_ts)
  temp.times<-c()
  if(!is.na(times.par)){
    temp.times<-times.par[temp.indices]
    temp.list<-list(out.filtered_ts=temp.filtered_ts,
                    out.times=temp.times,
                    out.indices=temp.indices)
  }
  return(temp.list)
}


filter_diagnostics.function<-function(frequencies.par,PTF.par,cutoff.par,filter_size.par,sampling_rate.par=1,filter_type_string.par="",
                                      abscissa_quantity.par="",abscissa_units.par="",plot_bool.par=FALSE,output_bool.par=FALSE){
  temp.M2=length(frequencies.par)
  temp.PTF_frequencies<-frequencies.par*sampling_rate.par
  #Determine the decay rate and principal-sidelobe characteristics.
  temp.Rsq=0
  temp.KS_percentile=0
  temp.TPT_percentile=0
  temp.decay_rate=0
  temp.ise_value=0
  temp.peak_sidelobe_frequency=0
  temp.peak_sidelobe_PTF_value=0
  temp.cutoff_value=0
  temp.filtered_max_stopband_power=0
  temp.fitting_frequencies<-frequencies.par[2:temp.M2]
  if(length(temp.PTF_frequencies[temp.PTF_frequencies>0])>0){
    temp.decimation_filter_object<-decimation_filter_diagnostics.function(temp.PTF_frequencies,PTF.par,cutoff.par,sampling_rate.par)
    #Diagnostic statistics for the linear fit.
    temp.Rsq=temp.decimation_filter_object$out.Rsq
    temp.KS_percentile=temp.decimation_filter_object$out.KS_percentile
    temp.TPT_percentile=temp.decimation_filter_object$out.TPT_percentile
    #Features extracted from the linear fit.
    temp.decay_rate=temp.decimation_filter_object$out.decay_rate
    temp.peak_sidelobe_frequency=temp.decimation_filter_object$out.peak_sidelobe_frequency
    temp.peak_sidelobe_PTF_value=temp.decimation_filter_object$out.maximum
    temp.cutoff_value=cutoff.par*sampling_rate.par
    temp.ise_value=temp.decimation_filter_object$out.ise
    temp.fitting_frequencies<-temp.decimation_filter_object$out.log_frequencies+10*log10(sampling_rate.par)
    temp.fitted_values<-temp.decimation_filter_object$out.fitted_values
    #Basic cleaning.
    temp.fitted_values[is.na(temp.fitted_values)==TRUE]<-0
    temp.fitted_values[is.nan(temp.fitted_values)==TRUE]<-0
    temp.fitted_values[is.infinite(temp.fitted_values)==TRUE]<-0
  }
  if(output_bool.par==TRUE){
    sink(paste("Filter_Diagnostics_",filter_type_string.par,"_",temp.cutoff_value,"_Hz",sep=""), append=FALSE, split=FALSE)
    cat("filter_type\torder\tcutoff\tdecay_rate\tRsq\tKS_percentile\tTPT_percentile\tpeak_frequency\tpeak_height\n")
    cat(filter_type_string.par,"\t",filter_size.par,"\t",temp.cutoff_value,"\t",temp.decay_rate,"\t",temp.Rsq,
        "\t",temp.KS_percentile,"\t",temp.TPT_percentile,"\t",temp.peak_sidelobe_frequency,"\t",temp.peak_sidelobe_PTF_value,"\n")
    sink()
  }
  if(plot_bool.par==TRUE){
    #Plot the PTF's.
    temp.cutoff_value=cutoff.par*sampling_rate.par
    temp.PB_edge=temp.passband_edge*sampling_rate.par
    temp.SB_edge=temp.stopband_edge*sampling_rate.par
    temp.x_label<-paste(abscissa_quantity.par,", in ",abscissa_units.par,sep="")
    temp.y_label<-"Gain"
    temp.PTF_frequency_list<-list(frequencies.par)
    temp.PTF_values_list<-list(PTF.par)
    temp.fitting_frequencies_list<-list(temp.fitting_frequencies)
    temp.fitting_PTF_values_list<-list(temp.fitting_PTF_values)
    multipage_plot_filter.function(temp.PTF_frequency_list,temp.PTF_values_list,x_label.par=temp.x_label,y_label.par=temp.y_label,
                                   title_strings.par=filter_labels.par,nominal_passband_frequency.par=temp.cutoff_value,
                                   passband_frequency.par=temp.cutoff_value,passband_edge.par=temp.PB_edge,
                                   stopband_edge.par=temp.SB_edge,fitting_log_frequencies.par=temp.fitting_frequencies_list,
                                   fitted_log_PTF_values.par=temp.fitting_PTF_values_list,filter_order.par=temp.parameter_matrix[,1],
                                   pdf_title.par=paste("Gain_Spectra_",temp.cutoff_value,"_Hz.pdf",sep=""),
                                   num_lin_interp.par=temp.nums_linear_interpolation,
                                   nums_nn_interpolation.par=temp.nums_nn_interpolation,decay_rates.par=temp.decay_rates,ise.par=temp.ise_values,
                                   include_reconstruction_numbers.par=TRUE)
  }
  temp.list<-list(out.decay_rate=temp.decay_rate,
                  out.ise_value=temp.ise_value,
                  out.cutoff_value=temp.cutoff_value,
                  out.peak_sidelobe_frequency=temp.peak_sidelobe_frequency,
                  out.peak_sidelobe_PTF_value=temp.peak_sidelobe_PTF_value,
                  out.fitting_frequencies=temp.fitting_frequencies,
                  out.fitted_values=temp.fitted_values,
                  out.Rsq=temp.Rsq,
                  out.KS_percentile=temp.KS_percentile,
                  out.TPT_percentile=temp.TPT_percentile)
  return(temp.list)
}









integer_periods.function<-function(frequencies.par,significant_indices.par,sampling_rate.par=1,verbose_bool.par=FALSE){
  temp.M2=length(frequencies.par)
  temp.significant_frequencies<-frequencies.par[significant_indices.par]
  temp.significant_frequencies<-temp.significant_frequencies[temp.significant_frequencies>0]
  if(verbose_bool.par==TRUE){
    cat("temp.significant_frequencies\n")
    print(temp.significant_frequencies*sampling_rate.par)
  }
  temp.significant_periods<-floor(1/temp.significant_frequencies)
  temp.significant_periods<-sort(unique(temp.significant_periods))
  temp.significant_periods<-temp.significant_periods[temp.significant_periods>0 & temp.significant_periods<=temp.M2]
  temp.list<-list(out.significant_periods=temp.significant_periods)
  return(temp.list)
}


buys_baillot_filtering.function<-function(ts.par,K.par=1,times.par=NA,indices.par=NA,verbose_bool.par=FALSE){
  #K.par the difference period.
  if(verbose_bool.par==TRUE){
    cat("K.par = ",K.par,"\n")
  }
  temp.N=length(ts.par)
  temp.first_section_index=ceil(temp.N/2)
  temp.R=floor(temp.first_section_index/K.par) #Number of sections.
  temp.filtered_series<-ts.par
  #Differentiating over two sections, covering the left and right halves of the full record.
  try({
    if(temp.R>0){
      temp.last_section_index=temp.N
      temp.first_section_indices<-1:temp.first_section_index
      temp.last_section_indices<-(temp.first_section_index+1):temp.last_section_index
      temp.num_last_section=length(temp.last_section_indices)
      temp.last_section_indices<-temp.last_section_indices[1:(temp.num_last_section-temp.num_last_section%%K.par)]
      temp.num_last_section=length(temp.last_section_indices)
      temp.template_filtered_series<-rep(0,K.par)
      temp.section_indices<-temp.last_section_indices[1:K.par]
      temp.counter=1
      for(temp.n in temp.section_indices){
        temp.template_filtered_series[temp.counter]=sum(ts.par[temp.n-seq(from=1,to=temp.R*K.par,by=K.par)])
        temp.counter=temp.counter+1
      }
      temp.template_filtered_series<-temp.template_filtered_series/temp.R
      temp.first_filtered_series_index=temp.first_section_index+1-temp.R*K.par
      temp.last_filtered_series_index=temp.last_section_indices[temp.num_last_section]
      temp.filtered_series_stepped_indices<-seq(from=temp.first_filtered_series_index,to=temp.last_filtered_series_index,by=K.par)
      temp.filtered_series_indices<-temp.first_filtered_series_index:temp.last_filtered_series_index
      temp.num_filtered_indices=length(temp.filtered_series_indices)
      #Periodic reconstruction.
      temp.filtered_series<-rep(0,temp.num_filtered_indices)
      temp.counter=1
      for(temp.n in temp.filtered_series_stepped_indices){
        temp.filtered_series[(temp.counter-1)*K.par+1:K.par]<-temp.template_filtered_series
        temp.counter=temp.counter+1
      }
      if(!is.na(times.par)){
        times.par<-times.par[temp.filtered_series_indices]
        indices.par<-indices.par[temp.filtered_series_indices]
      }
    }
  },silent=T)
  temp.list<-list(out.times=times.par,
                  out.filtered_series=temp.filtered_series,
                  out.indices=indices.par)
  return(temp.list)
}



buys_baillot_reconstruction.function<-function(ts.par,times.par,frequencies.par,significant_indices.par,sampling_rate.par=1,verbose_bool.par=FALSE){
  #Obtain all of the integer periods from the significant frequencies passed as input.
  temp.integer_periods_object<-integer_periods.function(frequencies.par,significant_indices.par,sampling_rate.par=sampling_rate.par,
                                                        verbose_bool.par=verbose_bool.par)
  temp.significant_periods<-temp.integer_periods_object$out.significant_periods
  temp.num_significant_periods=length(temp.significant_periods)
  #Initialization.
  temp.bb_reconstruction<-ts.par
  temp.bb_whitened_series<-temp.bb_reconstruction
  temp.record_size0=length(temp.bb_reconstruction)
  temp.bb_indices<-1:temp.record_size0
  temp.times<-times.par
  for(temp.i in 1:temp.num_significant_periods){
    temp.buys_baillot_object<-buys_baillot_filtering.function(temp.bb_whitened_series,K.par=temp.significant_periods[temp.i],
                                                              times.par=temp.times,indices.par=temp.bb_indices)
    temp.times<-temp.buys_baillot_object$out.times
    temp.bb_reconstruction<-temp.buys_baillot_object$out.filtered_series
    temp.bb_indices<-temp.buys_baillot_object$out.indices
    temp.bb_whitened_series<-ts.par[temp.bb_indices]-temp.bb_reconstruction
  }
  temp.bb_reconstruction<-ts.par[temp.bb_indices]-temp.bb_whitened_series
  temp.list<-list(out.bb_indices=temp.bb_indices,
                  out.bb_reconstruction=temp.bb_reconstruction,
                  out.times=temp.times,
                  out.bb_whitened_series=temp.bb_whitened_series)
  return(temp.list)
}



buys_baillot_whitening.function<-function(spectral_powers.par,frequencies.par,significant_indices.par,N.par,verbose_bool.par=FALSE){
  temp.M2=length(frequencies.par)
  temp.integer_periods_object<-integer_periods.function(frequencies.par,significant_indices.par,sampling_rate.par=sampling_rate.par,
                                                        verbose_bool.par=verbose_bool.par)
  temp.significant_periods<-temp.integer_periods_object$out.significant_periods
  if(verbose_bool.par==TRUE){
    cat("temp.significant_periods\n")
    print(temp.significant_periods)
  }
  temp.num_significant_periods=length(temp.significant_periods)
  #Initialization.
  temp.bb_whitened_spectral_powers<-spectral_powers.par
  temp.whitening_transfer_function<-rep(1,temp.M2)
  #The computations below fail if there are no spectral peaks, and this is the easiest way to code efficiently while ensuring that no
  #problems are encountered upon such a circumstance.
  #Successive whitening steps, one for each frequency.
  if(temp.num_significant_periods>0){
    for(temp.i in 1:temp.num_significant_periods){
      temp.K=temp.significant_periods[temp.i]
      if(temp.K<N.par){
        temp.R=floor(N.par/temp.K)
        temp.numerators<-sin(pi*temp.K*temp.R*frequencies.par[2:temp.M2]/2)
        temp.denominators<-sin(pi*temp.K*frequencies.par[2:temp.M2]/2)
        temp.tf<-rep(1,temp.M2)
        temp.tf[temp.denominators!=0]<-temp.numerators[temp.denominators!=0]/temp.denominators[temp.denominators!=0]
        temp.tf<-temp.tf/temp.R
        temp.bb_whitened_spectral_powers<-temp.bb_whitened_spectral_powers*Mod(1-temp.tf)^2
        temp.whitening_transfer_function<-temp.whitening_transfer_function/(1-temp.tf)
        if(verbose_bool.par==TRUE){
          cat("temp.R = ",temp.R,"\n")
          cat("temp.denominators\n")
          print(head(temp.denominators))
          cat("temp.tf\n")
          print(head(temp.tf))
        }
      }
    }
  }
  temp.whitening_transfer_function<-c(rev(temp.whitening_transfer_function[2:temp.M2]),temp.whitening_transfer_function)
  temp.list<-list(out.bb_whitened_spectral_powers=temp.bb_whitened_spectral_powers,
                  out.whitening_transfer_function=temp.whitening_transfer_function)
  return(temp.list)
}




plot.ts_model_uncertainty<-function(x_list.par,y_list.par,x_label.par="",y_label.par="",plot_title.par="",pdf_title.par="",plotting_LB.par=0,plotting_UB.par=0,
                                    lwd.par=1,col.par=NA,legend_labels.par=NA,legend_title.par="",vertical_line.par=NA,horizontal_line.par=NA,lty.par=NA,
                                    min_y.par=NA,max_y.par=NA){
  temp.num_list_entries=length(x_list.par)
  temp.colours<-rep(1,temp.num_list_entries)
  #temp.outlier_min_col<-c()
  #temp.outlier_max_col<-c()
  temp.min_LB_col<-c()
  #temp.max_LB_col<-c()
  #temp.min_UB_col<-c()
  temp.max_UB_col<-c()
  #temp.nominal_LB_col<-c()
  #temp.nominal_UB_col<-c()
  temp.min_averages_col<-c()
  temp.max_averages_col<-c()
  temp.nominal_averages_col<-c()
  temp.ts_col<-c()
  if(!is.na(col.par)){
    temp.colours<-col.par
    #temp.outlier_min_col=col.par[1]
    #temp.outlier_max_col=col.par[2]
    temp.min_LB_col=col.par[1]
    #temp.max_LB_col=col.par[4]
    #temp.min_UB_col=col.par[5]
    temp.max_UB_col=col.par[2]
    #temp.nominal_LB_col=col.par[7]
    #temp.nominal_UB_col=col.par[8]
    temp.min_averages_col=col.par[3]
    temp.max_averages_col=col.par[4]
    #temp.nominal_averages_col=col.par[5]
    temp.ts_col=col.par[5]
  }
  temp.lty<-rep(1,temp.num_list_entries)
  if(!is.na(lty.par)){
    temp.lty<-lty.par
  }
  temp.all_x<-unlist(x_list.par)
  temp.all_y<-unlist(y_list.par)
  temp.x_bounds=c(min(temp.all_x),max(temp.all_x))
  temp.y_bounds=c(plotting_LB.par,plotting_UB.par)
  if(!plotting_LB.par){
    temp.y_bounds[1]=min(temp.all_y)
  }
  if(!plotting_UB.par){
    temp.y_bounds[2]=max(temp.all_y)
  }
  temp.plotting_indices<-1:temp.num_list_entries
  if(!is.na(legend_labels.par) & !plotting_UB.par){
    temp.y_bounds[2]=legend.function(unlist(x_list.par),unlist(y_list.par),title.par=legend_title.par,labels.par=legend_labels.par,
                                     lty.par=temp.lty,lwd.par=rep(lwd.par,temp.num_list_entries))
  }
  if(!is.na(min_y.par) & !is.na(max_y.par)){
    temp.original_diff=temp.y_bounds[2]-temp.y_bounds[1]
    temp.new_diff=max_y.par-min_y.par
    temp.diff_ratio=max(temp.new_diff/temp.original_diff,temp.original_diff/temp.new_diff)
    if(temp.diff_ratio<20){
      temp.y_bounds[1]=min(temp.y_bounds[1],min_y.par)
      temp.y_bounds[2]=max(temp.y_bounds[2],max_y.par)
    }
  }
  pdf(paste(pdf_title.par),width=8,height=6)
  par(mgp=c(2,1,0))
  plot(0,0,xlab=paste(x_label.par),ylab=paste(y_label.par),main=paste(plot_title.par),xlim=c(temp.x_bounds[1],temp.x_bounds[2]),
       ylim=c(temp.y_bounds[1],temp.y_bounds[2]),pch=".",lab=c(10,10,7))
  grid()
  minor.tick(10,10)
  if(!is.na(horizontal_line.par)){
    abline(h=horizontal_line.par,lwd=2)
  }
  if(!is.na(vertical_line.par)){
    abline(v=vertical_line.par,lwd=2)
  }
  #Outlier thresholds.
  #temp.x_plotting<-x_list.par[[1]]
  #temp.y_plotting<-y_list.par[[1]]
  #lines(temp.x_plotting,temp.y_plotting,lwd=lwd.par,col=temp.min_LB_col,lty=temp.lty[1])
  #temp.x_plotting<-x_list.par[[2]]
  #temp.y_plotting<-y_list.par[[2]]
  #lines(temp.x_plotting,temp.y_plotting,lwd=lwd.par,col=temp.max_UB_col,lty=temp.lty[2])
  #CI LB.
  lines(x_list.par[[1]],y_list.par[[2]],pch=".",col=temp.min_LB_col)
  lines(x_list.par[[1]],y_list.par[[2]],pch=".",col=temp.max_UB_col)
  polygon(c(x_list.par[[1]],rev(x_list.par[[2]])),c(y_list.par[[1]],rev(y_list.par[[2]])),col=temp.min_LB_col,border=NA)
  #CI UB.
  lines(x_list.par[[3]],y_list.par[[3]],pch=".",col=temp.min_averages_col)
  lines(x_list.par[[4]],y_list.par[[4]],pch=".",col=temp.max_averages_col)
  polygon(c(x_list.par[[3]],rev(x_list.par[[4]])),c(y_list.par[[3]],rev(y_list.par[[4]])),col=temp.min_averages_col,border=NA)
  #Nominal CI bounds.
  #temp.x_plotting<-x_list.par[[7]]
  #temp.y_plotting<-y_list.par[[7]]
  #lines(temp.x_plotting,temp.y_plotting,lwd=lwd.par,col=temp.nominal_LB_col,lty=temp.lty[7])
  #temp.x_plotting<-x_list.par[[8]]
  #temp.y_plotting<-y_list.par[[8]]
  #lines(temp.x_plotting,temp.y_plotting,lwd=lwd.par,col=temp.nominal_UB_col,lty=temp.lty[8])
  #Averages.
  #lines(x_list.par[[9]],y_list.par[[9]],pch=".",col=temp.min_averages_col)
  #lines(x_list.par[[10]],y_list.par[[10]],pch=".",col=temp.max_averages_col)
  #polygon(c(x_list.par[[9]],rev(x_list.par[[10]])),c(y_list.par[[9]],rev(y_list.par[[10]])),col=temp.min_averages_col,border=NA)
  #Nominal averages.
  #temp.x_plotting<-x_list.par[[5]]
  #temp.y_plotting<-y_list.par[[5]]
  #lines(temp.x_plotting,temp.y_plotting,lwd=lwd.par,col=temp.nominal_averages_col,lty=temp.lty[5])
  #Nominal averages.
  temp.x_plotting<-x_list.par[[5]]
  temp.y_plotting<-y_list.par[[5]]
  lines(temp.x_plotting,temp.y_plotting,lwd=lwd.par[5],col=temp.ts_col,lty=temp.lty[5])
  if(!is.na(legend_labels.par)){
    legend.function(unlist(temp.x_plotting),unlist(temp.y_plotting),title.par=legend_title.par,labels.par=legend_labels.par,
                    lty.par=temp.lty,lwd.par=rep(lwd.par,temp.num_list_entries),legend_plot_bool.par=TRUE,col.par=col.par)
  }
  dev.off()
}





#Crossing statistics.

chi_squared_crossing.function<-function(ts.par,time_sequence.par,dof.par,percentile.par=c(0.1,0.25,0.5,0.75,0.9),first_time.par=0,
                                        NW.par=5,sampling_rate.par=1,M_exponent.par=1,F_test_threshold.par=NA,
                                        old_directory.par="",new_directory.par="",measured_quantity.par="",
                                        abscissa_measurement.par="",abscissa_units.par="",verbose_bool.par=FALSE){
  temp.N=length(ts.par)
  if(is.na(F_test_threshold.par)==TRUE){
    F_test_threshold.par=1-1/temp.N
  }
  temp.new_directory<-paste(new_directory.par,"/",sep="")
  percentile.par<-c(percentile.par,1-1/temp.N)
  temp.num_percentiles=length(percentile.par)
  temp.quantiles<-qchisq(percentile.par,dof.par)
  temp.multitaper_parameters_object<-multitaper_parameters.function(N.par=temp.N,NW.par=NW.par,sampling_rate.par=sampling_rate.par,
                                                                    M_exponent.par=M_exponent.par,verbose.par=FALSE)
  temp.M=temp.multitaper_parameters_object$out.M
  temp.M2=temp.M/2+1
  temp.K=temp.multitaper_parameters_object$out.K
  temp.frequencies=temp.multitaper_parameters_object$out.frequencies
  temp.centred_process_eigencoefficients_object<-centred_process.eigencoefficients(ts.par=ts.par,NW.par=NW.par,M.par=temp.M,K.par=temp.K,verbose.par=FALSE)
  temp.eigencoeffs<-temp.centred_process_eigencoefficients_object$out.eigencoeffs
  temp.eigenvalues<-temp.centred_process_eigencoefficients_object$out.eigenvalues
  temp.multitaper_regularized_spectrum<-multitaper.regularized_spectrum(eigencoefficients.par=temp.eigencoeffs,frequencies.par=temp.frequencies,
                                                                        concentrations.par=temp.eigenvalues)
  temp.multitaper_acvs_analysis_object<-multitaper_acvs_analysis.function(spectral_power_estimates.par=temp.multitaper_regularized_spectrum,
                                                                          NW.par=NW.par,sampling_rate.par=sampling_rate.par,
                                                                          plot_bool.par=FALSE)
  temp.autocorrelation_coefficient_sequence<-temp.multitaper_acvs_analysis_object$out.autocorrelation_coefficient_sequence
  temp.outlier_cleaner_object<-outlier_cleaner.function(times.par=time_sequence.par,ts.par=ts.par,spectral_powers.par=temp.multitaper_regularized_spectrum,
                                                        multitaper_autocorrelations.par=temp.autocorrelation_coefficient_sequence,
                                                        frequencies.par=temp.frequencies,soft_replacement_bool.par=FALSE)
  temp.cleaned_series<-temp.outlier_cleaner_object$out.cleaned_series
  time_sequence.par<-temp.outlier_cleaner_object$out.ar_times
  ts.par<-temp.cleaned_series
  ts.par<-sample(ts.par)
  temp.N=length(ts.par)
  temp.multitaper_parameters_object<-multitaper_parameters.function(N.par=temp.N,NW.par=NW.par,sampling_rate.par=sampling_rate.par,
                                                                    M_exponent.par=M_exponent.par,verbose.par=FALSE)
  temp.M=temp.multitaper_parameters_object$out.M
  temp.M2=temp.M/2+1
  temp.K=temp.multitaper_parameters_object$out.K
  temp.frequencies=temp.multitaper_parameters_object$out.frequencies
  temp.centred_process_eigencoefficients_object<-centred_process.eigencoefficients(ts.par=ts.par,NW.par=NW.par,M.par=temp.M,K.par=temp.K,verbose.par=FALSE)
  temp.eigencoeffs<-temp.centred_process_eigencoefficients_object$out.eigencoeffs
  temp.eigenvalues<-temp.centred_process_eigencoefficients_object$out.eigenvalues
  temp.multitaper_regularized_spectrum<-multitaper.regularized_spectrum(eigencoefficients.par=temp.eigencoeffs,frequencies.par=temp.frequencies,
                                                                        concentrations.par=temp.eigenvalues)
  temp.multitaper_acvs_analysis_object<-multitaper_acvs_analysis.function(spectral_power_estimates.par=temp.multitaper_regularized_spectrum,
                                                                          NW.par=NW.par,sampling_rate.par=sampling_rate.par,
                                                                          plot_bool.par=FALSE)
  temp.mt_acvs<-temp.multitaper_acvs_analysis_object$out.mt_acvs
  temp.variance=temp.mt_acvs[1]
  temp.first_diffs<-(temp.mt_acvs[2:temp.M2]-temp.mt_acvs[2:temp.M2-1])/(1/temp.M)
  temp.second_diffs<-(temp.first_diffs[2:(temp.M2-1)]-temp.first_diffs[2:(temp.M2-1)-1])/(1/temp.M)
  temp.acvs_ratio=sqrt(abs(temp.second_diffs[1]/temp.variance/pi))/temp.N
  temp.num_upcrossings_per_Rayleigh<-rep(0,temp.num_percentiles)
  if(verbose_bool.par==TRUE){
    sink("Sphericity_Tests_Summary_Statistics.txt", append=FALSE, split=FALSE)
    cat("percentage_point\tcrossings_fraction\texpected_fraction\n")
  }
  for(temp.i in 1:temp.num_percentiles){
    temp.num_upcrossings_per_Rayleigh=sqrt(temp.quantiles[temp.i])*temp.acvs_ratio*dchisq(temp.quantiles[temp.i],dof.par)
    temp.num_crossings=length(which(ts.par>=temp.quantiles[temp.i]))/2/temp.N
    cat(percentile.par[temp.i]*100,"\t",round(temp.num_crossings*100,ceil(-log10(temp.num_crossings)+1)),"\t",
        round(temp.num_upcrossings_per_Rayleigh*100,ceil(-log10(temp.num_upcrossings_per_Rayleigh)+1)),"\n")
  }
  if(verbose_bool.par==TRUE){
    sink()
  }
  return(temp.num_upcrossings_per_Rayleigh)
}





#Changpoint analysis.


correct_changepoints.function<-function(changepoints.par,index.par,max_all_times_dataset.par){
  #If the last section in the time series ends before the final changepoint specified by the user, then modify the changepoints
  #so that the last of them coincides with the end of the time series.
  if(!is.infinite(changepoints.par[index.par+1]) & changepoints.par[index.par+1]>max_all_times_dataset.par){
    changepoints.par[index.par+1]=max_all_times_dataset.par
  }
  return(changepoints.par)
}

changepoints_section_start_time.function<-function(changepoint_times.par,index.par,max_all_times_dataset.par){
  temp.start_time=0
  if(changepoint_times.par[index.par+1]<Inf){
    temp.start_time=(changepoint_times.par[index.par]+changepoint_times.par[index.par+1])/2
  } else{
    temp.start_time=(changepoint_times.par[index.par]+max_all_times_dataset.par)/2
  }
  return(temp.start_time)
}


changepoints_initialize_training.function<-function(time_sequence.par,ts_sequence.par,changepoint_times.par,index.par,frequency_band.par,first_time.par,
                                                    NW.par=5,truncation_bool.par=TRUE){
  temp.max_all_times=max(time_sequence.par)
  temp.changepoint_times<-correct_changepoints.function(changepoint_times.par,index.par,temp.max_all_times)
  #Start of the epoch under analysis should be midway into the section to avoid transient effects in the transition interval between epochs.
  temp.start_time=changepoints_section_start_time.function(changepoint_times.par=changepoint_times.par,index.par,temp.max_all_times)
  temp.changepoint_indices<-which(time_sequence.par>=changepoint_times.par[index.par] & time_sequence.par<changepoint_times.par[index.par+1])
  temp.N_samples=length(time_sequence.par[temp.changepoint_indices])
  if(truncation_bool.par==TRUE){
    if(frequency_band.par[2]<=10){
      temp.N_samples=min(1e4,temp.N_samples)
    } else{
      temp.N_samples=min(1e3,temp.N_samples)
    }
  }
  temp.sampling_period=time_sequence.par[2]-time_sequence.par[1]
  temp.start_time=temp.start_time-temp.N_samples/2*temp.sampling_period
  temp.start_time=max(0,temp.start_time)
  temp.end_time=temp.start_time+temp.N_samples*temp.sampling_period
  temp.training_indices<-which(time_sequence.par>=temp.start_time & time_sequence.par<temp.end_time)
  #The number of data points must be greater than 2NW when N is half the record size (required for section-overlap multitaper computations).
  temp.num_buffer_indices=length(temp.training_indices)
  temp.section_size0=ceil((4*(2*NW.par+1))/2)
  temp.section_size=temp.section_size0-temp.section_size0%%4
  temp.min_record_size=2*(temp.section_size+temp.section_size0%%4)
  if(temp.num_buffer_indices<temp.min_record_size){
    temp.training_indices<-(min(temp.training_indices)-(temp.min_record_size+1-temp.num_buffer_indices)):max(temp.training_indices)
  }
  temp.training_times<-time_sequence.par[temp.training_indices]
  temp.training_ts_sequence<-ts_sequence.par[temp.training_indices]
  temp.time_sequence_original_base_time<-temp.training_times+first_time.par
  #Extract the section series.
  temp.current_changepoint=temp.changepoint_times[index.par+1]
  temp.previous_changepoint=temp.changepoint_times[index.par]
  temp.indices<-which(temp.training_times>=temp.previous_changepoint & temp.training_times<temp.current_changepoint)
  temp.section_times<-temp.training_times[temp.indices]
  temp.ts_section<-temp.training_ts_sequence[temp.indices]
  temp.section_size=length(temp.section_times)
  temp.N_samples=temp.section_size
  temp.training_interval_bounds<-c(min(temp.section_times),max(temp.section_times))
  temp.list<-list(out.training_times=temp.section_times,
                  out.training_ts_sequence=temp.ts_section,
                  out.N_samples=temp.N_samples,
                  out.time_sequence_original_base_time=temp.time_sequence_original_base_time,
                  out.changepoint_times=temp.changepoint_times,
                  out.section_times=temp.section_times,
                  out.ts_section=temp.ts_section,
                  out.section_size=temp.section_size,
                  out.training_interval_bounds=temp.training_interval_bounds,
                  out.N=temp.section_size)
  return(temp.list)
}


epoch_periodic_extension.function<-function(time_sequence.par,ts_sequence.par,training_times.par,training_ts_values.par,mean_vector.par,sd_vector.par,
                                            previous_changepoint.par,current_changepoint.par,first_time.par=0,start_time.par=0,plot_titles.par=""){
  #Reconstruct the voltage in the entire epoch based on the training data above.
  temp.all_section_times<-time_sequence.par[time_sequence.par>=previous_changepoint.par & time_sequence.par<current_changepoint.par]
  temp.all_section_ts_values<-ts_sequence.par[time_sequence.par>=previous_changepoint.par & time_sequence.par<current_changepoint.par]
  temp.full_ts_size=length(temp.all_section_times)
  temp.N=length(training_times.par)
  temp.min_time=min(training_times.par)
  temp.max_time=max(training_times.par)
  temp.time_indices<-1:temp.full_ts_size
  temp.min_preceding_index=1
  #Reconstructions for times preceding the training set.
  temp.preceding_times0<-temp.all_section_times[temp.all_section_times<temp.min_time]
  temp.preceding_time_indices<-temp.time_indices[temp.all_section_times<temp.min_time]
  temp.num_preceding_times=length(temp.preceding_times0)
  temp.preceding_times<-c()
  temp.preceding_ts_values<-c()
  temp.preceding_reconstructions<-c()
  temp.preceding_sd<-c()
  if(temp.num_preceding_times>0){
    temp.max_preceding_index=temp.preceding_time_indices[temp.num_preceding_times]
    temp.num_preceding_sections=floor(temp.num_preceding_times/temp.N)
    temp.preceding_times_list<-list()
    temp.preceding_ts_values_list<-list()
    temp.preceding_reconstructions_list<-list()
    temp.preceding_sd_list<-list()
    if(temp.num_preceding_sections>0){
      for(temp.i in 1:temp.num_preceding_sections){
        temp.indices<-temp.max_preceding_index-temp.i*temp.N+1:temp.N
        temp.preceding_times_list[[temp.i]]<-temp.all_section_times[temp.indices]
        temp.current_ts_values<-temp.all_section_ts_values[temp.indices]
        temp.preceding_ts_values_list[[temp.i]]<-temp.current_ts_values
        temp.current_rss=crossprod(temp.current_ts_values-mean_vector.par)/temp.N
        temp.rss_values<-rep(0,temp.N-1)
        for(temp.j in 1:(temp.N-1)){
          temp.current_indices<-1:(temp.N-temp.j)
          temp.num_indices=length(temp.current_indices)
          temp.rss_values[temp.j]=crossprod(temp.current_ts_values[temp.current_indices]-mean_vector.par[temp.j+temp.current_indices])/temp.num_indices
        }
        temp.min_rss=min(temp.rss_values)
        temp.means<-mean_vector.par
        temp.sd_vector<-sd_vector.par
        if(temp.min_rss<temp.current_rss){
          temp.optimal_rss_index=min(which(temp.rss_values==temp.min_rss))
          temp.means<-c(mean_vector.par[temp.optimal_rss_index+1:(temp.N-temp.optimal_rss_index)],mean_vector.par[1:temp.optimal_rss_index])
          temp.sd_vector<-c(sd_vector.par[temp.optimal_rss_index+1:(temp.N-temp.optimal_rss_index)],sd_vector.par[1:temp.optimal_rss_index])
        }
        temp.preceding_reconstructions_list[[temp.i]]<-temp.means
        temp.preceding_sd_list[[temp.i]]<-temp.sd_vector
      }
    }
    temp.min_preceding_index=temp.num_preceding_times-temp.num_preceding_sections*temp.N
    if(temp.min_preceding_index>0){
      temp.indices<-1:temp.min_preceding_index
      temp.preceding_times_list[[temp.num_preceding_sections+1]]<-temp.all_section_times[temp.indices]
      temp.preceding_ts_values_list[[temp.num_preceding_sections+1]]<-temp.all_section_ts_values[temp.indices]
      temp.preceding_reconstructions_list[[temp.num_preceding_sections+1]]<-mean_vector.par[temp.indices]
      temp.preceding_sd_list[[temp.num_preceding_sections+1]]<-sd_vector.par[temp.indices]
    }
    temp.preceding_times<-unlist(temp.preceding_times_list)
    temp.preceding_ts_values<-unlist(temp.preceding_ts_values_list)
    temp.preceding_reconstructions<-unlist(temp.preceding_reconstructions_list)
    temp.preceding_sd<-unlist(temp.preceding_sd_list)
  }
  #Reconstructions for times following the training set.
  temp.following_times<-temp.all_section_times[temp.all_section_times>temp.max_time]
  temp.following_time_indices<-temp.time_indices[temp.all_section_times>temp.max_time]
  temp.min_following_index=temp.following_time_indices[1]
  temp.num_following_times=length(temp.following_times)
  temp.following_times<-c()
  temp.following_ts_values<-c()
  temp.following_reconstructions<-c()
  temp.following_sd<-c()
  if(temp.num_following_times>0){
    temp.num_following_sections=floor(temp.num_following_times/temp.N)
    temp.following_times_list<-list()
    temp.following_ts_values_list<-list()
    temp.following_reconstructions_list<-list()
    temp.following_sd_list<-list()
    if(temp.num_following_sections>0){
      for(temp.i in 1:temp.num_following_sections){
        temp.indices<-temp.min_following_index+(temp.i-1)*temp.N+1:temp.N-1
        temp.following_times_list[[temp.i]]<-temp.all_section_times[temp.indices]
        temp.following_ts_values_list[[temp.i]]<-temp.all_section_ts_values[temp.indices]
        temp.current_ts_values<-temp.all_section_ts_values[temp.indices]
        temp.current_rss=crossprod(temp.current_ts_values-mean_vector.par)/temp.N
        temp.rss_values<-rep(0,temp.N-1)
        for(temp.j in 1:(temp.N-1)){
          temp.current_indices<-1:(temp.N-temp.j)
          temp.num_indices=length(temp.current_indices)
          temp.rss_values[temp.j]=crossprod(temp.current_ts_values[temp.current_indices]-mean_vector.par[temp.j+temp.current_indices])/temp.num_indices
        }
        temp.min_rss=min(temp.rss_values)
        temp.means<-mean_vector.par
        temp.sd_vector<-sd_vector.par
        if(temp.min_rss<temp.current_rss){
          temp.optimal_rss_index=min(which(temp.rss_values==temp.min_rss))
          temp.means<-c(mean_vector.par[temp.optimal_rss_index+1:(temp.N-temp.optimal_rss_index)],mean_vector.par[1:temp.optimal_rss_index])
          temp.sd_vector<-c(sd_vector.par[temp.optimal_rss_index+1:(temp.N-temp.optimal_rss_index)],sd_vector.par[1:temp.optimal_rss_index])
        }
        temp.following_reconstructions_list[[temp.i]]<-temp.means
        temp.following_sd_list[[temp.i]]<-temp.sd_vector
      }
    }
    temp.max_following_index=(temp.num_following_times-temp.num_following_sections*temp.N)
    temp.max_time=max(training_times.par)
    if(temp.num_following_sections>0){
      temp.max_time=max(temp.following_times_list[[temp.num_following_sections]])
    }
    temp.last_preceding_time=temp.max_time-temp.decimation_sampling_period
    temp.max_time_index=temp.min_following_index+(temp.num_following_sections-1)*temp.N+1:temp.N-1
    if(temp.max_following_index>0){
      temp.indices<-c()
      if(temp.max_following_index>0){
        temp.indices<-1:temp.max_following_index+temp.full_ts_size-temp.max_following_index
      }
      else{
        while(temp.max_time<temp.last_preceding_time){
          temp.indices<-c(temp.indices,temp.max_time_index+1)
          temp.max_time_index=temp.max_time_index+1
          temp.max_time=temp.max_time+temp.decimation_sampling_period
        }
      }
      temp.following_times_list[[temp.num_following_sections+1]]<-temp.all_section_times[temp.indices]
      temp.following_ts_values_list[[temp.num_following_sections+1]]<-temp.all_section_ts_values[temp.indices]
      temp.following_reconstructions_list[[temp.num_following_sections+1]]<-mean_vector.par[1:length(temp.indices)]
      temp.following_sd_list[[temp.num_following_sections+1]]<-sd_vector.par[1:length(temp.indices)]
    }
    temp.following_times<-unlist(temp.following_times_list)
    temp.following_ts_values<-unlist(temp.following_ts_values_list)
    temp.following_reconstructions<-unlist(temp.following_reconstructions_list)
    temp.following_sd<-unlist(temp.following_sd_list)
  }
  #Periodic reconstructions.
  temp.all_times<-c(temp.preceding_times,training_times.par,temp.following_times)
  temp.all_ts_values<-c(temp.preceding_ts_values,training_ts_values.par,temp.following_ts_values)
  temp.all_reconstructions<-c(temp.preceding_reconstructions,mean_vector.par,temp.following_reconstructions)
  temp.all_sd<-c(temp.preceding_sd,sd_vector.par,temp.following_sd)
  temp.all_reconstructions<-temp.all_reconstructions[order(temp.all_times)]
  temp.all_sd<-temp.all_sd[order(temp.all_times)]
  #Plot the periodic reconstructions.
  temp.all_ts_values<-TF_cleaning.function(temp.all_ts_values)$out.TF
  temp.all_reconstructions<-TF_cleaning.function(temp.all_reconstructions)$out.TF
  temp.all_sd<-TF_cleaning.function(temp.all_sd)$out.TF
  temp.plotting_times<-plotting.sampled_vector(temp.all_times)
  temp.plotting_ts_values<-plotting.sampled_vector(temp.all_ts_values)
  temp.plotting_reconstructions<-plotting.sampled_vector(temp.all_reconstructions)
  temp.plotting_sd<-plotting.sampled_vector(temp.all_sd)
  temp.x_list<-list(temp.plotting_times)
  temp.standardized_ts_values<-rep(0,length(temp.plotting_ts_values))
  temp.standardized_ts_values[temp.plotting_sd>0]<-
    (temp.plotting_ts_values[temp.plotting_sd>0]-temp.plotting_reconstructions[temp.plotting_sd>0])/temp.plotting_sd[temp.plotting_sd>0]
  temp.y_list<-list(temp.standardized_ts_values)
  plot.graph(temp.x_list,temp.y_list,x_label.par=paste("Time, in seconds since ",
                                                       round(first_time.par/60,ceil(log10(first_time.par/60-floor(first_time.par/60)))+1)," min",sep=""),
             y_label.par="Estimation bias, in units of standard deviation",plot_title.par="",
             pdf_title.par="Periodic_Reconstruction.pdf",
             vertical_line.par=c(min(training_times.par),max(training_times.par)))
  temp.list<-list(out.all_times=temp.all_times,
                  out.all_ts_values=temp.all_ts_values,
                  out.all_reconstructions=temp.all_reconstructions,
                  out.all_sd=temp.all_sd)
  return(temp.list)
}



plot_epoch_reconstruction.function<-function(time_sequence.par,ts_sequence.par,
                                             times_full_record.par,ts_values_full_record.par,
                                             means_full_record.par,sd_full_record.par,LB_full_record.par,UB_full_record.par,
                                             training_interval_bounds_vector.par,changepoint.times.par,
                                             num_samples.par=5e3,first_time.par=0,num_synthetic.par=1,
                                             simulation_bool.par=FALSE,
                                             abscissa_value.par="",abscissa_units.par="",ordinate_value.par="",ordinate_units.par="",
                                             old_directory.par=""){
  temp.num_changepoint_times=length(changepoint.times.par)
  temp.changepoint_times<-changepoint.times.par[!is.infinite(changepoint.times.par)]
  temp.plotting_label<-"Summary_Plots"
  dir.create(temp.plotting_label,showWarnings=FALSE)
  temp.working_directory_string_plotting<-paste(old_directory.par,"/",temp.plotting_label,"/",sep="")
  setwd(temp.working_directory_string_plotting)
  #Assemble the downsampled time series for plotting.
  temp.plotting_times1<-plotting.sampled_vector(time_sequence.par,num_samples.par=num_samples.par)
  temp.plotting_times2<-plotting.sampled_vector(time_sequence.par)
  temp.plotting_ts_values<-plotting.sampled_vector(ts_sequence.par,num_samples.par=num_samples.par)
  temp.plotting_times_vector<-plotting.sampled_vector(times_full_record.par,num_samples.par=num_samples.par)
  temp.plotting_ts_vector<-plotting.sampled_vector(ts_values_full_record.par,num_samples.par=num_samples.par)
  temp.plotting_reconstructions<-plotting.sampled_vector(means_full_record.par,num_samples.par=num_samples.par)
  temp.plotting_LB<-plotting.sampled_vector(LB_full_record.par,num_samples.par=num_samples.par)
  temp.plotting_UB<-plotting.sampled_vector(UB_full_record.par,num_samples.par=num_samples.par)
  #Plot the full reconstruction accompanied by confidence bounds.
  temp.all_y_values<-c(temp.plotting_ts_values,temp.plotting_reconstructions,temp.plotting_LB,temp.plotting_UB)
  temp.global_y_min=min(temp.all_y_values)
  temp.global_y_max=max(temp.all_y_values)
  temp.shading_parameter=NA
  plot.graph(list(temp.plotting_times_vector,temp.plotting_times_vector,temp.plotting_times_vector),
             list(temp.plotting_LB,temp.plotting_UB,temp.plotting_reconstructions),
             x_label.par=paste(abscissa_value.par,", in ",abscissa_units.par," since ",
                               round(first_time.par/60,ceil(log10(first_time.par/60-floor(first_time.par/60)))+1)," ",abscissa_units.par,sep=""),
             y_label.par=paste(ordinate_value.par,", in ",ordinate_units.par,sep=""),plotting_LB.par=temp.global_y_min,plotting_UB.par=temp.global_y_max,
             pdf_title.par="Periodic_Reconstruction_Full_Record_Confidence_Bounds.pdf",col=c("grey75","grey75",1),
             vertical_line.par=temp.changepoint_times,shade_intervals.par=NA)
  #Plot the full data series and generate a second plot in the same PDF file containing the mean reconstruction.
  temp.plotting_reconstructions_highres<-plotting.sampled_vector(means_full_record.par,num_samples.par=num_samples.par)
  multipage_plot_comparison.function(list(temp.plotting_times_vector,temp.plotting_times_vector),
                                     list(temp.plotting_ts_vector,temp.plotting_reconstructions_highres),
                                     x_label.par=paste(abscissa_value.par,", in ",abscissa_units.par," since ",
                                                       round(first_time.par/60,ceil(log10(first_time.par/60-floor(first_time.par/60)))+1)," ",
                                                       abscissa_units.par,sep=""),
                                     y_label.par=paste(ordinate_value.par,", in ",ordinate_units.par,sep=""),bounds_all.par=c(temp.global_y_min,temp.global_y_max),
                                     pdf_title.par="Decimated_Series_Comparison_Full_Record.pdf",
                                     vertical_line.par=temp.changepoint_times,num_samples.par=num_samples.par,
                                     shade_intervals.par=NA)
  #Plot the time series of the estimated variance.
  temp.plotting_sd_highres<-plotting.sampled_vector(sd_full_record.par,num_samples.par=num_samples.par)
  plot.graph(list(temp.plotting_times_vector),
             list(temp.plotting_sd_highres),
             x_label.par=paste(abscissa_value.par,", in ",abscissa_units.par," since ",
                               round(first_time.par/60,ceil(log10(first_time.par/60-floor(first_time.par/60)))+1)," ",
                               abscissa_units.par,sep=""),
             y_label.par=paste(ordinate_value.par,", in ",ordinate_units.par,sep=""),pdf_title.par="Standard_Deviation_Series_Full_Record.pdf",
             vertical_line.par=temp.changepoint_times,shade_intervals.par=NA)
  #Plot the standardized series to determine the level of agreement.
  temp.standardized_series<-rep(0,length(temp.plotting_ts_vector))
  temp.standardized_series[temp.plotting_sd_highres>0]<-
    (temp.plotting_ts_vector[temp.plotting_sd_highres>0]-temp.plotting_reconstructions_highres[temp.plotting_sd_highres>0])/
    temp.plotting_sd_highres[temp.plotting_sd_highres>0]
  plot.graph(list(temp.plotting_times_vector),
             list(temp.standardized_series),
             x_label.par=paste(abscissa_value.par,", in ",abscissa_units.par," since ",
                               round(first_time.par/60,ceil(log10(first_time.par/60-floor(first_time.par/60)))+1)," ",
                               abscissa_units.par,sep=""),
             y_label.par="Fit discrepancy, in units of standard deviations",pdf_title.par="Standardized_Series_Full_Record.pdf",
             plotting_LB.par=max(-10,min(temp.standardized_series)),plotting_UB.par=min(10,max(temp.standardized_series)),
             vertical_line.par=temp.changepoint_times,shade_intervals.par=NA,
             type.par="p",pch.par=".",cex.par=3)
  if(simulation_bool.par==TRUE){
    #Plot an overlay of the time series with the LAPTV reconstruction.
    temp.ts_comparison_strings<-c("LAPTV Noise","AR Noise")
    temp.all_laptv_times<-list()
    temp.all_laptv_min_LB<-list()
    temp.all_laptv_max_UB<-list()
    temp.all_laptv_avg_LB<-list()
    temp.all_laptv_avg_UB<-list()
    temp.laptv_synthetic_file_names<-
      c("Model_Uncertainty_LAPTV_Reconstruction_Statistics.txt","Model_Uncertainty_Signal_Plus_Noise_Reconstruction_Statistics.txt")
    temp.y_min=0
    temp.y_max=0
    for(temp.i in 1:(temp.num_changepoint_times-1)){
      temp.all_laptv_times_i<-list()
      temp.all_laptv_min_LB_i<-list()
      temp.all_laptv_max_UB_i<-list()
      temp.all_laptv_avg_LB_i<-list()
      temp.all_laptv_avg_UB_i<-list()
      for(temp.j in 1:2){
        temp.input_dataset<-
          read.table(paste(old_directory.par,temp.i,"_Section_",temp.i,"/LAPTV_Analysis/",temp.laptv_synthetic_file_names[temp.j],sep=""),
                     header=TRUE,fill=TRUE)
        temp.LAPTV_times<-temp.input_dataset$time
        temp.all_laptv_times_i[[temp.j]]<-temp.LAPTV_times
        temp.all_laptv_min_LB_i[[temp.j]]<-temp.input_dataset$min_LB
        temp.all_laptv_max_UB_i[[temp.j]]<-temp.input_dataset$max_UB
        temp.min_average_vector<-temp.input_dataset$min_average
        temp.max_average_vector<-temp.input_dataset$max_average
        temp.indices<-which(time_sequence.par>=min(temp.LAPTV_times) & time_sequence.par<max(temp.LAPTV_times))
        temp.section_ts<-ts_sequence.par[temp.indices]
        temp.section_ts_median=mean(temp.section_ts)
        temp.centred_section_ts<-temp.section_ts-temp.section_ts_median
        temp.section_energy=crossprod(temp.centred_section_ts)/length(temp.centred_section_ts)
        temp.averages<-(temp.min_average_vector+temp.max_average_vector)/2
        temp.averages_median=mean(temp.averages)
        temp.centred_averages<-temp.averages-temp.averages_median
        temp.averages_energy<-crossprod(temp.centred_averages)/length(temp.centred_averages)
        temp.all_laptv_avg_LB_i[[temp.j]]<-temp.centred_averages*sqrt(temp.section_energy/temp.averages_energy)+temp.averages_median
        temp.all_laptv_avg_UB_i[[temp.j]]<-temp.centred_averages*sqrt(temp.section_energy/temp.averages_energy)+temp.averages_median
        if(temp.i==1 & temp.j==1){
          temp.y_min=min(temp.all_laptv_avg_LB_i[[temp.j]])
          temp.y_max=max(temp.all_laptv_avg_UB_i[[temp.j]])
        }
        else{
          if(temp.y_min>min(temp.all_laptv_avg_LB_i[[temp.j]])){
            temp.y_min=min(temp.all_laptv_avg_LB_i[[temp.j]])
          }
          if(temp.y_max<max(temp.all_laptv_avg_UB_i[[temp.j]])){
            temp.y_max=max(temp.all_laptv_avg_UB_i[[temp.j]])
          }
        }
      }
      temp.all_laptv_times[[temp.i]]<-temp.all_laptv_times_i
      temp.all_laptv_min_LB[[temp.i]]<-temp.all_laptv_min_LB_i
      temp.all_laptv_max_UB[[temp.i]]<-temp.all_laptv_max_UB_i
      temp.all_laptv_avg_LB[[temp.i]]<-temp.all_laptv_avg_LB_i
      temp.all_laptv_avg_UB[[temp.i]]<-temp.all_laptv_avg_UB_i
    }
    pdf("LAPTV_Reconstruction_Full_Record.pdf",width=8,height=6)
    for(temp.j in 1:2){
      par(mgp=c(2,1,0))
      plot(0,0,xlab=paste(abscissa_value.par,", in ",abscissa_units.par," since ",
                          round(first_time.par/60,ceil(log10(first_time.par/60-floor(first_time.par/60)))+1)," ",abscissa_units.par,sep=""),
           ylab=paste(ordinate_value.par,", in ",ordinate_units.par,sep=""),main=temp.ts_comparison_strings[temp.j],
           xlim=c(min(temp.plotting_times_vector),max(temp.plotting_times_vector)),
           ylim=c(min(c(temp.global_y_min,temp.y_min)),max(c(temp.global_y_max,temp.y_max))),pch=".",lab=c(10,10,7))
      grid()
      minor.tick(10,10)
      temp.min_LB_col="grey85"
      temp.max_averages_col="grey60"
      for(temp.i in 1:(temp.num_changepoint_times-1)){
        temp.all_laptv_times_j<-temp.all_laptv_times[[temp.i]][[temp.j]]+temp.changepoint_times[temp.i]
        temp.all_laptv_min_LB_j<-temp.all_laptv_min_LB[[temp.i]][[temp.j]]
        temp.all_laptv_max_UB_j<-temp.all_laptv_max_UB[[temp.i]][[temp.j]]
        temp.all_laptv_avg_LB_j<-temp.all_laptv_avg_LB[[temp.i]][[temp.j]]
        temp.all_laptv_avg_UB_j<-temp.all_laptv_avg_UB[[temp.i]][[temp.j]]
        polygon(c(temp.all_laptv_times_j,rev(temp.all_laptv_times_j)),c(temp.all_laptv_avg_LB_j,rev(temp.all_laptv_avg_UB_j)),col=1,border=NA)
        lines(temp.all_laptv_times_j,temp.all_laptv_avg_LB_j)
        lines(temp.all_laptv_times_j,temp.all_laptv_avg_UB_j)
      }
      abline(v=temp.changepoint_times)
      lines(temp.plotting_times_vector,temp.plotting_ts_vector,lwd=0.5,col=temp.max_averages_col)
    }
    dev.off()
    sink()
  }
  setwd(old_directory.par)
}



output_epoch_reconstruction.function<-function(all_significant_harmonic_ACS_frequencies_list.par=NA,
                                               all_significant_harmonic_coefficients_list.par=NA,all_significant_harmonic_ACS_coefficients_list.par=NA,
                                               all_significant_frequencies_list.par=NA,record_sizes.par=NA,prewhitened_process_variances.par=NA,
                                               ar_coefficient_list.par=NA,wishart_correlation_coefficients.par=NA,wishart_positive_log_bin_heights.par=NA,
                                               old_directory.par=""){
  ar_coefficient_list.par<-list_item_hard_replacement.function(ar_coefficient_list.par)
  temp.files_label<-"Summary_Files"
  dir.create(temp.files_label,showWarnings=FALSE)
  temp.working_directory_string_files<-paste(old_directory.par,"/",temp.files_label,"/",sep="")
  setwd(temp.working_directory_string_files)
  #Sort the harmonic-content statistics.
  temp.all_significant_harmonic_amplitudes_list<-list()
  temp.all_significant_harmonic_phases_list<-list()
  for(temp.i in 1:length(all_significant_harmonic_coefficients_list.par)){
    temp.harmonic_coefficients<-all_significant_harmonic_coefficients_list.par[[temp.i]]
    if(!is.null(temp.harmonic_coefficients)){
      temp.all_significant_harmonic_amplitudes_list[[temp.i]]<-2*Mod(temp.harmonic_coefficients)
      temp.all_significant_harmonic_phases_list[[temp.i]]<-atan2(Im(temp.harmonic_coefficients),Re(temp.harmonic_coefficients))
    }
    else{
      temp.all_significant_harmonic_amplitudes_list[[temp.i]]<-0
      temp.all_significant_harmonic_phases_list[[temp.i]]<-0
    }
  }
  #Sort the ACS harmonic-content statistics.
  temp.all_significant_ACS_frequencies_list<-list()
  temp.all_significant_harmonic_ACS_amplitudes_list<-list()
  temp.all_significant_harmonic_ACS_phases_list<-list()
  for(temp.i in 1:length(all_significant_harmonic_ACS_coefficients_list.par)){
    temp.harmonic_frequencies<-all_significant_harmonic_ACS_frequencies_list.par[[temp.i]]
    temp.harmonic_coefficients<-all_significant_harmonic_ACS_coefficients_list.par[[temp.i]]
    if(!is.null(temp.harmonic_coefficients)){
      temp.all_significant_ACS_frequencies_list[[temp.i]]<-temp.harmonic_frequencies
      temp.all_significant_harmonic_ACS_amplitudes_list[[temp.i]]<-2*Mod(temp.harmonic_coefficients)
      temp.all_significant_harmonic_ACS_phases_list[[temp.i]]<-atan2(Im(temp.harmonic_coefficients),Re(temp.harmonic_coefficients))
    }
    else{
      temp.all_significant_harmonic_ACS_amplitudes_list[[temp.i]]<-0
      temp.all_significant_harmonic_ACS_phases_list[[temp.i]]<-0
    }
  }
  output_list.function(list(record_sizes.par),"Training_Sizes_All_Epochs")
  output_list.function(ar_coefficient_list.par,"AR_Coefficients_All_Epochs")
  output_list.function(list(prewhitened_process_variances.par),"Innovations_Variances_All_Epochs")
  output_list.function(all_significant_frequencies_list.par,"Harmonic_Frequencies_All_Epochs")
  output_list.function(temp.all_significant_harmonic_amplitudes_list,"Harmonic_Amplitudes_All_Epochs")
  output_list.function(temp.all_significant_harmonic_phases_list,"Harmonic_Phases_All_Epochs")
  output_list.function(temp.all_significant_ACS_frequencies_list,"Harmonic_ACS_Frequencies_All_Epochs")
  output_list.function(temp.all_significant_harmonic_ACS_amplitudes_list,"Harmonic_ACS_Amplitudes_All_Epochs")
  output_list.function(temp.all_significant_harmonic_ACS_phases_list,"Harmonic_ACS_Phases_All_Epochs")
  output_list.function(list(wishart_correlation_coefficients.par,wishart_positive_log_bin_heights.par),"Wishart_Statistics_All_Epochs")
  setwd(old_directory.par)
}

set_default_changepoint_indices.function<-function(ts.par,section_size.par=1e3){
  temp.N=length(ts.par)
  temp.section_index_list<-list()
  if(temp.N<=section_size.par){
    temp.section_index_list[[1]]<-1:temp.N
  }
  else{
    step_size.par=floor(temp.N/section_size.par)
    temp.running_max_index=1
    temp.counter=1
    for(temp.i in seq(from=1,to=temp.N,by=step_size.par)){
      temp.section_indices<-(temp.i-1)*step_size.par+1:step_size.par
      temp.section_index_list[[temp.i]]<-temp.section_indices
      temp.running_max_index=temp.section_indices[step_size.par]
      temp.counter=temp.counter+1
    }
    if(temp.running_max_index<temp.N){
      temp.section_indices<-temp.running_max_index+1:(temp.N-temp.running_max_index)
      temp.section_index_list<-list.append(temp.section_index_list,
                                           temp.section_indices)
    }
  }
  return(temp.section_index_list)
}



decimation_full_analysis.function<-function(truncated_times.par,truncated_ts_series.par,start_time_all.par,end_time_all.par,filter_types.par,
                                            sampling_rate.par=1,sampling_period.par=1,first_time.par=0,
                                            time_window_index.par=1,record_size.par=NA,x_scale.par=1,y_scale.par=1,
                                            #multitaper_parameters.function
                                            N.par,NW.par=5,M_exponent.par=1,
                                            cepstral_bool.par=FALSE,verbose_multitaper_parameters.par=TRUE,
                                            #marshall_filter.function
                                            changepoint_times.par=NA,frequency_band.par,filter_type_thresholds.par,
                                            F_test_threshold.par=NA,num_sections.par=2,threshold_crossings_LB.par=3,
                                            abscissa_quantity.par="Measured quantity",abscissa_units.par="units",
                                            ordinates_quantity.par="Measured quantity",ordinates_units.par="units",
                                            old_directory.par="",new_directory.par="",
                                            output_bool.par=FALSE,specific_subdirectory_string.par=FALSE,whitening_bool.par=FALSE,harmonic_bool.par=FALSE,
                                            differencing_bool.par=FALSE,original_sampling_bool.par=FALSE,plot_sections_bool.par=FALSE,
                                            filter_diagnostics_bool.par=FALSE,plot_bool.par=TRUE,verbose.par=TRUE){
  #Read in the data.
  if(verbose.par==TRUE){
    cat("Reading in the data\n")
  }
  if(!is.na(start_time_all.par)){
    truncated_ts_series.par<-truncated_ts_series.par[truncated_times.par>=start_time_all.par]
    truncated_times.par<-truncated_times.par[truncated_times.par>=start_time_all.par]
  }
  if(!is.na(end_time_all.par)){
    truncated_ts_series.par<-truncated_ts_series.par[truncated_times.par<=end_time_all.par]
    truncated_times.par<-truncated_times.par[truncated_times.par<=end_time_all.par]
  }
  temp.N_samples=length(truncated_times.par)
  #The change points have been determined through visual inspection of the voltage trace for Patient C5.
  #The two change points (first and second entries of the vector below) separate early-ictal/ictal-wavefront and ictal-wavefront/late-ictal.
  temp.marshall_filter_single_section_object<-marshall_filter.function(time_sequence.par=truncated_times.par,ts_values.par=truncated_ts_series.par,
                                                                       trial_N.par=N.par,N.par=temp.N_samples,section_N.par=N.par,
                                                                       changepoint_times.par=changepoint_times.par,
                                                                       first_time.par=first_time.par,sampling_period.par=sampling_period.par,
                                                                       frequency_band.par=frequency_band.par,filter_types.par=filter_types.par,
                                                                       sampling_rate.par=sampling_rate.par,F_test_threshold.par=F_test_threshold.par,
                                                                       num_sections.par=num_sections.par,threshold_crossings_LB.par=threshold_crossings_LB.par,
                                                                       filter_type_thresholds.par=filter_type_thresholds.par,
                                                                       abscissa_quantity.par=measured_abscissa.string,abscissa_units.par=abscissa_units.par,
                                                                       ordinates_quantity.par=ordinates_quantity.par,ordinates_units.par=ordinates_units.par,
                                                                       old_directory.par=old_directory.par,new_directory.par=new_directory.par,
                                                                       output_bool.par=output_bool.par,
                                                                       specific_subdirectory_string.par=specific_subdirectory_string.par,
                                                                       whitening_bool.par=whitening_bool.par,harmonic_bool.par=harmonic_bool.par,
                                                                       differencing_bool.par=differencing_bool.par,
                                                                       original_sampling_bool.par=original_sampling_bool.par,
                                                                       plot_sections_bool.par=plot_sections_bool.par,
                                                                       filter_diagnostics_bool.par=filter_diagnostics_bool.par,plot_bool.par=plot_bool.par,
                                                                       verbose.par=verbose.par)
  if(verbose.par==TRUE){
    cat("Total time for filtering = ")
    toc()
  }
  #Plot the downsampled version of the series.
  temp.full_decimated_ts_times<-temp.marshall_filter_single_section_object$out.full_decimated_ts_times
  temp.full_decimated_ts_values<-temp.marshall_filter_single_section_object$out.full_decimated_ts_values
  temp.num_filtered=length(temp.full_decimated_ts_times)
  step_size.par=max(1,floor(1/2/frequency_band.par[2]/(temp.full_decimated_ts_times[2]-temp.full_decimated_ts_times[1])))
  temp.decimation_indices<-seq(from=1,to=temp.num_filtered,by=step_size.par)
  temp.full_decimated_ts_times<-temp.full_decimated_ts_times[temp.decimation_indices]
  temp.full_decimated_ts_values<-temp.full_decimated_ts_values[temp.decimation_indices]
  if(plot_bool.par==TRUE){
    #Plotting.
    temp.x_list<-list(plotting.sampled_vector(temp.full_decimated_ts_times)-first_time.par)
    temp.y_list<-list(plotting.sampled_vector(temp.full_decimated_ts_values))
    plot.graph(temp.x_list,temp.y_list,
               x_label.par=paste(measured_abscissa.string,", in seconds since ",round(first_time.par/60,3)," minutes",sep=""),
               y_label.par=paste(measure_quantity.string,", in ",measure_units.string,sep=""),
               pdf_title.par=paste("Downsampled_",frequency_band.par[1],"_",frequency_band.par[2],"_Hz_Demodulate.pdf",sep=""))
  }
  temp.list<-list(out.full_decimated_ts_times=temp.full_decimated_ts_times,
                  out.full_decimated_ts_values=temp.full_decimated_ts_values)
  return(temp.list)
}





partitioned_series.function<-function(plotting_x1.par,plotting_y1.par,
                                      time_sequence_Marshall_MUA.par,
                                      num_trial_sections.par=1,
                                      measure_units_string.par="",
                                      abbreviated_time_units_string.par="",time_units_string.par="",
                                      pdf_title.par="Section_Series.pdf",
                                      plot_bool.par=FALSE){
  temp.min_plotting_x1=min(plotting_x1.par)
  temp.max_plotting_x1=max(plotting_x1.par)
  temp.trial_section_length=(temp.max_plotting_x1-temp.min_plotting_x1)/num_trial_sections.par
  temp.firing_sections_times_list<-list()
  temp.firing_sections_ordinates_list<-list()
  temp.running_trial_section_indices<-c()
  temp.counter=1
  for(temp.j in 1:num_trial_sections.par){
    temp.min_j=temp.min_plotting_x1+(temp.j-1)*temp.trial_section_length
    temp.max_j=temp.min_plotting_x1+temp.j*temp.trial_section_length
    temp.running_trial_section_indices<-which(plotting_x1.par>=temp.min_j & plotting_x1.par<temp.max_j)
    temp.section_second_time_sequence<-plotting_x1.par[temp.running_trial_section_indices]
    temp.section_second_diff_series<-plotting_y1.par[temp.running_trial_section_indices]
    temp.mean_j=mean(temp.section_second_diff_series)
    temp.diffs_j<-abs(temp.section_second_diff_series-temp.mean_j)
    if(!length(temp.section_second_time_sequence)){
      temp.firing_sections_times_list[[temp.counter]]<-0
      temp.firing_sections_ordinates_list[[temp.counter]]<-0
    } else{
      temp.firing_sections_times_list[[temp.counter]]<-temp.section_second_time_sequence
      temp.firing_sections_ordinates_list[[temp.counter]]<-temp.section_second_diff_series
    }
    temp.counter=temp.counter+1
  }
  if(plot_bool.par==TRUE){
    multipage_plot_comparison.function(x_plotting_list.par=temp.firing_sections_times_list,
                                       y_plotting_list.par=temp.firing_sections_ordinates_list,
                                       x_label.par=paste("Time, in ",abbreviated_time_units_string.par," since ",
                                                         round_general.function(time_sequence_Marshall_MUA.par[1])," ",time_units_string.par,sep=""),
                                       y_label.par=paste("Squared units of ",measure_units_string.par,", normalized to [0,1]",sep=""),
                                       types.par=c("h","h"),
                                       no_comparison_bool.par=TRUE,
                                       pdf_title.par=pdf_title.par)
  }
  temp.list<-list(out.firing_sections_times_list=temp.firing_sections_times_list,
                  out.firing_sections_ordinates_list=temp.firing_sections_ordinates_list)
  return(temp.list)
}













