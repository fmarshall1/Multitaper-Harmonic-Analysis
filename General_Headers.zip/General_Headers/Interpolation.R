#Francois Marshall, Boston University
#Header file for statistics functions.
###################################################################################################################

list_item_hard_replacement.function<-function(list.par){
  temp.num_list_elements=length(list.par)
  for(temp.i in 1:temp.num_list_elements){
    temp.list_element_i<-list.par[[temp.i]]
    if(typeof(temp.list_element_i)=="list"){
      list.par[[temp.i]]<-0
    }
    else if(is.null(temp.list_element_i)==TRUE){
      temp.list_element_i=0
      list.par[[temp.i]]<-temp.list_element_i
    }
    else{
      temp.NA_indices<-which(is.na(temp.list_element_i)==TRUE)
      if(length(temp.NA_indices)>0){
        temp.list_element_i[temp.NA_indices]<-0
        list.par[[temp.i]]<-temp.list_element_i
      }
      temp.NAN_indices<-which(is.nan(temp.list_element_i)==TRUE)
      if(length(temp.NAN_indices)>0){
        temp.list_element_i[temp.NAN_indices]<-0
        list.par[[temp.i]]<-temp.list_element_i
      }
    }
  }
  return(list.par)
}


interpolation_setup.function<-function(ts.par,outlier_indices.par,new_directory.par="Multitaper_F_Test",old_directory.par=""){
  temp.subDir_string<-paste(old_directory.par,"Interpolation/",sep="")
  dir.create(temp.subDir_string,showWarnings=FALSE)
  setwd(temp.subDir_string)
  temp.N=length(ts.par)
  temp.time_indices<-1:temp.N
  temp.num_outliers=length(outlier_indices.par)
  temp.neighbour_diffs<-rep(0,temp.num_outliers)
  for(temp.i in 1:temp.num_outliers){
    temp.diff=0
    if(temp.i==1){
      temp.diff=outlier_indices.par[2]-outlier_indices.par[1]
    }
    else if(temp.i==temp.num_outliers){
      temp.diff=outlier_indices.par[temp.num_outliers]-outlier_indices.par[temp.num_outliers-1]
    }
    else{
      temp.min=min(outlier_indices.par[temp.i]-outlier_indices.par[temp.i-1],outlier_indices.par[temp.i+1]-outlier_indices.par[temp.i])
      temp.diff=temp.min
    }
    temp.neighbour_diffs[temp.i]=temp.diff
  }
  outlier_indices.par<-outlier_indices.par[temp.neighbour_diffs==1]
  temp.num_outliers=length(outlier_indices.par)
  temp.outlier_start_time_indices<-c()
  temp.outlier_end_time_indices<-c()
  temp.outlier_gap_sizes<-c()
  temp.counter1_previous=1
  temp.counter1=1
  temp.counter2=1
  sink("Neighbours.txt", append=FALSE, split=FALSE)
  cat("gap_index\tprior_time\tprior\tpost_time\tpost\n")
  temp.running_counter=1
  while(temp.counter1<(temp.num_outliers-1) & temp.running_counter<1e3){
    if((outlier_indices.par[temp.counter1+1]-outlier_indices.par[temp.counter1])==1){
      temp.start_index=outlier_indices.par[temp.counter1]
      temp.outlier_start_time_indices[temp.counter2]=temp.start_index
      temp.end_index=temp.start_index
      while((outlier_indices.par[temp.counter1+1]-outlier_indices.par[temp.counter1])==1 & temp.counter1<(temp.num_outliers-1)){
        temp.end_index=temp.end_index+1
        temp.counter1=temp.counter1+1
      }
      temp.outlier_end_time_indices[temp.counter2]=temp.end_index
      temp.gap_size=temp.end_index-temp.start_index+1
      temp.outlier_gap_sizes[temp.counter2]=temp.gap_size
      temp.num_prior<-num.interpolation_sections*temp.gap_size
      #Construct the neighbour sets for the gap.
      temp.index1=temp.start_index-temp.num_prior
      temp.index2=temp.start_index-1
      #If the set of prior neighbours begins before the time of the first measurement, then the first prior neighbour is the one at the time
      #of the first measurement time.
      if(temp.index1<1){
        temp.index1=1
      }
      if(temp.index2<1){
        temp.index2=1
      }
      temp.prior_neighbours<-ts.par[temp.index1:temp.index2]
      temp.prior_time_indices<-temp.time_indices[temp.index1:temp.index2]
      #Repeat for the posterior neighbours.
      temp.index1=temp.end_index+1
      temp.index2=temp.end_index+temp.num_prior
      #If the set of posterior neighbours begins after the time of the last measurement, then the last prior neighbour is the one at the time
      #of the last measurement time.
      if(temp.index1>temp.N){
        temp.index1=temp.N
      }
      if(temp.index2>temp.N){
        temp.index2=temp.N
      }
      temp.post_neighbours<-ts.par[temp.index1:temp.index2]
      temp.post_time_indices<-temp.time_indices[temp.index1:temp.index2]
      temp.length_prior=length(temp.prior_neighbours)
      temp.length_post=length(temp.post_neighbours)
      if(temp.length_prior>temp.length_post){
        temp.prior_neighbours<-temp.prior_neighbours[(temp.length_prior-temp.length_post+1):temp.length_prior]
      }
      else if(temp.length_prior<temp.length_post){
        temp.post_neighbours<-temp.post_neighbours[1:temp.length_prior]
      }
      temp.num_prior=min(temp.length_prior,temp.length_post)
      for(temp.i in 1:temp.num_prior){
        cat(temp.counter2,"\t",temp.prior_time_indices[temp.i],"\t",temp.prior_neighbours[temp.i],"\t",temp.post_time_indices[temp.i],"\t",
            temp.post_neighbours[temp.i],"\n")
      }
      temp.counter1=temp.counter1+1
      temp.counter2=temp.counter2+1
    }
    if(temp.counter1==temp.counter1_previous){
      temp.counter1=temp.counter1+1
      temp.counter1_previous=temp.counter1
    }
    temp.running_counter=temp.running_counter+1
  }
  sink()
  setwd(old_directory.par)
}


linear.interpolation<-function(prior_time_indices.par,post_time_indices.par,prior_samples.par,post_samples.par,first_time.par,num_gap_lengths.par){
  temp.gap_indices<-(max(prior_time_indices.par)+1):(min(post_time_indices.par)-1)
  temp.gap_length=length(temp.gap_indices)
  temp.prior_times<-first_time.par+prior_time_indices.par
  temp.post_times<-first_time.par+post_time_indices.par
  temp.gap_start_time=max(temp.prior_times)+1
  temp.gap_end_time=min(temp.post_times)-1
  temp.gap_times<-first_time.par+temp.gap_indices
  #Linear interpolation of the gap using the two nearest neighbours.
  temp.num_in_average=num_gap_lengths.par*(temp.gap_end_time-temp.gap_start_time+1)
  temp.num_prior=length(prior_samples.par)
  temp.total_length=num_gap_lengths.par*temp.num_prior+temp.gap_length
  temp.time11=temp.num_prior-temp.num_in_average+1
  temp.time12=temp.num_prior
  if(temp.time11<1){
    temp.time11=1
  }
  if(temp.time12>temp.total_length){
    temp.time12=temp.total_length
  }
  temp.fitting_left_times<-min(temp.prior_times)+temp.time11:temp.time12-1
  temp.left_voltages_fit<-lm(prior_samples.par[temp.time11:temp.time12]~temp.fitting_left_times)
  temp.left_voltages_coefficients<-temp.left_voltages_fit$coefficients
  temp.left_voltages<-temp.left_voltages_coefficients[1]+temp.left_voltages_coefficients[2]*temp.prior_times
  temp.voltage1=temp.left_voltages[length(temp.prior_times)]
  temp.time21=1
  temp.time22=temp.gap_length
  temp.time21=1
  temp.time22=temp.gap_length
  if(temp.time22>temp.total_length){
    temp.time22=temp.total_length
  }
  temp.fitting_right_times<-max(temp.gap_times)+temp.time21:temp.time22
  temp.right_voltages_fit<-lm(post_samples.par[temp.time21:temp.time22]~temp.fitting_right_times)
  temp.right_voltages_coefficients<-temp.right_voltages_fit$coefficients
  temp.right_voltages<-temp.right_voltages_coefficients[1]+temp.right_voltages_coefficients[2]*temp.post_times
  temp.voltage2=temp.right_voltages[1]
  temp.lin_interp_slope=(temp.voltage2-temp.voltage1)/(min(temp.fitting_right_times)-max(temp.fitting_left_times))
  temp.lin_interp_intercept=temp.voltage1-temp.lin_interp_slope*max(temp.fitting_left_times)
  temp.gap_reconstruction0<-rep(0,temp.gap_length)
  for(i in 1:temp.gap_length){
    temp.gap_reconstruction0[i]=temp.lin_interp_intercept+temp.lin_interp_slope*temp.gap_times[i]
  }
  return(temp.gap_reconstruction0)
}



#Linear interpolation
linear.reconstruction<-function(neighbour_series1.par,neighbour_series2.par,gap_length.par){
  temp.num_prior=length(neighbour_series1.par)
  temp.num_post=length(neighbour_series2.par)
  temp.gap_start_time=temp.num_prior+1
  temp.gap_end_time=temp.num_prior+gap_length.par
  temp.num_in_average=min(temp.num_prior,gap_length.par)
  #Linear interpolation for a number of neighbours on the left side of the gap.
  temp.time11=max(1,temp.num_prior-temp.num_in_average+1)
  temp.time12=temp.num_prior
  temp.fitting_left_times<-temp.time11:temp.time12
  temp.left_voltages=neighbour_series1.par
  temp.voltage1=temp.left_voltages
  if(temp.num_prior>1){
    temp.left_fit<-lm(neighbour_series1.par[temp.fitting_left_times]~temp.fitting_left_times)
    temp.left_fit_coefficients<-temp.left_fit$coefficients
    temp.left_voltages<-temp.left_fit_coefficients[1]+temp.left_fit_coefficients[2]*temp.fitting_left_times
    temp.voltage1=temp.left_voltages[length(temp.fitting_left_times)]
  }
  #Repeat for right neighbours.
  temp.num_in_average=min(temp.num_post,gap_length.par)
  temp.time21=1
  temp.time22=temp.num_in_average
  temp.fitting_right_times<-temp.num_prior+gap_length.par+temp.time21:temp.time22
  temp.right_voltages=neighbour_series2.par
  temp.voltage2=temp.right_voltages
  if(temp.num_post>1){
    temp.right_fit<-lm(neighbour_series2.par[temp.time21:temp.time22]~temp.fitting_right_times)
    temp.right_fit_coefficients<-temp.right_fit$coefficients
    temp.right_voltages<-temp.right_fit_coefficients[1]+temp.right_fit_coefficients[2]*temp.fitting_right_times
    temp.voltage2=temp.right_voltages[1]
  }
  #Fill the gap.
  temp.time31=max(temp.fitting_left_times)+1
  temp.time32=min(temp.fitting_right_times)-1
  temp.fitting_gap_times<-temp.time31:temp.time32
  temp.slope=(temp.voltage2-temp.voltage1)/(min(temp.fitting_right_times)-max(temp.fitting_left_times))
  temp.intercept=temp.voltage1-temp.slope*max(temp.fitting_left_times)
  temp.gap_reconstruction<-rep(0,gap_length.par)
  for(i in 1:gap_length.par){
    temp.gap_reconstruction[i]=temp.intercept+temp.slope*temp.fitting_gap_times[i]
  }
  return(temp.gap_reconstruction)
}


linear_interpolation.function<-function(ts.par,new_directory.par="Multitaper_F_Test",old_directory.par="",first_time.par=0){
  temp.subDir_string<-paste(old_directory.par,"Interpolation/",sep="")
  dir.create(temp.subDir_string,showWarnings=FALSE)
  setwd(temp.subDir_string)
  temp.interpolation_data<-read.table("Neighbours.txt", header=TRUE)
  temp.gap_indices<-temp.interpolation_data$gap_index
  temp.prior_neighbour_series0<-temp.interpolation_data$prior
  temp.post_neighbour_series0<-temp.interpolation_data$post
  temp.prior_time_indices0<-temp.interpolation_data$prior_time
  temp.post_time_indices0<-temp.interpolation_data$post_time
  temp.prior_times<-first_time.par+temp.prior_time_indices0-1
  temp.post_times<-first_time.par+temp.post_time_indices0-1
  temp.num_gap_points=length(temp.gap_indices)
  temp.unique_gap_indices<-unique(temp.gap_indices)
  temp.N_gaps=length(temp.unique_gap_indices)
  temp.na_counter=0
  sink(paste(measure_quantity.string,"_Series_Pilot_Interpolation.txt",sep=""), append=FALSE, split=FALSE)
  cat("time_index\treconstruction\tgap_index\n")
  for(temp.i in 1:temp.N_gaps){
    temp.prior_time_indices<-temp.prior_time_indices0[temp.gap_indices==temp.i]
    temp.post_time_indices<-temp.post_time_indices0[temp.gap_indices==temp.i]
    temp.prior_neighbour_series<-temp.prior_neighbour_series0[temp.gap_indices==temp.i]
    temp.post_neighbour_series<-temp.post_neighbour_series0[temp.gap_indices==temp.i]
    temp.reconstruction<-linear.interpolation(temp.prior_time_indices,temp.post_time_indices,temp.prior_neighbour_series,
                                              temp.post_neighbour_series,first_time.par,num.interpolation_sections)
    for(temp.j in 1:length(temp.reconstruction)){
      temp.index=max(temp.prior_time_indices)+temp.j
      temp.reconstructed_voltage=temp.reconstruction[temp.j]
      #NA's appear when the gap size is only a single point because the linear.interpolation function does not properly account for this situation.
      if(is.na(temp.reconstructed_voltage)){
        temp.na_counter=temp.na_counter+1
        temp.slope=(temp.post_neighbour_series[1]-temp.prior_neighbour_series[1])/2
        temp.reconstructed_voltage=temp.prior_neighbour_series[1]+temp.slope
      }
      ts.par[temp.index]=temp.reconstructed_voltage
      cat(temp.index,"\t",temp.reconstructed_voltage,"\t",temp.i,"\n")
    }
  }
  sink()
}


trend_removed_interpolation.function<-function(ts.par,F_test_threshold.par=0.999,new_directory.par="Multitaper_F_Test",old_directory.par="",
                                               num_iterations.par=20){
  temp.subDir_string<-paste(main_directory.string,new_directory.par,sep="")
  dir.create(temp.subDir_string,showWarnings=FALSE)
  setwd(temp.subDir_string)
  temp.interpolation_data<-read.table("Neighbours.txt",header=TRUE)
  temp.gap_indices<-temp.interpolation_data$gap_index
  temp.prior_neighbour_series0<-temp.interpolation_data$prior
  temp.post_neighbour_series0<-temp.interpolation_data$post
  temp.prior_time_indices0<-temp.interpolation_data$prior_time
  temp.post_time_indices0<-temp.interpolation_data$post_time
  temp.unique_gap_indices<-unique(temp.gap_indices)
  temp.N_indices=max(temp.unique_gap_indices)
  #Determine the unique gap sizes.
  temp.gap_time_indices<-list()
  for(temp.i in 1:temp.N_indices){
    temp.prior_time_indices<-temp.prior_time_indices0[temp.gap_indices==temp.i]
    temp.start_index=max(temp.prior_time_indices)+1
    temp.post_time_indices<-temp.post_time_indices0[temp.gap_indices==temp.i]
    temp.end_index=min(temp.post_time_indices)-1
    temp.gap_time_indices[[temp.i]]<-temp.start_index:temp.end_index
  }
  temp.gap_time_indices<-unlist(temp.gap_time_indices)
  temp.gap_time_indices<-sort(temp.gap_time_indices)
  temp.num_prior_neighbours=length(temp.prior_time_indices0)
  temp.num_post_neighbours=length(temp.post_time_indices0)
  temp.num_zero_prior_neighbours=length(which(temp.prior_time_indices0==0))
  temp.num_zero_post_neighbours=length(which(temp.post_time_indices0==0))
  temp.reconstruction=NA
  if(temp.num_zero_prior_neighbours<temp.num_prior_neighbours & temp.num_zero_post_neighbours<temp.num_post_neighbours){
    cat("Reconstruction.\n")
    invisible({
      try({
      temp.reconstruction_object<-interpolate(ts.par,temp.gap_time_indices,maxit=num_iterations.par,progress=FALSE,sigClip=F_test_threshold.par,delT=1)
      temp.reconstruction<-temp.reconstruction_object[[1]]
      },silent=T)
    })
  }
  else if(is.na(temp.reconstruction)==TRUE){
    temp.reconstruction<-ts.par[temp.gap_time_indices]
  }
  temp.na_counter=0
  sink(paste(measure_quantity.string,"_Series_Pilot_Interpolation.txt",sep=""), append=FALSE, split=FALSE)
  cat("time_index\treconstruction\tgap_index\n")
  for(temp.i in 1:temp.N_indices){
    temp.prior_time_indices<-temp.prior_time_indices0[temp.gap_indices==temp.i]
    temp.min_gap_index=max(temp.prior_time_indices)+1
    temp.post_time_indices<-temp.post_time_indices0[temp.gap_indices==temp.i]
    temp.max_gap_index=min(temp.post_time_indices)-1
    temp.single_gap_indices<-temp.min_gap_index:temp.max_gap_index
    temp.prior_neighbour_series<-temp.prior_neighbour_series0[temp.gap_indices==temp.i]
    temp.post_neighbour_series<-temp.post_neighbour_series0[temp.gap_indices==temp.i]
    temp.gap_reconstruction<-temp.reconstruction[temp.single_gap_indices]
    for(temp.j in 1:length(temp.gap_reconstruction)){
      temp.index=max(temp.prior_time_indices)+temp.j
      temp.reconstructed_voltage=temp.reconstruction[temp.j]
      #NA's appear when the gap size is only a single point because the linear.interpolation function does not properly account for this situation.
      if(is.na(temp.reconstructed_voltage)){
        temp.na_counter=temp.na_counter+1
        temp.slope=(temp.post_neighbour_series[1]-temp.prior_neighbour_series[1])/2
        temp.reconstructed_voltage=temp.prior_neighbour_series[1]+temp.slope
      }
      ts.par[temp.index]=temp.reconstructed_voltage
      cat(temp.index,"\t",temp.reconstructed_voltage,"\t",temp.i,"\n")
    }
  }
  sink()
}


gn.mean_removed<-function(ts.par,M.par,slepian_sequences.par,neighbour_series1.par,neighbour_series2.par,Slepian_functions.par){
  temp.K=ncol(slepian_sequences.par)
  temp.NW=(temp.K-1)/2
  temp.mean_removed_object<-mean_removed.series(ts.par,temp.NW,slepian_sequences.par,Slepian_functions.par)
  temp.mean_estimate=temp.mean_removed_object$out.mean_estimate
  temp.variance_estimate=temp.mean_removed_object$out.process_variance
  temp.multitaper_spectrum<-temp.mean_removed_object$out.spectrum_estimate
  temp.neighbour_series1<-neighbour_series1.par-temp.mean_estimate
  temp.neighbour_series2<-neighbour_series2.par-temp.mean_estimate
  temp.list<-list(out.neighbour_series1=temp.neighbour_series1,
                  out.neighbour_series2=temp.neighbour_series2,
                  out.mean_estimate=temp.mean_estimate,
                  out.variance_estimate=temp.variance_estimate,
                  out.multitaper_spectrum=temp.multitaper_spectrum)
  return(temp.list)
}


gn.periodic_removed<-function(ts.par,eigencoeffs.par,slepian_functions.par,frequencies.par,concentrations.par,NW.par,verbose.par=FALSE){
  temp.N=length(ts.par)
  temp.M=nrow(eigencoeffs.par)
  temp.zero_index=temp.M/2
  temp.F_test_object<-multitaper_harmonic_F_test.function(eigencoeffs.par,frequencies.par,slepian_functions.par,temp.N,NW.par,verbose.par=verbose.par,
                                                          energy_concentrations.par=concentrations.par)
  temp.residual_ts_eigencoefficients<-temp.F_test_object$out.residual_eigencoefficients
  temp.significant_frequencies<-temp.F_test_object$out.significant_frequencies
  temp.significant_frequency_indices<-temp.F_test_object$out.significant_frequency_indices
  temp.harmonic_amplitudes<-temp.F_test_object$out.harmonic_amplitudes
  temp.harmonic_amplitudes<-temp.harmonic_amplitudes[temp.zero_index+temp.significant_frequency_indices-1]
  temp.num_harmonic_amplitudes=length(temp.harmonic_amplitudes)
  temp.residual_spectrum<-multitaper.regularized_spectrum(temp.residual_ts_eigencoefficients,frequencies.par,concentrations.par)
  temp.reconstructed_signal<-rep(0,temp.N)
  temp.residual_series<-ts.par
  if(temp.num_harmonic_amplitudes>0){
    for(temp.j in 1:temp.num_harmonic_amplitudes){
      temp.amplitude=temp.harmonic_amplitudes[temp.j]
      temp.frequency=temp.significant_frequencies[temp.j]
      temp.reconstructed_signal<-
        temp.reconstructed_signal+Mod(temp.amplitude)*cos(2*pi*temp.frequency*(1:temp.N-1)+atan2(Im(temp.amplitude),Re(temp.amplitude)))
    }
    temp.residual_series<-temp.residual_series-temp.reconstructed_signal
  }
  temp.list<-list(out.residual_series=temp.residual_series,
                  out.reconstructed_signal=temp.reconstructed_signal,
                  out.residual_spectrum=temp.residual_spectrum,
                  out.residual_ts_eigencoefficients=temp.residual_ts_eigencoefficients,
                  out.significant_frequencies=temp.significant_frequencies)
  return(temp.list)
}


gn.acrf<-function(spectrum.par){
  temp.gapped_acrs_object<-multitaper.acrs(spectrum.par,FALSE)
  temp.gapped_autocorrelations<-temp.gapped_acrs_object$temp.acrs
  return(temp.gapped_autocorrelations)
}


gn.reconstruction<-function(ts.par,num_prior.par,num_post.par,num_time_base.par,acrf.par){
  temp.N=length(ts.par)
  temp.gap_length=temp.N-num_prior.par-num_post.par
  temp.prior_indices<-(num_prior.par-num_time_base.par+1):num_prior.par
  temp.post_indices<-(num_prior.par+temp.gap_length+1):(num_prior.par+temp.gap_length+num_time_base.par)
  temp.acrf<-c(acrf.par,rep(0,temp.gap_length+max(length(temp.prior_indices),length(temp.post_indices))))
  temp.gap_indices<-(num_prior.par+1):(num_prior.par+temp.gap_length)
  temp.indices<-c(temp.prior_indices,temp.post_indices)
  if(max(temp.indices)>=temp.N){
    temp.min_index=max(min(min(temp.indices),temp.N-1),2)
  }
  else{
    temp.min_index=max(min(min(temp.indices),temp.N-1),1)
  }
  if(min(temp.indices)<1){
    temp.max_index=min(max(max(temp.indices),1),temp.N-1)
  }
  else{
    temp.max_index=min(max(max(temp.indices),1),temp.N)
  }
  temp.indices<-temp.min_index:temp.max_index
  #Using all the neighbours in the reconstruction.
  temp.num_coefficients=temp.gap_length
  temp.gamma_matrix<-matrix(0,nrow=temp.num_coefficients,ncol=temp.num_coefficients)
  temp.lags_matrix<-temp.gamma_matrix
  for(temp.k in 1:temp.num_coefficients){
    temp.lags<-abs(temp.gap_indices[temp.k]-temp.indices)+1
    temp.sorted_lags<-sort(temp.lags)
    temp.max_sorted_lag=temp.sorted_lags[temp.num_coefficients]
    temp.lags<-temp.lags[temp.lags<=temp.max_sorted_lag]
    temp.lags<-temp.lags[1:temp.num_coefficients]
    temp.lags_matrix[,temp.k]<-temp.lags
    temp.gamma_matrix[,temp.k]<-temp.acrf[temp.lags]
  }
  temp.gn_reconstruction<-rep(0,temp.gap_length)
  temp.det=det(temp.gamma_matrix)
  temp.indices2<-temp.gap_indices
  if(max(temp.indices2)>=temp.N){
    temp.min_index=max(min(min(temp.indices2),temp.N-1),2)
  }
  else{
    temp.min_index=max(min(min(temp.indices2),temp.N-1),1)
  }
  if(min(temp.indices2)<1){
    temp.max_index=min(max(max(temp.indices2),1),temp.N-1)
  }
  else{
    temp.max_index=min(max(max(temp.indices2),1),temp.N)
  }
  temp.indices2<-temp.min_index:temp.max_index
  temp.gn_reconstruction<-ts.par[temp.indices2]
  for(temp.j in 1:temp.num_coefficients){
    try({
      temp.rho_vector<-temp.gamma_matrix[temp.j,]
      temp.coefficients<-qr.solve(temp.gamma_matrix,temp.rho_vector)
      temp.ts_indices<-temp.lags_matrix[,temp.k]
      temp.point_reconstruction=sum(temp.coefficients*ts.par[num_time_base.par+temp.ts_indices-1])
      temp.gn_reconstruction[temp.j]=temp.point_reconstruction
    },silent=T)
  }
  return(temp.gn_reconstruction)
}


good_neighbours_interpolation.original<-function(neighbour_series1.par,neighbour_series2.par,slepian_sequences.par,slepian_functions.par,
                                                 concentrations.par,frequencies.par,num_neighbours.par=num.interpolation_sections,
                                                 linear_interpolation.bool=TRUE){
  temp.N=nrow(slepian_sequences.par)
  temp.K=ncol(slepian_sequences.par)
  temp.NW=(temp.K+1)/2
  temp.M=nrow(slepian_functions.par)
  temp.length1=length(neighbour_series1.par)
  temp.length2=length(neighbour_series2.par)
  temp.gap_length=temp.N-temp.length1-temp.length2
  temp.gap_indices<-1:temp.gap_length
  #Linear interpolation.
  temp.reconstruction0<-linear.reconstruction(neighbour_series1.par,neighbour_series2.par,temp.gap_length)
  #Subtract the mean from the neighbour series.
  temp.full_reconstruction0<-c(neighbour_series1.par,temp.reconstruction0[temp.gap_indices],neighbour_series2.par)
  temp.dpss_size=nrow(slepian_sequences.par)
  temp.reconstruction_size=length(temp.full_reconstruction0)
  temp.demeaned_object<-gn.mean_removed(temp.full_reconstruction0,temp.M,slepian_sequences.par,neighbour_series1.par,neighbour_series2.par,
                                        slepian_functions.par)
  temp.neighbour_series1<-temp.demeaned_object$out.neighbour_series1
  temp.neighbour_series2<-temp.demeaned_object$out.neighbour_series2
  temp.mean_estimate1=temp.demeaned_object$out.mean_estimate
  temp.variance_estimate1=temp.demeaned_object$out.variance_estimate
  temp.spectral_power_estimates<-temp.demeaned_object$out.multitaper_spectrum
  temp.series<-temp.full_reconstruction0-temp.mean_estimate1
  temp.eigencoeffs<-eigencoefficients(temp.series,slepian_sequences.par,temp.M)
  #Remove periodic components deemed significant by the harmonic F-test.
  temp.residual_object<-gn.periodic_removed(temp.series,temp.eigencoeffs,slepian_functions.par,frequencies.par,concentrations.par,temp.NW)
  temp.residual_series<-temp.residual_object$out.residual_series
  temp.reconstructed_harmonic_signal<-temp.residual_object$out.reconstructed_signal
  temp.residual_spectrum<-temp.residual_object$out.residual_spectrum
  temp.residual_eigenspectra<-temp.residual_object$out.residual_ts_eigencoefficients
  temp.F_spectrum<-temp.residual_object$out.significant_SNRs
  temp.significant_frequencies<-temp.residual_object$out.significant_frequencies
  #Noncausal AR-reconstruction of the gap.
  temp.num_time_base=num_neighbours.par*temp.gap_length
  temp.acrf<-gn.acrf(temp.residual_spectrum)
  temp.reconstruction2<-gn.reconstruction(temp.residual_series,temp.length1,temp.length2,temp.num_time_base,temp.acrf)
  temp.reconstruction2<-temp.reconstruction2+temp.reconstructed_harmonic_signal[temp.gap_indices]+temp.mean_estimate1
  temp.full_reconstruction2<-c(neighbour_series1.par,temp.reconstruction2,neighbour_series2.par)
  temp.list<-list(out.full_reconstruction2=temp.full_reconstruction2,
                  out.full_reconstruction0=temp.full_reconstruction0,
                  out.mean_estimate1=temp.mean_estimate1,
                  out.variance_estimate1=temp.variance_estimate1,
                  out.spectral_power_estimates=temp.spectral_power_estimates,
                  out.residual_spectrum=temp.residual_spectrum,
                  out.residual_series=temp.residual_series,
                  out.reconstructed_harmonic_signal=temp.reconstructed_harmonic_signal,
                  out.F_spectrum=temp.F_spectrum,
                  out.significant_frequencies=temp.significant_frequencies,
                  out.residual_spectrum=temp.residual_spectrum,
                  out.residual_eigenspectra=temp.residual_eigenspectra,
                  out.acrf=temp.acrf)
  return(temp.list)
}


gn_interpolation.function<-function(ts.par,interpolation_NW.par=3,sampling_rate.par=1,new_directory.par="Multitaper_F_Test",old_directory.par="",
                                    mdss_bool.par=FALSE,max_length.par=200){
  temp.mean=mean(ts.par)
  temp.N=length(ts.par)
  temp.interpolation_data<-read.table("Neighbours.txt",header=TRUE)
  temp.gap_indices<-temp.interpolation_data$gap_index
  temp.prior_time_indices0<-temp.interpolation_data$prior_time
  temp.post_time_indices0<-temp.interpolation_data$post_time
  temp.N_indices=max(temp.gap_indices)
  temp.unique_gap_indices<-unique(temp.gap_indices)
  #Determine the unique gap sizes.
  temp.unique_gap_lengths<-c()
  for(temp.i in 1:temp.N_indices){
    temp.prior_time_indices<-temp.prior_time_indices0[temp.gap_indices==temp.i]
    temp.start_index=max(temp.prior_time_indices)+1
    temp.post_time_indices<-temp.post_time_indices0[temp.gap_indices==temp.i]
    temp.end_index=min(temp.post_time_indices)-1
    temp.gap_series<-ts.par[temp.start_index:temp.end_index]
    temp.gap_length=length(temp.gap_series)+1
    temp.unique_gap_lengths[temp.i]=temp.gap_length
  }
  #Initialize parameters for the multitaper calculations.
  temp.MT_pars_object<-multitaper_parameters.function(temp.N,interpolation_NW.par,sampling_rate.par=sampling_rate.par,verbose.par=FALSE)
  temp.K=temp.MT_pars_object$out.K
  temp.M=temp.MT_pars_object$out.M
  temp.frequencies<-temp.MT_pars_object$out.frequencies
  #For each of the unique gap sizes, compute both the Slepian sequences and the gapped Slepian sequences.
  temp.gap_lengths<-sort(temp.unique_gap_lengths)
  #Don't use gap lengths for interpolation which exceed 200 samples.  Otherwise, increasing the computation time
  #by a significant fraction and removing too much information from the samples.
  temp.min_length=6 #Gap should have more than 5 missing samples.
  temp.gap_lengths<-temp.gap_lengths[temp.gap_lengths>=temp.min_length]
  max_length.par=max(max_length.par,min(temp.gap_lengths))
  temp.gap_lengths<-temp.gap_lengths[temp.gap_lengths<=max_length.par]
  temp.K=0
  temp.N_gap_lengths=length(temp.gap_lengths)
  temp.dpss_sizes<-rep(0,temp.N_gap_lengths)
  temp.M_values<-temp.dpss_sizes
  temp.frequencies_full_list<-list()
  temp.slepian_sequences_list<-list()
  temp.slepian_functions_list<-list()
  temp.energy_concentrations_list<-list()
  temp.MT_pars_object<-multitaper_parameters.function(5,interpolation_NW.par,sampling_rate.par=sampling_rate.par,verbose.par=FALSE)
  temp.K=temp.MT_pars_object$out.K
  for(temp.i in 1:temp.N_gap_lengths){
    #Construct the neighbour series.
    temp.prior_time_indices<-temp.prior_time_indices0[temp.gap_indices==temp.i]
    temp.start_index=max(temp.prior_time_indices)+1
    temp.post_time_indices<-temp.post_time_indices0[temp.gap_indices==temp.i]
    temp.end_index=min(temp.post_time_indices)-1
    temp.gap_series<-ts.par[temp.start_index:temp.end_index]
    temp.gap_length=length(temp.gap_series)
    temp.max_prior_index=max(temp.prior_time_indices)
    temp.num_prior=num.interpolation_sections*temp.gap_length
    temp.time11=temp.start_index-temp.num_prior
    temp.time12=temp.start_index-1
    temp.min_post_index=min(temp.post_time_indices)
    temp.time21=temp.end_index+1
    temp.time22=temp.end_index+temp.num_prior
    if(temp.gap_length>=temp.min_length & temp.gap_length<=max_length.par){
      #Error handling for time indices leading to prior or post neighbour sets outside the valid range of record indices.
      #If the set of prior neighbours begins before the time of the first measurement, then the first prior neighbour is the one at the time
      #of the first measurement time.
      if(temp.time11<1){
        temp.time11=1
      }
      if(temp.time22>temp.N){
        temp.time22=temp.N
      }
    }
    #temp.record_length=temp.time12-temp.time11+temp.time22-temp.time21+2+temp.gap_lengths[temp.i]
    temp.record_length=temp.time22-temp.time11+1
    temp.gap_indices1<-temp.time11:temp.time12
    temp.gap_indices2<-temp.time21:temp.time22
    #Ensure that each gap has at least three points, since the matrix dimension of the MDSS function requires three points minimum.
    if(length(temp.gap_indices1)==1){
      if(temp.gap_indices1<3){
        temp.time12=temp.gap_indices1+2
      }
      else{
        temp.time11=temp.gap_indices1-2
      }
    }
    if(length(temp.gap_indices2)==1){
      if(temp.gap_indices2>(temp.N-3)){
        temp.time21=temp.gap_indices2-2
      }
      else{
        temp.time22=temp.gap_indices2+2
      }
    }
    temp.gap_indices1<-temp.time11:temp.time12
    temp.gap_indices2<-temp.time21:temp.time22
    temp.nonzero_indices<-c(temp.gap_indices1,temp.gap_indices2)-temp.time11+1
    #Avoid re-computing the DPSS's by recycling ones used for previous gaps when those gaps have the same length as the current gap in question.
    temp.size_previous_instances<-which(temp.dpss_sizes==temp.record_length)
    temp.num_previous_size_instances=length(temp.size_previous_instances)
    temp.M=0
    if(temp.num_previous_size_instances>0){
      temp.index=temp.size_previous_instances[temp.num_previous_size_instances]
      temp.M=temp.M_values[temp.index]
      temp.frequencies_full_list[[temp.i]]<-temp.frequencies_full_list[[temp.index]]
      temp.slepian_sequences_list[[temp.i]]<-temp.slepian_sequences_list[[temp.index]]
      temp.energy_concentrations_list[[temp.i]]<-temp.energy_concentrations_list[[temp.index]]
    }
    else{
      temp.MT_pars_object<-multitaper_parameters.function(temp.record_length,interpolation_NW.par,sampling_rate.par=sampling_rate.par,verbose.par=FALSE)
      temp.M=temp.MT_pars_object$out.M
      temp.frequencies_full_list[[temp.i]]<-temp.MT_pars_object$out.frequencies
      if(!mdss_bool.par){
        temp.dpss_object<-dpss.matrix(temp.record_length,interpolation_NW.par,temp.K)
        temp.slepian_sequences_list[[temp.i]]<-temp.dpss_object$out.dpss
        temp.energy_concentrations_list[[temp.i]]<-temp.dpss_object$out.eigenvalues
      }
      else{
        temp.mdss_object<-mdss.function(temp.nonzero_indices,temp.record_length,interpolation_NW.par,temp.M)
        temp.slepian_sequences_list[[temp.i]]<-temp.mdss_object$out.mdss_matrix
        temp.energy_concentrations_list[[temp.i]]<-temp.mdss_object$out.eigenvalues
      }
    }
    temp.slepian_functions_list[[temp.i]]<-Slepian.functions(temp.slepian_sequences_list[[temp.i]],temp.M)
  }
  temp.pilot_estimates_dataset<-read.table(paste(measure_quantity.string,"_Series_Pilot_Interpolation.txt",sep=""),
                                           header=TRUE)
  temp.pilot_time_indices<-temp.pilot_estimates_dataset$time_index
  temp.pilot_reconstruction<-temp.pilot_estimates_dataset$reconstruction
  sink("GN_Interpolation.txt", append=FALSE, split=FALSE)
  cat("index\ttime_index\treconstruction\n")
  for(temp.i in 1:temp.N_gap_lengths){
    #Construct the neighbour series.
    temp.prior_time_indices<-temp.prior_time_indices0[temp.gap_indices==temp.i]
    temp.start_index=max(temp.prior_time_indices)+1
    temp.post_time_indices<-temp.post_time_indices0[temp.gap_indices==temp.i]
    temp.end_index=min(temp.post_time_indices)-1
    temp.gap_series<-ts.par[temp.start_index:temp.end_index]
    temp.gap_length=length(temp.gap_series)
    #Ensure that the gap length is in the desired range.
    if(temp.gap_length>=temp.min_length & temp.gap_length<=max_length.par){
      #Error handling for time indices leading to prior or post neighbour sets outside the valid range of record indices.
      temp.max_prior_index=max(temp.prior_time_indices)
      temp.num_prior=num.interpolation_sections*temp.gap_length
      temp.time11=temp.start_index-temp.num_prior
      temp.time12=temp.start_index-1
      #If the set of prior neighbours begins before the time of the first measurement, then the first prior neighbour is the one at the time
      #of the first measurement time.
      if(temp.time11<1){
        temp.time11=1
      }
      temp.prior_time_indices<-temp.time11:temp.time12
      temp.min_post_index=min(temp.post_time_indices)
      temp.time21=temp.end_index+1
      temp.time22=temp.end_index+temp.num_prior
      if(temp.time22>temp.N){
        temp.time22=temp.N
      }
      temp.post_time_indices<-temp.time21:temp.time22
      temp.num_prior=length(temp.prior_time_indices)
      temp.num_post=length(temp.post_time_indices)
      temp.num_training=temp.num_prior+temp.num_post
      if(temp.num_training>=temp.gap_lengths[temp.i]){
        temp.record_length=temp.time12-temp.time11+temp.time22-temp.time21+2+temp.gap_lengths[temp.i]
        temp.prior_neighbours<-ts.par[temp.prior_time_indices]
        temp.post_neighbours<-ts.par[temp.post_time_indices]
        #Select the set of windows corresponding to the length of the current gap.
        temp.gap_length_index=which(temp.gap_lengths==temp.gap_length)
        temp.frequencies<-temp.frequencies_full_list[[temp.i]]
        temp.slepian_sequences<-temp.slepian_sequences_list[[temp.i]]
        temp.slepian_functions<-temp.slepian_functions_list[[temp.i]]
        temp.energy_concentrations<-temp.energy_concentrations_list[[temp.i]]
        temp.reconstruction0_object<-good_neighbours_interpolation.original(temp.prior_neighbours,temp.post_neighbours,
                                                                            temp.slepian_sequences,temp.slepian_functions,
                                                                            temp.energy_concentrations,temp.frequencies)
        temp.reconstruction0<-temp.reconstruction0_object[[1]]
        for(temp.j in 1:temp.gap_length){
          temp.index=temp.max_prior_index+temp.j
          temp.reconstruction0_j=temp.reconstruction0[temp.j]
          if(is.na(temp.reconstruction0_j)==TRUE){
            temp.global_index=min(which(temp.pilot_time_indices==temp.index))
            temp.reconstruction0_j=temp.pilot_reconstruction[temp.global_index]
            ts.par[temp.index]=temp.reconstruction0_j
          }
          ts.par[temp.index]=temp.reconstruction0_j
          cat(temp.i,"\t",temp.index,"\t",temp.reconstruction0_j,"\n")
        }
      }
    }#endif
  }
  closeAllConnections()
  temp.interpolation_data<-read.table("GN_Interpolation.txt",header=TRUE)
  time.indices<-temp.interpolation_data$time_index
  interpolated.voltages<-temp.interpolation_data$reconstruction
  ts.par[time.indices]<-interpolated.voltages
  sink("Reconstructed_Series.txt", append=FALSE, split=FALSE)
  cat("voltage\n")
  for(temp.i in 1:temp.N){
    cat(ts.par[temp.i],"\n")
  }
  sink()
}


multitaper_interpolation.function<-function(ts.par,frequency_indices.par,new_directory.par="Interpolation/",old_directory.par="",
                                            measured_quantity.par="Measured quantity",F_test_threshold.par=0.999,ts_interp_bool.par=FALSE,
                                            mdss_bool.par=FALSE,num_iterations.par=20,first_time.par=0,sampling_rate.par=1,gn_bool.par=TRUE,
                                            max_length.par=200,main_directory.par=main_directory.string,
                                            method_directory_string.par="",new_directory2.par=""){
  ts.par<-TF_cleaning.function(TF.par=ts.par,0)$out.TF
  cat("Interpolation: ")
  tic()
  interpolation_setup.function(ts.par,frequency_indices.par,new_directory.par=new_directory.par,
                               old_directory.par=old_directory.par)
  sink()
  cat("Finished interpolation setup\n")
  temp.running_directory<-getwd()
  temp.subDir_string<-paste(main_directory.par,new_directory.par,sep="")
  if(strcmp(temp.subDir_string,paste(main_directory.string,"/Interpolation",sep=""))==TRUE){
    #https://stackoverflow.com/questions/10128617/test-if-characters-are-in-a-string
    if(!grepl(method_directory_string.par,new_directory2.par, fixed = TRUE)){
      temp.subDir_string<-paste(main_directory.string,new_directory2.par,"/",method_directory_string.par,"/Interpolation",sep="")
    } else{
      temp.subDir_string<-paste(main_directory.string,new_directory2.par,"/Interpolation",sep="")
    }
  }
  setwd(temp.subDir_string)
  temp.interpolation_data<-read.table("Neighbours.txt", header=TRUE)
  temp.gap_indices<-temp.interpolation_data$gap_index
  setwd(temp.running_directory)
  temp.log_power_spectrum<-c()
  if(length(temp.gap_indices)>0){
    if(!ts_interp_bool.par){
      linear_interpolation.function(ts.par,new_directory.par=new_directory.par,
                                    old_directory.par=old_directory.par,first_time.par=first_time.par)
    }
    else{
      trend_removed_interpolation.function(ts.par,F_test_threshold.par,new_directory.par=new_directory.par,
                                           old_directory.par=old_directory.par,
                                           num_iterations.par=num_iterations.par)
    }
    if(gn_bool.par==TRUE){
      gn_interpolation.function(ts.par,interpolation_NW.par=interpolation_NW.par,sampling_rate.par=sampling_rate.par,
                                new_directory.par=paste(source.directory,harmonic_analysis_directory_string.par,"Residual/",sep=""),
                                old_directory.par=old_directory.par,mdss_bool.par=mdss_bool.par,max_length.par=max_length.par)
      temp.interpolation_data<-read.table(paste(main_directory.string,new_directory.par,"Reconstructed_Series.txt",sep=""),header=TRUE)
      temp.log_power_spectrum<-temp.interpolation_data$voltage
    }
    else{
      temp.log_power_spectrum<-ts.par
    }
  }
  else{
    temp.log_power_spectrum<-ts.par
  }
  toc()
  setwd(old_directory.par)
  return(temp.log_power_spectrum)
}



multitaper_periodic_interpolation.function<-function(ts.par,measured_quantity.par="",
                                                     new_directory.par="",old_directory.par="",directory_string.par="",
                                                     first_time.par=0,
                                                     ts_interp_bool.par=FALSE,mdss_bool.par=FALSE,gn_bool.par=FALSE,
                                                     num_iterations.par=1,max_length.par=200,gap_indices.par=NA,
                                                     main_directory.par=main_directory.string,
                                                     method_directory_string.par="",
                                                     new_directory2.par=""){
  temp.N=length(ts.par)
  #Periodic extension to ensure that there are points before and after the period of the Fourier series captured by the record window.
  temp.periodic_interpolation_reconstruction<-c(ts.par,ts.par,ts.par)
  temp.fraction=1/12
  temp.missing_data_indices_vector<-c(1:floor(temp.N*temp.fraction),temp.N-rev(1:floor(temp.N*temp.fraction))+1)
  temp.missing_data_indices_vector<-c(temp.N-rev(1:floor(temp.N*temp.fraction))+1,temp.missing_data_indices_vector+temp.N,
                                      1:floor(temp.N*temp.fraction)+2*temp.N)
  if(!is.na(gap_indices.par)){
    temp.gap_indices_vector<-c(gap_indices.par,gap_indices.par+temp.N,gap_indices.par+2*temp.N)
    temp.missing_data_indices_vector<-c(temp.missing_data_indices_vector,temp.gap_indices_vector)
    temp.missing_data_indices_vector<-sort(temp.missing_data_indices_vector)
  }
  temp.periodic_interpolation_reconstruction[temp.missing_data_indices_vector]<-0
  temp.periodic_reconstruction_F_threshold=1-1/(temp.N-floor(temp.N*temp.fraction)*2)
  temp.cleaned_ts<-temp.periodic_interpolation_reconstruction
  if(!is.null(temp.missing_data_indices_vector)){
    temp.cleaned_ts<-multitaper_interpolation.function(temp.periodic_interpolation_reconstruction,temp.missing_data_indices_vector,
                                                       new_directory.par=new_directory.par,
                                                       old_directory.par=old_directory.par,
                                                       measured_quantity.par=measured_quantity.par,
                                                       F_test_threshold.par=temp.periodic_reconstruction_F_threshold,
                                                       ts_interp_bool.par=ts_interp_bool.par,mdss_bool.par=mdss_bool.par,
                                                       num_iterations.par=num_iterations.par,first_time.par=first_time.par,
                                                       gn_bool.par=gn_bool.par,max_length.par=max_length.par,
                                                       main_directory.par=main_directory.par,
                                                       method_directory_string.par=method_directory_string.par,
                                                       new_directory2.par=new_directory2.par)
  }
  temp.interpolation_dataset_string<-""
  if(!gn_bool.par){
    temp.interpolation_dataset_string<-paste(measured_quantity.par,"_Series_Pilot_Interpolation.txt",sep="")
  }
  else{
    temp.interpolation_dataset_string<-"Reconstructed_Series.txt"
  }
  temp.dataset<-read.table(paste(getwd(),"/Interpolation/",temp.interpolation_dataset_string,sep=""),header=TRUE)
  temp.time_indices<-temp.dataset$time_index
  temp.reconstructions<-temp.dataset$reconstruction
  temp.periodic_interpolation_reconstruction[temp.time_indices]<-temp.reconstructions
  ts.par<-temp.periodic_interpolation_reconstruction[1:temp.N+temp.N]
  temp.list<-list(out.reconstruction=ts.par)
  return(temp.list)
}


ends_interpolation.function<-function(ts.par,first_time.par=0,
                                      ts_interp_bool.par=FALSE,mdss_bool.par=FALSE,gn_bool.par=FALSE,
                                      num_iterations.par=1,max_length.par=200,
                                      main_directory_string.par="",directory_label.par="",old_directory.par="",new_directory.par="",
                                      revised_specific_directory_string.par="",
                                      measured_quantity.par="",
                                      main_directory.par=main_directory.string,
                                      method_directory_string.par=""){
  temp.revised_specific_directory_string<-paste(revised_specific_directory_string.par,directory_label.par,sep="")
  temp.working_directory_string<-paste(old_directory.par,directory_label.par,"/",sep="")
  setwd(temp.working_directory_string)
  temp.interpolation_string<-paste("Interpolation",sep="")
  temp.interpolation_analysis_directory_string<-paste(temp.revised_specific_directory_string,"/Interpolation",sep="")
  dir.create("Interpolation")#,recursive=TRUE,showWarnings=FALSE)
  setwd(temp.working_directory_string)
  temp.multitaper_periodic_interpolation_object<-multitaper_periodic_interpolation.function(ts.par=ts.par,
                                                                                            measured_quantity.par=measured_quantity.par,
                                                                                            new_directory.par=temp.interpolation_analysis_directory_string,
                                                                                            old_directory.par=temp.working_directory_string,
                                                                                            directory_string.par=temp.interpolation_analysis_directory_string,
                                                                                            first_time.par=first_time.par,
                                                                                            ts_interp_bool.par=ts_interp_bool.par,mdss_bool.par=mdss_bool.par,
                                                                                            gn_bool.par=gn_bool.par,
                                                                                            num_iterations.par=num_iterations.par,max_length.par=max_length.par,
                                                                                            main_directory.par=main_directory.par,
                                                                                            method_directory_string.par=method_directory_string.par,
                                                                                            new_directory2.par=new_directory.par)
  temp.cosine_reconstruction<-temp.multitaper_periodic_interpolation_object$out.reconstruction
  setwd(old_directory.par)
  return(temp.cosine_reconstruction)
}














