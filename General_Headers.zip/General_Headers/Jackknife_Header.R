#Francois Marshall, Boston University
#Header file for jackknife functions.
###################################################################################################################

delete.one_matrix<-function(k.par,matrix.par){
  temp.num_rows=nrow(matrix.par)
  temp.num_columns=ncol(matrix.par)
  temp.matrix<-matrix(0,nrow=temp.num_rows,ncol=temp.num_columns-1)
  if(k.par==1){
    temp.matrix<-matrix.par[,2:temp.num_columns]
  }
  else if(k.par==temp.num_columns){
    temp.matrix<-matrix.par[,1:(temp.num_columns-1)]
  }
  else{
    temp.matrix<-cbind(matrix.par[,1:(k.par-1)],matrix.par[,(k.par+1):temp.num_columns])
  }
  return(temp.matrix)
}

delete_one.regularized_spectrum<-function(k.par,eigenspectra.par,frequencies.par,concentrations.par){
  temp.num_columns=ncol(eigenspectra.par)
  temp.concentrations<-c()
  if(k.par==1){
    temp.concentrations<-concentrations.par[2:temp.num_columns]
  }
  else if(k.par==temp.num_columns){
    temp.concentrations<-concentrations.par[1:(temp.num_columns-1)]
  }
  else{
    temp.concentrations<-c(concentrations.par[1:(k.par-1)],concentrations.par[(k.par+1):temp.num_columns])
  }
  temp.matrix<-delete.one_matrix(k.par,eigenspectra.par)
  temp.spectrum<-multitaper.regularized_spectrum(temp.matrix,frequencies.par,temp.concentrations)
  temp.spectrum<-Mod(temp.spectrum)
  return(temp.spectrum)
}

delete.one_spectrum<-function(k.par,eigenspectra.par,concentrations.par){
  temp.num_columns=ncol(eigenspectra.par)
  if(k.par==1){
    temp.concentrations<-concentrations.par[2:temp.num_columns]
  }
  else if(k.par==temp.num_columns){
    temp.concentrations<-concentrations.par[1:(temp.num_columns-1)]
  }
  else{
    temp.concentrations<-c(concentrations.par[1:(k.par-1)],concentrations.par[(k.par+1):temp.num_columns])
  }
  temp.matrix<-delete.one_matrix(k.par,eigenspectra.par)
  temp.spectrum<-multitaper.weighted_spectrum(temp.matrix,temp.concentrations)
  return(temp.spectrum)
}

delete_one.average_spectrum<-function(k.par,eigenspectra.par){
  temp.matrix<-delete.one_matrix(k.par,eigenspectra.par)
  temp.spectrum<-multitaper.average_spectrum(temp.matrix)
  return(temp.spectrum)
}

delete_one.F_statistic_spectrum<-function(indices.par,k.par,eigencoefficients.par,Slepian_function.par,num_diffs.par=0){
  temp.num_columns=ncol(eigencoefficients.par)
  temp.eigencoefficient_matrix<-delete.one_matrix(k.par,eigencoefficients.par)
  temp.slepian_function_matrix<-delete.one_matrix(k.par,Slepian_function.par)
  temp.F_statistic_spectrum<-sapply(indices.par,single_F_statistic.function,temp.eigencoefficient_matrix,temp.slepian_function_matrix,num_diffs.par)
  return(temp.F_statistic_spectrum)
}


jackknife.regularized_spectrum<-function(eigencoefficients.par,frequencies.par,concentrations.par){
  temp.M=nrow(eigencoefficients.par)
  temp.M2=temp.M/2+1
  temp.num_columns=ncol(eigencoefficients.par)
  delete_one.spectra<-matrix(0,nrow=temp.M2,ncol=temp.num_columns)
  for(temp.k in 1:temp.num_columns){
    temp.delete_one_spectrum<-delete_one.regularized_spectrum(temp.k,eigencoefficients.par,frequencies.par,concentrations.par)
    delete_one.spectra[,temp.k]<-temp.delete_one_spectrum
  }
  temp.log_spectra<-log(delete_one.spectra)
  temp.log_averages<-rowMeans(temp.log_spectra)
  temp.difference_matrix<-sweep(temp.log_spectra,MARGIN=1,temp.log_averages,FUN="-")
  temp.log_variances<-(temp.num_columns-1)*rowMeans(temp.difference_matrix^2)
  temp.dt<-data.frame(temp.log_averages,temp.log_variances)
  return(temp.dt)
}


jackknife.F_spectrum<-function(eigencoefficients.par,frequency_indices.par,frequencies.par,F_spectrum.par,bandwidth_index_spacing.par,
                               Slepian_function.par,sampling_rate.par=1,training_size.par=5,Rsq_threshold.par=0.95,
                               Kolmogorov_percentile.par=0,TPT_threshold.par=0,outlier_percentile.par=0.99,num_diffs.par=0){
  temp.M=nrow(eigencoefficients.par)
  temp.M2=temp.M/2+1
  temp.num_frequencies=length(frequency_indices.par)
  temp.frequencies<-frequencies.par[frequency_indices.par]
  temp.num_columns=ncol(eigencoefficients.par)
  temp.training_size=2*bandwidth_index_spacing.par+1
  temp.num_bands=max(1,floor(temp.num_frequencies/temp.training_size))
  temp.training_indices<-1:temp.training_size
  temp.delete_one_frequencies<-matrix(0,temp.num_bands,temp.num_columns)
  temp.delete_one_inverted_SNRs<-temp.delete_one_frequencies
  temp.delete_one_line_Rsqs<-temp.delete_one_frequencies
  temp.delete_one_line_TPTs<-temp.delete_one_frequencies
  temp.delete_one_line_KS<-temp.delete_one_frequencies
  temp.delete_one_Rsqs<-temp.delete_one_frequencies
  temp.delete_one_TPTs<-temp.delete_one_frequencies
  temp.delete_one_KS<-temp.delete_one_frequencies
  temp.delete_one_ndiffs<-temp.delete_one_frequencies
  temp.delete_one_nout<-temp.delete_one_frequencies
  temp.quadratic_training_sizes<-temp.delete_one_frequencies
  temp.derivatives1<-temp.delete_one_frequencies
  temp.derivatives2<-temp.delete_one_frequencies
  temp.all_fitted_values_list<-list()
  temp.all_frequencies_list<-list()
  for(temp.k in 1:temp.num_columns){
    temp.fitted_values_list<-list()
    temp.sizes_list<-list()
    temp.frequencies_list<-list()
    temp.SNRs<-delete_one.F_statistic_spectrum(frequency_indices.par,temp.k,eigencoefficients.par,Slepian_function.par,num_diffs.par)
    temp.counter=1
    for(temp.j in seq(from=1,to=temp.num_frequencies,by=temp.training_size)){
      if(temp.counter<=temp.num_bands){
        temp.select_frequencies<-temp.frequencies[temp.j+temp.training_indices-1]
        temp.training_SNR<-temp.SNRs[temp.j+temp.training_indices-1]
        temp.F_reconstruction_object<-F_peak_reconstruction.function(temp.training_indices,temp.training_SNR,temp.select_frequencies,
                                                                     training_size.par=training_size.par,Rsq_threshold.par=Rsq_threshold.par,
                                                                     Kolmogorov_percentile.par=Kolmogorov_percentile.par,
                                                                     TPT_threshold.par=TPT_threshold.par,outlier_percentile.par=outlier_percentile.par)
        temp.derivatives<-temp.F_reconstruction_object$out.derivatives
        temp.derivative1=temp.derivatives[1]
        temp.derivative2=temp.derivatives[2]
        temp.derivatives1[temp.counter,temp.k]=temp.derivative1
        temp.derivatives2[temp.counter,temp.k]=temp.derivative2
        temp.quadratic_training_size=temp.F_reconstruction_object$out.training_size
        temp.quadratic_training_sizes[temp.counter,temp.k]=temp.quadratic_training_size
        temp.index=temp.j+temp.F_reconstruction_object$out.median-1
        #Debugging for the indices to avoid ends overshoots.
        temp.index=round(temp.index)
        temp.index=max(1,temp.index)
        temp.index=min(temp.num_frequencies,temp.index)
        #Read in the relevant frequency estimate.
        temp.frequency=temp.frequencies[temp.index]
        temp.delete_one_frequencies[temp.counter,temp.k]=temp.frequency
        #Only update the relevant matrices if the fit parabola is concave up.  For the frequencies vector, this is fixed further down the code.
        if(temp.derivative1<0 & temp.derivative2>0){
          temp.n_diffs=temp.F_reconstruction_object$out.ndiffs
          temp.delete_one_ndiffs[temp.counter,temp.k]=temp.n_diffs
          temp.num_outliers=temp.F_reconstruction_object$out.num_outliers
          temp.delete_one_nout[temp.counter,temp.k]=temp.num_outliers
          #Read in the line-reconstruction statistics.
          temp.line_Rsq_value=temp.F_reconstruction_object$out.line_Rsq
          temp.line_TPT_value=temp.F_reconstruction_object$out.line_TPT_percentile
          temp.line_KS_value=temp.F_reconstruction_object$out.line_KS_percentile
          temp.delete_one_line_Rsqs[temp.counter,temp.k]=temp.line_Rsq_value
          temp.delete_one_line_TPTs[temp.counter,temp.k]=temp.line_TPT_value
          temp.delete_one_line_KS[temp.counter,temp.k]=temp.line_KS_value
          #Read in the parabola-reconstruction statistics.
          temp.Rsq_value=temp.F_reconstruction_object$out.Rsq
          temp.TPT_value=temp.F_reconstruction_object$out.TPT_percentile
          temp.KS_value=temp.F_reconstruction_object$out.KS_percentile
          temp.delete_one_Rsqs[temp.counter,temp.k]=temp.Rsq_value
          temp.delete_one_TPTs[temp.counter,temp.k]=temp.TPT_value
          temp.delete_one_KS[temp.counter,temp.k]=temp.KS_value
        }
        #Read in the fitted-value details for the visual diagnostic plots.
        temp.training_frequencies<-temp.F_reconstruction_object$out.frequencies
        temp.fitted_values<-temp.F_reconstruction_object$out.fitted_values
        temp.fitted_values_list[[temp.counter]]<-temp.fitted_values
        temp.frequencies_list[[temp.counter]]<-temp.training_frequencies*sampling_rate.par
        temp.counter=temp.counter+1
      }
    }
    temp.all_fitted_values_list[[temp.k]]<-temp.fitted_values_list
    temp.all_frequencies_list[[temp.k]]<-temp.frequencies_list
  }
  temp.frequencies<-temp.frequencies*sampling_rate.par
  #Frequency calculations.
  temp.frequency_averages<-rep(0,temp.num_bands)
  temp.num_jk<-temp.frequency_averages
  for(temp.j in 1:temp.num_bands){
    temp.correct_indices1<-which(temp.derivatives1[temp.j,]<0)
    temp.correct_indices2<-which(temp.derivatives2[temp.j,]>0)
    temp.correct_indices<-c(temp.correct_indices1,temp.correct_indices2)
    temp.correct_indices<-unique(temp.correct_indices)
    temp.correct_indices<-sort(temp.correct_indices)
    temp.num_correct_indices=length(temp.correct_indices)
    if(temp.num_correct_indices>0){
      temp.frequency_averages[temp.j]<-sum(temp.delete_one_frequencies[temp.j,temp.correct_indices])/temp.num_correct_indices
      temp.num_jk[temp.j]=temp.num_correct_indices
    }
  }
  temp.frequency_variances<-rep(0,temp.num_bands)
  for(temp.j in 1:temp.num_bands){
    temp.correct_indices1<-which(temp.derivatives1[temp.j,]<0)
    temp.correct_indices2<-which(temp.derivatives2[temp.j,]>0)
    temp.correct_indices<-c(temp.correct_indices1,temp.correct_indices2)
    temp.correct_indices<-unique(temp.correct_indices)
    temp.correct_indices<-sort(temp.correct_indices)
    temp.num_correct_indices=length(temp.correct_indices)
    if(temp.num_correct_indices>0){
      temp.frequency_variances[temp.j]<-crossprod(temp.delete_one_frequencies[temp.j,temp.correct_indices]-temp.frequency_averages[temp.j])/
        temp.num_correct_indices
    }
  }
  temp.frequency_averages<-temp.frequency_averages*sampling_rate.par
  temp.frequency_variances<-temp.frequency_variances*sampling_rate.par^2
  #R-squared calculations.
  temp.line_Rsqs_matrix<-min_median_max.function(temp.delete_one_line_Rsqs)
  temp.line_TPTs_matrix<-min_median_max.function(temp.delete_one_line_TPTs)
  temp.line_KS_matrix<-min_median_max.function(temp.delete_one_line_KS)
  temp.Rsqs_matrix<-min_median_max.function(temp.delete_one_Rsqs)
  temp.TPTs_matrix<-min_median_max.function(temp.delete_one_TPTs)
  temp.KS_matrix<-min_median_max.function(temp.delete_one_KS)
  temp.list<-list(out.frequency_averages=temp.frequency_averages,
                  out.frequency_variances=temp.frequency_variances,
                  out.all_frequencies=temp.all_frequencies_list,
                  out.all_fitted_values=temp.all_fitted_values_list,
                  out.line_Rsqs_matrix=temp.line_Rsqs_matrix,
                  out.line_TPTs_matrix=temp.line_TPTs_matrix,
                  out.line_KS_matrix=temp.line_KS_matrix,
                  out.Rsqs_matrix=temp.Rsqs_matrix,
                  out.TPTs_matrix=temp.TPTs_matrix,
                  out.KS_matrix=temp.KS_matrix,
                  out.delete_one_ndiffs=temp.delete_one_ndiffs,
                  out.delete_one_nout=temp.delete_one_nout,
                  out.quadratic_training_sizes=temp.quadratic_training_sizes,
                  out.frequencies=temp.frequencies,
                  out.derivatives1=temp.derivatives1,
                  out.derivatives2=temp.derivatives2,
                  out.num_jk=temp.num_jk)
  return(temp.list)
}


jackknife.variance<-function(matrix.par,concentrations.par){
  temp.num_rows=nrow(matrix.par)
  temp.num_columns=ncol(matrix.par)
  delete_one.spectra<-matrix(0,nrow=temp.num_rows,ncol=temp.num_columns)
  for(k in 1:temp.num_columns){
    delete_one.spectra[,k]<-delete.one_spectrum(k,matrix.par,concentrations.par)
  }
  temp.log_spectra<-log(delete_one.spectra)
  temp.log_averages<-rowMeans(temp.log_spectra)
  temp.difference_matrix<-sweep(temp.log_spectra,MARGIN=1,temp.log_averages,FUN="-")
  temp.log_variances<-rowMeans(temp.difference_matrix^2)
  temp.dt<-data.frame(temp.log_averages,temp.log_variances)
  return(temp.dt)
}

jackknife.average_spectrum_variance<-function(matrix.par){
  temp.num_rows=nrow(matrix.par)
  temp.num_columns=ncol(matrix.par)
  delete_one.spectra<-matrix(0,nrow=temp.num_rows,ncol=temp.num_columns)
  for(k in 1:temp.num_columns){
    delete_one.spectra[,k]<-delete_one.average_spectrum(k,matrix.par)
  }
  temp.log_spectra<-log(delete_one.spectra)
  temp.log_averages<-rowMeans(temp.log_spectra)
  temp.difference_matrix<-sweep(temp.log_spectra,MARGIN=1,temp.log_averages,FUN="-")
  temp.log_variances<-(temp.num_columns-1)*rowMeans(temp.difference_matrix^2)
  temp.dt<-data.frame(temp.log_averages,temp.log_variances)
  return(temp.dt)
}

jackknife.regularized_spectrum_bounds<-function(eigencoefficients.par,frequencies.par,concentrations.par,
                                                plot.par=FALSE,measured_quantity.par="",units.par1="units",units.par2="units",sampling_rate.par=1,
                                                cepstral_bool.par=FALSE){
  temp.M=nrow(eigencoefficients.par)
  temp.num_columns=ncol(eigencoefficients.par)
  temp.jackknife_object<-jackknife.regularized_spectrum(eigencoefficients.par,frequencies.par,concentrations.par)
  temp.quantile=qt(1-alpha.par/2,temp.num_columns-1)
  temp.log_avgs<-temp.jackknife_object$temp.log_averages
  temp.log_vars<-temp.jackknife_object$temp.log_variances
  temp.log_sigmas<-sqrt(temp.log_vars)
  temp.log_LB<-temp.log_avgs-temp.quantile*temp.log_sigmas
  temp.log_UB<-temp.log_avgs+temp.quantile*temp.log_sigmas
  temp.y_plotting_LB=0
  temp.y_plotting_UB=0
  if(plot.par==TRUE){
    temp.abscissa_string<-"Frequency"
    if(cepstral_bool.par==TRUE){
      temp.abscissa_string<-"Quefrency"
    }
    temp.log.frequencies<-log10(frequencies.par[frequencies.par>0]*sampling_rate.par)
    temp.log_cyclic_spectrum<-log10(exp(1))*temp.log_avgs[frequencies.par>0]
    temp.plotting_LB<-log10(exp(1))*temp.log_LB[frequencies.par>0]
    temp.plotting_UB<-log10(exp(1))*temp.log_UB[frequencies.par>0]
    temp.y_plotting_LB=min(temp.plotting_LB)
    temp.y_plotting_UB=max(temp.plotting_UB)
    #Plot the spectral-power estimates.
    temp.second_title_substring<-"_Jackknife_Spectral_Power_Estimates.pdf"
    temp.PDF_title_string<-paste(measured_quantity.par,temp.second_title_substring,sep="")
    temp.x_label_string<-paste(temp.abscissa_string,", in ",units.par1,sep="")
    temp.y_label_string<-paste(str_remove(measured_quantity.par,"Residual_")," spectral power, in squared ",units.par2," per ",abbreviated_frequency_units.string,sep="")
    if(cepstral_bool.par==TRUE){
      temp.y_label_string<-paste(str_remove(measured_quantity.par,"Residual_")," cepstral power, in quad ",units.par2," per ",abbreviated_frequency_units.string,sep="")
    }
    plot_graph.confidence_intervals(temp.log.frequencies,temp.log_cyclic_spectrum,temp.plotting_LB,temp.plotting_UB,temp.x_label_string,
                                    temp.y_label_string,"",temp.PDF_title_string,log_bool.par=TRUE)
  }
  temp.dt<-list(out.averages=temp.log_avgs,
                out.log_LB=temp.log_LB,
                out.log_UB=temp.log_UB,
                out.plotting_LB=temp.y_plotting_LB,
                out.plotting_UB=temp.y_plotting_UB)
  return(temp.dt)
}

jackknife.bounds<-function(matrix.par,alpha.par){
  temp.num_columns=ncol(matrix.par)
  temp.jackknife_object<-jackknife.variance(matrix.par,concentrations.par)
  temp.quantile=qt(1-alpha.par/2,temp.num_columns-1)
  temp.log_avgs<-temp.jackknife_object$temp.log_averages
  temp.log_vars<-temp.jackknife_object$temp.log_variances
  temp.log_sigmas<-sqrt(temp.log_vars)
  temp.log_LB<-temp.log_avgs-temp.quantile*temp.log_sigmas
  temp.log_UB<-temp.log_avgs+temp.quantile*temp.log_sigmas
  temp.LB<-exp(temp.log_LB)
  temp.UB<-exp(temp.log_UB)
  temp.dt<-data.frame(temp.log_avgs,temp.LB,temp.UB,temp.log_LB,temp.log_UB)
  return(temp.dt)
}

jackknife.average_spectrum_bounds<-function(matrix.par,alpha.par){
  temp.num_columns=ncol(matrix.par)
  temp.jackknife_object<-jackknife.average_spectrum_variance(matrix.par)
  temp.quantile=qt(1-alpha.par/2,temp.num_columns-1)
  temp.log_avgs<-temp.jackknife_object$temp.log_averages
  temp.log_vars<-temp.jackknife_object$temp.log_variances
  temp.log_sigmas<-sqrt(temp.log_vars)
  temp.log_LB<-temp.log_avgs-temp.quantile*temp.log_sigmas
  temp.log_UB<-temp.log_avgs+temp.quantile*temp.log_sigmas
  temp.LB<-exp(temp.log_LB)
  temp.UB<-exp(temp.log_UB)
  temp.dt<-data.frame(temp.log_avgs,temp.LB,temp.UB,temp.log_LB,temp.log_UB)
  return(temp.dt)
}












wrapped.phase<-function(phase.par){
  temp.num_pi=abs(floor(phase.par/pi))
  temp.wrapped_phase=0
  if(phase.par>0){
    temp.wrapped_phase=phase.par-temp.num_pi*pi
  }
  else{
    temp.wrapped_phase=phase.par+temp.num_pi*pi
  }
  return(temp.wrapped_phase-pi/2)
}






