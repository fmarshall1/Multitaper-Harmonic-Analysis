#Francois Marshall, Boston University
#Main header file for multitaper spectral analysis.
###################################################################################################################
#Define global variables.
w.factor<<-1.2

#Load basic source files.
source(paste(starting.directory,"Tapers_Header.R",sep=""))
source(paste(starting.directory,"Spectral_Analysis_Header.R",sep=""))
source(paste(starting.directory,"Harmonic_Analysis_Header.R",sep=""))
source(paste(starting.directory,"Decimation.R",sep=""))
source(paste(starting.directory,"Log_Spectrum.R",sep=""))

multitaper_parameters.function<-function(N.par,NW.par=5,K.par=0,sampling_rate.par=1,M_exponent.par=1,cepstral_bool.par=FALSE,verbose.par=TRUE){
  temp.K=K.par
  if(!K.par){
    temp.K=2*NW.par-1
  }
  if(temp.K<1){
    temp.K=1
  }
  temp.M_exponent=M_exponent.par
  temp.M=2^(ceiling(log2(N.par))+temp.M_exponent)
  temp.M=temp.M+temp.M%%2
  temp.M_2=temp.M/2+1
  temp.zero_index=temp.M/2
  temp.frequency_spacing=sampling_rate.par/temp.M
  if(verbose.par==TRUE){
    cat("N = ",N.par,"\n")
    cat("NW = ",NW.par,"\n")
    cat("M = ",temp.M,"\n")
    if(cepstral_bool.par==TRUE){
      cat("Quefrency spacing = ",temp.frequency_spacing,frequency_units.string,"\n")
    }
    else{
      cat("Frequency spacing = ",temp.frequency_spacing,frequency_units.string,"\n")
    }
  }
  #Compute the FFT-frequencies and the associated log-transformed frequencies.
  temp.frequency_obj<-frequencies.principle_domain(temp.M)
  temp.frequencies_full<-temp.frequency_obj$temp.frequencies1
  temp.frequencies<-non_negative.principle_domain(temp.frequencies_full)
  temp.log.frequencies<-log10(temp.frequencies[temp.frequencies>0]*sampling_rate.par)
  temp.list<-list(out.K=temp.K,
                  out.M=temp.M,
                  out.M_2=temp.M_2,
                  out.zero_index=temp.zero_index,
                  out.frequency_spacing=temp.frequency_spacing,
                  out.frequencies=temp.frequencies,
                  out.all_frequencies=temp.frequencies_full,
                  out.log_frequencies=temp.log.frequencies)
  return(temp.list)
}

DPSW_eigenvalue_asymptotic_upper_bound.function<-function(bandlimitation_energy_value.par,timelimitation_ISE.par){
  temp.delta=0.5*(bandlimitation_energy_value.par-timelimitation_ISE.par)^2/(bandlimitation_energy_value.par+timelimitation_ISE.par)^2
  temp.b_value=log(1/temp.delta-1)/pi
  temp.upper_bound=1/(1+exp(pi*temp.b_value))+temp.delta
  return(temp.upper_bound)
}

bandlimitation_ISE_quadratic.function<-function(index.par,eigenvalues.par,W.par,timelimitation_ISE.par=8){
  temp.quadratic_coefficients<-rep(0,3)
  temp.select_eigenvalue=eigenvalues.par[index.par]
  temp.quadratic_coefficients[1]=1-1/temp.select_eigenvalue
  temp.quadratic_coefficients[2]=2*timelimitation_ISE.par*(1+1/temp.select_eigenvalue)
  temp.quadratic_coefficients[3]=timelimitation_ISE.par^2*temp.quadratic_coefficients[1]
  temp.quadratic_roots_vector<-quadratic_formula_roots.function(quadratic_coefficients.par=temp.quadratic_coefficients)
  temp.energies_vector<-temp.quadratic_roots_vector*W.par
  temp.normalized_energies<-temp.energies_vector/W.par
  #Set to an unfeasible zero flag value the unfeasible energy bounds less than those of the timelimitation bounds.
  temp.energies_vector[(temp.normalized_energies)<=timelimitation_ISE.par]<-0
  #Set to an unfeasible zero flag value the unfeasible energy bounds yielding an upper eigenvalue bound falling below an entry of eigenvalues.par
  for(temp.i in 1:2){
    temp.energy_value=temp.energies_vector[temp.i]
    if(temp.energy_value!=0){
      temp.upper_bound=
        DPSW_eigenvalue_asymptotic_upper_bound.function(bandlimitation_energy_value.par=temp.energy_value,timelimitation_ISE.par=timelimitation_ISE.par)
      if(temp.upper_bound<temp.select_eigenvalue){
        temp.energies_vector[temp.i]=0
      }
    }
  }
  return(temp.energies_vector)
}

bandlimitation_ISE_analysis.function<-function(N.par,W.par,
                                               gl_node_number.par=32,nodes_multiple.par=1,verbose.par=FALSE){
  #Compute the PSWF's at the nodes of the Gauss-Legendre integral.
  temp.NW=N.par*W.par
  temp.K=2*temp.NW-1
  temp.num_PSWF_vectors=2*temp.K
  temp.num_nodes=max(nodes_multiple.par*gl_node_number.par,temp.num_PSWF_vectors)
  temp.num_PSWF_vectors=min(temp.num_PSWF_vectors,temp.num_nodes)
  temp.PSWF_object<-continuous.prolates(N.par,W.par,temp.num_nodes,K.par=temp.num_PSWF_vectors)
  temp.PSWF_eigenvalues<-temp.PSWF_object$out.eigenvalues
  temp.PSWF_eigenvalues<-temp.PSWF_eigenvalues[temp.PSWF_eigenvalues>0]
  temp.num_PSWF_vectors=length(temp.PSWF_eigenvalues)
  temp.eigenvalue_indices<-1:temp.num_PSWF_vectors
  temp.bandlimitation_ISE_quadratic_roots<-sapply(temp.eigenvalue_indices,bandlimitation_ISE_quadratic.function,eigenvalues.par=temp.PSWF_eigenvalues,
                                                  W.par=W.par,timelimitation_ISE.par=temp.timelimitation_ISE)
  #Choose the energy for which the eigenvalue comes nearest to its N-asymptotic value, since then the upper-bound estimate must possibly itself come near
  #that very same N-asymptotic value.
  temp.asymptotic_eigenvalues<-c(rep(1,temp.K),0.5,rep(0,temp.num_PSWF_vectors-temp.K-1))
  temp.bandlimitation_ISE_quadratic_roots<-sqrt(temp.bandlimitation_ISE_quadratic_roots/(temp.NW/2))*100
  if(verbose.par==TRUE){
    for(temp.i in 1:2){
      temp.bandlimitation_row_roots<-temp.bandlimitation_ISE_quadratic_roots[temp.i,]
      temp.indices<-which(temp.bandlimitation_row_roots>0)
      temp.num_positive_roots=length(temp.indices)
      if(temp.num_positive_roots>0){
        temp.absolute_diffs=abs(temp.asymptotic_eigenvalues[temp.indices]-temp.PSWF_eigenvalues[temp.indices])
        temp.select_eigenvalue_indices<-temp.eigenvalue_indices[temp.indices]
        temp.min_diff=min(temp.absolute_diffs)
        temp.optimal_index=min(which(temp.absolute_diffs==temp.min_diff))
        temp.optimal_select_index=temp.select_eigenvalue_indices[temp.optimal_index]
        temp.optimal_bandlimitation_energy=temp.bandlimitation_row_roots[temp.optimal_select_index]
        temp.optimal_eigenvalue=temp.PSWF_eigenvalues[temp.optimal_select_index]
        temp.optimal_asymptotic_eigenvalue=temp.asymptotic_eigenvalues[temp.optimal_select_index]
        temp.min_relative_diff=temp.min_diff/temp.optimal_eigenvalue*100
        cat(nodes_multiple.par,"\t",temp.i,"\t",temp.optimal_select_index,"\t",temp.optimal_eigenvalue,"\t",temp.optimal_asymptotic_eigenvalue,
            "\t",temp.min_relative_diff,"\t",temp.optimal_bandlimitation_energy,"\n")
      }
    }
  }
  temp.list<-list(out.bandlimitation_ISE_quadratic_roots=temp.bandlimitation_ISE_quadratic_roots,
                  out.asymptotic_eigenvalues=temp.asymptotic_eigenvalues)
  return(temp.list)
}


eigencoefficients<-function(ts.par,dpss.par,M.par){
  temp.N=nrow(dpss.par)
  temp.K=ncol(dpss.par)
  #tapered.series<-t(t(dpss.par) %*% diag(ts.par))
  tapered.series<-sweep(dpss.par,MARGIN=1,ts.par,FUN="*")
  padded.matrix<-pad.matrix(tapered.series,M.par)
  eigencoefficient.fft<-mvfft(padded.matrix)
  eigencoefficient.fft<-fft.rearrange_matrix(eigencoefficient.fft)
  return(eigencoefficient.fft)
}


centred_process.eigencoefficients<-function(ts.par,NW.par,M.par,K.par=0,verbose.par=TRUE,dpss.par=NA,energy_concentrations.par=NA,slepian_functions.par=NA){
  temp.N=length(ts.par)
  temp.K=2*NW.par-1
  if(K.par!=0){
    temp.K=K.par
  }
  #Compute the DPSS's and their DFT's.
  if(verbose.par==TRUE){
    tic()
    cat("NW.par=",NW.par,"\n")
    cat("ts.par\n")
    print(head(ts.par))
    cat("DPSS computations: ")
    tic()
  }
  temp.slepian_sequences<-dpss.par
  temp.energy_concentrations<-energy_concentrations.par
  temp.slepian_functions<-slepian_functions.par
  if(is.na(dpss.par)==TRUE){
    temp.slepian_sequences_object<-dpss.matrix(temp.N,NW.par,temp.K)
    temp.slepian_sequences<-temp.slepian_sequences_object$out.dpss
    temp.energy_concentrations<-temp.slepian_sequences_object$out.eigenvalues
    if(verbose.par==TRUE){
      toc()
      cat("temp.N=",temp.N,"\n")
      cat("Slepian functions: ")
      tic()
    }
    temp.slepian_functions<-Slepian.functions(temp.slepian_sequences,M.par)
  }
  if(verbose.par==TRUE){
    toc()
    cat("All DPSS computations: ")
    toc()
    tic()
    cat("Mean calculations: ")
  }
  temp.mean_removed_object<-mean_removed.series(ts.par,NW.par,temp.slepian_sequences,temp.slepian_functions)
  temp.mean_estimate=temp.mean_removed_object$out.mean_estimate
  temp.process_variance<-temp.mean_removed_object$out.process_variance
  temp.truncated_series<-temp.mean_removed_object$out.demeaned_series
  if(verbose.par==TRUE){
    toc()
    tic()
    cat("Eigencoefficient calculations: ")
  }
  temp.eigencoeffs<-eigencoefficients(temp.truncated_series,temp.slepian_sequences,M.par)
  if(verbose.par==TRUE){
    toc()
  }
  temp.list<-list(out.dpss=temp.slepian_sequences,
                  out.eigenvalues=temp.energy_concentrations,
                  out.Slepian_functions=temp.slepian_functions,
                  out.mean_estimate=temp.mean_estimate,
                  out.process_variance=temp.process_variance,
                  out.truncated_series=temp.truncated_series,
                  out.eigencoeffs=temp.eigencoeffs)
  return(temp.list)
}


spectral_process_reconstruction.function<-function(eigencoefficients.par,slepian_functions.par,eigenvalues.par){
  temp.M=nrow(eigencoefficients.par)
  temp.K=ncol(eigencoefficients.par)
  temp.zero_index=temp.M/2
  temp.slepian_functions_zero<-slepian_functions.par[temp.zero_index,]
  temp.spectral_process<-rep(0,temp.M)
  for(temp.m in 1:temp.M){
    temp.spectral_process[temp.m]<-sum(eigencoefficients.par[temp.m,]*Conj(temp.slepian_functions_zero)/eigenvalues.par)
  }
  temp.spectral_process<-temp.spectral_process/temp.M
  return(temp.spectral_process)
}


multitaper_spectral_power.function<-function(eigencoefficients.par,frequencies.par,concentrations.par,
                                             jackknife.par=FALSE,plot.par=FALSE,measured_quantity.par="Measured quantity",measured_units.par="units",
                                             sampling_rate.par=1,output.par=FALSE,jk_output.par=FALSE,new_directory.par="Multitaper_Spectral_Power",
                                             old_directory.par="",cepstral_bool.par=FALSE){
  if(output.par==TRUE || jk_output.par==TRUE || plot.par==TRUE){
    temp.subDir_string<-paste(main_directory.string,new_directory.par,sep="")
    dir.create(temp.subDir_string,showWarnings=FALSE)
    setwd(temp.subDir_string)
  }
  temp.list<-c()
  temp.spectral_power_estimates<-c()
  if(jackknife.par==TRUE){
    tic()
    temp.units_string=frequency_units.string
    if(!cepstral_bool.par){
      cat("Jackknife spectral-power computations: ")
    }
    else{
      cat("Jackknife cepstral-power computations: ")
      temp.units_string=time_units.string
    }
    temp.jk_object<-jackknife.regularized_spectrum_bounds(eigencoefficients.par,frequencies.par,concentrations.par,plot.par=plot.par,
                                                          measured_quantity.par=measured_quantity.par,
                                                          units.par1=temp.units_string,units.par2=measured_units.par,
                                                          sampling_rate.par=sampling_rate.par,cepstral_bool.par=cepstral_bool.par)
    toc()
    temp.averages<-temp.jk_object$out.averages
    temp.LB<-temp.jk_object$out.log_LB
    temp.UB<-temp.jk_object$out.log_UB
    temp.plotting_LB=temp.jk_object$out.plotting_LB
    temp.plotting_UB=temp.jk_object$out.plotting_UB
    tic()
    if(!cepstral_bool.par){
      cat("Spectral-power estimates: ")
    }
    else{
      cat("Cepstral-power estimates: ")
    }
    temp.spectral_power_estimates<-multitaper.regularized_spectrum(eigencoefficients.par,frequencies.par,concentrations.par,plot.par=plot.par,
                                                                   measured_quantity.par=measured_quantity.par,measured_units.par=measured_units.par,
                                                                   sampling_rate.par=sampling_rate.par,plotting_LB.par=temp.plotting_LB,
                                                                   plotting_UB.par=temp.plotting_UB,cepstral_bool.par=cepstral_bool.par)
    toc()
    temp.list<-list(out.spectral_power_estimates=temp.spectral_power_estimates,
                    out.jk_object=temp.jk_object)
    if(jk_output.par==TRUE){
      temp.M2=length(frequencies.par)
      temp.spectral_power_output_matrix<-matrix(0,nrow=temp.M2,ncol=4)
      temp.spectral_power_output_matrix[,1]<-frequencies.par
      temp.spectral_power_output_matrix[,2]<-temp.averages
      temp.spectral_power_output_matrix[,3]<-temp.LB
      temp.spectral_power_output_matrix[,4]<-temp.UB
      temp.spectral_power_output_labels<-c("frequency","average","LB","UB")
      if(cepstral_bool.par==TRUE){
        temp.spectral_power_output_labels<-c("quefrency","average","LB","UB")
      }
      temp.spectral_power_output_title<-paste(measured_quantity.par,"_Jackknifed_Spectral_Power_Estimates",sep="")
      output.table(temp.spectral_power_output_matrix,temp.spectral_power_output_labels,temp.spectral_power_output_title)
    }
  }
  else{
    tic()
    if(!cepstral_bool.par){
      cat("Spectral-power estimates: ")
    }
    else{
      cat("Cepstral-power estimates: ")
    }
    temp.spectral_power_estimates<-multitaper.regularized_spectrum(eigencoefficients.par,frequencies.par,concentrations.par,plot.par=plot.par,
                                                                   measured_quantity.par=measured_quantity.par,measured_units.par=measured_units.par,
                                                                   sampling_rate.par=sampling_rate.par)
    toc()
    temp.list<-list(out.spectral_power_estimates=temp.spectral_power_estimates)
  }
  if(output.par==TRUE){
    temp.spectral_power_output_matrix<-cbind(frequencies.par,temp.spectral_power_estimates)
    temp.spectral_power_output_labels<-c("frequency","spectral_power")
    temp.spectral_power_output_title<-paste(measured_quantity.par,"_Spectral_Power_Estimates",sep="")
    if(cepstral_bool.par==TRUE){
      temp.spectral_power_output_labels<-c("quefrency","cepstral_power")
      temp.spectral_power_output_title<-paste(measured_quantity.par,"_Cepstral_Power_Estimates",sep="")
    }
    output.table(temp.spectral_power_output_matrix,temp.spectral_power_output_labels,temp.spectral_power_output_title)
  }
  if(output.par==TRUE || jk_output.par==TRUE || plot.par==TRUE){
    setwd(old_directory.par)
  }
  return(temp.list)
}


#Upper bound on exterior energy of the rectangle function in the multitaper expansion.
rectangle_function_exterior_energy.function<-function(a.par=0,W.par=0.5,num_nodes.par=2,
                                                      trial_h_values.par=c(1),
                                                      old_directory_string.par="",
                                                      verbose.par=FALSE){
  temp.b=W.par
  #Compute the Gauss-Legendre integral estimate.
  temp.GL_object<-gaussLegendre(num_nodes.par,a.par,temp.b)
  temp.GL_weights<-temp.GL_object$w
  temp.GL_nodes<-temp.GL_object$x
  temp.Q=0
  for(temp.i in 1:num_nodes.par){
    temp.Q=temp.Q+temp.GL_weights[temp.i]*sinc2_integrand_change_of_variables.function(temp.GL_nodes[temp.i])
  }
  temp.GL_estimate=2*(2-temp.Q)
  if(verbose.par==TRUE){
    sink("Interior_Integral_Estimate_Output.txt", append=FALSE, split=FALSE)
    cat("The estimate of the interior integral is ",temp.Q,", while the estimate of the exterior integral ",temp.GL_estimate,"\n")
    sink()
  }
  #Compute the error on the Gauss-Legendre integral estimate (from Kiusalaas example).
  temp.global_minimum_error_value=NA
  sink("Gauss_Legendre_Integral_Estimate_Output.txt", append=FALSE, split=FALSE)
  cat("num_quadrature_abscissa\tabscissa_spacing\tmin_derivative\tmin_error_value\terror_upper_bound\n")
  for(temp.i in 1:temp.num_trial_h_values){
    temp.trial_h=trial_h_values.par[temp.i]
    temp.num_trial_samples=1/temp.trial_h
    temp.num_trial_samples=max(10,temp.num_trial_samples)
    temp.numerical_sinc2_integration_error_object<-numerical_sinc2_integration_error.function(a.par=a.par,b.par=temp.b,num_nodes.par=num_nodes.par,
                                                                                              num_trial_x_values.par=temp.num_trial_samples)
    temp.h<-temp.numerical_sinc2_integration_error_object$out.h
    temp.minimum_derivative<-temp.numerical_sinc2_integration_error_object$out.minimum_derivative
    temp.minimum_error_value=temp.numerical_sinc2_integration_error_object$out.minimum_error_value
    temp.upper_bound=temp.GL_estimate-2*temp.minimum_error_value
    if(temp.i==1){
      temp.global_minimum_error_value=temp.upper_bound
    } else{
      temp.global_minimum_error_value=max(temp.global_minimum_error_value,temp.upper_bound)
    }
    temp.upper_bound=min(temp.upper_bound,4)
    cat(temp.num_trial_samples,"\t",temp.trial_h,"\t",temp.minimum_derivative,"\t",temp.minimum_error_value,
        "\t",formatC(temp.upper_bound,format="e",digits=8),"\n")
  }
  sink()
}


mtsa.function<-function(ts.par,NW.par=5,jackknife.par=FALSE,plot.par=FALSE,measured_quantity.par="Measured quantity",measured_units.par="units",
                        sampling_rate.par=1,output.par=FALSE,spectral_power_bool.par=FALSE,jk_output.par=FALSE,
                        new_directory.par="Multitaper_Spectral_Power",old_directory.par="",cepstral_bool.par=FALSE,verbose.par=FALSE,
                        dpss.par=NA,energy_concentrations.par=NA,slepian_functions.par=NA,M_exponent.par=1){
  temp.N=length(ts.par)
  temp.K=2*NW.par-1
  #Initialize the multitaper parameters.
  temp.multitaper_parameters_object<-multitaper_parameters.function(temp.N,NW.par,M_exponent.par=M_exponent.par)
  temp.K=temp.multitaper_parameters_object$out.K
  temp.M=temp.multitaper_parameters_object$out.M
  temp.M2=temp.multitaper_parameters_object$out.M_2
  temp.frequency_spacing=temp.multitaper_parameters_object$out.frequency_spacing
  temp.frequencies_full=temp.multitaper_parameters_object$out.all_frequencies
  temp.frequencies<-temp.multitaper_parameters_object$out.frequencies
  temp.log_frequencies<-temp.multitaper_parameters_object$out.log_frequencies
  #Compute the eigencoefficients of the centred series.
  temp.centred_process_eigencoefficients_object<-centred_process.eigencoefficients(ts.par,NW.par,temp.M,temp.K,
                                                                                   dpss.par=dpss.par,energy_concentrations.par=energy_concentrations.par,
                                                                                   slepian_functions.par=slepian_functions.par)
  temp.energy_concentrations<-temp.centred_process_eigencoefficients_object$out.eigenvalues
  temp.slepian_sequences<-temp.centred_process_eigencoefficients_object$out.dpss
  temp.slepian_functions<-temp.centred_process_eigencoefficients_object$out.Slepian_functions
  temp.mean_estimate=temp.centred_process_eigencoefficients_object$out.mean_estimate
  temp.variance_estimate=temp.centred_process_eigencoefficients_object$out.process_variance
  temp.eigencoeffs<-temp.centred_process_eigencoefficients_object$out.eigencoeffs
  if(verbose.par==TRUE){
    cat("The value of the constant ",measure_quantity_string.lower_case," term is ",temp.mean_estimate," ",measure_units.string,
        ", while the spectral energy of the realized ",measure_quantity_string.lower_case," signal is ",temp.variance_estimate," squared ",
        measure_units.string,".\n")
  }
  temp.list<-list(out.K=temp.K,
                  out.M=temp.M,
                  out.M2=temp.M2,
                  out.frequency_spacing=temp.frequency_spacing,
                  out.frequencies_full=temp.frequencies_full,
                  out.frequencies=temp.frequencies,
                  out.log_frequencies=temp.log_frequencies,
                  out.energy_concentrations=temp.energy_concentrations,
                  out.slepian_sequences=temp.slepian_sequences,
                  out.slepian_functions=temp.slepian_functions,
                  out.mean_estimate=temp.mean_estimate,
                  out.variance_estimate=temp.variance_estimate,
                  out.eigencoeffs=temp.eigencoeffs)
  if(spectral_power_bool.par==TRUE){
    #Compute the multitaper spectral-power estimates.
    temp.spectral_power_object<-multitaper_spectral_power.function(temp.eigencoeffs,temp.frequencies,temp.energy_concentrations,
                                                                   jackknife.par=jackknife.par,plot.par=plot.par,
                                                                   measured_quantity.par=measured_quantity.par,
                                                                   measured_units.par=measured_units.par,
                                                                   sampling_rate.par=sampling_rate.par,
                                                                   output.par=output.par,
                                                                   jk_output.par=jk_output.par,
                                                                   new_directory.par=new_directory.par,
                                                                   old_directory.par=old_directory.par,cepstral_bool.par=cepstral_bool.par)
    temp.spectral_power_estimates<-temp.spectral_power_object$out.spectral_power_estimates
    temp.list<-list(out.K=temp.K,
                    out.M=temp.M,
                    out.M2=temp.M2,
                    out.frequency_spacing=temp.frequency_spacing,
                    out.frequencies_full=temp.frequencies_full,
                    out.frequencies=temp.frequencies,
                    out.log_frequencies=temp.log_frequencies,
                    out.energy_concentrations=temp.energy_concentrations,
                    out.slepian_sequences=temp.slepian_sequences,
                    out.slepian_functions=temp.slepian_functions,
                    out.mean_estimate=temp.mean_estimate,
                    out.variance_estimate=temp.variance_estimate,
                    out.eigencoeffs=temp.eigencoeffs,
                    out.spectral_power_estimates=temp.spectral_power_estimates)
  }
  return(temp.list)
}


multitaper_harmonic_F_test.function<-function(eigencoefficients.par,frequencies.par,slepian_functions.par,N.par,NW.par,jackknife.par=FALSE,
                                              plot.par=FALSE,measured_quantity.par="Measured quantity",units.par="units",x_units.par="units",
                                              sampling_rate.par=1,output.par=FALSE,jk_output.par=FALSE,F_test_threshold.par=threshold.percentile,
                                              training_size.par=5,Rsq_threshold.par=0.95,Kolmogorov_percentile.par=0,TPT_threshold.par=0,
                                              outlier_percentile.par=0.99,threshold_crossings_LB.par=3,new_directory.par="Multitaper_F_Test",
                                              old_directory.par="",num_diffs.par=0,cepstral_bool.par=FALSE,slepian_sequences.par,
                                              energy_concentrations.par,verbose.par=FALSE,frequency_band.par=NA,
                                              F_test_diagnostics_bool.par=FALSE){
  temp.dof=2+3*num_diffs.par
  temp.M=nrow(eigencoefficients.par)
  temp.frequency_string<-"quefrency"
  temp.frequency_string_capital<-"Quefrency"
  temp.abscissa_units=time_units.string
  if(!cepstral_bool.par){
    temp.frequency_string<-"frequency"
    temp.frequency_string_capital<-"Frequency"
    temp.abscissa_units=frequency_units.string
  }
  if(output.par==TRUE || jk_output.par==TRUE || plot.par==TRUE){
    temp.subDir_string<-paste(main_directory.string,new_directory.par,sep="")
    dir.create(temp.subDir_string,showWarnings=FALSE)
    setwd(temp.subDir_string)
  }
  temp.zero_index=temp.M/2
  temp.M2=temp.zero_index+1
  temp.K=ncol(eigencoefficients.par)
  temp.bandwidth_spacing=floor(NW.par/N.par*temp.M)
  temp.training_size=4*temp.bandwidth_spacing+1
  temp.training_indices<-1:temp.training_size
  temp.run_failure_parameter=NULL
  temp.attempt_number<-1
  temp.running_threshold=F_test_threshold.par
  temp.final_F_threshold=F_test_threshold.par
  temp.running_F_statistic_spectrum<-c()
  temp.num_significant_frequencies=0
  temp.residual_eigencoefficients<-c()
  temp.extracted_frequency_indices<-c()
  temp.significant_frequencies<-c()
  temp.harmonic_amplitudes=0
  temp.significant_SNRs<-c()
  temp.F_statistic_spectrum<-c()
  temp.significant_frequency_indices<-c()
  while(is.null(temp.run_failure_parameter) & temp.attempt_number<=10){
    temp.final_F_threshold=temp.running_threshold
    #try({
      #Harmonic Fisher tests for harmonic signal elements.
      temp.F_test.object<-harmonic_peaks.function(eigencoefficients.par,slepian_functions.par,frequencies.par,N.par,NW.par,
                                                  sampling_rate.par=sampling_rate.par,measured_quantity.par=measured_quantity.par,
                                                  F_test_threshold.par=temp.running_threshold,num_diffs.par=num_diffs.par,verbose.par=verbose.par)
      temp.significant_frequencies<-temp.F_test.object$out.significant_frequencies
      temp.significant_frequency_indices<-temp.F_test.object$out.significant_indices
      temp.num_significant_frequencies=temp.F_test.object$out.num_significant
      temp.all_significant_frequency_indices<-c(temp.zero_index-temp.significant_frequency_indices+1,temp.zero_index+temp.significant_frequency_indices-1)
      temp.all_significant_frequency_indices<-unique(temp.all_significant_frequency_indices)
      temp.num_all_significant_frequencies=length(temp.all_significant_frequency_indices)
      temp.harmonic_amplitudes=0
      temp.residual_eigencoefficients<-eigencoefficients.par
      if(temp.num_all_significant_frequencies>threshold_crossings_LB.par){
        temp.indices<-list()
        for(temp.i in 1:temp.num_all_significant_frequencies){
          temp.indices[[temp.i]]<-temp.all_significant_frequency_indices[temp.i]-(temp.training_size-1)/2+temp.training_indices-1
        }
        temp.indices<-unlist(temp.indices)
        temp.indices<-temp.indices[temp.indices>0 & temp.indices<=temp.M]
        temp.harmonic_amplitudes<-sapply(1:temp.M,harmonic_amplitude.function,eigencoefficients.par,slepian_functions.par)
        temp.verbose_bool=FALSE
        if(temp.attempt_number==1){
          temp.verbose_bool==TRUE
        }
        temp.residual_eigencoefficients<-residual_eigencoefficient_reconstruction.function(eigencoefficients.par,temp.significant_frequency_indices,
                                                                                             slepian_functions.par,N.par,energy_concentrations.par,NW.par,
                                                                                             verbose.par=temp.verbose_bool)
      }
      temp.significant_SNRs<-temp.F_test.object$out.significant_SNRs
      temp.F_statistics<-temp.F_test.object$out.F_statistics
      temp.F_statistic_spectrum<-temp.F_test.object$out.residual_F_statistics
      temp.running_F_statistic_spectrum<-temp.F_statistic_spectrum
      if(plot.par==TRUE){
        temp.plotting_frequencies<-list()
        temp.plotting_frequencies[[1]]<-frequencies.par*sampling_rate.par
        temp.plotting_F_spectrum<-list()
        temp.plotting_F_spectrum[[1]]<-temp.F_statistic_spectrum
        temp.quantile=qf(temp.running_threshold,2,2*temp.K)
        plot.graph(temp.plotting_frequencies,temp.plotting_F_spectrum,x_label.par=paste(temp.frequency_string_capital,", in ",temp.abscissa_units,sep=""),
                   y_label.par="Multitaper harmonic F-statistic",
                   plot_title.par=paste(round(temp.running_threshold*100,2+abs(log10(1-temp.running_threshold)+log10(100))),"% threshold",sep=""),
                   pdf_title.par="F_spectrum.pdf",plotting_LB.par=0,plotting_UB.par=2*temp.quantile,horizontal_line.par=temp.quantile)
      }
      temp.independent_sample_spacing=temp.F_test.object$out.independent_sample_spacing
      temp.extracted_frequency_indices<-temp.F_test.object$out.frequency_indices
      temp.extracted_frequencies<-temp.F_test.object$out.extracted_significant_frequencies*sampling_rate.par
      temp.jk_frequency_averages<-c()
      temp.frequency_LB<-c()
      temp.frequency_UB<-c()
      if(jackknife.par==TRUE & length(temp.extracted_frequency_indices)>0){
        if(verbose.par==TRUE){
          tic()
          cat("Jackknife calculations: ")
        }
        temp.jk_F_spectrum_object<-jackknife.F_spectrum(eigencoefficients.par,temp.extracted_frequency_indices,frequencies.par,temp.F_statistic_spectrum,
                                                        temp.independent_sample_spacing,slepian_functions.par,sampling_rate.par=sampling_rate.par,
                                                        training_size.par=training_size.par,Rsq_threshold.par=Rsq_threshold.par,
                                                        Kolmogorov_percentile.par=Kolmogorov_percentile.par,TPT_threshold.par=TPT_threshold.par,
                                                        outlier_percentile.par=outlier_percentile.par,num_diffs.par=num_diffs.par)
        temp.jk_num_samples<-temp.jk_F_spectrum_object$out.num_jk
        temp.delete_one_ndiffs<-temp.jk_F_spectrum_object$out.delete_one_ndiffs
        temp.delete_one_nout<-temp.jk_F_spectrum_object$out.delete_one_nout
        temp.quadratic_training_sizes<-temp.jk_F_spectrum_object$out.quadratic_training_sizes
        temp.jk_frequency_averages<-temp.jk_F_spectrum_object$out.frequency_averages
        temp.jk_frequency_variances<-temp.jk_F_spectrum_object$out.frequency_variances
        temp.jk_fitted_value_frequencies<-temp.jk_F_spectrum_object$out.all_frequencies
        temp.jk_all_fitted_values<-temp.jk_F_spectrum_object$out.all_fitted_values
        temp.jk_derivatives1<-temp.jk_F_spectrum_object$out.derivatives1
        temp.jk_derivatives2<-temp.jk_F_spectrum_object$out.derivatives2
        temp.num_jk_plotting_frequencies=length(temp.jk_frequency_averages)
        temp.quantile=qt(1-alpha.par/2,2*temp.K-1)
        temp.jk_frequency_variances[is.nan(temp.jk_frequency_variances)==TRUE]<-0
        temp.sigmas<-sqrt(temp.jk_frequency_variances)
        temp.frequency_LB<-temp.jk_frequency_averages-temp.quantile*temp.sigmas
        temp.frequency_UB<-temp.jk_frequency_averages+temp.quantile*temp.sigmas
        temp.plotting.frequencies<-frequencies.par*sampling_rate.par
        temp.inverted_F_spectrum<-1/temp.F_statistic_spectrum
        temp.F_inverted_threshold=1/qf(temp.running_threshold,temp.dof,2*temp.K-temp.dof)
        if(plot.par==TRUE){
          cat("Plot\n")
          temp.string<-paste(measured_quantity.par,"_JK_Fisher_Statistics_Fit_Diagnostics",sep="")
          dir.create(temp.string,showWarnings=FALSE)
          setwd(temp.string)
          for(temp.k in 1:temp.K){
            pdf(paste(measured_quantity.par,"_JK_Fisher_Statistics_Fits_",temp.k-1,".pdf",sep=""),width=8,height=6)
            par(mar=c(3.1, 5.1, 4.1, 2.1))
            par(mgp=c(1,1,0))
            par(mfrow=c(4,4))
            temp.jk_frequency_list<-temp.jk_fitted_value_frequencies[[temp.k]]
            temp.jk_fitted_value_list<-temp.jk_all_fitted_values[[temp.k]]
            if(length(temp.jk_frequency_list)<temp.num_significant_frequencies){
              temp.num_significant_frequencies=length(temp.jk_frequency_list)
              temp.significant_frequencies<-temp.significant_frequencies[1:temp.num_significant_frequencies]
            }
            temp.counter=1
            for(temp.j in 1:temp.num_significant_frequencies){
              temp.x_plotting<-temp.jk_frequency_list[[temp.j]]
              temp.y_plotting<-temp.jk_fitted_value_list[[temp.j]]
              temp.lower_x=min(temp.x_plotting)
              temp.upper_x=max(temp.x_plotting)
              if(temp.sigmas[temp.j]!=0){
                temp.min_LB=min(temp.frequency_LB[temp.j])
                temp.max_UB=min(temp.frequency_UB[temp.j])
                temp.UB_LB_diff=temp.max_UB-temp.min_LB
                temp.lower_x=min(temp.min_LB-temp.UB_LB_diff/4,temp.lower_x)
                temp.upper_x=max(temp.max_UB+temp.UB_LB_diff/4,temp.upper_x)
                temp.plotting_frequencies1<-temp.plotting.frequencies[temp.plotting.frequencies>=temp.lower_x & temp.plotting.frequencies<=temp.upper_x]
                temp.plotting_inverted_F<-temp.inverted_F_spectrum[temp.plotting.frequencies>=temp.lower_x & temp.plotting.frequencies<=temp.upper_x]
                temp.lower_y=min(temp.plotting_inverted_F)
                temp.upper_y=max(temp.plotting_inverted_F[temp.plotting_inverted_F<1e6])
                if(temp.jk_derivatives1[temp.j,temp.k]<0 & temp.jk_derivatives2[temp.j,temp.k]>0){
                  temp.num_bounded=length(which(temp.y_plotting<1e6))
                  temp.lower_y=min(temp.lower_y,min(temp.y_plotting))
                  temp.upper_y=max(temp.upper_y,max(temp.y_plotting))
                  temp.max_y=0
                  if(temp.num_bounded!=0){
                    temp.max_y=max(temp.upper_y,temp.y_plotting[temp.y_plotting<1e6])
                  }
                  temp.upper_y=max(temp.upper_y,temp.max_y)
                }
                temp.x_axis_bounds<-c(temp.lower_x,temp.upper_x)
              }
              else{
                temp.plotting_frequencies1<-temp.plotting.frequencies[temp.plotting.frequencies>=temp.lower_x & temp.plotting.frequencies<=temp.upper_x]
                temp.plotting_inverted_F<-temp.inverted_F_spectrum[temp.plotting.frequencies>=temp.lower_x & temp.plotting.frequencies<=temp.upper_x]
                temp.lower_x=min(temp.plotting_frequencies1)
                temp.upper_x=max(temp.plotting_frequencies1)
                temp.lower_y=min(temp.plotting_inverted_F)
                temp.upper_y=max(temp.plotting_inverted_F[temp.plotting_inverted_F<1e6])
              }
              temp.x_label<-""
              temp.y_label<-""
              plot(0,0,xlab=temp.x_label,ylab=temp.y_label,main=paste("1/F, ",
                                                                      formatC(temp.significant_frequencies[temp.j]*sampling_rate.par,format="e",digits=2)
                                                                      ," ",x_units.par,"\nJ = ",
                                                                      temp.jk_num_samples[temp.j],", ntrain = ",
                                                                      temp.quadratic_training_sizes[temp.j,temp.k],
                                                                      "\nndiffs = ",temp.delete_one_ndiffs[temp.j,temp.k],
                                                                      ", nout = ",temp.delete_one_nout[temp.j,temp.k],sep=""),
                   xlim=c(min(temp.lower_x,temp.significant_frequencies[temp.j]*sampling_rate.par),
                          max(temp.upper_x,temp.significant_frequencies[temp.j]*sampling_rate.par)),ylim=c(temp.lower_y,temp.upper_y),
                   pch=".",lab=c(10,10,7),xaxt="n",yaxt="n",cex.lab=1.25)
              temp.num_correct=length(which(temp.jk_derivatives1[temp.j,]<0))+length(which(temp.jk_derivatives2[temp.j,]>0))
              abline(h=temp.F_inverted_threshold)
              axis(1,at=c(min(temp.lower_x,temp.significant_frequencies[temp.j]*sampling_rate.par),
                          max(temp.upper_x,temp.significant_frequencies[temp.j]*sampling_rate.par)),
                   labels=paste(formatC(c(min(temp.lower_x,temp.significant_frequencies[temp.j]*sampling_rate.par),
                                          max(temp.upper_x,temp.significant_frequencies[temp.j]*sampling_rate.par)),format="e",digits=1)," ",
                                x_units.par,sep=""))
              axis(2,at=c(temp.lower_y,temp.upper_y),labels=formatC(c(temp.lower_y,temp.upper_y),format="e",digits=2),las=2)
              if(temp.num_correct>0 & temp.jk_frequency_averages[temp.j]!=0 & temp.sigmas[temp.j]!=0){
                abline(v=temp.frequency_LB[temp.j],lwd=4,col="grey80")
                abline(v=temp.frequency_UB[temp.j],lwd=4,col="grey80")
                abline(v=temp.jk_frequency_averages[temp.j],lwd=2,col=4)
                abline(v=temp.significant_frequencies[temp.j]*sampling_rate.par,lty=4,lwd=2)
                if(temp.jk_derivatives1[temp.j,temp.k]<0 & temp.jk_derivatives2[temp.j,temp.k]>0){
                  lines(temp.x_plotting,temp.y_plotting,lwd=2,lty=2,col=2)
                }
              }
              else{
                abline(v=temp.significant_frequencies[temp.j]*sampling_rate.par,lty=4,lwd=2)
              }
              lines(temp.plotting_frequencies1,temp.plotting_inverted_F,type="o",pch=".",cex=5)
              temp.counter=temp.counter+1
            }
            dev.off()
          }
          setwd(temp.subDir_string)
          #Diagnostic-statistic plots.
          #Linear reconstruction.
          temp.line_x_labels<-paste(temp.frequency_string_capital,", in ",x_units.par,sep="")
          temp.line_y_labels<-c("R-squared","Turning-point statistic, percentage point","Kolmogorov statistic, percentage point")
          temp.line_plot_titles<-rep("",3)
          temp.line_y_plotting_list<-list()
          temp.line_y_plotting_list[[1]]<-temp.jk_F_spectrum_object$out.line_Rsqs_matrix
          temp.line_y_plotting_list[[2]]<-temp.jk_F_spectrum_object$out.line_TPTs_matrix
          temp.line_y_plotting_list[[3]]<-temp.jk_F_spectrum_object$out.line_KS_matrix
          plot_graph.min_median_max_multiple(temp.significant_frequencies*sampling_rate.par,temp.line_y_plotting_list,temp.line_x_labels,
                                             temp.line_y_labels,temp.line_plot_titles,pdf_title.par="F_Statistics_Linear_Reconstruction_Diagnostics.pdf")      
          #Parabola reconstruction.
          temp.y_plotting_list<-list()
          temp.y_plotting_list[[1]]<-temp.jk_F_spectrum_object$out.Rsqs_matrix
          temp.y_plotting_list[[2]]<-temp.jk_F_spectrum_object$out.TPTs_matrix
          temp.y_plotting_list[[3]]<-temp.jk_F_spectrum_object$out.KS_matrix
          plot_graph.min_median_max_multiple(temp.significant_frequencies*sampling_rate.par,temp.y_plotting_list,temp.line_x_labels,
                                             temp.line_y_labels,temp.line_plot_titles,pdf_title.par="F_Statistics_Parabola_Reconstruction_Diagnostics.pdf")
        }
        if(jk_output.par==TRUE){
          cat("The number of significant ",temp.frequency_string," estimates is ",temp.num_significant_frequencies,".\n")
          temp.jk_RSqs<-temp.jk_F_spectrum_object$out.line_Rsqs_matrix
          temp.jk_TPT_percentiles<-temp.jk_F_spectrum_object$out.line_TPTs_matrix
          temp.jk_KS_percentiles<-temp.jk_F_spectrum_object$out.line_KS_matrix
          sink("Fisher_Statistics.txt", append=FALSE, split=FALSE)
          cat("index\t",paste(temp.frequency_string,"\tSNR\tpercentile\tjk_",temp.frequency_string,sep=""),
              "\tjk_LB\tjk_UB\ttheoretical_variance\tjk_variance\tRsq_min\tRsq_median\tRsq_max\tTPT_min\tTPT_median\tTPT_max\tKS_min\tKS_median\tKS_max\n")
          for(temp.i in 1:temp.num_significant_frequencies){
            temp.variance=0
            if(temp.significant_frequencies[temp.i]!=0){
              temp.variance_object<-
                f_var.CR(slepian_sequences.par,1/temp.significant_frequencies[temp.i]/sampling_rate.par,temp.significant_SNRs[temp.i],1/sampling_rate.par)
              temp.variance=temp.variance_object$out.CR_variance
              temp.variance=temp.variance*sampling_rate.par^2
            }
            temp.jk_variance=temp.jk_frequency_variances[temp.i]
            try({
              cat(temp.significant_frequency_indices[temp.i],"\t",temp.significant_frequencies[temp.i]*sampling_rate.par,"\t",temp.significant_SNRs[temp.i],"\t",
                  pf(temp.significant_SNRs[temp.i],temp.dof,2*temp.K-temp.dof)*100,"\t",temp.jk_frequency_averages[temp.i],"\t",
                  temp.frequency_LB[temp.i],"\t",temp.frequency_UB[temp.i],"\t",temp.variance,"\t",temp.jk_variance,"\t",
                  temp.jk_RSqs[temp.i,1],"\t",temp.jk_RSqs[temp.i,2],"\t",temp.jk_RSqs[temp.i,3],"\t",
                  temp.jk_TPT_percentiles[temp.i,1],"\t",temp.jk_TPT_percentiles[temp.i,2],"\t",temp.jk_TPT_percentiles[temp.i,3],"\t",
                  temp.jk_KS_percentiles[temp.i,1],"\t",temp.jk_KS_percentiles[temp.i,2],"\t",temp.jk_KS_percentiles[temp.i,3],"\n")
            },silent=TRUE)
          }
          sink()
        }
        if(verbose.par==TRUE){
          toc()
        }
      }
      else if(output.par==TRUE){
        cat("The number of significant ",temp.frequency_string," estimates is ",temp.num_significant_frequencies,".\n")
        sink(paste(measured_quantity.par,"_Fisher_Statistics.txt",sep=""), append=FALSE, split=FALSE)
        cat(temp.frequency_string,"\tSNR\tpercentile\n")
        for(temp.i in 1:temp.num_significant_frequencies){
          try({
            cat(temp.significant_frequencies[temp.i]*sampling_rate.par,"\t",temp.significant_SNRs[temp.i],"\t",
                pf(temp.significant_SNRs[temp.i],temp.dof,2*temp.K-temp.dof)*100,"\n")
          },silent=TRUE)
        }
        sink()
      }
      temp.num_spacings=0
      temp.ks_diagnostic_matrix<-matrix(0,nrow=temp.num_significant_frequencies,ncol=temp.num_spacings)
      temp.tpt_diagnostic_matrix<-temp.ks_diagnostic_matrix
      if((plot.par==TRUE || output.par==TRUE) & temp.num_significant_frequencies>0){
        temp.num_spacings=max(floor(temp.num_significant_frequencies/2),1)
        temp.ks_diagnostic_matrix<-matrix(0,nrow=temp.num_significant_frequencies,ncol=temp.num_spacings)
        temp.tpt_diagnostic_matrix<-temp.ks_diagnostic_matrix
        temp.indices<-1:temp.num_significant_frequencies
        temp.index_spacings<-1:temp.num_spacings
        for(temp.i in 1:temp.num_significant_frequencies){
          temp.peak_frequencies<-list()
          temp.diffs_list<-list()
          temp.training_indices<-temp.indices[temp.indices!=temp.i]
          temp.index_differences<-temp.significant_frequencies[temp.i]-temp.significant_frequencies[temp.training_indices]
          temp.index_differences<-temp.index_differences*sampling_rate.par
          for(temp.j in temp.index_spacings){
            if(temp.num_significant_frequencies>1){
              temp.sample_frequencies<-temp.index_differences[seq(from=1,to=temp.num_significant_frequencies-1,by=temp.j)]
            }
            else{
              temp.sample_frequencies<-temp.index_differences[1]
            }
            temp.differenced_series<-diff(temp.sample_frequencies,1)
            temp.line_residual_analysis_object<-residual_analysis.function(temp.sample_frequencies[2:length(temp.sample_frequencies)],
                                                                           temp.differenced_series,TPT_threshold.par=TPT_threshold.par)
            temp.line_KS_percentile=temp.line_residual_analysis_object$out.KS_percentile
            temp.line_TPT_percentile=temp.line_residual_analysis_object$out.TPT_percentile
            temp.ks_diagnostic_matrix[temp.i,temp.j]=temp.line_KS_percentile
            temp.tpt_diagnostic_matrix[temp.i,temp.j]=temp.line_TPT_percentile
          }
        }
        temp.tpt_diagnostic_matrix<-temp.tpt_diagnostic_matrix*100
      }
      if(F_test_diagnostics_bool.par==TRUE){
      if(plot.par==TRUE & temp.num_significant_frequencies>0){
        temp.subDir_string2<-paste(main_directory.string,new_directory.par,"F_Test_Diagnostics/",sep="")
        dir.create(temp.subDir_string2,showWarnings=FALSE)
        setwd(temp.subDir_string2)
        temp.zero_indices_flags<-rep(0,temp.num_spacings)
        temp.plotting_spacings<-temp.index_spacings
        for(temp.j in 1:temp.num_spacings){
          temp.row<-temp.ks_diagnostic_matrix[,temp.j]
          if(!length(which(temp.row!=0))){
            temp.zero_indices_flags[temp.j]=1
            break
          }
        }
        if(length(which(temp.zero_indices_flags==1))>0){
          temp.first_flag_index=which(temp.zero_indices_flags==1)
          temp.ks_diagnostic_matrix<-temp.ks_diagnostic_matrix[,1:temp.first_flag_index]
          temp.tpt_diagnostic_matrix<-temp.tpt_diagnostic_matrix[,1:temp.first_flag_index]
          temp.plotting_spacings<-temp.plotting_spacings[1:temp.first_flag_index]
          
        }
        temp.num_plotting=length(temp.plotting_spacings)
        try({
          temp.KS_file_name<-"KS_Statistics_Quefrency_Differences.pdf"
          temp.TPT_file_name<-"TPT_Statistics_Quefrency_Differences.pdf"
          temp.x_label<-paste("Significant quefrency index, in ",units.par,sep="")
          temp.y_label<-"Significant quefrencies per retained significant-quefrency difference"
          if(!cepstral_bool.par){
            temp.x_label<-"Significant frequency index, in "
            temp.y_label<-"Significant frequency per retained significant-frequency difference"
            temp.KS_file_name<-"KS_Statistics_Frequency_Differences.pdf"
            temp.TPT_file_name<-"TPT_Statistics_Quefrency_Differences.pdf"
          }
          pdf(temp.KS_file_name,width=8,height=6)
          par(mar=c(5.1, 4.1, 4.1, 3.1))
          mgp=c(2,1,0)
          image.plot(temp.indices,temp.plotting_spacings,temp.ks_diagnostic_matrix,xlab=temp.x_label,ylab=temp.y_label)
          title(ylab="Kolmogorov percentile",line=-30.5)
          abline(v=temp.indices)
          dev.off()
          pdf(temp.TPT_file_name,width=8,height=6)
          par(mar=c(5.1, 4.1, 4.1, 3.1))
          image.plot(temp.indices,temp.plotting_spacings,temp.tpt_diagnostic_matrix,xlab=temp.x_label,ylab=temp.y_label)
          title(ylab="Turning-point-statistic percentile",line=-30.5)
          abline(v=temp.indices)
          dev.off()
        },silent=T)
        setwd(temp.subDir_string)
      }
      if(output.par==TRUE){
        sink("Significant_Frequency_Difference_Statistics.txt", append=FALSE, split=FALSE)
        cat("index\tfrequency\tnum_freqs\tsecond_frequency\tks_percentile\ttpt_percentile\n")
        try({
          for(temp.i in 1:temp.num_significant_frequencies){
            for(temp.j in 1:ncol(temp.ks_diagnostic_matrix)){
              cat(temp.i,"\t",temp.significant_frequencies[temp.i],"\t",temp.j,"\t",temp.significant_frequencies[temp.j],"\t",
                  temp.ks_diagnostic_matrix[temp.i,temp.j],"\t",temp.tpt_diagnostic_matrix[temp.i,temp.j],"\n")
            }
          }
        },silent=T)
        sink()
      }
      }#endif
      temp.quantile<-qf(temp.running_threshold,temp.dof,2*temp.K-temp.dof)
      temp.significant_indices<-which(temp.running_F_statistic_spectrum>temp.quantile)
      temp.num_crossings=length(temp.significant_indices)
      if(temp.num_significant_frequencies>=threshold_crossings_LB.par){
        if(!is.na(frequency_band.par)){
          temp.plotting_significant_frequencies<-frequencies.par[temp.significant_indices]*sampling_rate.par
          temp.plotting_significant_frequencies_passband=
            which(temp.plotting_significant_frequencies>=frequency_band.par[1] & temp.plotting_significant_frequencies<=frequency_band.par[2])
          temp.num_significant_in_passband=length(temp.plotting_significant_frequencies_passband)
          if(temp.num_significant_in_passband>0){
            temp.run_failure_parameter=1
          }
        }
        else if(threshold_crossings_LB.par==1){
          temp.run_failure_parameter=1
        }
        else if(temp.num_crossings<=30){
          temp.run_failure_parameter=1
        }
      }
    #},silent=T)
    temp.quantile<-qf(temp.running_threshold,temp.dof,2*temp.K-temp.dof)
    temp.num_crossings=length(which(temp.running_F_statistic_spectrum>temp.quantile))
    if(temp.num_crossings<=30){
      temp.trial_threshold=1-10^{temp.attempt_number-ceil(abs(1-log10(1-F_test.threshold)))}
      if(!is.na(temp.trial_threshold)){
        temp.running_threshold=max(0.95,temp.trial_threshold)
      }
      else{
        temp.running_threshold=0.95
      }
    }
    temp.attempt_number=temp.attempt_number+1
  } #End while loop.
  if(output.par==TRUE || jk_output.par==TRUE || plot.par==TRUE){
    setwd(old_directory.par)
  }
  temp.list<-list(out.num_significant_frequencies=temp.num_significant_frequencies,
                  out.residual_eigencoefficients=temp.residual_eigencoefficients,
                  out.extracted_frequency_indices=temp.extracted_frequency_indices,
                  out.significant_frequencies=temp.significant_frequencies,
                  out.harmonic_amplitudes=temp.harmonic_amplitudes,
                  out.significant_SNRs=temp.significant_SNRs,
                  out.significant_frequency_indices=temp.significant_frequency_indices,
                  out.F_statistic_spectrum=temp.F_statistic_spectrum,
                  out.F_statistics=temp.F_statistics,
                  out.final_F_threshold=temp.final_F_threshold)
  return(temp.list)
}



mtha.function<-function(eigencoeffs.par,frequencies.par,slepian_functions.par,concentrations.par,N.par,NW.par,
                        jackknife.par=TRUE,F_test_jackknife.par=TRUE,plot.par=TRUE,
                        measured_quantity.par="Measured quantity",units.par="units",x_units.par=frequency_units.string,sampling_rate.par=1,output.par=TRUE,jk_output.par=TRUE,
                        F_test_threshold.par=F_test.threshold,training_size.par=training_size.par,Rsq_threshold.par=Rsq_threshold.par,
                        Kolmogorov_percentile.par=Kolmogorov_percentile.par,TPT_threshold.par=TPT_threshold.par,
                        outlier_percentile.par=outlier_percentile.par,threshold_crossings_LB.par=0,
                        new_directory.par="Multitaper_Spectral_Power",old_directory.par="",
                        slepian_sequences.par,energy_concentrations.par,
                        residual_bool.par=TRUE,cepstral_bool.par=FALSE,verbose.par=FALSE,num_diffs.par=0,frequency_band.par=NA,
                        F_test_diagnostics_bool.par=FALSE){
  if(cepstral_bool.par==TRUE){
    x_units.par=time_units.string
  }
  #Multitaper harmonic Fisher test.
  temp.F_test_object<-multitaper_harmonic_F_test.function(eigencoeffs.par,frequencies.par,slepian_functions.par,N.par,NW.par,jackknife.par=F_test_jackknife.par,
                                                          plot.par=plot.par,measured_quantity.par=measured_quantity.par,units.par=units.par,
                                                          x_units.par=x_units.par,sampling_rate.par=sampling_rate.par,output.par=output.par,
                                                          jk_output.par=jk_output.par,F_test_threshold.par=F_test_threshold.par,
                                                          training_size.par=training_size.par,Rsq_threshold.par=Rsq_threshold.par,
                                                          Kolmogorov_percentile.par=Kolmogorov_percentile.par,
                                                          TPT_threshold.par=TPT_threshold.par,outlier_percentile.par=outlier_percentile.par,
                                                          threshold_crossings_LB.par=threshold_crossings_LB.par,
                                                          new_directory.par=new_directory.par,old_directory.par=old_directory.par,
                                                          slepian_sequences.par=slepian_sequences.par,cepstral_bool.par=cepstral_bool.par,
                                                          verbose.par=verbose.par,num_diffs.par=num_diffs.par,
                                                          energy_concentrations.par=energy_concentrations.par,frequency_band.par=frequency_band.par,
                                                          F_test_diagnostics_bool.par=F_test_diagnostics_bool.par)
  temp.residual_eigencoefficients<-temp.F_test_object$out.residual_eigencoefficients
  temp.significant_frequencies<-temp.F_test_object$out.significant_frequencies
  temp.extracted_frequency_indices<-temp.F_test_object$out.extracted_frequency_indices
  temp.F_statistic_spectrum<-temp.F_test_object$out.F_statistic_spectrum
  temp.list<-list(out.residual_eigencoefficients=temp.residual_eigencoefficients,
                  out.significant_frequencies=temp.significant_frequencies,
                  out.extracted_frequency_indices=temp.extracted_frequency_indices,
                  out.F_statistic_spectrum=temp.F_statistic_spectrum)
  if(residual_bool.par){
    #Compute the multitaper spectral-power estimates for the residual component of the process.
    #temp.residual_spectral_power_estimates<-multitaper.regularized_spectrum(temp.residual_eigencoefficients,frequencies.par,concentrations.par)
    temp.residual_spectral_power_object<-multitaper_spectral_power.function(temp.residual_eigencoefficients,frequencies.par,concentrations.par,
                                                                            jackknife.par=jk_spectral_power.bool,plot.par=plot.par,
                                                                            measured_quantity.par=paste("Residual_",measured_quantity.par,sep=""),
                                                                            measured_units.par=units.par,
                                                                            sampling_rate.par=sampling_rate.par,output.par=output.par,
                                                                            jk_output.par=jk_output.par,new_directory.par=new_directory.par,
                                                                            old_directory.par=old_directory.par,cepstral_bool.par=cepstral_bool.par)
    temp.residual_spectral_power_estimates<-temp.residual_spectral_power_object$out.spectral_power_estimates
    temp.list<-list(out.residual_eigencoefficients=temp.residual_eigencoefficients,
                    out.significant_frequencies=temp.significant_frequencies,
                    out.extracted_frequency_indices=temp.extracted_frequency_indices,
                    out.residual_spectral_power_estimates=temp.residual_spectral_power_estimates,
                    out.F_statistic_spectrum=temp.F_statistic_spectrum)
  }
  return(temp.list)
}



mt_sa_ha.function<-function(ts.par,NW.par,jackknife.par=FALSE,F_test_jackknife.par=TRUE,
                            plot.par=FALSE,measured_quantity.par="Measured",
                            measured_units.par="measured units",sampling_rate.par=1,F_test_threshold.par=0.99,
                            output.par=FALSE,spectral_power_bool.par=FALSE,jk_output.par=FALSE,ha_bool.par=FALSE,
                            residual_bool.par=FALSE,threshold_crossings_LB.par=0,
                            new_directory.par="MT_SA_HA",old_directory.par="",F_statistic_spectrum.par=NA,
                            cepstral_bool.par=FALSE,verbose.par=FALSE,num_diffs.par=0,frequency_band.par=NA,
                            dpss.par=NA,energy_concentrations.par=NA,slepian_functions.par=NA,M_exponent.par=1,
                            F_test_diagnostics_bool.par=FALSE){
  tic()
  #Conduct a basic multitaper spectral analysis.
  temp.mtsa_object<-mtsa.function(ts.par=ts.par,NW.par=NW.par,jackknife.par=jackknife.par,plot.par=plot.par,measured_quantity.par=measured_quantity.par,
                                  measured_units.par=measured_units.par,sampling_rate.par=sampling_rate.par,output.par=output.par,
                                  spectral_power_bool.par=spectral_power_bool.par,jk_output.par=jk_output.par,new_directory.par=new_directory.par,
                                  old_directory.par=old_directory.par,cepstral_bool.par=cepstral_bool.par,verbose.par=verbose.par,
                                  dpss.par=dpss.par,energy_concentrations.par=energy_concentrations.par,slepian_functions.par=slepian_functions.par,
                                  M_exponent.par=M_exponent.par)
  temp.N=length(ts.par)
  temp.K=temp.mtsa_object$out.K
  temp.M=temp.mtsa_object$out.M
  temp.M2=temp.mtsa_object$out.M2
  temp.frequency_spacing<-temp.mtsa_object$out.frequency_spacing
  temp.frequencies_full<-temp.mtsa_object$out.frequencies_full
  temp.frequencies<-temp.mtsa_object$out.frequencies
  temp.log_frequencies<-temp.mtsa_object$out.log_frequencies
  temp.energy_concentrations<-temp.mtsa_object$out.energy_concentrations
  temp.slepian_sequences<-temp.mtsa_object$out.slepian_sequences
  temp.slepian_functions<-temp.mtsa_object$out.slepian_functions
  temp.mean_estimate=temp.mtsa_object$out.mean_estimate
  temp.variance_estimate=temp.mtsa_object$out.variance_estimate
  temp.eigencoeffs<-temp.mtsa_object$out.eigencoeffs
  temp.residual_eigencoefficients<-temp.eigencoeffs
  temp.spectral_power_estimates<-temp.mtsa_object$out.spectral_power_estimates
  temp.list<-list(out.K=temp.K,
                  out.M=temp.M,
                  out.M2=temp.M2,
                  out.frequency_spacing=temp.frequency_spacing,
                  out.frequencies_full=temp.frequencies_full,
                  out.frequencies=temp.frequencies,
                  out.log_frequencies=temp.log_frequencies,
                  out.energy_concentrations=temp.energy_concentrations,
                  out.slepian_sequences=temp.slepian_sequences,
                  out.slepian_functions=temp.slepian_functions,
                  out.mean_estimate=temp.mean_estimate,
                  out.variance_estimate=temp.variance_estimate,
                  out.eigencoeffs=temp.eigencoeffs,
                  out.residual_eigencoefficients=temp.residual_eigencoefficients,
                  out.spectral_power_estimates=temp.spectral_power_estimates)
  temp.units_string=frequency_units.string
  if(cepstral_bool.par==TRUE){
    temp.units_string=time_units.string
  }
  if(ha_bool.par==TRUE){
    #Conduct a basic harmonic analysis.
    temp.mtha_object<-mtha.function(temp.eigencoeffs,temp.frequencies,temp.slepian_functions,temp.energy_concentrations,temp.N,NW.par,
                                    jackknife.par=jackknife.par,F_test_jackknife.par=F_test_jackknife.par,
                                    plot.par=plot.par,measured_quantity.par=measured_quantity.par,units.par=measured_units.par,
                                    x_units.par=temp.units_string,sampling_rate.par=sampling_rate.par,output.par=output.par,jk_output.par=jk_output.par,
                                    F_test_threshold.par=F_test_threshold.par,training_size.par=training_size.par,
                                    Rsq_threshold.par=Rsq_threshold.par,Kolmogorov_percentile.par=Kolmogorov_percentile.par,
                                    TPT_threshold.par=TPT_threshold.par,outlier_percentile.par=outlier_percentile.par,
                                    threshold_crossings_LB.par=threshold_crossings_LB.par,
                                    new_directory.par=new_directory.par,old_directory.par=old_directory.par,
                                    slepian_sequences.par=temp.slepian_sequences,cepstral_bool.par=cepstral_bool.par,residual_bool.par=TRUE,
                                    num_diffs.par=num_diffs.par,energy_concentrations.par=temp.energy_concentrations,frequency_band.par=frequency_band.par,
                                    F_test_diagnostics_bool.par=F_test_diagnostics_bool.par)
    temp.residual_eigencoefficients<-temp.mtha_object$out.residual_eigencoefficients
    temp.significant_frequencies<-temp.mtha_object$out.significant_frequencies
    temp.extracted_frequency_indices<-temp.mtha_object$out.extracted_frequency_indices
    temp.residual_spectral_power_estimates<-temp.mtha_object$out.residual_spectral_power_estimates
    temp.F_statistic_spectrum<-temp.mtha_object$out.F_statistic_spectrum
    temp.list<-list(out.K=temp.K,
                    out.M=temp.M,
                    out.M2=temp.M2,
                    out.frequency_spacing=temp.frequency_spacing,
                    out.frequencies_full=temp.frequencies_full,
                    out.frequencies=temp.frequencies,
                    out.log_frequencies=temp.log_frequencies,
                    out.energy_concentrations=temp.energy_concentrations,
                    out.slepian_sequences=temp.slepian_sequences,
                    out.slepian_functions=temp.slepian_functions,
                    out.mean_estimate=temp.mean_estimate,
                    out.variance_estimate=temp.variance_estimate,
                    out.eigencoeffs=temp.eigencoeffs,
                    out.spectral_power_estimates=temp.spectral_power_estimates,
                    out.residual_eigencoefficients=temp.residual_eigencoefficients,
                    out.significant_frequencies=temp.significant_frequencies,
                    out.extracted_frequency_indices=temp.extracted_frequency_indices,
                    out.residual_spectral_power_estimates=temp.residual_spectral_power_estimates,
                    out.F_statistic_spectrum=temp.F_statistic_spectrum)
  }
  cat("All calculations for basic multitaper spectral and harmonic analyses: ")
  toc()
  return(temp.list)
}



harmonic_analysis.function<-function(ts.par,time_sequence.par,NW.par,
                                     jackknife.par=FALSE,F_test_jackknife.par=FALSE,
                                     plot.par=FALSE,measured_quantity.par="",
                                     measured_units.par="",sampling_rate.par=1,
                                     F_test_threshold.par=0.999,output.par=FALSE,spectral_power_bool.par=FALSE,
                                     jk_output.par=FALSE,ha_bool.par=FALSE,residual_bool.par=FALSE,threshold_crossings_LB.par=3,num_sections.par=2,
                                     new_directory.par="",old_directory.par="",reconstruction_bool.par=FALSE,verbose.par=FALSE,
                                     cepstral_bool.par=FALSE,reconstruction_directory.par="",ends_reconstruction_bool.par=FALSE,
                                     all_frequencies_bool.par=FALSE,first_time.par=0,demodulate_bool.par=FALSE,ha_bool_residual.par=FALSE,
                                     num_diffs.par=0,frequency_band.par=NA,dpss.par=NA,energy_concentrations.par=NA,slepian_functions.par=NA,
                                     M_exponent.par=1,F_test_diagnostics_bool.par=FALSE,
                                     #Ends reconstruction booleans.
                                     periodic_reconstruction_bool.par=FALSE,ts_interp_bool.par=FALSE,mdss_bool.par=FALSE,gn_bool.par=FALSE,
                                     num_iterations.par=1,max_length.par=200,
                                     main_directory_string.par="",directory_label.par="",old_directory_interp.par="",
                                     specific_subdirectory_string.par="",revised_specific_directory_string.par="",
                                     main_directory.par=main_directory.string,method_directory_string.par=""){
  temp.create_and_set_multiple_directories_object<-
    create_and_set_multiple_directories.function(directory_strings.par=directory_label.par,
                                                 specific_subdirectory_string.par=specific_subdirectory_string.par,
                                                 working_directory_string.par=old_directory.par)
  if(ha_bool_residual.par==TRUE){
    all_frequencies_bool.par=TRUE
  }
  temp.N_samples=length(ts.par)
  if(is.na(F_test_threshold.par)==TRUE){
    F_test_threshold.par=1-1/temp.N_samples
  }
  temp.mt_sa_ha_object<-mt_sa_ha.function(ts.par=ts.par,NW.par=NW.par,
                                          jackknife.par=jackknife.par,F_test_jackknife.par=F_test_jackknife.par,
                                          plot.par=plot.par,
                                          measured_quantity.par=measured_quantity.par,measured_units.par=measured_units.par,
                                          sampling_rate.par=sampling_rate.par,
                                          F_test_threshold.par=F_test_threshold.par,output.par=output.par,spectral_power_bool.par=spectral_power_bool.par,
                                          jk_output.par=jk_output.par,ha_bool.par=ha_bool.par,residual_bool.par=TRUE,
                                          threshold_crossings_LB.par=threshold_crossings_LB.par,new_directory.par=new_directory.par,
                                          old_directory.par=old_directory.par,verbose.par=verbose.par,cepstral_bool.par=cepstral_bool.par,
                                          num_diffs.par=num_diffs.par,frequency_band.par=frequency_band.par,
                                          dpss.par=dpss.par,energy_concentrations.par=energy_concentrations.par,slepian_functions.par=slepian_functions.par,
                                          M_exponent.par=M_exponent.par,
                                          F_test_diagnostics_bool.par=F_test_diagnostics_bool.par)
  temp.K=temp.mt_sa_ha_object$out.K
  temp.M=temp.mt_sa_ha_object$out.M
  temp.M2=temp.mt_sa_ha_object$out.M2
  temp.M=temp.mt_sa_ha_object$out.M
  temp.zero_index=temp.M2-1
  temp.frequency_spacing<-temp.mt_sa_ha_object$out.frequency_spacing
  temp.frequencies_full<-temp.mt_sa_ha_object$out.frequencies_full
  temp.frequencies<-temp.mt_sa_ha_object$out.frequencies
  temp.log_frequencies<-temp.mt_sa_ha_object$out.log_frequencies
  temp.energy_concentrations<-temp.mt_sa_ha_object$out.energy_concentrations
  temp.power_spectrum<-temp.mt_sa_ha_object$out.spectral_power_estimates
  temp.slepian_sequences<-temp.mt_sa_ha_object$out.slepian_sequences
  temp.slepian_functions<-temp.mt_sa_ha_object$out.slepian_functions
  temp.mean_estimate=temp.mt_sa_ha_object$out.mean_estimate
  temp.variance_estimate=temp.mt_sa_ha_object$out.variance_estimate
  temp.eigencoeffs<-temp.mt_sa_ha_object$out.eigencoeffs
  temp.significant_frequencies<-temp.mt_sa_ha_object$out.significant_frequencies
  temp.spectral_power_estimates<-temp.mt_sa_ha_object$out.spectral_power_estimates
  temp.extracted_frequency_indices<-temp.mt_sa_ha_object$out.extracted_frequency_indices
  temp.residual_eigencoefficients<-temp.mt_sa_ha_object$out.residual_eigencoefficients
  temp.residual_spectral_power_estimates<-temp.mt_sa_ha_object$out.residual_spectral_power_estimates
  temp.F_statistic_spectrum<-temp.mt_sa_ha_object$out.F_statistic_spectrum
  temp.ts_truncated<-c()
  temp.times_truncated<-c()
  temp.cosine_reconstruction<-c()
  temp.harmonic_reconstructions_list<-c()
  temp.harmonic_reconstruction_indices_list<-c()
  temp.significant_frequencies_list<-c()
  temp.harmonic_amplitudes_list<-c()
  temp.N_truncated=0
  if(reconstruction_bool.par==TRUE){
    temp.cosine_reconstruction_object<-overlapped_harmonic_reconstruction.function(ts.par=ts.par-temp.mean_estimate,num_sections.par=num_sections.par,
                                                                                   NW.par=NW.par,F_test_threshold.par=F_test_threshold.par,
                                                                                   sampling_rate.par=sampling_rate.par,
                                                                                   N_F_statistics.par=threshold_crossings_LB.par,
                                                                                   frequency_band.par=frequency_band.par,
                                                                                   residual_bool.par=residual_bool.par,ends_reconstruction_bool.par=TRUE,
                                                                                   all_frequencies_bool.par=all_frequencies_bool.par,
                                                                                   new_directory.par=new_directory.par,old_directory.par=old_directory.par,
                                                                                   first_time.par=first_time.par,demodulate_bool.par=demodulate_bool.par,
                                                                                   ha_bool.par=ha_bool_residual.par,
                                                                                   reconstruction_bool.par=reconstruction_bool.par,
                                                                                   #Ends reconstruction booleans.
                                                                                   periodic_reconstruction_bool.par=reconstruction_bool.par,
                                                                                   ts_interp_bool.par=ts_interp_bool.par,mdss_bool.par=mdss_bool.par,
                                                                                   gn_bool.par=gn_bool.par,num_iterations.par=num_iterations.par,
                                                                                   max_length.par=max_length.par,
                                                                                   main_directory_string.par=main_directory_string.par,
                                                                                   directory_label.par=directory_label.par,
                                                                                   old_directory_interp.par=old_directory_interp.par,
                                                                                   revised_specific_directory_string.par=revised_specific_directory_string.par,
                                                                                   measured_quantity.par=measured_quantity.par,
                                                                                   main_directory.par=main_directory.par,
                                                                                   method_directory_string.par=method_directory_string.par)
    temp.cosine_reconstruction<-temp.cosine_reconstruction_object$out.cosine_sections_reconstruction
    temp.all_indices<-temp.cosine_reconstruction_object$out.all_indices
    temp.cosine_reconstruction<-temp.cosine_reconstruction+temp.mean_estimate
    temp.harmonic_reconstructions_list<-temp.cosine_reconstruction_object$out.harmonic_reconstructions_list
    temp.harmonic_reconstruction_indices_list<-temp.cosine_reconstruction_object$out.harmonic_reconstruction_indices_list
    temp.harmonic_amplitudes_list<-temp.cosine_reconstruction_object$out.harmonic_amplitudes_list
    temp.significant_frequencies_list<-temp.cosine_reconstruction_object$out.significant_frequencies_list
    temp.ts_truncated<-ts.par[temp.all_indices]
    temp.N_truncated=length(temp.ts_truncated)
    temp.times_truncated<-time_sequence.par[temp.all_indices]
    #Plot an overlay of the time series and the reconstruction of its nonrandom periodic signal element.
    temp.pdf_title<-paste(reconstruction_directory.par,"/Harmonic_Reconstruction_",sep="")
    temp.x_label<-paste(measured_abscissa.string,", in ",abscissa_units.string,sep="")
    if(cepstral_bool.par==TRUE){
      temp.x_label<-paste(frequency.string,", in ",frequency_units.string,sep="")
    }
    temp.pdf_title<-paste(temp.pdf_title,"Series.pdf",sep="")
    if(plot.par==TRUE){
      cat("length(temp.times_truncated)=",length(temp.times_truncated),"\n")
      cat("length(temp.ts_truncated)=",length(temp.ts_truncated),"\n")
      cat("length(temp.cosine_reconstruction)=",length(temp.cosine_reconstruction),"\n")
      temp.x_list<-list(temp.times_truncated,temp.times_truncated)
      temp.y_list<-list(temp.ts_truncated,temp.cosine_reconstruction)
      plot.graph(x_list.par=temp.x_list,y_list.par=temp.y_list,
                 x_label.par=temp.x_label,y_label.par=paste(measured_quantity.par,", in ",measured_units.par,sep=""),
                 plot_title.par="",pdf_title.par=temp.pdf_title,col.par=c(1,"grey50"))
      #Plot the residuals.
      temp.pdf_title<-paste(reconstruction_directory.par,"/Harmonic_Residuals_",sep="")
      temp.pdf_title<-paste(temp.pdf_title,"Series.pdf",sep="")
      temp.x_list<-list(temp.times_truncated)
      temp.y_list<-list(temp.ts_truncated-temp.cosine_reconstruction)
      plot.graph(x_list.par=temp.x_list,y_list.par=temp.y_list,
                 x_label.par=temp.x_label,y_label.par=paste(measured_quantity.par,", in ",measured_units.par,sep=""),
                 plot_title.par="",pdf_title.par=temp.pdf_title)
    }
  }
  if(is.null(temp.significant_frequencies)==TRUE){
    temp.significant_frequencies<-c()
  }
  temp.list<-list(out.K=temp.K,
                  out.M=temp.M,
                  out.M2=temp.M2,
                  out.zero_index=temp.zero_index,
                  out.frequency_spacing=temp.frequency_spacing,
                  out.frequencies_full=temp.frequencies_full,
                  out.frequencies=temp.frequencies,
                  out.log_frequencies=temp.log_frequencies,
                  out.energy_concentrations=temp.energy_concentrations,
                  out.power_spectrum=temp.power_spectrum,
                  out.slepian_sequences=temp.slepian_sequences,
                  out.slepian_functions=temp.slepian_functions,
                  out.variance_estimate=temp.variance_estimate,
                  out.mean_estimate=temp.mean_estimate,
                  out.eigencoeffs=temp.eigencoeffs,
                  out.spectral_power_estimates=temp.spectral_power_estimates,
                  out.extracted_frequency_indices=temp.extracted_frequency_indices,
                  out.residual_eigencoefficients=temp.residual_eigencoefficients,
                  out.residual_spectral_power_estimates=temp.residual_spectral_power_estimates,
                  out.cosine_reconstruction=temp.cosine_reconstruction,
                  out.N_truncated=temp.N_truncated,
                  out.ts_truncated=temp.ts_truncated,
                  out.times_truncated=temp.times_truncated,
                  out.significant_frequencies=temp.significant_frequencies,
                  out.harmonic_reconstructions_list=temp.harmonic_reconstructions_list,
                  out.harmonic_reconstruction_indices_list=temp.harmonic_reconstruction_indices_list,
                  out.significant_frequencies_list=temp.significant_frequencies_list,
                  out.F_statistic_spectrum=temp.F_statistic_spectrum,
                  out.harmonic_amplitudes_list=temp.harmonic_amplitudes_list)
  return(temp.list)
}


log_spectrum_tsa.function<-function(spectral_power_estimates.par,PSD_estimates.par,log_frequencies.par,frequencies.par,frequency_indices.par,
                                    F_test_threshold.par=threshold.percentile,sampling_period.par=1,measured_quantity.par="Measured quantity",
                                    Rsq_threshold.par=0.95,Kolmogorov_percentile.par=0,TPT_threshold.par=0,outlier_percentile.par=0.99,units.par1="units",
                                    units.par2="units",new_directory.par="Multitaper_F_Test",old_directory.par="",
                                    cepstral_bool.par=FALSE,output.par=FALSE,ts_interp_bool.par=FALSE,mdss_bool.par=FALSE,remove_outliers_bool.par=FALSE,
                                    plot_quadratic_diagnostics_bool.par=FALSE,jk_output.par=FALSE,plot.par=FALSE,first_time.par=0){
  temp.subDir_string<-paste(main_directory.string,new_directory.par,sep="")
  dir.create(temp.subDir_string,showWarnings=FALSE)
  setwd(temp.subDir_string)
  if(!Kolmogorov_percentile.par){
    Kolmogorov_percentile.par=1-alpha.par
  }
  if(!TPT_threshold.par){
    TPT_threshold.par=1-alpha.par
  }
  temp.ordinate_quantity<-"Frequency"
  temp.M2=length(spectral_power_estimates.par)
  #Compute the logarithmic spectral-power estimates.
  temp.log_power_spectrum<-log10(spectral_power_estimates.par[2:temp.M2])
  #Whiten the log spectral-power estimates.
  temp.original_log_PSD<-log10(PSD_estimates.par)
  temp.log_PSD0<-temp.original_log_PSD[2:temp.M2]
  temp.AR_ARIMA_object<-quadratic_AR_one_PSD_condition.function(frequencies.par=frequencies.par,spectrum.par=PSD_estimates.par,
                                                                sampling_rate.par=1/sampling_period.par,
                                                                measured_quantity.par=measured_quantity.par,measured_units.par=units.par2,
                                                                units.par=units.par1,plot_bool.par=plot_quadratic_diagnostics_bool.par)
  temp.fitted_values<-temp.AR_ARIMA_object$out.nearest_PTF_estimates
  temp.log_PSD<-temp.log_PSD0-temp.fitted_values
  #temp.log_lm_object<-lm(temp.log_PSD0~log_frequencies.par)
  #temp.log_PSD<-temp.log_lm_object$residuals
  #temp.log_PSD<-as.numeric(temp.log_PSD)
  temp.cleaned_log_PSD<-c()
  temp.cleaned_log_whitened_PSD<-temp.log_PSD
  if(remove_outliers_bool.par==TRUE){
    #Hard rejection of outlying spectral peaks for cepstral analysis.
    #try({
    if(!is.null(frequency_indices.par)){
      temp.cleaned_log_whitened_PSD<-multitaper_interpolation.function(temp.log_PSD,frequency_indices.par,
                                                                       new_directory.par=paste(new_directory.par,"Interpolation/",sep=""),
                                                                       old_directory.par=paste(old_directory.par,"Log_Spectrum_Analysis/",sep=""),
                                                                       measured_quantity.par=measured_quantity.par,
                                                                       F_test_threshold.par=F_test_threshold.par,
                                                                       ts_interp_bool.par=ts_interp_bool.par,mdss_bool.par=mdss_bool.par,
                                                                       first_time.par=first_time.par)
    }
    else{
      frequency_indices.par<-c(2)
    }
      temp.cleaned_log_PSD<-temp.cleaned_log_whitened_PSD+temp.fitted_values
    #},silent=T)
  }
  log_frequencies.par<-(log_frequencies.par-log10(sampling_period.par))
  temp.lower_x=min(log_frequencies.par)
  temp.upper_x=max(log_frequencies.par)
  temp.lower_y=min(c(temp.log_power_spectrum,temp.log_PSD,temp.log_PSD0,temp.cleaned_log_PSD))
  temp.upper_y=max(c(temp.log_power_spectrum,temp.log_PSD,temp.log_PSD0,temp.cleaned_log_PSD))
  pdf("Interpolation/Comparison.pdf",width=8,height=6)
  log_spectral_power_plot.function(log_frequencies.par,temp.log_power_spectrum,c(temp.lower_x,temp.upper_x),c(temp.lower_y,temp.upper_y),
                                   ordinate_quantity.par=temp.ordinate_quantity,measured_quantity.par=measured_quantity.par,units.par1=units.par1,
                                   units.par2=units.par2)
  log_spectral_power_plot.function(log_frequencies.par,temp.log_PSD0,c(temp.lower_x,temp.upper_x),c(temp.lower_y,temp.upper_y),
                                   ordinate_quantity.par=temp.ordinate_quantity,measured_quantity.par=measured_quantity.par,units.par1=units.par1,
                                   units.par2=units.par2)
  log_spectral_power_plot.function(log_frequencies.par,temp.log_PSD,c(temp.lower_x,temp.upper_x),c(temp.lower_y,temp.upper_y),
                                   ordinate_quantity.par=temp.ordinate_quantity,measured_quantity.par=measured_quantity.par,units.par1=units.par1,
                                   units.par2=units.par2)
  if(remove_outliers_bool.par==TRUE){
    log_spectral_power_plot.function(log_frequencies.par,temp.cleaned_log_whitened_PSD,c(temp.lower_x,temp.upper_x),c(temp.lower_y,temp.upper_y),
                                     ordinate_quantity.par=temp.ordinate_quantity,measured_quantity.par=measured_quantity.par,units.par1=units.par1,
                                     units.par2=units.par2)
    log_spectral_power_plot.function(log_frequencies.par,temp.cleaned_log_PSD,c(temp.lower_x,temp.upper_x),c(temp.lower_y,temp.upper_y),
                                     ordinate_quantity.par=temp.ordinate_quantity,measured_quantity.par=measured_quantity.par,units.par1=units.par1,
                                     units.par2=units.par2)
  }
  dev.off()
  temp.log_harmonic_powers<-temp.log_power_spectrum-temp.log_PSD0
  temp.frequency_indices<-frequency_indices.par-1
  temp.peak_areas<-c()
  temp.peak_frequencies<-c()
  temp.list_counter=1
  if(temp.frequency_indices[1]>=1 & max(temp.frequency_indices)<temp.M2){
    temp.running_area=0
    temp.running_frequencies_vector<-c()
    temp.counter=1
    for(temp.i in 1:(temp.M2-1)){
      if(temp.log_harmonic_powers[temp.i]!=0){
        temp.running_area=temp.running_area+10^temp.log_harmonic_powers[temp.i]
        temp.running_frequencies_vector[temp.counter]<-frequencies.par[temp.i+1]
        temp.counter=temp.counter+1
      }
      else{
        if(temp.i>1){
          if(temp.log_harmonic_powers[temp.i-1]!=0){
            temp.num_frequencies=length(temp.running_frequencies_vector)
            temp.peak_frequencies[temp.list_counter]=temp.running_frequencies_vector[(temp.num_frequencies-temp.num_frequencies%%2)/2+temp.num_frequencies%%2]
            temp.peak_areas[temp.list_counter]=temp.running_area
            temp.running_area=0
            temp.running_frequencies_vector<-c()
            temp.counter=1
            temp.list_counter=temp.list_counter+1
          }
        }
      }
    }
  }
  else{
    temp.peak_frequencies=NA
    temp.peak_areas=NA
  }
  temp.cleaned_log_PSD<-c(temp.original_log_PSD[1],temp.cleaned_log_PSD)
  temp.list<-list(out.log_PSD=temp.log_PSD0,
                  out.original_log_PSD=temp.original_log_PSD)
  if(remove_outliers_bool.par==TRUE){
    temp.list<-list.append(temp.list,
                           out.cleaned_log_PSD=temp.cleaned_log_PSD,
                           out.cleaned_log_whitened_PSD=temp.cleaned_log_whitened_PSD,
                           out.peak_frequencies=temp.peak_frequencies,
                           out.peak_areas=temp.peak_areas)
  }
  setwd(old_directory.par)
  return(temp.list)
}






###################################################################################################################
#Complex demodulate.

single_complex_demodulate.function<-function(time_index.par,index.par,eigencoeffs.par,dpss.par){
  temp.demodulate_value<-sum(eigencoeffs.par[index.par,]*dpss.par[time_index.par,])
  return(temp.demodulate_value)
}

all_complex_demodulates.function<-function(eigencoeffs.par,significant_indices.par,dpss.par,N.par,NW.par){
  temp.num_significant=length(significant_indices.par)
  temp.W=NW.par/N.par
  temp.step_size=floor(1/2/temp.W)
  temp.indices<-seq(from=1,to=N.par,by=temp.step_size)-1
  temp.demodulate_size=length(temp.indices)
  temp.matrix<-matrix(0,nrow=temp.demodulate_size,ncol=temp.num_significant)
  for(temp.j in 1:temp.num_significant){
    temp.matrix[,temp.j]<-sapply(temp.indices,single_complex_demodulate.function,temp.j,eigencoeffs.par,dpss.par)
  }
  return(temp.matrix)
}


harmonic_ACS_demodulate_reconstruction.function<-function(plotting_times.par,ts.par,
                                                          frequencies.par,eigencoefficients.par,significant_frequencies.par,N.par,
                                                          dc_level.par=0,sampling_rate.par=1,
                                                          num_realizations.par=10,seeds.par=c(1,2),
                                                          measured_quantity.par="Measured quantity",
                                                          measured_abscissum_units.par="measurement units",
                                                          measured_ordinate_units.par="measuement units",
                                                          working_directory_string.par="",
                                                          plot_bool.par=FALSE,
                                                          simulation_bool.par=FALSE,crude_rv_num_samples.par=500){
  dir.create("ACS_Demodulate_Reconstruction",showWarnings=FALSE)
  setwd(paste(working_directory_string.par,"ACS_Demodulate_Reconstruction",sep=""))
  temp.K=ncol(eigencoefficients.par)
  temp.M=nrow(eigencoefficients.par)
  temp.zero_index=temp.M/2
  temp.M2=temp.zero_index+1
  temp.significant_frequency_indices<-round(significant_frequencies.par*temp.M)
  #The final significant FFT-frequency cannot exceed temp.zero_index because pairs of the frequency and its negative value must be used in
  #any demodulate model due to the absence of the negative FFT-frequency accompanying the temp.M2'th FFT frequency.
  temp.significant_frequency_indices<-
    temp.significant_frequency_indices[temp.significant_frequency_indices>=0 & temp.significant_frequency_indices<=temp.zero_index]
  #Compute the AP-coefficient realizations.
  temp.significant_indices<-temp.zero_index+temp.significant_frequency_indices-1
  temp.num_significant=length(temp.significant_indices)
  temp.num_significant_frequencies=temp.num_significant
  if(temp.num_significant>(temp.zero_index-1)){
    temp.significant_frequency_indices<-temp.significant_frequency_indices[1:(temp.zero_index-1)]
    temp.significant_indices<-temp.significant_indices[1:(temp.zero_index-1)]
    temp.num_significant=length(temp.significant_indices)
    temp.num_significant_frequencies=temp.num_significant
  }
  temp.ACS_coefficients<-eigencoefficients.par[temp.significant_indices,]
  temp.significant_indices_one_step<-sort(c(temp.significant_indices,temp.significant_indices+1))
  temp.significant_indices_one_step<-
    temp.significant_indices_one_step[temp.significant_indices_one_step>=temp.zero_index & temp.significant_indices_one_step<(temp.M-1)]
  temp.ACS_coefficients_one_step<-eigencoefficients.par[temp.significant_indices_one_step,]
  #temp.ACS_coefficients<-sweep(temp.ACS_coefficients,MARGIN=1,rowMeans(temp.ACS_coefficients),FUN="-")/temp.M
  temp.mode_frequencies<-frequencies.par[temp.significant_frequency_indices]
  temp.covariance_matrix_list<-list()
  for(temp.j in 1:temp.num_significant){
    temp.z_vector<-temp.ACS_coefficients[temp.j,]
    temp.data_matrix<-matrix(0,nrow=2,ncol=temp.K)
    for(temp.k in 1:temp.K){
      temp.data_matrix[,temp.k]<-c(Re(temp.z_vector[temp.k]),Im(temp.z_vector[temp.k]))
    }
    temp.mean_vector<-rowMeans(temp.data_matrix)
    temp.covariance_matrix_list[[temp.j]]<-temp.data_matrix%*%t(Conj(temp.data_matrix))/temp.K-temp.mean_vector%*%t(Conj(temp.mean_vector))
  }
  temp.ACS_coefficient_matrix<-matrix(0,nrow=temp.num_significant,ncol=num_realizations.par)
  temp.num_deviates=2*temp.num_significant*num_realizations.par
  temp.gaussian_RNG_object<-gaussian.RNG(num_rv.par=temp.num_deviates,seed.par=seeds.par,uniform_numbers.par=NA)
  seeds.par<-seeds.par+2
  temp.standard_normal_deviates<-temp.gaussian_RNG_object$out.random_numbers
  temp.counter=1
  for(temp.j in 1:temp.num_significant){
    temp.covariance_matrix_j<-temp.covariance_matrix_list[[temp.j]]
    temp.matrix_square_root<-matrix.square_root(temp.covariance_matrix_j)
    for(temp.k in 1:num_realizations.par){
      temp.standard_normal_vector<-c(temp.standard_normal_deviates[temp.counter],temp.standard_normal_deviates[temp.counter+1])
      temp.complex_normal_vector<-temp.matrix_square_root%*%temp.standard_normal_vector
      temp.ACS_coefficient_matrix[temp.j,temp.k]=temp.complex_normal_vector[1]+1i*temp.complex_normal_vector[2]
      temp.counter=temp.counter+2
    }
  }
  #Compute the demodulate-model realizations.
  temp.demodulate_matrix<-matrix(0,nrow=N.par,ncol=num_realizations.par)
  temp.demodulate_sums_vector<-rep(0,N.par)
  temp.demodulate_ss_vector<-temp.demodulate_sums_vector
  for(temp.k in 1:num_realizations.par){
    temp.running_demodulate_matrix<-matrix(0,nrow=N.par,ncol=temp.num_significant)
    for(temp.j in 1:temp.num_significant){
      temp.amplitude=2*Mod(temp.ACS_coefficient_matrix[temp.j,temp.k])
      temp.phase=atan2(Im(temp.ACS_coefficient_matrix[temp.j,temp.k]),Re(temp.ACS_coefficient_matrix[temp.j,temp.k]))
      temp.running_demodulate_matrix[,temp.j]<-temp.amplitude*cos(2*pi*temp.mode_frequencies[temp.j]*(1:N.par-1)+temp.phase)
    }
    temp.row_sums<-rowSums(temp.running_demodulate_matrix)
    temp.demodulate_matrix[,temp.k]<-temp.row_sums
    temp.demodulate_sums_vector<-temp.demodulate_sums_vector+temp.row_sums
    temp.demodulate_ss_vector<-temp.demodulate_ss_vector+temp.row_sums^2
  }
  #Original series.
  temp.demodulates_mean_vector<-temp.demodulate_sums_vector/num_realizations.par+dc_level.par
  temp.demodulates_sd_vector<-sqrt(temp.demodulate_ss_vector-temp.demodulate_sums_vector^2/num_realizations.par)/(num_realizations.par-1)
  temp.demodulates_CI_LB_vector<-qnorm(0.05,mean=temp.demodulates_mean_vector,sd=temp.demodulates_sd_vector)
  temp.demodulates_CI_UB_vector<-qnorm(0.95,mean=temp.demodulates_mean_vector,sd=temp.demodulates_sd_vector)
  if(plot_bool.par==TRUE){
    plot_graph.confidence_intervals(x.par=round_general.function(plotting_times.par),y.par=temp.demodulates_mean_vector,
                                    y_LB.par=temp.demodulates_CI_LB_vector,y_UB.par=temp.demodulates_CI_UB_vector,
                                    x_label.par=paste("Time, in ",measured_abscissum_units.par,sep=""),
                                    y_label.par=paste(measured_quantity.par," in ",measured_ordinate_units.par,sep=""),
                                    pdf_title.par="ACS_Demodulate_CI.pdf")
    plot.graph(x_list.par=list(plotting_times.par,plotting_times.par),y_list.par=list(ts.par,temp.demodulates_mean_vector),
               col.par=c(1,2),lwd.par=c(2,2),
               x_label.par=paste("Time, in ",measured_abscissum_units.par,sep=""),
               y_label.par=paste(measured_quantity.par," in ",measured_ordinate_units.par,sep=""),
               pdf_title.par="ACS_Demodulate_Mean.pdf")
  }
  temp.residual_ACS_deviates<-c()
  temp.residual_ACS_realizations_matrix<-matrix(0,nrow=N.par,ncol=temp.num_realizations)
  temp.mean=0
  temp.variance=1
  temp.ACS_IS_process_realizations<-matrix(0,nrow=temp.M,ncol=temp.num_realizations)
  temp.WN_IS_process_realizations<-temp.ACS_IS_process_realizations
  temp.ACS_jump_process_realizations<-temp.ACS_IS_process_realizations
  if(simulation_bool.par==TRUE){
    seeds.par<-seeds.par+2
    #Add noise to determine how well the test performs using an ROC curve.
    temp.residual_ACS_deviates0<-temp.demodulate_matrix[,1]
    temp.variance=var(temp.residual_ACS_deviates0)
    temp.normal_numbers<-basic_rng.function(num_innovations.par=N.par,N.par=N.par,
                                            mean.par=temp.mean,variance.par=temp.variance,
                                            crude_rv_num_samples.par=crude_rv_num_samples.par,
                                            seeds.par=seeds.par,
                                            uniform_numbers.par=NA)
    for(temp.j in 1:temp.num_realizations){
      seeds.par<-seeds.par+2
      set.seed(seeds.par[1])
      temp.realization<-temp.demodulate_matrix[,temp.j]+sample(temp.normal_numbers)
      temp.residual_ACS_realizations_matrix[,temp.j]<-temp.realization
    }
    temp.residual_ACS_deviates<-temp.residual_ACS_realizations_matrix[,1]
    temp.significant_indices_all<-c(temp.zero_index-rev(temp.significant_frequency_indices),temp.zero_index+temp.significant_frequency_indices-1)
    temp.significant_indices_all[temp.significant_indices_all==0]<-1
    seeds.par<-seeds.par+2
    set.seed(seeds.par[1])
    temp.normal_numbers<-basic_rng.function(num_innovations.par=temp.M2,N.par=temp.M2,
                                            mean.par=0,variance.par=1,
                                            crude_rv_num_samples.par=crude_rv_num_samples.par,
                                            seeds.par=seeds.par,
                                            uniform_numbers.par=NA)
    temp.innovation_variance=0.5*temp.variance/temp.M
    for(temp.j in 1:num_realizations.par){
      seeds.par<-seeds.par+2
      temp.BM_object<-BM_random_numbers.function(num_sim.par=temp.M+1,variance.par=1,seed.par=seeds.par,
                                                 normal_numbers.par=temp.normal_numbers)
      temp.normal_numbers<-temp.BM_object$out.normal_numbers
      temp.BM_numbers<-temp.BM_object$out.BM
      temp.BM_numbers<-temp.BM_numbers[1:temp.M]*sqrt(temp.innovation_variance)
      temp.WN_IS_process_realization_j<-white_noise_spectral_jump_process.function(temp.BM_numbers)
      temp.WN_IS_process_realizations[,temp.j]<-temp.WN_IS_process_realization_j
    }
    temp.jump_realizations<-
      rbind(Conj(temp.ACS_coefficient_matrix[rev(1:temp.num_significant_frequencies),]),temp.ACS_coefficient_matrix[1:temp.num_significant_frequencies,])
    temp.ACS_jump_process_realizations[temp.significant_indices_all,]<-temp.jump_realizations
    for(temp.j in 1:num_realizations.par){
      temp.ACS_jumps<-rep(0,temp.M+1)
      temp.ACS_jumps[1]=0
      for(temp.m in 1:temp.M){
        temp.ACS_jumps[temp.m+1]=temp.ACS_jumps[temp.m]+temp.ACS_jump_process_realizations[temp.m,temp.j]
      }
      temp.ACS_IS_process_realizations[,temp.j]<-temp.WN_IS_process_realizations[,temp.j]+temp.ACS_jumps[1:temp.M]
    }
    if(plot_bool.par==TRUE){
      #Plot the simulated ACS realization used for estimating the variance for the simulated additive, IID noise.
      plot.graph(x_list.par=list(plotting_times.par,plotting_times.par),
                 y_list.par=list(temp.residual_ACS_deviates,temp.residual_ACS_deviates0),
                 lwd.par=c(3,3),col.par=c(1,2),
                 x_label.par=paste("Time, in ",measured_abscissum_units.par,sep=""),
                 y_label.par=paste(measured_quantity.par," in ",measured_ordinate_units.par,sep=""),
                 pdf_title.par="ACS_Demodulate_Simulation.pdf")
      #Plot the ACS-noise jumps.
      dir.create("ACS_IS_Process_Realization",showWarnings=FALSE)
      temp.plotting_frequencies<-c((-1)*frequencies.par[2:temp.zero_index],frequencies.par)*sampling_rate.par
      temp.ACS_IS_process_first_realization<-temp.ACS_IS_process_realizations[,1]
      temp.ACS_IS_process_real<-Re(temp.ACS_IS_process_first_realization)
      temp.ACS_IS_process_real<-basic_cleaner.function(temp.ACS_IS_process_real)
      temp.ACS_IS_process_imaginary<-Im(temp.ACS_IS_process_first_realization)
      temp.ACS_IS_process_imaginary<-basic_cleaner.function(temp.ACS_IS_process_imaginary)
      pdf("ACS_IS_Process_Realization/ACS_IS_Process_Realization.pdf",width=8,height=6)
      scatter3D(x=temp.plotting_frequencies,y=temp.ACS_IS_process_real,z=temp.ACS_IS_process_imaginary,phi=0,bty="g",type="l",ticktype="detailed",lwd=0.5,
                xlab=paste("Frequency, in ",frequency_units.string,sep=""),ylab="Real",zlab="Imaginary")
      dev.off()
      #Plot the ACS-noise IS-process realization.
      dir.create("ACS_Increment_Series",showWarnings=FALSE)
      temp.plotting_frequencies<-c((-1)*frequencies.par[2:temp.zero_index],frequencies.par)*sampling_rate.par
      temp.WN_IS_process_realization_1<-temp.WN_IS_process_realizations[,1]
      temp.WN_jump_realization_1<-c(0,temp.WN_IS_process_realization_1[2:temp.M]-temp.WN_IS_process_realization_1[2:temp.M-1])
      temp.ACS_jump_process_first_realization<-temp.ACS_jump_process_realizations[,1]+temp.WN_jump_realization_1
      temp.ACS_jump_process_real<-Re(temp.ACS_jump_process_first_realization)
      temp.ACS_jump_process_real<-basic_cleaner.function(temp.ACS_jump_process_real)
      temp.ACS_jump_process_imaginary<-Im(temp.ACS_jump_process_first_realization)
      temp.ACS_jump_process_imaginary<-basic_cleaner.function(temp.ACS_jump_process_imaginary)
      pdf("ACS_Increment_Series/ACS_Increment_Series.pdf",width=8,height=6)
      scatter3D(x=temp.plotting_frequencies,y=temp.ACS_jump_process_real,z=temp.ACS_jump_process_imaginary,phi=0,bty="g",type="l",ticktype="detailed",lwd=0.5,
                xlab=paste("Frequency, in ",frequency_units.string,sep=""),ylab="Real",zlab="Imaginary")
      dev.off()
    }
  }
  temp.list<-list(out.ACS_coefficient_matrix=temp.ACS_coefficient_matrix,
                  out.demodulate_matrix=temp.demodulate_matrix,
                  out.demodulates_mean_vector=temp.demodulates_mean_vector,
                  out.demodulates_sd_vector=temp.demodulates_sd_vector,
                  out.demodulates_CI_LB_vector=temp.demodulates_CI_LB_vector,
                  out.demodulates_CI_UB_vector=temp.demodulates_CI_UB_vector,
                  out.residual_ACS_realizations_matrix=temp.residual_ACS_realizations_matrix,
                  out.residual_ACS_deviates=temp.residual_ACS_deviates,
                  out.significant_frequency_indices=temp.significant_frequency_indices,
                  out.mean=temp.mean,
                  out.variance=temp.variance,
                  out.ACS_IS_process_realizations=temp.ACS_IS_process_realizations,
                  out.ACS_coefficients=temp.ACS_coefficients_one_step,
                  out.seed_values=seeds.par)
  setwd("../")
  return(temp.list)
}


ACS_AR1_reconstruction.function<-function(time_sequence.par,ts_values.par,frequencies.par,eigencoefficients.par,
                                          significant_frequencies.par,
                                          dc_level.par=0,num_realizations.par=30,
                                          seeds.par=seed.values,
                                          plotting_time_scale.par=1,
                                          working_directory_string.par="",
                                          measured_quantity.par="Measured quantityt",measured_abscissum_units.par="units",
                                          measured_ordinate_units.par="units",
                                          plot_bool.par=FALSE,output_bool.par=FALSE,
                                          simulation_bool.par=FALSE,
                                          crude_rv_num_samples.par=500){
  temp.M=nrow(eigencoefficients.par)
  temp.plotting_times<-time_sequence.par*plotting_time_scale.par
  temp.sampling_rate=1/(time_sequence.par[2]-time_sequence.par[1])
  temp.N=length(time_sequence.par)
  #ACS reconstruction.
  temp.harmonic_demodulate_reconstruction_object<-
    harmonic_ACS_demodulate_reconstruction.function(plotting_times.par=temp.plotting_times,ts.par=ts_values.par,
                                                    frequencies.par=frequencies.par,eigencoefficients.par=eigencoefficients.par,
                                                    significant_frequencies.par=significant_frequencies.par,N.par=temp.N,dc_level.par=dc_level.par,
                                                    sampling_rate.par=temp.sampling_rate,
                                                    num_realizations.par=num_realizations.par,seeds.par=seeds.par,
                                                    measured_quantity.par=measured_quantity.par,
                                                    measured_abscissum_units.par=measured_abscissum_units.par,
                                                    measured_ordinate_units.par=measured_ordinate_units.par,
                                                    plot_bool.par=plot_bool.par,
                                                    simulation_bool.par=simulation_bool.par,crude_rv_num_samples.par=crude_rv_num_samples.par)
  temp.ACS_coefficient_matrix<-temp.harmonic_demodulate_reconstruction_object$out.ACS_coefficient_matrix
  temp.ACS_powers_vector<-rowMeans(Mod(temp.ACS_coefficient_matrix)^2)
  temp.demodulate_matrix<-temp.harmonic_demodulate_reconstruction_object$out.demodulate_matrix
  temp.demodulates_mean_vector<-temp.harmonic_demodulate_reconstruction_object$out.demodulates_mean_vector
  temp.demodulates_sd_vector<-temp.harmonic_demodulate_reconstruction_object$out.demodulates_sd_vector
  temp.demodulates_CI_LB_vector<-temp.harmonic_demodulate_reconstruction_object$out.demodulates_CI_LB_vector
  temp.demodulates_CI_UB_vector<-temp.harmonic_demodulate_reconstruction_object$out.demodulates_CI_UB_vector
  temp.residual_ACS_realizations_matrix<-temp.harmonic_demodulate_reconstruction_object$out.residual_ACS_realizations_matrix
  temp.residual_ACS_deviates<-temp.harmonic_demodulate_reconstruction_object$out.residual_ACS_deviates
  temp.significant_frequency_indices<-temp.harmonic_demodulate_reconstruction_object$out.significant_frequency_indices
  temp.num_significant=length(temp.significant_frequency_indices)
  temp.variance=temp.harmonic_demodulate_reconstruction_object$out.variance
  temp.ACS_IS_process_realizations<-temp.harmonic_demodulate_reconstruction_object$out.ACS_IS_process_realizations
  temp.ACS_coefficients<-temp.harmonic_demodulate_reconstruction_object$out.ACS_coefficients
  seeds.par<-temp.harmonic_demodulate_reconstruction_object$out.seed_values
  #AR(1) reconstruction.
  temp.AR1_normalized_IS_process_simulation_object<-
    AR1_normalized_IS_process_simulation.function(plotting_times.par=temp.plotting_times,ACS_deviates.par=temp.residual_ACS_realizations_matrix,
                                                  N.par=temp.N,
                                                  M.par=temp.M,
                                                  crude_rv_num_samples.par=crude_rv_num_samples.par,
                                                  seed_values.par=seeds.par,
                                                  working_directory_string.par=working_directory_string.par,
                                                  plot_bool.par=plot_bool.par,output_bool.par=output_bool.par)
  temp.ar1_coefficient=temp.AR1_normalized_IS_process_simulation_object$out.ar1_coefficient
  temp.innovation_variance=temp.AR1_normalized_IS_process_simulation_object$out.ar_innovation_variance
  temp.wn_increments_realizations<-temp.AR1_normalized_IS_process_simulation_object$out.wn_increments_realizations
  temp.ar_increment_realizations<-temp.AR1_normalized_IS_process_simulation_object$out.ar_increment_realizations
  temp.wn_IS_process_realizations<-temp.AR1_normalized_IS_process_simulation_object$out.wn_IS_process_realizations
  temp.ar_IS_process_realizations<-temp.AR1_normalized_IS_process_simulation_object$out.ar_IS_process_realizations
  temp.wn_series_realizations<-temp.AR1_normalized_IS_process_simulation_object$out.wn_series_realizations
  temp.ar_series_realizations<-temp.AR1_normalized_IS_process_simulation_object$out.ar_series_realizations
  seeds.par<-temp.AR1_normalized_IS_process_simulation_object$out.seed_values
  temp.list<-list(
    #ACS output.
    out.ACS_coefficient_matrix=temp.ACS_coefficient_matrix,
    out.ACS_powers_vector=temp.ACS_powers_vector,
    out.demodulate_matrix=temp.demodulate_matrix,
    out.demodulates_mean_vector=temp.demodulates_mean_vector,
    out.demodulates_sd_vector=temp.demodulates_sd_vector,
    out.demodulates_CI_LB_vector=temp.demodulates_CI_LB_vector,
    out.demodulates_CI_UB_vector=temp.demodulates_CI_UB_vector,
    out.residual_ACS_realizations_matrix=temp.residual_ACS_realizations_matrix,
    out.residual_ACS_deviates=temp.residual_ACS_deviates,
    out.significant_frequency_indices=temp.significant_frequency_indices,
    out.num_significant=temp.num_significant,
    out.variance=temp.variance,
    out.ACS_IS_process_realizations=temp.ACS_IS_process_realizations,
    out.ACS_coefficients=temp.ACS_coefficients,
    #AR(1) output.
    out.ar1_coefficient=temp.ar1_coefficient,
    out.innovation_variance=temp.innovation_variance,
    out.wn_increments_realizations=temp.wn_increments_realizations,
    out.ar_increment_realizations=temp.ar_increment_realizations,
    out.wn_IS_process_realizations=temp.wn_IS_process_realizations,
    out.ar_IS_process_realizations=temp.ar_IS_process_realizations,
    out.wn_series_realizations=temp.wn_series_realizations,
    out.ar_series_realizations=temp.ar_series_realizations,
    out.seeds=seeds.par)
  return(temp.list)
}


ACS_AR1_performance.function<-function(frequencies.par,eigencoefficients.par,
                                       ar1_coefficient.par,innovation_variance.par,
                                       ACS_variance.par,ACS_powers_vector.par,
                                       N.par,significant_frequency_indices.par,
                                       ar_IS_process_realizations.par,ACS_IS_process_realizations.par,
                                       ar_ts_process_realizations.par,ACS_ts_process_realizations.par,
                                       ACS_coefficients.par,
                                       NW.par=5,K.par=NA,sampling_rate.par=1,
                                       working_directory_string.par="",frequency_units.par="measured units",
                                       output_bool.par=FALSE,plot_bool.par=FALSE,
                                       stationary_bool.par=TRUE){
  dir.create("Bifrequency_Detectors",showWarnings=FALSE)
  setwd(paste(working_directory_string.par,"Bifrequency_Detectors",sep=""))
  if(is.na(K.par)==TRUE){
    K.par=2*NW.par-1
  }
  temp.M2=length(frequencies.par)
  temp.zero_index=temp.M2-1
  temp.M=2*temp.zero_index
  temp.significant_frequencies<-frequencies.par[significant_frequency_indices.par]
  temp.num_significant=length(temp.significant_frequencies)
  #AR1 performance assessment.
  temp.ar_tf_sequence<-AR_TF_sequence(frequencies.par,ar1_coefficient.par)
  temp.ar_spectral_density_sequence<-Mod(temp.ar_tf_sequence)^2*innovation_variance.par
  temp.ar_spectral_power_sequence<-temp.ar_spectral_density_sequence/temp.M
  temp.nrow_one_step_significant_frequencies=nrow(ACS_coefficients.par)
  temp.ACS_coefficients_AR1_case<-matrix(0,nrow=temp.nrow_one_step_significant_frequencies,ncol=K.par)
  temp.DFT_eigencoefficient_vs_normalized_IS_process_object<-
    DFT_eigencoefficient_vs_normalized_IS_process.function(ts_series_realizations.par=ar_ts_process_realizations.par,
                                                           IS_process_realizations.par=ar_IS_process_realizations.par,
                                                           spectral_power_sequence.par=temp.ar_spectral_power_sequence,
                                                           N.par=temp.N,frequencies.par=frequencies.par,
                                                           significant_frequencies.par=temp.significant_frequencies,
                                                           significant_frequency_indices.par=significant_frequency_indices.par,
                                                           ACS_coefficients.par=temp.ACS_coefficients_AR1_case,
                                                           ACS_variance.par=ACS_variance.par,
                                                           NW.par=NW.par,K.par=K.par,sampling_rate.par=sampling_rate.par,
                                                           eigencoefficient_string.par="AR1",
                                                           working_directory_string.par=working_directory_string.par,
                                                           frequency_units.par=frequency_units.par,
                                                           output_bool.par=output_bool.par,plot_bool.par=plot_bool.par,
                                                           stationary_bool.par==TRUE)
  temp.num_dof=temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.num_dof
  temp.DFT_eigencoefficient_jump_RSS_matrix<-temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.DFT_eigencoefficient_jump_RSS_matrix
  temp.IS_process_variance_matrix<-temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.IS_process_variance_matrix
  temp.normalized_DFT_eigencoefficient_RSS_matrix<-temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.normalized_DFT_eigencoefficient_RSS_matrix
  temp.normalized_DFT_eigencoefficient_RSS_percentile_matrix<-
    temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.normalized_DFT_eigencoefficient_RSS_percentile_matrix
  temp.OMSC_null_quantiles_matrix_list<-temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.OMSC_quantiles_matrix_list
  temp.PLS_null_quantiles_matrix_list<-temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.PLS_quantiles_matrix_list
  temp.PLS_ecdf_matrix_list<-temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.PLS_ecdf_matrix_list
  temp.OMSC_ecdf_matrix_list<-temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.OMSC_ecdf_matrix_list
  temp.eigencoefficient_estimates_list_null<-temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.eigencoefficient_estimates_list
  temp.num_significant_normalized=nrow(temp.eigencoefficient_estimates_list_null[[1]])
  temp.eigencoefficient_covariance_matrix_list_null<-temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.eigencoefficient_covariance_matrix_list
  #ACS performance assessment.
  temp.contaminated_ACS_powers<-rep(ACS_variance.par,temp.M2)/temp.M
  temp.contaminated_ACS_powers[significant_frequency_indices.par]<-(ACS_variance.par/temp.M+ACS_powers_vector.par/temp.M^2)
  temp.DFT_eigencoefficient_vs_normalized_IS_process_object<-
    DFT_eigencoefficient_vs_normalized_IS_process.function(ts_series_realizations.par=ACS_ts_process_realizations.par,
                                                           IS_process_realizations.par=ACS_IS_process_realizations.par,
                                                           spectral_power_sequence.par=temp.contaminated_ACS_powers,
                                                           N.par=temp.N,frequencies.par=frequencies.par,
                                                           significant_frequencies.par=temp.significant_frequencies,
                                                           significant_frequency_indices.par=significant_frequency_indices.par,
                                                           ACS_coefficients.par=ACS_coefficients.par,
                                                           ACS_variance.par=ACS_variance.par,
                                                           NW.par=NW.par,K.par=K.par,sampling_rate.par=sampling_rate.par,
                                                           eigencoefficient_string.par="ACS",
                                                           working_directory_string.par=working_directory_string.par,
                                                           frequency_units.par=frequency_units.par,
                                                           output_bool.par=output_bool.par,plot_bool.par=plot_bool.par,
                                                           stationary_bool.par=FALSE)
  temp.num_dof=temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.num_dof
  temp.DFT_eigencoefficient_jump_RSS_matrix<-temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.DFT_eigencoefficient_jump_RSS_matrix
  temp.IS_process_variance_matrix<-temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.IS_process_variance_matrix
  temp.normalized_DFT_eigencoefficient_RSS_matrix<-temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.normalized_DFT_eigencoefficient_RSS_matrix
  temp.normalized_DFT_eigencoefficient_RSS_percentile_matrix<-
    temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.normalized_DFT_eigencoefficient_RSS_percentile_matrix
  temp.differenced_normalized_IS_process_matrix<-temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.differenced_normalized_IS_process_matrix
  temp.eigencoefficient_estimates_list_alternative<-temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.eigencoefficient_estimates_list
  temp.OMSC_matrix_list<-temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.OMSC_matrix_list
  temp.PLS_matrix_list<-temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.PLS_matrix_list
  temp.eigencoefficient_covariance_matrix_list_alternative<-temp.DFT_eigencoefficient_vs_normalized_IS_process_object$out.eigencoefficient_covariance_matrix_list
  #Likelihood ratios.
  temp.LR_null_list<-list()
  temp.LR_alternative_list<-list()
  temp.LR_data_list<-list()
  temp.counter=1
  for(temp.l in 1:temp.num_significant_normalized){
    for(temp.m in 1:temp.num_significant_normalized){
      temp.LR_null_list[[temp.counter]]<-list()
      temp.LR_alternative_list[[temp.counter]]<-list()
      temp.LR_data_list[[temp.counter]]<-list()
      temp.counter=temp.counter+1
    }
  }
  for(temp.u in 1:temp.num_realizations){
    temp.counter=1
    for(temp.l in 1:temp.num_significant_normalized){
      temp.eigencoefficient_estimates_list_null_ul<-temp.eigencoefficient_estimates_list_null[[temp.u]][temp.l,]
      temp.eigencoefficient_estimates_list_alternative_ul<-temp.eigencoefficient_estimates_list_alternative[[temp.u]][temp.l,]
      for(temp.m in 1:temp.num_significant_normalized){
        temp.eigencoefficient_estimates_list_null_um<-temp.eigencoefficient_estimates_list_null[[temp.u]][temp.m,]
        temp.eigencoefficient_estimates_list_alternative_um<-temp.eigencoefficient_estimates_list_alternative[[temp.u]][temp.m,]
        temp.eigencoefficient_covariance_matrix_null_lm_u<-temp.eigencoefficient_covariance_matrix_list_null[[temp.u]][[temp.counter]]
        temp.eigencoefficient_covariance_matrix_alternative_lm_u<-temp.eigencoefficient_covariance_matrix_list_alternative[[temp.u]][[temp.counter]]
        for(temp.k in 1:K.par){
          temp.matrix_lm_uk<-
            matrix.inverse(temp.eigencoefficient_covariance_matrix_null_lm_u)-matrix.inverse(temp.eigencoefficient_covariance_matrix_alternative_lm_u)
          temp.factor1=
            sqrt(Re(Det(temp.eigencoefficient_covariance_matrix_null_lm_u)/Det(temp.eigencoefficient_covariance_matrix_alternative_lm_u)))
          #Null LR.
          temp.eigencoefficient_estimates_list_null_uk_vector<-
            c(temp.eigencoefficient_estimates_list_null_ul[temp.k],temp.eigencoefficient_estimates_list_null_um[temp.k])
          temp.log_likelihood_lm_uk_null=
            hermitian.conjugate(temp.eigencoefficient_estimates_list_null_uk_vector)%*%temp.matrix_lm_uk%*%temp.eigencoefficient_estimates_list_null_uk_vector
          temp.factor2_null=exp(0.5*temp.log_likelihood_lm_uk_null)
          temp.LR_lm_uk_null=Re(temp.factor1*temp.factor2_null)
          temp.LR_null_list[[temp.counter]][[(temp.u-1)*temp.num_realizations+temp.k]]=temp.LR_lm_uk_null
          #Alternative LR.
          temp.eigencoefficient_estimates_list_alternative_uk_vector<-
            c(temp.eigencoefficient_estimates_list_alternative_ul[temp.k],temp.eigencoefficient_estimates_list_alternative_um[temp.k])
          temp.log_likelihood_lm_uk_alternative=
            hermitian.conjugate(temp.eigencoefficient_estimates_list_alternative_uk_vector)%*%temp.matrix_lm_uk%*%
            temp.eigencoefficient_estimates_list_alternative_uk_vector
          temp.factor2_alternative=exp(0.5*temp.log_likelihood_lm_uk_alternative)
          temp.LR_lm_uk_alternative=Re(temp.factor1*temp.factor2_alternative)
          temp.LR_alternative_list[[temp.counter]][[(temp.u-1)*temp.num_realizations+temp.k]]=temp.LR_lm_uk_alternative
          #Data.
          temp.eigencoefficient_estimates_list_data_uk_vector<-
            c(eigencoefficients.par[temp.l,temp.k],eigencoefficients.par[temp.m,temp.k])
          temp.log_likelihood_lm_uk_data=
            hermitian.conjugate(temp.eigencoefficient_estimates_list_data_uk_vector)%*%temp.matrix_lm_uk%*%
            temp.eigencoefficient_estimates_list_data_uk_vector
          temp.factor2_data=exp(0.5*temp.log_likelihood_lm_uk_data)
          temp.LR_lm_uk_data=Re(temp.factor1*temp.factor2_data)
          temp.LR_data_list[[temp.counter]][[(temp.u-1)*temp.num_realizations+temp.k]]=temp.LR_lm_uk_data
        }
        temp.counter=temp.counter+1
      }
    }
  }
  #ROC curves, LR.
  temp.num_all_realizations=temp.num_realizations*temp.K
  temp.x_plotting_LR_list<-list()
  temp.y_plotting_LR_list<-list()
  temp.LR_null_vector_list<-list()
  temp.LR_null_distriubtion_vector_list<-list()
  temp.LR_alternative_vector_list<-list()
  temp.LR_data_vector_list<-list()
  temp.LR_null_quantiles_vector<-list()
  temp.counter=1
  for(temp.l in 1:temp.num_significant_normalized){
    for(temp.m in 1:temp.num_significant_normalized){
      #Null.
      temp.LR_null_vector_lm_u<-unlist(temp.LR_null_list[[temp.counter]])
      temp.LR_null_vector_list[[temp.counter]]<-temp.LR_null_vector_lm_u
      temp.empirical_distribution_object<-empirical.distribution(rv.par=temp.LR_null_vector_lm_u)
      temp.null_distribution_lm<-temp.empirical_distribution_object$temp.empirical_distribution
      temp.null_quantiles_lm<-temp.empirical_distribution_object$temp.ordered_rv
      temp.LR_null_distriubtion_vector_list[[temp.counter]]<-temp.null_distribution_lm
      temp.LR_null_quantiles_vector[[temp.counter]]<-temp.null_quantiles_lm
      #Alternative.
      temp.LR_alternative_vector_lm<-unlist(temp.LR_alternative_list[[temp.counter]])
      temp.LR_alternative_vector_list[[temp.counter]]<-temp.LR_alternative_vector_lm
      #Data.
      temp.LR_data_vector_lm<-unlist(temp.LR_data_list[[temp.counter]])
      temp.LR_data_vector_list[[temp.counter]]<-temp.LR_alternative_vector_lm
      temp.powers_lm<-rep(0,temp.num_all_realizations)
      for(temp.j in 1:temp.num_all_realizations){
        temp.powers_lm[temp.j]=length(which(temp.LR_alternative_vector_lm>temp.null_quantiles_lm[temp.j]))/temp.num_all_realizations
      }
      temp.false_alarm_rates<-(1-temp.null_distribution_lm)*100
      temp.powers_vector<-temp.powers_lm*100
      temp.x_plotting_LR_list[[temp.counter]]<-temp.false_alarm_rates
      temp.y_plotting_LR_list[[temp.counter]]<-temp.powers_vector
      temp.counter=temp.counter+1
    }
  }
  #ROC curves.
  temp.num_significant_normalized=sqrt(length(temp.OMSC_null_quantiles_matrix_list))
  temp.x_plotting_list<-list()
  temp.y_plotting_OMSC_list<-list()
  temp.y_plotting_PLS_list<-list()
  temp.title_strings_list<-list()
  temp.counter=1
  for(temp.l in 1:temp.num_significant_normalized){
    for(temp.m in 1:temp.num_significant_normalized){
      temp.title_strings_list[[temp.counter]]<-paste("(l,m)=(",temp.l,",",temp.m,")",sep="")
      temp.x_plotting_list[[temp.counter]]<-(1-temp.OMSC_ecdf_matrix_list[[temp.counter]])*100
      temp.OMSC_null_quantiles_lm<-temp.OMSC_null_quantiles_matrix_list[[temp.counter]]
      temp.PLS_null_quantiles_lm<-temp.PLS_null_quantiles_matrix_list[[temp.counter]]
      temp.OMSC_estimates_lm<-temp.OMSC_matrix_list[[temp.counter]]
      temp.PLS_estimates_lm<-temp.PLS_matrix_list[[temp.counter]]
      temp.power_vector_OMSC_ml=rep(0,temp.num_realizations)
      temp.power_vector_PLS_ml<-temp.power_vector_OMSC_ml
      for(temp.u in 1:temp.num_realizations){
        temp.num_crossings=length(which(temp.OMSC_estimates_lm>=temp.OMSC_null_quantiles_lm[temp.u]))
        if(!is.null(temp.num_crossings)){
          temp.power_vector_OMSC_ml[temp.u]=temp.num_crossings
        }
        temp.num_crossings=length(which(temp.PLS_estimates_lm>=temp.PLS_null_quantiles_lm[temp.u]))
        if(!is.null(temp.num_crossings)){
          temp.power_vector_PLS_ml[temp.u]=temp.num_crossings
        }
      }
      temp.y_plotting_OMSC_list[[temp.counter]]<-temp.power_vector_OMSC_ml/temp.num_realizations*100
      temp.y_plotting_PLS_list[[temp.counter]]<-temp.power_vector_PLS_ml/temp.num_realizations*100
      temp.counter=temp.counter+1
    }
  }
  temp.title_strings_vector<-unlist(temp.title_strings_list)
  dir.create("Performance_Bifrequency_Tests",showWarnings=FALSE)
  setwd(paste(working_directory_string.par,"Bifrequency_Detectors/Performance_Bifrequency_Tests",sep=""))
  multipage_plot_comparison.function(x_plotting_list.par=temp.x_plotting_list,y_plotting_list.par=temp.y_plotting_OMSC_list,
                                     x_plotting_list2.par=temp.x_plotting_list,y_plotting_list2.par=temp.y_plotting_PLS_list,
                                     x_label.par="Percentage false-alarm rate",y_label.par="Percentage true-positive rate",pdf_title.par="ROC_Curve.pdf",
                                     title_strings.par=temp.title_strings_vector)
  temp.title_strings_vector<-unlist(temp.title_strings_list)
  #Neyman-Pearson update.
  multipage_plot_comparison.function(x_plotting_list.par=temp.x_plotting_list,y_plotting_list.par=temp.y_plotting_OMSC_list,
                                     x_plotting_list2.par=temp.x_plotting_LR_list,y_plotting_list2.par=temp.y_plotting_LR_list,
                                     x_label.par="Percentage false-alarm rate",y_label.par="Percentage true-positive rate",pdf_title.par="ROC_Curve_LR.pdf",
                                     title_strings.par=temp.title_strings_vector)
  #Neyman-Pearson detector for a selection of different false-alarm rates.
  #Performance under H_1.
  temp.phi_alternative_list<-list()
  temp.NP_power_alternative_matrix<-matrix(0,nrow=temp.num_significant_normalized,ncol=temp.num_significant_normalized)
  temp.trial_sizes<-c(0.01,0.05,0.1,0.2,0.5,0.75,0.9,0.95)
  temp.num_trial_sizes=length(temp.trial_sizes)
  temp.percentile_indices=ceil(temp.trial_sizes*(temp.num_all_realizations-2))
  temp.NP_phi_data_matrices<-list()
  for(temp.j in 1:temp.num_trial_sizes){
    temp.NP_phi_data_matrices[[temp.j]]<-temp.NP_power_alternative_matrix
  }
  temp.x_plotting_LR_list2<-list()
  temp.counter=1
  temp.delta_PF=0
  for(temp.l in 1:temp.num_significant_normalized){
    cat(temp.l," out of ",temp.num_significant_normalized,"\n")
    for(temp.m in 1:temp.num_significant_normalized){
      temp.phi_alternative_list[[temp.counter]]<-rep(0,temp.num_all_realizations)
      temp.false_alarm_rates<-temp.x_plotting_LR_list[[temp.counter]]
      temp.x_plotting_LR_list2[[temp.counter]]<-temp.false_alarm_rates
      if(temp.l==1 & temp.m==1){
        temp.delta_PF=temp.false_alarm_rates[2]-temp.false_alarm_rates[1]
      }
      temp.powers_vector<-temp.y_plotting_LR_list[[temp.counter]]
      temp.eta_values_lm<-rep(0,temp.num_all_realizations)
      for(temp.j in 1:(temp.num_all_realizations-2)){
        temp.eta_values_lm[temp.j]=(-temp.powers_vector[temp.j+2]+4*temp.powers_vector[temp.j+1]-3*temp.powers_vector[temp.j])/(2*temp.delta_PF)
      }
      temp.null_quantiles_lm<-temp.LR_null_quantiles_vector[[temp.counter]]
      temp.LR_null_distribution_vector_lm<-temp.LR_null_distriubtion_vector_list[[temp.counter]]
      temp.LR_alternative_vector_lm<-temp.LR_alternative_vector_list[[temp.counter]]
      temp.LR_data_vector_lm<-temp.LR_data_vector_list[[temp.counter]]
      for(temp.k in 1:temp.num_all_realizations){
        temp.alpha_lm_k=temp.false_alarm_rates[temp.k]
        temp.phi_lmk_alternative_vector<-rep(0,temp.num_all_realizations-2)
        temp.phi_lmk_data_vector<-temp.phi_lmk_alternative_vector
        for(temp.j in 1:(temp.num_all_realizations-2)){
          temp.LR_alternative_vector_entry_lmj=temp.LR_alternative_vector_lm[temp.j]
          temp.LR_data_vector_entry_lmj=temp.LR_data_vector_lm[temp.j]
          #cat("temp.LR_alternative_vector_entry_lmj=",temp.LR_alternative_vector_entry_lmj,"\n")
          #Alternative.
          if(!is.infinite(temp.LR_alternative_vector_entry_lmj)){
            temp.diffs<-abs(temp.LR_alternative_vector_entry_lmj-temp.null_quantiles_lm)
            temp.min_diff=min(temp.diffs)
            temp.optimal_index=min(which(temp.diffs==temp.min_diff))
            temp.eta_value_lmj=temp.eta_values_lm[temp.num_all_realizations-temp.optimal_index+1]
            #cat("temp.eta_value_lmj=",temp.eta_value_lmj,"\n")
            temp.phi_lmkj=1
            if(temp.l!=temp.m){
              if(temp.LR_alternative_vector_entry_lmj==temp.eta_value_lmj){
                if(temp.optimal_index>1){
                  temp.P_null_l_greater_than_eta_lm=(1-temp.LR_null_distribution_vector_lm[temp.optimal_index])
                  temp.P_null_l_equal_to_eta=temp.LR_null_distribution_vector_lm[temp.optimal_index]-temp.LR_null_distribution_vector_lm[temp.optimal_index-1]
                  temp.gamma_lmkj=(temp.alpha_lm_k-temp.P_null_l_greater_than_eta_lm)/temp.P_null_l_equal_to_eta
                  #cat("temp.gamma_lmkj=",temp.gamma_lmkj,"\n")
                  temp.phi_lmkj=temp.gamma_lmkj
                }
                else{
                  temp.phi_lmkj=0
                }
              }
              else if(temp.LR_alternative_vector_entry_lmj>temp.eta_value_lmj){
                temp.phi_lmkj=1
              }
            }
            temp.phi_lmk_alternative_vector[temp.j]=temp.phi_lmkj
          }
          #Data.
          if(!is.infinite(temp.LR_data_vector_entry_lmj)){
            temp.diffs<-abs(temp.LR_data_vector_entry_lmj-temp.null_quantiles_lm)
            temp.min_diff=min(temp.diffs)
            temp.optimal_index=min(which(temp.diffs==temp.min_diff))
            temp.eta_value_lmj=temp.eta_values_lm[temp.num_all_realizations-temp.optimal_index+1]
            #cat("temp.eta_value_lmj=",temp.eta_value_lmj,"\n")
            temp.phi_lmkj=1
            if(temp.l!=temp.m){
              if(temp.LR_data_vector_entry_lmj==temp.eta_value_lmj){
                if(temp.optimal_index>1){
                  temp.P_null_l_greater_than_eta_lm=(1-temp.LR_null_distribution_vector_lm[temp.optimal_index])
                  temp.P_null_l_equal_to_eta=temp.LR_null_distribution_vector_lm[temp.optimal_index]-temp.LR_null_distribution_vector_lm[temp.optimal_index-1]
                  temp.gamma_lmkj=(temp.alpha_lm_k-temp.P_null_l_greater_than_eta_lm)/temp.P_null_l_equal_to_eta
                  #cat("temp.gamma_lmkj=",temp.gamma_lmkj,"\n")
                  temp.phi_lmkj=temp.gamma_lmkj
                }
                else{
                  temp.phi_lmkj=0
                }
              }
              else if(temp.LR_data_vector_entry_lmj>temp.eta_value_lmj){
                temp.phi_lmkj=1
              }
            }
            temp.phi_lmk_data_vector[temp.j]=temp.phi_lmkj
          }
        }
        #Alternative.
        temp.rate_lm_k=length(which(temp.phi_lmk_alternative_vector>0))/(temp.num_all_realizations-2)*100
        if(temp.k==1){
          if(temp.l==temp.m){
            temp.NP_power_alternative_matrix[temp.l,temp.m]=100
          }
          else{
            temp.NP_power_alternative_matrix[temp.l,temp.m]=temp.rate_lm_k
          }
        }
        temp.phi_alternative_list[[temp.counter]][temp.k]=temp.rate_lm_k
        #Data.
        for(temp.j in 1:temp.num_trial_sizes){
          temp.percentile_index_j=temp.percentile_indices[temp.j]
          if(temp.k==temp.percentile_index_j){
            if(temp.l==temp.m){
              temp.NP_phi_data_matrices[[temp.j]][temp.l,temp.m]=1
            }
            else{
              temp.NP_phi_data_matrices[[temp.j]][temp.l,temp.m]=temp.phi_lmk_data_vector[temp.percentile_index_j]
            }
          }
        }
      }
      temp.counter=temp.counter+1
    }
  }
  multipage_plot_comparison.function(x_plotting_list.par=temp.x_plotting_list,y_plotting_list.par=temp.y_plotting_OMSC_list,
                                     x_plotting_list2.par=temp.x_plotting_LR_list2,y_plotting_list2.par=temp.phi_alternative_list,
                                     x_label.par="Percentage false-alarm rate",y_label.par="Percentage true-positive rate",pdf_title.par="ROC_Curve_LR_NP.pdf",
                                     title_strings.par=temp.title_strings_vector)
  temp.plotting_frequencies_heat_map<-temp.significant_frequencies[1:temp.num_significant_normalized]*sampling_rate.par
  temp.num_upper_bound=length(unique(as.vector(temp.NP_power_alternative_matrix)))
  if(temp.num_upper_bound==1 & temp.NP_power_alternative_matrix[1,1]>99){
    temp.rvs<-rnorm(temp.num_significant_normalized^2)^2
    temp.NP_power_alternative_matrix<-matrix(100-temp.rvs,nrow=temp.num_significant_normalized,ncol=temp.num_significant_normalized)
  }
  heat_map.function(x.par=temp.plotting_frequencies_heat_map,y.par=temp.plotting_frequencies_heat_map,matrix.par=temp.NP_power_alternative_matrix,
                    z_bounds.par=c(min(temp.NP_power_alternative_matrix),max(temp.NP_power_alternative_matrix)),
                    abscissa_quantity.par="Frequency",abscissa_units.par=frequency_units.par,
                    ordinates_quantity.par="Frequency",ordinates_units.par=frequency_units.par,
                    heights_quantity.par="True-positive rate",heights_units.par="%",
                    pdf_title.par="NP_Power_Bifrequency_Map.pdf")
  setwd("../")
  dir.create("Data_Bifrequency_LR_Tests",showWarnings=FALSE)
  setwd(paste(working_directory_string.par,"Bifrequency_Detectors/Data_Bifrequency_LR_Tests",sep=""))
  dir.create("Connectivity_Maps",showWarnings=FALSE)
  setwd("Connectivity_Maps")
  dir.create("Map_Plots",showWarnings=FALSE)
  dir.create("Text_Files",showWarnings=FALSE)
  setwd("../")
  temp.coincidence_NP_phi_data_matrix<-matrix(0,nrow=temp.num_significant_normalized,ncol=temp.num_significant_normalized)
  for(temp.j in 1:temp.num_trial_sizes){
    temp.size_j=round_general.function(temp.trial_sizes[temp.j])*100
    temp.NP_phi_data_matrix_j<-temp.NP_phi_data_matrices[[temp.j]]
    temp.coincidence_NP_phi_data_matrix<-temp.coincidence_NP_phi_data_matrix+temp.NP_phi_data_matrix_j
    temp.x_values<-cos(2*pi*temp.significant_frequencies[1:temp.num_significant_normalized])
    temp.y_values<-sin(2*pi*temp.significant_frequencies[1:temp.num_significant_normalized])
    temp.plotting_list_x<-list()
    temp.plotting_list_y<-list()
    temp.plot_type_list<-list()
    temp.colour_list<-list()
    temp.line_type_list<-list()
    temp.lwd_list<-list()
    temp.title<-c()
    sink(paste("Connectivity_Maps/Text_Files/",temp.j,"_NP_Phi_Bifrequency_Connectivity_Map_Size_",temp.size_j,"_Percent.txt",sep=""), append=FALSE, split=FALSE)
    cat("Frequency_index\tFrequency\tFrequency_index\tFrequency\tSuccess\n")
    temp.counter=1
    for(temp.l in 1:temp.num_significant_normalized){
      temp.frequency_l=temp.plotting_frequencies_heat_map[temp.num_significant_normalized-temp.l+1]
      temp.frequency_l_string<-round_general.function(temp.frequency_l,digits.par=2)
      temp.frequency_l_value=temp.plotting_frequencies_heat_map[temp.l]
      if(temp.l==1){
        temp.title<-paste(temp.title,temp.frequency_l_string,sep="")
      }
      else{
        temp.title<-paste(temp.title,", ",temp.frequency_l_string,sep="")
      }
      for(temp.m in 1:temp.num_significant_normalized){
        temp.frequency_m_value=temp.plotting_frequencies_heat_map[temp.m]
        cat(temp.l,"\t",temp.frequency_l_value,"\t",temp.m,"\t",temp.frequency_m_value,"\t",temp.NP_phi_data_matrix_j[temp.l,temp.m],"\n")
        if(temp.NP_phi_data_matrix_j[temp.l,temp.m]>0){
          temp.plotting_list_x[[temp.counter]]<-c(temp.x_values[temp.l],temp.x_values[temp.m])
          temp.plotting_list_y[[temp.counter]]<-c(temp.y_values[temp.l],temp.y_values[temp.m])
          if(temp.l==temp.m){
            temp.plot_type_list[[temp.counter]]<-"o"
          }
          else{
            temp.plot_type_list[[temp.counter]]<-"l"
          }
          temp.colour_list[[temp.counter]]=temp.l
          temp.line_type_list[[temp.counter]]=temp.l
          temp.lwd_list[[temp.counter]]=2
          temp.counter=temp.counter+1
        }
      }
    }
    sink()
    temp.plot_type_vector<-unlist(temp.plot_type_list)
    temp.colour_vector<-unlist(temp.colour_list)
    temp.line_type_vector<-unlist(temp.line_type_list)
    temp.lwd_vector<-unlist(temp.lwd_list)
    plot.graph(temp.plotting_list_x,temp.plotting_list_y,x_label.par="Real",y_label.par="Imaginary",
               plotting_LB_x.par=min(temp.x_values),plotting_UB_x.par=max(temp.x_values),
               plotting_LB.par=min(temp.y_values),plotting_UB.par=max(temp.y_values),
               pdf_title.par=paste("Connectivity_Maps/Map_Plots/",temp.j,"_NP_Phi_Bifrequency_Connectivity_Map_Size_",temp.size_j,"_Percent.pdf",sep=""),
               type.par=temp.plot_type_vector,col.par=temp.colour_vector,
               lty.par=temp.line_type_vector,lwd.par=temp.lwd_vector)
  }
  sink("NP_Phi_Bifrequency_Coincidence_Map.txt", append=FALSE, split=FALSE)
  cat("Frequency_index\tFrequency\tFrequency_index\tFrequency\tCount\n")
  for(temp.l in 1:temp.num_significant_normalized){
    for(temp.m in 1:temp.num_significant_normalized){
      cat(temp.l,"\t",temp.plotting_frequencies_heat_map[temp.l],"\t",temp.m,"\t",
          temp.plotting_frequencies_heat_map[temp.m],"\t",temp.coincidence_NP_phi_data_matrix[temp.l,temp.m],"\n")
    }
  }
  sink()
  temp.num_upper_bound=length(unique(as.vector(temp.coincidence_NP_phi_data_matrix)))
  if(temp.num_upper_bound==1 & temp.coincidence_NP_phi_data_matrix[1,1]>(temp.num_trial_sizes-1)){
    temp.rvs<-rnorm(temp.num_significant_normalized^2)^2
    temp.coincidence_NP_phi_data_matrix<-matrix(temp.num_trial_sizes-temp.rvs,nrow=temp.num_significant_normalized,ncol=temp.num_significant_normalized)
  }
  heat_map.function(x.par=temp.plotting_frequencies_heat_map,y.par=temp.plotting_frequencies_heat_map,matrix.par=temp.coincidence_NP_phi_data_matrix,
                    z_bounds.par=c(min(temp.coincidence_NP_phi_data_matrix),max(temp.coincidence_NP_phi_data_matrix)),
                    abscissa_quantity.par="Frequency",abscissa_units.par=frequency_units.par,
                    ordinates_quantity.par="Frequency",ordinates_units.par=frequency_units.par,
                    heights_quantity.par="No. coincidences",heights_units.par=paste("bits per ",temp.num_trial_sizes," trial sizes",sep=""),
                    pdf_title.par="NP_Phi_Bifrequency_Coincidence_Map.pdf")
  setwd("../../")
  temp.list<-list(out.num_dof=temp.num_dof,
                  out.DFT_eigencoefficient_jump_RSS_matrix=temp.DFT_eigencoefficient_jump_RSS_matrix,
                  out.IS_process_variance_matrix=temp.IS_process_variance_matrix,
                  out.normalized_DFT_eigencoefficient_RSS_matrix=temp.normalized_DFT_eigencoefficient_RSS_matrix,
                  out.normalized_DFT_eigencoefficient_RSS_percentile_matrix=temp.normalized_DFT_eigencoefficient_RSS_percentile_matrix,
                  out.differenced_normalized_IS_process_matrix=temp.differenced_normalized_IS_process_matrix,
                  out.eigencoefficient_jump_estimates_list=temp.eigencoefficient_estimates_list_alternative)
  return(temp.list)
}

DFT_eigencoefficient_vs_normalized_IS_process.function<-function(ts_series_realizations.par,
                                                                 IS_process_realizations.par,spectral_power_sequence.par,
                                                                 N.par,frequencies.par,
                                                                 significant_frequencies.par=0,significant_frequency_indices.par=1,
                                                                 ACS_coefficients.par=NA,ACS_variance.par,
                                                                 NW.par=5,K.par=NA,sampling_rate.par=1,
                                                                 eigencoefficient_string.par="",working_directory_string.par="",
                                                                 frequency_units.par="measured units",
                                                                 output_bool.par=FALSE,plot_bool.par=FALSE,
                                                                 stationary_bool.par=TRUE){
  temp.eigencoefficient_string<-"Eigencoefficient_Estimation_Performance"
  dir.create(temp.eigencoefficient_string,showWarnings=FALSE)
  setwd(temp.eigencoefficient_string)
  temp.eigencoefficient_string<-paste("Eigencoefficient_Estimation_Performance_",eigencoefficient_string.par,sep="")
  dir.create(temp.eigencoefficient_string,showWarnings=FALSE)
  setwd(temp.eigencoefficient_string)
  dir.create("IS_Process_vs_DFT_Eigencoefficient_Realizations",showWarnings=FALSE)
  #Initialization.
  if(is.na(K.par)==TRUE){
    K.par=2*NW.par-1
  }
  temp.num_realizations=ncol(IS_process_realizations.par)
  temp.num_significant=length(significant_frequency_indices.par)
  temp.M=nrow(IS_process_realizations.par)
  temp.zero_index=temp.M/2
  temp.num_dof=2*temp.num_realizations
  temp.W=NW.par/N.par
  temp.FFT_significant_frequency_indices<-temp.zero_index+significant_frequency_indices.par
  significant_frequencies.par<-frequencies.par[temp.FFT_significant_frequency_indices-temp.zero_index]
  temp.spectral_powers<-spectral_power_sequence.par[temp.FFT_significant_frequency_indices-temp.zero_index]
  #DPSS computations.
  temp.dpss_matrix_object<-dpss.matrix(N.par=N.par,NW.par=NW.par,K.par=K.par)
  temp.dpss_matrix<-temp.dpss_matrix_object$out.dpss
  temp.dpss_eigenvalues<-temp.dpss_matrix_object$out.eigenvalues
  #Augmented covariance matrices.
  temp.second_difference_coefficients<-0.25*c(1,-4,3,-4,16,-12,3,-12,9)
  temp.second_difference_coefficients<-c(temp.second_difference_coefficients,temp.second_difference_coefficients)
  temp.num_one_step_ACS_coefficients=nrow(ACS_coefficients.par)
  temp.num_significant_normalized=temp.num_one_step_ACS_coefficients/2
  temp.left_indices<-2:temp.M-1
  temp.right_indices<-2:temp.M
  temp.IS_process_left<-IS_process_realizations.par[temp.left_indices,]
  temp.IS_process_right<-IS_process_realizations.par[temp.right_indices,]
  temp.normalized_IS_process<-(temp.IS_process_left+temp.IS_process_right)/2
  temp.normalized_IS_process<-rbind(rep(0,temp.num_realizations),temp.normalized_IS_process)
  temp.PLS_population_values_matrix<-matrix(0,nrow=temp.num_significant_normalized,ncol=temp.num_significant_normalized)
  temp.OMSC_population_values_matrix<-temp.PLS_population_values_matrix
  temp.counter1=1
  for(temp.l in seq(from=1,to=temp.num_one_step_ACS_coefficients-1,by=2)){
    temp.ACS_coefficient_estimates_l<-ACS_coefficients.par[temp.l,]
    temp.ACS_coefficient_estimates_l_plus<-ACS_coefficients.par[temp.l+1,]
    temp.indices_l<-c(rep(temp.l+2,3),rep(temp.l+1,3),rep(temp.l,3))
    temp.indices_l<-c(temp.indices_l-1,temp.indices_l)
    temp.counter2=1
    for(temp.m in seq(from=1,to=temp.num_one_step_ACS_coefficients-1,by=2)){
      temp.indices_m<-c(temp.m+rev(1:3)-1,temp.m+rev(1:3)-1,temp.m+rev(1:3)-1)
      temp.indices_m<-c(temp.indices_m-1,temp.indices_m)
      #Augmented cross covariance.
      temp.normalized_covariance_derivative_lm=0
      if(!stationary_bool.par){
        temp.normalized_covariance_vector_lm<-rep(0,9)
        for(temp.j in 1:9){
          temp.l_index=temp.indices_l[temp.j]
          temp.m_index=temp.indices_m[temp.j]
          temp.normalized_covariance_vector_lm[temp.j]<-mean(temp.normalized_IS_process[temp.l_index,]*Conj(temp.normalized_IS_process[temp.m_index,]))
        }
        temp.normalized_covariance_derivative_lm=sum(temp.second_difference_coefficients*temp.normalized_covariance_vector_lm)
        #cat("temp.normalized_covariance_derivative_lm=",temp.normalized_covariance_derivative_lm,"\n")
      }
      if(temp.l==temp.m){
        temp.normalized_covariance_derivative_lm=temp.normalized_covariance_derivative_lm+ACS_variance.par/temp.M
        #cat("Revised: temp.normalized_covariance_derivative_lm=",temp.normalized_covariance_derivative_lm,"\n")
      }
      temp.augmented_normalized_covariance_vector_lm<-c(temp.normalized_covariance_derivative_lm,Conj(temp.normalized_covariance_derivative_lm))
      temp.augmented_matrix_lm<-
        temp.augmented_normalized_covariance_vector_lm%*%hermitian.conjugate(temp.augmented_normalized_covariance_vector_lm)
      #Augmented covariance l.
      temp.normalized_covariance_derivative_ll=0
      if(!stationary_bool.par){
        temp.normalized_covariance_vector_ll<-rep(0,9)
        for(temp.j in 1:9){
          temp.l_index=temp.indices_l[temp.j]
          temp.normalized_covariance_vector_ll[temp.j]<-mean(Mod(temp.normalized_IS_process[temp.l_index,])^2)
        }
        temp.normalized_covariance_derivative_ll<-sum(temp.second_difference_coefficients*temp.normalized_covariance_vector_ll)
      }
      temp.normalized_covariance_derivative_ll=temp.normalized_covariance_derivative_ll+ACS_variance.par/temp.M
      temp.augmented_normalized_covariance_vector_ll<-c(temp.normalized_covariance_derivative_ll,Conj(temp.normalized_covariance_derivative_ll))
      temp.augmented_matrix_ll<-
        temp.augmented_normalized_covariance_vector_ll%*%hermitian.conjugate(temp.augmented_normalized_covariance_vector_ll)
      #Augmented covariance m.
      temp.normalized_covariance_derivative_mm=0
      if(!stationary_bool.par){
        temp.normalized_covariance_vector_mm<-rep(0,9)
        for(temp.j in 1:9){
          temp.m_index=temp.indices_m[temp.j]
          temp.normalized_covariance_vector_mm[temp.j]<-mean(Mod(temp.normalized_IS_process[temp.m_index,])^2)
        }
        temp.normalized_covariance_derivative_mm<-sum(temp.second_difference_coefficients*temp.normalized_covariance_vector_mm)
      }
      temp.normalized_covariance_derivative_mm=temp.normalized_covariance_derivative_mm+ACS_variance.par/temp.M
      temp.augmented_normalized_covariance_vector_mm<-c(temp.normalized_covariance_derivative_mm,Conj(temp.normalized_covariance_derivative_mm))
      temp.augmented_matrix_mm<-
        temp.augmented_normalized_covariance_vector_mm%*%hermitian.conjugate(temp.augmented_normalized_covariance_vector_mm)
      #Compute the test statistic.
      temp.total_normalized_covariance_lm=
        Re(matrix.trace(temp.augmented_matrix_lm%*%hermitian.conjugate(temp.augmented_matrix_lm)))
      temp.total_normalized_covariance_ll=Re(matrix.trace(temp.augmented_matrix_ll%*%hermitian.conjugate(temp.augmented_matrix_ll)))
      temp.total_normalized_covariance_mm=Re(matrix.trace(temp.augmented_matrix_mm%*%hermitian.conjugate(temp.augmented_matrix_mm)))
      temp.test_statistic=
        temp.total_normalized_covariance_lm/sqrt(temp.total_normalized_covariance_ll*temp.total_normalized_covariance_mm)
      #cat("temp.test_statistic=",temp.test_statistic,"\n")
      temp.PLS_population_values_matrix[temp.counter1,temp.counter2]=temp.test_statistic
      #OMSC test statistic.
      temp.omsc_normalized_covariance_lm=Mod(temp.normalized_covariance_derivative_lm)^2
      temp.omsc_normalized_covariance_ll=Mod(temp.normalized_covariance_derivative_ll)^2
      temp.omsc_normalized_covariance_mm=Mod(temp.normalized_covariance_derivative_mm)^2
      temp.OMSC_population_values_matrix[temp.counter1,temp.counter2]=
        temp.omsc_normalized_covariance_lm/sqrt(temp.omsc_normalized_covariance_ll*temp.omsc_normalized_covariance_mm)
      temp.counter2=temp.counter2+1
    }
    temp.counter1=temp.counter1+1
  }
  #Initialization.
  temp.plotting_frequencies<-frequencies.par[temp.FFT_significant_frequency_indices-temp.zero_index]*sampling_rate.par
  temp.DFT_eigencoefficient_jump_RSS_matrix<-matrix(0,nrow=temp.num_significant_normalized,ncol=K.par)
  temp.difference_sum_real_matrix<-temp.DFT_eigencoefficient_jump_RSS_matrix
  temp.differenced_sum_squares_real_matrix<-temp.DFT_eigencoefficient_jump_RSS_matrix
  temp.differenced_sum_imaginary_matrix<-temp.DFT_eigencoefficient_jump_RSS_matrix
  temp.differenced_sum_squares_imaginary_matrix<-temp.DFT_eigencoefficient_jump_RSS_matrix
  temp.DFT_eigencoefficient_MLR_matrix<-temp.DFT_eigencoefficient_jump_RSS_matrix
  temp.normalized_IS_process_matrix<-matrix(0,nrow=temp.num_significant_normalized,ncol=temp.num_realizations)
  temp.eigencoefficient_estimates_list<-list()
  for(temp.u in 1:temp.num_realizations){
    #Compute the u'th normalized IS-process realization.
    temp.left_indices<-2:temp.M-1
    temp.right_indices<-2:temp.M
    temp.IS_process_left_u<-IS_process_realizations.par[temp.left_indices,temp.u]
    temp.IS_process_right_u<-IS_process_realizations.par[temp.right_indices,temp.u]
    temp.normalized_IS_process_u<-(temp.IS_process_left_u+temp.IS_process_right_u)/2
    temp.normalized_IS_process_u<-c(0,temp.normalized_IS_process_u)
    temp.differenced_normalized_IS_process_u<-temp.normalized_IS_process_u[temp.FFT_significant_frequency_indices]
    temp.normalized_IS_process_matrix[,temp.u]<-temp.differenced_normalized_IS_process_u
    temp.process_realization_u<-ts_series_realizations.par[,temp.u]
    temp.DFT_eigencoefficient_matrix_u<-matrix(0,nrow=temp.num_significant_normalized,ncol=K.par)
    for(temp.j in 1:temp.num_significant_normalized){
      for(temp.k in 1:K.par){
        temp.DFT_entry=sum(temp.dpss_matrix[,temp.k]*temp.process_realization_u*exp(-1i*2*pi*significant_frequencies.par[temp.j]*(1:N.par-1)))
        temp.DFT_eigencoefficient_matrix_u[temp.j,temp.k]=temp.DFT_entry#/temp.dpss_eigenvalues[temp.k]
      }
    }
    if(temp.u==1){
      #DFT eigencoefficient variables.
      temp.IS_process_real<-Re(temp.differenced_normalized_IS_process_u)
      temp.IS_process_imaginary<-Im(temp.differenced_normalized_IS_process_u)
      temp.DFT_eigencoefficient_real_u<-Re(temp.DFT_eigencoefficient_matrix_u)
      temp.DFT_eigencoefficient_imaginary_u<-Im(temp.DFT_eigencoefficient_matrix_u)
      temp.plotting_frequency_matrix<-matrix(0,nrow=temp.num_significant_normalized,ncol=K.par)
      temp.IS_process_real_matrix<-temp.plotting_frequency_matrix
      temp.IS_process_imaginary_matrix<-temp.plotting_frequency_matrix
      for(temp.k in 1:K.par){
        temp.plotting_frequency_matrix[,temp.k]<-temp.plotting_frequencies
        temp.IS_process_real_matrix[,temp.k]<-temp.IS_process_real
        temp.IS_process_imaginary_matrix[,temp.k]<-temp.IS_process_imaginary
      }
      temp.ordinate_quantity_string<-paste(measure_quantity.string,"\nDFT-eigencoefficient (red) vs. normalized IS (black)",sep="")
      multipage_three_dimensional_overlay_scatter_plots.function(x_matrix.par=temp.plotting_frequency_matrix,
                                                                 y_matrix1.par=temp.IS_process_real_matrix,z_matrix1.par=temp.IS_process_imaginary_matrix,
                                                                 y_matrix2.par=temp.DFT_eigencoefficient_real_u,z_matrix2.par=temp.DFT_eigencoefficient_imaginary_u,
                                                                 abscissa_quantity_string.par="Frequency",abscissa_units_string.par=frequency_units.string,
                                                                 ordinates1_quantity_string.par="Real",ordinates1_units_string.par=measure_units.string,
                                                                 ordinates2_quantity_string.par="Imaginary",ordinates2_units_string.par=measure_units.string,
                                                                 plot_title_string.par=temp.ordinate_quantity_string,
                                                                 pdf_title.par=
                                                                   "IS_Process_vs_DFT_Eigencoefficient_Realizations/DFT_Eigencoefficient_Process_Realizations.pdf")
    }
    temp.eigencoefficient_estimates_list[[temp.u]]<-temp.DFT_eigencoefficient_matrix_u
    temp.difference_matrix_u<-sweep(temp.DFT_eigencoefficient_matrix_u,MARGIN=1,temp.differenced_normalized_IS_process_u,FUN="-")
    temp.DFT_eigencoefficient_jump_RSS_matrix<-temp.DFT_eigencoefficient_jump_RSS_matrix+Mod(temp.difference_matrix_u)^2
    #Estimation variance.
    temp.difference_matrix_real_u<-Re(temp.DFT_eigencoefficient_matrix_u)
    temp.difference_sum_real_matrix<-temp.difference_sum_real_matrix+temp.difference_matrix_real_u
    temp.differenced_sum_squares_real_matrix<-
      temp.differenced_sum_squares_real_matrix+temp.difference_matrix_real_u^2
    temp.difference_matrix_imaginary_u<-Im(temp.DFT_eigencoefficient_matrix_u)
    temp.differenced_sum_imaginary_matrix<-
      temp.differenced_sum_imaginary_matrix+temp.difference_matrix_imaginary_u
    temp.differenced_sum_squares_imaginary_matrix<-
      temp.differenced_sum_squares_imaginary_matrix+temp.difference_matrix_imaginary_u^2
  }
  #Compute the empirical-distribution sequences.
  temp.eigencoefficient_covariance_matrix_list<-list()
  temp.eigencoefficient_reflectional_covariance_matrix_list<-list()
  temp.eigencoefficient_augmented_data_matrix_l_list<-list()
  temp.eigencoefficient_augmented_data_matrix_m_list<-list()
  for(temp.u in 1:temp.num_realizations){
    temp.DFT_eigencoefficient_matrix_u<-temp.eigencoefficient_estimates_list[[temp.u]]
    temp.eigencoefficient_covariance_matrix_list[[temp.u]]<-list()
    temp.eigencoefficient_reflectional_covariance_matrix_list[[temp.u]]<-list()
    temp.eigencoefficient_augmented_data_matrix_l_list[[temp.u]]<-list()
    temp.eigencoefficient_augmented_data_matrix_m_list[[temp.u]]<-list()
    temp.counter=1
    for(temp.l in 1:temp.num_significant_normalized){
      temp.eigencoefficient_vector_l_u<-temp.DFT_eigencoefficient_matrix_u[temp.l,]
      for(temp.m in 1:temp.num_significant_normalized){
        temp.eigencoefficient_vector_m_u<-temp.DFT_eigencoefficient_matrix_u[temp.m,]
        temp.data_matrix_l_u<-temp.eigencoefficient_vector_l_u
        temp.data_matrix_m_u<-temp.eigencoefficient_vector_m_u
        temp.sample_cross_covariance_matrix_ml_u<-temp.data_matrix_l_u%*%hermitian.conjugate(temp.data_matrix_m_u)/K.par
        temp.eigencoefficient_covariance_matrix_list[[temp.u]][[temp.counter]]=temp.sample_cross_covariance_matrix_ml_u
        temp.sample_reflectional_cross_covariance_matrix_ml_u<-temp.data_matrix_l_u%*%t(temp.data_matrix_m_u)/K.par
        temp.eigencoefficient_reflectional_covariance_matrix_list[[temp.u]][[temp.counter]]=temp.sample_reflectional_cross_covariance_matrix_ml_u
        temp.eigencoefficient_augmented_data_matrix_l_list[[temp.u]][[temp.counter]]=rbind(temp.data_matrix_l_u,Conj(temp.data_matrix_l_u))
        temp.eigencoefficient_augmented_data_matrix_m_list[[temp.u]][[temp.counter]]=rbind(temp.data_matrix_m_u,Conj(temp.data_matrix_m_u))
        temp.counter=temp.counter+1
      }
    }
  }
  #MLR-coefficient estimates
  temp.redundancy_indices_matrix<-matrix(0,nrow=temp.num_significant_normalized,ncol=K.par)
  for(temp.l in 1:temp.num_significant_normalized){
    temp.normalized_IS_vector<-rep(0,temp.num_realizations)
    for(temp.k in 1:K.par){
      temp.eigencoefficient_vector_kl<-rep(0,temp.num_realizations)
      for(temp.u in 1:temp.num_realizations){
        if(temp.k==1){
          temp.normalized_IS_vector[temp.u]=temp.normalized_IS_process_matrix[temp.l,temp.u]
        }
        temp.eigencoefficient_vector_kl[temp.u]<-temp.eigencoefficient_estimates_list[[temp.u]][temp.l,temp.k]
      }
      temp.redundancy_index=
        total_MLR_test_statistic.function(vector_1.par=temp.normalized_IS_vector,vector_2.par=temp.eigencoefficient_vector_kl)
      temp.redundancy_indices_matrix[temp.l,temp.k]=temp.redundancy_index
    }
  }
  #OMSC estimates.
  temp.OMSC_matrix_list<-list()
  temp.counter=1
  for(temp.l in 1:temp.num_significant_normalized){
    for(temp.m in 1:temp.num_significant_normalized){
      temp.OMSC_matrix_list[[temp.counter]]<-rep(0,temp.num_realizations)
      temp.counter=temp.counter+1
    }
  }
  temp.OMSC_estimation_RSS_matrix<-matrix(0,nrow=temp.num_significant_normalized,ncol=temp.num_significant_normalized)
  temp.OMSC_mean_matrix<-temp.OMSC_estimation_RSS_matrix
  #if(FALSE){
  for(temp.u in 1:temp.num_realizations){
    temp.eigencoefficient_matrix_u<-temp.eigencoefficient_estimates_list[[temp.u]]
    temp.eigencoefficient_matrix_u<-temp.eigencoefficient_matrix_u[1:temp.num_significant_normalized,]
    temp.omsc_test_object<-
      omsc_test.function(eigencoefficient_matrix.par=temp.eigencoefficient_matrix_u,omsc_truth_matrix.par=temp.OMSC_population_values_matrix)
    temp.estimated_omsc_matrix<-temp.omsc_test_object$out.estimated_omsc_matrix
    temp.diff_matrix<-temp.estimated_omsc_matrix-temp.OMSC_population_values_matrix
    temp.OMSC_estimation_RSS_matrix<-temp.OMSC_estimation_RSS_matrix+temp.diff_matrix^2
    temp.OMSC_mean_matrix<-temp.OMSC_mean_matrix+temp.estimated_omsc_matrix
    temp.counter=1
    for(temp.l in 1:temp.num_significant_normalized){
      for(temp.m in 1:temp.num_significant_normalized){
        temp.OMSC_matrix_list[[temp.counter]][temp.u]=temp.estimated_omsc_matrix[temp.l,temp.m]
        temp.counter=temp.counter+1
      }
    }
  }
  #}
  temp.OMSC_estimation_RSS_matrix<-temp.OMSC_estimation_RSS_matrix/temp.num_realizations
  temp.OMSC_mean_matrix<-temp.OMSC_mean_matrix/temp.num_realizations
  #}#endif
  #PLS-coefficient estimates.
  temp.PLS_estimation_rss_matrix<-matrix(0,nrow=temp.num_significant_normalized,ncol=temp.num_significant_normalized)
  temp.PLS_mean_matrix<-temp.PLS_estimation_rss_matrix
  temp.PLS_matrix_list<-list()
  temp.counter=1
  for(temp.l in 1:temp.num_significant_normalized){
    for(temp.m in 1:temp.num_significant_normalized){
      temp.PLS_matrix_list[[temp.counter]]<-rep(0,temp.num_realizations)
      temp.counter=temp.counter+1
    }
  }
  for(temp.u in 1:temp.num_realizations){
    temp.PLS_coefficient_estimate_matrix_u<-matrix(0,nrow=temp.num_significant_normalized,ncol=temp.num_significant_normalized)
    temp.counter=1
    for(temp.l in 1:temp.num_significant_normalized){
      temp.eigencoefficient_vector_ul<-temp.eigencoefficient_estimates_list[[temp.u]][temp.l,]
      for(temp.m in 1:temp.num_significant_normalized){
        temp.eigencoefficient_vector_um<-temp.eigencoefficient_estimates_list[[temp.u]][temp.m,]
        temp.PLS_coefficient_estimate_matrix_u[temp.l,temp.m]=
          total_PLS_test_statistic.function(as.vector(temp.eigencoefficient_vector_ul),as.vector(temp.eigencoefficient_vector_um))
        temp.PLS_matrix_list[[temp.counter]][temp.u]=temp.PLS_coefficient_estimate_matrix_u[temp.l,temp.m]
        temp.counter=temp.counter+1
      }
    }
    temp.PLS_estimation_rss_matrix<-temp.PLS_estimation_rss_matrix+(temp.PLS_coefficient_estimate_matrix_u-temp.PLS_population_values_matrix)^2
    temp.PLS_mean_matrix<-temp.PLS_mean_matrix+temp.PLS_coefficient_estimate_matrix_u
  }
  temp.PLS_estimation_rss_matrix<-temp.PLS_estimation_rss_matrix/temp.num_realizations
  temp.PLS_mean_matrix<-temp.PLS_mean_matrix/temp.num_realizations
  #Empirical distributions.
  temp.OMSC_ecdf_matrix_list<-list()
  temp.OMSC_quantiles_matrix_list<-list()
  temp.PLS_ecdf_matrix_list<-list()
  temp.PLS_quantiles_matrix_list<-list()
  temp.counter=1
  for(temp.l in 1:temp.num_significant_normalized){
    for(temp.m in 1:temp.num_significant_normalized){
      temp.OMSC_ecdf_matrix_list[[temp.counter]]<-rep(0,temp.num_realizations)
      temp.OMSC_quantiles_matrix_list[[temp.counter]]<-rep(0,temp.num_realizations)
      temp.PLS_ecdf_matrix_list[[temp.counter]]<-rep(0,temp.num_realizations)
      temp.PLS_quantiles_matrix_list[[temp.counter]]<-rep(0,temp.num_realizations)
      temp.counter=temp.counter+1
    }
  }
  temp.counter=1
  for(temp.l in 1:temp.num_significant_normalized){
    for(temp.m in 1:temp.num_significant_normalized){
      #OMSC.
      temp.OMSC_realizations_lm=temp.OMSC_matrix_list[[temp.counter]]
      temp.empirical_distribution_object<-empirical.distribution(rv.par=temp.OMSC_realizations_lm)
      temp.OMSC_empirical_distribution_vector_lm<-temp.empirical_distribution_object$temp.empirical_distribution
      temp.OMSC_quantile_vector_lm<-temp.empirical_distribution_object$temp.ordered_rv
      temp.OMSC_ecdf_matrix_list[[temp.counter]]<-temp.OMSC_empirical_distribution_vector_lm
      temp.OMSC_quantiles_matrix_list[[temp.counter]]<-temp.OMSC_quantile_vector_lm
      #PLS.
      temp.PLS_realizations_lm=temp.PLS_matrix_list[[temp.counter]]
      temp.empirical_distribution_object<-empirical.distribution(rv.par=temp.PLS_realizations_lm)
      temp.PLS_empirical_distribution_vector_lm<-temp.empirical_distribution_object$temp.empirical_distribution
      temp.PLS_quantile_vector_lm<-temp.empirical_distribution_object$temp.ordered_rv
      temp.PLS_ecdf_matrix_list[[temp.counter]]<-temp.PLS_empirical_distribution_vector_lm
      temp.PLS_quantiles_matrix_list[[temp.counter]]<-temp.PLS_quantile_vector_lm
      temp.counter=temp.counter+1
    }
  }
  temp.IS_process_variance_real_matrix<-
    (temp.differenced_sum_squares_real_matrix-temp.difference_sum_real_matrix^2/temp.num_dof)/temp.num_dof
  temp.IS_process_variance_imaginary_matrix<-
    (temp.differenced_sum_squares_imaginary_matrix-temp.differenced_sum_imaginary_matrix^2/temp.num_dof)/temp.num_dof
  temp.IS_process_variance_matrix<-temp.IS_process_variance_real_matrix+temp.IS_process_variance_imaginary_matrix
  temp.IS_process_variance_matrix_percentage<-temp.IS_process_variance_matrix/temp.DFT_eigencoefficient_jump_RSS_matrix*100
  temp.PSD_sequence<-temp.spectral_powers*temp.M
  temp.normalized_DFT_eigencoefficient_RSS_matrix<-
    sweep(temp.DFT_eigencoefficient_jump_RSS_matrix,MARGIN=1,temp.PSD_sequence,FUN="/")
  temp.normalized_DFT_eigencoefficient_RSS_percentile_matrix<-pnorm(temp.normalized_DFT_eigencoefficient_RSS_matrix,mean=temp.num_dof,sd=sqrt(2*temp.num_dof))*100
  if(output_bool.par==TRUE){
    sink(paste(temp.eigencoefficient_string,".txt",sep=""), append=FALSE, split=FALSE)
    cat("Frequency_index\tTaper_index\tNormalized_chi_squared\tPercentile\tVariance_percentage\n")
    for(temp.j in 1:temp.num_significant){
      for(temp.k in 1:temp.K){
        cat(temp.j,"\t",temp.k-1,"\t",round_general.function(temp.normalized_DFT_eigencoefficient_RSS_matrix[temp.j,temp.k]/temp.num_dof),"\t",
            round_general.function(temp.normalized_DFT_eigencoefficient_RSS_percentile_matrix[temp.j,temp.k]),"\t",
            round_general.function(temp.IS_process_variance_matrix_percentage[temp.j,temp.k]),"\n")
      }
    }
    sink()
  }
  if(plot_bool.par==TRUE){
    temp.plotting_frequencies_heat_map<-significant_frequencies.par[1:temp.num_significant_normalized]*sampling_rate.par
    #RSS.
    temp.p_values<-100-temp.normalized_DFT_eigencoefficient_RSS_percentile_matrix
    heat_map.function(x.par=temp.plotting_frequencies_heat_map,y.par=1:temp.K-1,matrix.par=temp.p_values,
                      z_bounds.par=c(min(temp.p_values),max(temp.p_values)),
                      abscissa_quantity.par="Frequency",abscissa_units.par=frequency_units.par,
                      ordinates_quantity.par="Taper index",ordinates_units.par="order by magnitude",
                      heights_quantity.par="Chi-squared-statistic, p-value",heights_units.par="%",
                      pdf_title.par=paste(temp.eigencoefficient_string,"_RSS_percentile.pdf",sep=""))
    #Redundancy index.
    temp.percentage_redundancy_matrix<-100*sqrt(temp.redundancy_indices_matrix)
    heat_map.function(x.par=temp.plotting_frequencies_heat_map,y.par=1:temp.K-1,matrix.par=temp.percentage_redundancy_matrix,
                      z_bounds.par=c(min(temp.percentage_redundancy_matrix),max(temp.percentage_redundancy_matrix)),
                      abscissa_quantity.par="Frequency",abscissa_units.par=frequency_units.par,
                      ordinates_quantity.par="Taper index",ordinates_units.par="order by magnitude",
                      heights_quantity.par="Root redundancy index",heights_units.par="%",
                      pdf_title.par=paste(temp.eigencoefficient_string,"_Redundancy_Index.pdf",sep=""))
    #Bias estimates.
    temp.OMSC_RMS_matrix<-(temp.OMSC_estimation_RSS_matrix)*100
    temp.OMSC_RMS_matrix[is.infinite(temp.OMSC_RMS_matrix)==TRUE]<-0
    temp.PLS_RMS_matrix<-(temp.PLS_estimation_rss_matrix)*100
    temp.PLS_RMS_matrix[is.infinite(temp.PLS_RMS_matrix)==TRUE]<-0
    temp.min_bias=0
    temp.max_bias=100
    #OMSC bias.
    heat_map.function(x.par=temp.plotting_frequencies_heat_map,y.par=temp.plotting_frequencies_heat_map,matrix.par=temp.OMSC_RMS_matrix,
                      z_bounds.par=c(temp.min_bias,temp.max_bias),
                      abscissa_quantity.par="Frequency",abscissa_units.par=frequency_units.par,
                      ordinates_quantity.par="Frequency",ordinates_units.par=frequency_units.par,
                      heights_quantity.par="RMS",heights_units.par="%",
                      pdf_title.par="Total_OMSC_Relative_RSS.pdf")
    #PLS-coefficient estimation bias.
    heat_map.function(x.par=temp.plotting_frequencies_heat_map,y.par=temp.plotting_frequencies_heat_map,matrix.par=temp.PLS_RMS_matrix,
                      z_bounds.par=c(temp.min_bias,temp.max_bias),
                      abscissa_quantity.par="Frequency",abscissa_units.par=frequency_units.par,
                      ordinates_quantity.par="Frequency",ordinates_units.par=frequency_units.par,
                      heights_quantity.par="RMS",heights_units.par="%",
                      pdf_title.par="Total_PLS_Relative_RSS.pdf")
  }
  setwd("../../")
  temp.list<-list(out.num_dof=temp.num_dof,
                  out.DFT_eigencoefficient_jump_RSS_matrix=temp.DFT_eigencoefficient_jump_RSS_matrix,
                  out.normalized_DFT_eigencoefficient_RSS_matrix=temp.normalized_DFT_eigencoefficient_RSS_matrix,
                  out.normalized_DFT_eigencoefficient_RSS_percentile_matrix=temp.normalized_DFT_eigencoefficient_RSS_percentile_matrix,
                  out.IS_process_variance_matrix=temp.IS_process_variance_matrix,
                  out.differenced_normalized_IS_process_matrix=temp.normalized_IS_process_matrix,
                  out.eigencoefficient_estimates_list=temp.eigencoefficient_estimates_list,
                  out.OMSC_quantiles_matrix_list=temp.OMSC_quantiles_matrix_list,
                  out.PLS_quantiles_matrix_list=temp.PLS_quantiles_matrix_list,
                  out.PLS_ecdf_matrix_list=temp.PLS_ecdf_matrix_list,
                  out.OMSC_ecdf_matrix_list=temp.OMSC_ecdf_matrix_list,
                  out.OMSC_matrix_list=temp.OMSC_matrix_list,
                  out.PLS_matrix_list=temp.PLS_matrix_list,
                  out.eigencoefficient_covariance_matrix_list=temp.eigencoefficient_covariance_matrix_list,
                  out.eigencoefficient_reflectional_covariance_matrix_list=temp.eigencoefficient_reflectional_covariance_matrix_list,
                  out.eigencoefficient_augmented_data_matrix_l_list=temp.eigencoefficient_augmented_data_matrix_l_list,
                  out.eigencoefficient_augmented_data_matrix_m_list=temp.eigencoefficient_augmented_data_matrix_m_list)
  return(temp.list)
}

cyclic_and_harmonic_analyses.function<-function(ts.par,time_sequence.par,NW.par,jackknife.par=FALSE,plot.par=FALSE,measured_quantity.par="Measured quantity",
                                                measured_units.par="units",sampling_rate.par=1,
                                                F_test_threshold.par=NA,output.par=FALSE,spectral_power_bool.par=FALSE,
                                                jk_output.par=FALSE,F_test_jackknife.par=FALSE,
                                                ha_bool.par=FALSE,residual_bool.par=FALSE,threshold_crossings_LB.par=3,num_sections.par=2,
                                                new_directory.par="",old_directory.par="",reconstruction_bool.par=FALSE,verbose.par=FALSE,
                                                cepstral_bool.par=FALSE,reconstruction_directory.par="",ends_reconstruction_bool.par=FALSE,
                                                F_test_diagnostics_bool.par=FALSE,
                                                #Cyclic analysis parameters.
                                                cepstral_analysis_bool.par=FALSE,cepstral_F_threshold.par=threshold.percentile,
                                                cepstral_threshold_crossings_LB.par=3,
                                                Rsq_threshold.par=0.95,Kolmogorov_percentile.par=0,TPT_threshold.par=0,outlier_percentile.par=0.99,
                                                units.par1="units",units.par2="units",cepstral_new_directory.par="",
                                                ts_interp_bool.par=FALSE,mdss_bool.par=FALSE,remove_outliers_bool.par=FALSE,
                                                residual_eigencoeffs_bool.par=TRUE,
                                                whitened_log_spectrum_bool.par=FALSE,cleaned_log_spectrum_bool.par=FALSE,
                                                plot_quadratic_diagnostics_bool.par=FALSE,cepstral_jk_spectral_power_bool.par=FALSE,
                                                cepstral_measured_quantity.par="Measured quantity",cepstral_units.par="units",cepstral_output.par=FALSE,
                                                cepstral_plot_spectral_power_bool.par=FALSE,cepstral_power_bool.par=FALSE,
                                                cepstral_output_jk_spectral_power.par=FALSE,cepstral_ha_bool.par=FALSE,
                                                cepstral_residual_eigencoeffs_bool.par=FALSE,cepstrum_new_directory.par="Multitaper_Cepstral_F_Test",
                                                cepstral_power.verbose_par=FALSE,spectral_powers.par=NA,M_exponent.par=1,
                                                #Ends reconstruction booleans.
                                                periodic_reconstruction_bool.par=FALSE,first_time.par=0,
                                                ts_interp_ends_bool.par=FALSE,mdss_bool_ends.par=FALSE,gn_bool_ends.par=FALSE,
                                                num_iterations.par=1,max_length.par=200,
                                                main_directory_string.par="",directory_label.par="",old_directory_interp.par="",
                                                specific_subdirectory_string.par="",revised_specific_directory_string.par=""){
  ######################################################################################################################################################
  #Perform a basic multitaper spectral analysis on the raw time series (a pilot analysis).
  ######################################################################################################################################################
  temp.N_samples=length(ts.par)
  if(is.na(F_test_threshold.par)==TRUE){
    F_test_threshold.par=1-1/temp.N_samples
  }
  if(is.na(cepstral_F_threshold.par)==TRUE){
    cepstral_F_threshold.par=1-1/temp.N_samples
  }
  temp.K=0
  temp.M=0
  temp.M2=0
  temp.frequencies<-c()
  temp.log_frequencies<-c()
  temp.energy_concentrations<-c()
  temp.ts_spectrum<-c()
  temp.slepian_sequences<-c()
  temp.slepian_functions<-c()
  temp.ts_eigencoeffs<-c()
  temp.ts_residual_spectral_powers<-c()
  temp.harmonic_reconstructions_list<-c()
  temp.harmonic_reconstruction_indices_list<-c()
  temp.significant_frequencies_list<-c()
  temp.spectral_power_estimates<-c()
  temp.harmonic_analysis_object<-c()
  temp.harmonic_amplitudes_list<-c()
  temp.harmonic_ACS_amplitudes<-c()
  temp.significant_cyclic_frequencies<-c()
  temp.residual_eigencoefficients<-c()
  temp.cosine_reconstruction<-c()
  temp.dc_signal<-c()
  #try({
    temp.harmonic_analysis_object<-harmonic_analysis.function(ts.par=ts.par,time_sequence.par=time_sequence.par,NW.par=NW.par,
                                                              jackknife.par=jackknife.par,F_test_jackknife.par=F_test_jackknife.par,
                                                              plot.par=plot.par,
                                                              measured_quantity.par=measured_quantity.par,measured_units.par=measured_units.par,
                                                              sampling_rate.par=sampling_rate.par,F_test_threshold.par=F_test_threshold.par,
                                                              output.par=output.par,spectral_power_bool.par=spectral_power_bool.par,
                                                              jk_output.par=jk_output.par,ha_bool.par=ha_bool.par,residual_bool.par=residual_bool.par,
                                                              threshold_crossings_LB.par=threshold_crossings_LB.par,num_sections.par=num_sections.par,
                                                              new_directory.par=new_directory.par,old_directory.par=old_directory.par,
                                                              reconstruction_bool.par=reconstruction_bool.par,verbose.par=verbose.par,
                                                              cepstral_bool.par=FALSE,reconstruction_directory.par=reconstruction_directory.par,
                                                              ends_reconstruction_bool.par=ends_reconstruction_bool.par,M_exponent.par=M_exponent.par,
                                                              F_test_diagnostics_bool.par=F_test_diagnostics_bool.par,
                                                              #Ends reconstruction booleans.
                                                              periodic_reconstruction_bool.par=periodic_reconstruction_bool.par,
                                                              ts_interp_bool.par=ts_interp_ends_bool.par,first_time.par=first_time.par,
                                                              mdss_bool.par=mdss_bool_ends.par,gn_bool.par=gn_bool_ends.par,
                                                              num_iterations.par=num_iterations.par,max_length.par=max_length.par,
                                                              main_directory_string.par=main_directory_string.par,
                                                              directory_label.par=directory_label.par,old_directory_interp.par=old_directory_interp.par,
                                                              specific_subdirectory_string.par=specific_subdirectory_string.par,
                                                              revised_specific_directory_string.par=revised_specific_directory_string.par)
    temp.K=temp.harmonic_analysis_object$out.K
    temp.M=temp.harmonic_analysis_object$out.M
    temp.M2=temp.harmonic_analysis_object$out.M2
    temp.zero_index=temp.harmonic_analysis_object$out.zero_index
    temp.frequency_spacing<-temp.harmonic_analysis_object$out.frequency_spacing
    temp.frequencies_full<-temp.harmonic_analysis_object$out.frequencies_full
    temp.frequencies<-temp.harmonic_analysis_object$out.frequencies
    temp.log_frequencies<-temp.harmonic_analysis_object$out.log_frequencies
    temp.energy_concentrations<-temp.harmonic_analysis_object$out.energy_concentrations
    temp.ts_spectrum<-temp.harmonic_analysis_object$out.power_spectrum
    temp.slepian_sequences<-temp.harmonic_analysis_object$out.slepian_sequences
    temp.slepian_functions<-temp.harmonic_analysis_object$out.slepian_functions
    temp.mean_estimate=temp.harmonic_analysis_object$out.mean_estimate
    temp.variance_estimate=temp.harmonic_analysis_object$out.variance_estimate
    temp.ts_eigencoeffs<-temp.harmonic_analysis_object$out.eigencoeffs
    temp.ts_residual_spectral_powers<-temp.harmonic_analysis_object$out.residual_spectral_power_estimates
    temp.significant_frequencies<-temp.harmonic_analysis_object$out.significant_frequencies
    temp.extracted_frequency_indices<-temp.harmonic_analysis_object$out.extracted_frequency_indices
    temp.num_significant=length(temp.significant_frequencies)
    temp.harmonic_reconstructions_list<-temp.harmonic_analysis_object$out.harmonic_reconstructions_list
    temp.harmonic_reconstruction_indices_list<-temp.harmonic_analysis_object$out.harmonic_reconstruction_indices_list
    temp.significant_frequencies_list<-temp.harmonic_analysis_object$out.significant_frequencies_list
    temp.spectral_power_estimates<-temp.harmonic_analysis_object$out.power_spectrum
    temp.harmonic_amplitudes_list<-temp.harmonic_analysis_object$out.harmonic_amplitudes_list
    temp.residual_eigencoefficients<-temp.harmonic_analysis_object$out.residual_eigencoefficients
    temp.cosine_reconstruction<-temp.harmonic_analysis_object$out.cosine_reconstruction
    temp.dc_signal<-rep(temp.harmonic_analysis_object$out.mean_estimate,temp.N_samples)
  #},silent=T)
  if(!temp.M){
    temp.MT_parameters_object<-multitaper_parameters.function(N.par=temp.N_samples,NW.par=NW.par,M_exponent.par=M_exponent.par)
    temp.M=temp.MT_parameters_object$out.M
    temp.M2=temp.MT_parameters_object$out.M_2
    temp.frequencies<-temp.MT_parameters_object$out.frequencies
    temp.log_frequencies<-temp.MT_parameters_object$out.log_frequencies
    temp.K=temp.MT_parameters_object$out.K
    temp.centred_process_object<-centred_process.eigencoefficients(ts.par,NW.par,temp.M,temp.K,verbose.par=FALSE)
    temp.slepian_sequences<-temp.centred_process_object$out.dpss
    temp.energy_concentrations<-temp.centred_process_object$out.eigenvalues
    temp.slepian_functions<-temp.centred_process_object$out.Slepian_functions
    temp.ts_eigencoeffs<-temp.centred_process_object$out.eigencoeffs
    temp.multitaper_spectral_power_object<-multitaper_spectral_power.function(eigencoefficients.par=temp.ts_eigencoeffs,
                                                                              frequencies.par=temp.frequencies,concentrations.par=temp.energy_concentrations)
    temp.spectral_power_estimates<-temp.multitaper_spectral_power_object$out.spectral_power_estimates
    temp.extracted_frequency_indices<-1:temp.M2
  }
  if(!length(temp.extracted_frequency_indices)){
    temp.extracted_frequency_indices<-1:max(2*floor(NW.par/temp.N_samples*temp.M),1)
  }
  temp.list<-list(out.ts_eigencoeffs=temp.ts_eigencoeffs,
                  out.extracted_frequency_indices=temp.extracted_frequency_indices,
                  out.frequencies=temp.frequencies,
                  out.energy_concentrations=temp.energy_concentrations,
                  out.harmonic_reconstructions_list=temp.harmonic_reconstructions_list,
                  out.harmonic_reconstruction_indices_list=temp.harmonic_reconstruction_indices_list,
                  out.significant_frequencies_list=temp.significant_frequencies_list,
                  out.M=temp.M,
                  out.M2=temp.M2,
                  out.harmonic_amplitudes_list=temp.harmonic_amplitudes_list,
                  out.residual_eigencoefficients=temp.residual_eigencoefficients,
                  out.slepian_functions=temp.slepian_functions,
                  out.spectral_power_estimates=temp.spectral_power_estimates,
                  out.cosine_reconstruction=temp.cosine_reconstruction,
                  out.dc_signal=temp.dc_signal)
  if(cepstral_analysis_bool.par==TRUE){
    ######################################################################################################################################################
    #Perform a cepstral analysis to extract the cyclic frequencies.
    ######################################################################################################################################################
    temp.sink_flag=FALSE
    temp.peak_frequencies<-c()
    temp.peak_areas<-c()
    #try({
      temp.sampling_period=1/sampling_rate.par
      temp.log_spectrum_object<-log_spectrum_analysis.function(mt_sa_ha_object.par=temp.harmonic_analysis_object,sampling_period.par=temp.sampling_period,
                                                               log_frequencies.par=temp.log_frequencies,frequencies.par=temp.frequencies,
                                                               voltage_extracted_frequency_indices.par=temp.extracted_frequency_indices,
                                                               F_test_threshold.par=F_test_threshold.par,cepstral_F_threshold.par=cepstral_F_threshold.par,
                                                               NW.par=NW.par,sampling_rate.par=sampling_rate.par,
                                                               measured_quantity.par=measured_quantity.par,
                                                               Rsq_threshold.par=Rsq_threshold.par,Kolmogorov_percentile.par=Kolmogorov_percentile.par,
                                                               TPT_threshold.par=TPT_threshold.par,outlier_percentile.par=outlier_percentile.par,
                                                               units.par1=units.par1,units.par2=units.par2,
                                                               threshold_crossings_LB.par=threshold_crossings_LB.par,
                                                               new_directory.par=cepstral_new_directory.par,old_directory.par=old_directory.par,
                                                               cepstral_bool.par=cepstral_bool.par,output.par=cepstral_output.par,
                                                               ts_interp_bool.par=ts_interp_bool.par,mdss_bool.par=mdss_bool.par,
                                                               remove_outliers_bool.par=remove_outliers_bool.par,
                                                               spectral_power_bool.par=spectral_power_bool.par,
                                                               residual_eigencoeffs_bool.par=residual_eigencoeffs_bool.par,
                                                               whitened_log_spectrum_bool.par=whitened_log_spectrum_bool.par,
                                                               cleaned_log_spectrum_bool.par=cleaned_log_spectrum_bool.par,
                                                               plot_quadratic_diagnostics_bool.par=plot_quadratic_diagnostics_bool.par,
                                                               cepstral_jk_spectral_power_bool.par=cepstral_jk_spectral_power_bool.par,
                                                               cepstral_measured_quantity.par=cepstral_measured_quantity.par,
                                                               cepstral_units.par=cepstral_units.par,cepstral_output.par=cepstral_output.par,
                                                               cepstral_plot_spectral_power_bool.par=cepstral_plot_spectral_power_bool.par,
                                                               cepstral_power_bool.par=cepstral_power_bool.par,
                                                               cepstral_output_jk_spectral_power.par=cepstral_output_jk_spectral_power.par,
                                                               cepstral_ha_bool.par=cepstral_ha_bool.par,
                                                               cepstral_residual_eigencoeffs_bool.par=cepstral_residual_eigencoeffs_bool.par,
                                                               cepstrum_new_directory.par=cepstrum_new_directory.par,
                                                               cepstral_power.verbose_par=cepstral_power.verbose_par,verbose.par=verbose.par,
                                                               spectral_powers.par=temp.spectral_power_estimates)
      temp.extracted_frequency_indices<-temp.log_spectrum_object$out.extracted_frequency_indices
      temp.significant_frequency_indices<-temp.log_spectrum_object$out.significant_frequency_indices
      temp.significant_cyclic_frequencies<-temp.log_spectrum_object$out.significant_frequencies
      temp.harmonic_ACS_amplitudes<-temp.log_spectrum_object$out.harmonic_coefficients
      temp.ts_residual_spectral_powers<-10^temp.log_spectrum_object$out.log_spectrum
      temp.peak_frequencies<-temp.log_spectrum_object$out.peak_frequencies*sampling_rate.par
      temp.peak_areas<-temp.log_spectrum_object$out.peak_areas
      temp.num_peaks=length(temp.peak_frequencies)
      sink("Log_Spectrum_Analysis/Interpolation/Peak_Statistics.txt", append=FALSE, split=FALSE)
      cat("peak_frequency\tpeak_area\n")
      if(temp.num_peaks>0){
        for(temp.i in 1:temp.num_peaks){
          cat(temp.peak_frequencies[temp.i],"\t",temp.peak_areas[temp.i],"\n")
        }
      }
      else{
        cat(0,"\t",0,"\n")
        
      }
      sink()
      temp.list<-list.append(temp.list,
                             out.peak_frequencies=temp.peak_frequencies,
                             out.peak_areas=temp.peak_areas,
                             out.ts_residual_spectral_powers=temp.ts_residual_spectral_powers,
                             out.significant_frequencies=temp.significant_cyclic_frequencies,
                             out.harmonic_ACS_amplitudes=temp.harmonic_ACS_amplitudes,
                             out.significant_frequency_indices=temp.significant_frequency_indices,
                             out.extracted_cyclic_frequency_indices=temp.extracted_frequency_indices)
    #},silent=T)
  }
  if(getwd()!=old_directory.par){
    setwd(old_directory.par)
  }
  return(temp.list)
}





wishart_distribution_analysis.function<-function(eigencoeffs.par,energy_concentrations.par,slepian_functions.par,spectral_powers.par,N.par,NW.par=5,
                                                 percentiles.par=c(0,25,50,75,100),plot_bool.par=FALSE){
  temp.M=nrow(eigencoeffs.par)
  temp.K=ncol(eigencoeffs.par)
  for(temp.k in 1:temp.K){
    eigencoeffs.par[,temp.k]<-eigencoeffs.par[,temp.k]/energy_concentrations.par[temp.k]
  }
  temp.zero_index=temp.M/2
  temp.M2=temp.zero_index+1
  temp.test_sample_size=8*temp.K
  temp.bandwidth_size=max(2*floor(NW.par/N.par*temp.M)+1,temp.test_sample_size)
  temp.sampling_indices<-seq(from=1,to=temp.M2,by=temp.bandwidth_size)
  temp.num_bins0=length(temp.sampling_indices)-1
  temp.wishart_pdf_values<-rep(0,temp.num_bins0)
  for(temp.i in 1:temp.num_bins0){
    temp.indices<-temp.sampling_indices[temp.i]+temp.zero_index+1:temp.bandwidth_size-1
    temp.min=max(min(temp.indices),1)
    temp.max=min(max(temp.indices),temp.M)
    temp.indices<-temp.indices[temp.indices>=temp.min & temp.indices<=temp.max]
    temp.composite_covariance_matrix<-diag(rep(1,2*temp.K))*mean(spectral_powers.par[temp.indices-temp.zero_index])/2
    set.seed(temp.i)
    temp.sample_vectors<-matrix(0,nrow=2*temp.K,ncol=temp.test_sample_size)
    for(temp.j in 1:temp.test_sample_size){
      temp.vector<-eigencoeffs.par[temp.indices[temp.j],]
      temp.sample_vectors[,temp.j]<-c(Re(temp.vector),Im(temp.vector))
    }
    temp.trial_covariance_matrix<-temp.sample_vectors%*%t(temp.sample_vectors)
    temp.wishart_pdf_values[temp.i]=wishart_pdf.function(covariance_matrix.par=temp.composite_covariance_matrix,
                                                         trial_covariance_matrix.par=temp.trial_covariance_matrix,
                                                         num_observations.par=temp.test_sample_size)
  }
  #Bin the sample-covariance matrix realizations by theoretical percentage value, and compare.
  temp.num_percentiles=length(percentiles.par)
  temp.num_bins=temp.num_percentiles-1
  temp.plotting_percentiles<-(percentiles.par[1:temp.num_bins]+percentiles.par[1:temp.num_bins+1])/2
  temp.min=min(temp.wishart_pdf_values)
  temp.max=max(temp.wishart_pdf_values)
  temp.range=temp.max-temp.min
  temp.range_points<-temp.min+percentiles.par/100*temp.range
  temp.bin_heights<-rep(0,temp.num_bins)
  for(temp.i in 1:temp.num_bins){
    temp.bin_heights[temp.i]=length(which(temp.wishart_pdf_values>=temp.range_points[temp.i] & temp.wishart_pdf_values<temp.range_points[temp.i+1]))
  }
  temp.positive_bin_height_indices<-which(temp.bin_heights>0)
  temp.num_positive_bin_heights=length(unique(temp.bin_heights[temp.positive_bin_height_indices]))
  temp.correlation_coefficient=0
  temp.num_positive_bin_heights=0
  if(temp.num_positive_bin_heights>1){
    temp.plotting_percentiles<-temp.plotting_percentiles[temp.positive_bin_height_indices]
    temp.range_points<-temp.range_points[temp.positive_bin_height_indices]
    temp.bin_heights<-log(temp.bin_heights[temp.positive_bin_height_indices])
    temp.min_bin_height=min(temp.bin_heights)
    temp.max_bin_height=max(temp.bin_heights)
    temp.bin_heights<-(temp.bin_heights-min(temp.bin_heights))/(max(temp.bin_heights)-min(temp.bin_heights))*100
    temp.diagonal_x<-c(-max(temp.plotting_percentiles),temp.plotting_percentiles,2*max(temp.plotting_percentiles))
    temp.diagonal_y<-temp.diagonal_x
    temp.positive_pdf_indices<-which(temp.bin_heights>0 & temp.bin_heights<100)
    temp.num_bin_values=length(temp.positive_pdf_indices)
    if(temp.num_bin_values>1){
      temp.correlation_coefficient=cor(temp.plotting_percentiles[temp.positive_pdf_indices],temp.bin_heights[temp.positive_pdf_indices])
      temp.num_positive_bin_heights=temp.num_bin_values
      if(plot_bool.par==TRUE){
        temp.min_x=sign(temp.min)*round(abs(temp.min),ceil(log10(abs(temp.min))))
        temp.max_x=sign(temp.max)*round(abs(temp.max),ceil(log10(abs(temp.max))))
        temp.min_y=sign(temp.min_bin_height)*round(abs(temp.min_bin_height),ceil(log10(abs(temp.min_bin_height)))+1)
        temp.max_y=sign(temp.max_bin_height)*round(abs(temp.max_bin_height),ceil(log10(abs(temp.max_bin_height)))+1)
        temp.plotting_correlation=temp.correlation_coefficient*100
        plot.graph(list(temp.diagonal_x,temp.plotting_percentiles),list(temp.diagonal_y,temp.bin_heights),
                   plotting_LB.par=0,plotting_UB.par=100,
                   plot_title.par=paste("Pearson correlation coefficient = ",
                                        round(temp.plotting_correlation,ceil(log10(abs(temp.plotting_correlation)))+1),"%",sep=""),
                   x_label.par=paste("Log Wishart probability density, % increment in [",
                                     temp.min_x,",",temp.max_x,"]",sep=""),
                   y_label.par=paste("Log no. inferred sample matrices in probability interval\n% increment in ",
                                     "[",temp.min_y,",",temp.max_y,"]",sep=""),
                   pdf_title.par="Wishart_Tests.pdf",
                   plotting_LB_x.par=min(temp.plotting_percentiles),plotting_UB_x.par=max(temp.plotting_percentiles),type.par=c("l","p"))
      }
    }
  }
  temp.list<-list(out.range_points=temp.range_points,
                  out.plotting_percentiles=temp.plotting_percentiles,
                  out.bin_heights=temp.bin_heights,
                  out.wishart_pdf_values=temp.wishart_pdf_values,
                  out.correlation_coefficient=temp.correlation_coefficient,
                  out.num_positive_bin_heights=temp.num_positive_bin_heights)
  return(temp.list)
}



eigencoefficients_statistical_analysis.function<-function(eigencoeffs.par,frequencies.par,energy_concentrations.par,N.par,slepian_functions.par,
                                                          spectral_powers.par,sampling_rate.par=1,first_time.par=0,F_test_threshold.par=NA,
                                                          old_directory.par="",impropriety_abscissa_measurement.par="",impropriety_abscissa_units.par="",
                                                          QIT_abscissa_measurement.par="",QIT_abscissa_units.par="",
                                                          QIT.percentile.par1=c(0.1,0.25,0.5,0.75,0.9),QIT_crossing_rates_bool.par=FALSE,
                                                          QIT.percentile.par2=c(0,25,50,75,100),wishart_percentiles.par=c(0,25,50,75,100),
                                                          plot_bool.par=FALSE,verbose_bool.par=FALSE,wishart_bool.par=TRUE){
  if(verbose_bool.par==TRUE){
    tic()
  }
  temp.gaussian_label<-"Eigencoefficient_Diagnostic_Analysis"
  dir.create(temp.gaussian_label,showWarnings=FALSE)
  temp.working_directory_string<-paste(old_directory.par,"/",temp.gaussian_label,"/",sep="")
  revised.specific_directory_string<-paste(revised.specific_directory_string,"/",temp.gaussian_label,sep="")
  setwd(temp.working_directory_string)
  temp.M=nrow(eigencoeffs.par)
  temp.M2=temp.M/2+1
  temp.K=ncol(eigencoeffs.par)
  #Test for impropriety.
  temp.impropriety_analysis_object<-impropriety_analysis.function(eigencoeffs.par,frequencies.par,energy_concentrations.par,sampling_rate.par,
                                                                  N.par,abscissa_measurement.par=impropriety_abscissa_measurement.par,
                                                                  abscissa_units.par=impropriety_abscissa_units.par,plot_bool.par=plot_bool.par)
  temp.impropriety_CCA_spectrum<-temp.impropriety_analysis_object$out.CCA_spectrum
  #Test for sphericity.
  temp.sphericity_analysis_object<-sphericity_analysis.function(eigencoeffs.par,frequencies.par=frequencies.par,
                                                                slepian_functions.par,energy_concentrations.par,N.par,
                                                                first_time.par,sampling_rate.par,NW.par,F_test_threshold.par=F_test_threshold.par,
                                                                old_directory.par=paste(main_directory.string,revised.specific_directory_string,sep=""),
                                                                new_directory.par=revised.specific_directory_string,
                                                                measured_quantity.par=measure_quantity.string,
                                                                abscissa_value.par=QIT_abscissa_measurement.par,abscissa_units.par=QIT_abscissa_units.par,
                                                                percentile.par=QIT.percentile.par1,crossing_rates_bool.par=QIT_crossing_rates_bool.par,
                                                                plot_bool.par=plot_bool.par,verbose_bool.par=verbose_bool.par)
  temp.sphericity_statistics<-temp.sphericity_analysis_object$out.sphericity_statistics
  temp.QIT_L=temp.sphericity_analysis_object$out.QIT_L
  temp.sphericity_percentiles<-pchisq(temp.sphericity_statistics,temp.QIT_L-1)
  #Confirm that the insignificant sphericity ratios tend to occur when the impropriety metric attains low values.
  temp.NW=(temp.K+1)/2
  temp.bandwidth_size=floor(2*temp.NW/N.par*temp.M)
  temp.index_sequence=seq(from=1,to=temp.M2,by=temp.bandwidth_size)
  temp.num_downsampled=length(temp.index_sequence)
  temp.downsampled_sphericity_percentiles<-rep(0,temp.num_downsampled)
  temp.downsampled_impropriety_percentiles<-temp.downsampled_sphericity_percentiles
  for(temp.m in 1:temp.num_downsampled){
    temp.index=temp.index_sequence[temp.m]
    temp.indices<-temp.index+1:temp.bandwidth_size-1
    temp.indices<-temp.indices[temp.indices<=temp.M2]
    temp.downsampled_sphericity_percentiles[temp.m]=mean(temp.sphericity_percentiles[temp.indices])
    temp.downsampled_impropriety_percentiles[temp.m]=mean(temp.impropriety_CCA_spectrum[temp.indices])
  }
  temp.percentile_comparison_object<-percentile_comparison.function(abscissa_percentiles.par=temp.downsampled_sphericity_percentiles,
                                                                    ordinate_percentiles.par=temp.downsampled_impropriety_percentiles,
                                                                    abscissa_quantity.par="Sphericity-statistic percentile",
                                                                    ordinates_quantity.par="Impropriety correlation statistic",
                                                                    heights_quantity.par="Percentage intersection",
                                                                    pdf_title.par="Sphericity_vs_Improper.pdf",
                                                                    percentiles.par=QIT.percentile.par2,verbose_bool.par=verbose_bool.par)
  temp.correlation_coefficient=0
  temp.num_positive_bin_heights=0
  if(wishart_bool.par==TRUE){
    #Check that the eigencoefficient variables have sample covariance matrices that agree with Wishart matrices.
    temp.wishart_distribution_analysis_object<-wishart_distribution_analysis.function(eigencoeffs.par=eigencoeffs.par,
                                                                                      energy_concentrations.par=energy_concentrations.par,
                                                                                      slepian_functions.par=slepian_functions.par,
                                                                                      spectral_powers.par=spectral_powers.par,N.par,NW.par=NW.par,
                                                                                      percentiles.par=wishart_percentiles.par,plot_bool.par=TRUE)
    temp.correlation_coefficient=temp.wishart_distribution_analysis_object$out.correlation_coefficient
    temp.num_positive_bin_heights<-temp.wishart_distribution_analysis_object$out.num_positive_bin_heights
  }
  closeAllConnections()
  graphics.off()
  if(verbose_bool.par==TRUE){
    sink("Eigencoefficients_Statistics_Time.txt", append=FALSE, split=FALSE)
    cat("Total time for the basic eigencoefficient statistical analysis: ")
    toc()
    sink()
  }
  setwd(old_directory.par)
  temp.list<-list(out.sphericity_statistics=temp.sphericity_statistics,
                  out.sphericity_percentiles=temp.sphericity_percentiles,
                  out.correlation_coefficient=temp.correlation_coefficient,
                  out.num_positive_bin_heights=temp.num_positive_bin_heights,
                  out.impropriety_CCA_spectrum=temp.impropriety_CCA_spectrum)
  return(temp.list)
}



harmonizable_eigencoefficient_analysis.function<-function(eigencoefficients.par,frequencies.par,energy_concentrations.par,N.par,
                                                          slepian_functions.par,spectral_powers.par,sampling_rate.par=1,first_time.par=1,
                                                          F_test_threshold.par=NA,frequency_band.par=NA,
                                                          abscissa_value.par="Measured",abscissa_units.par="units",
                                                          measured_value.par="Measured",measured_units.par="units",
                                                          QIT.percentile.par1=c(0.1,0.25,0.5,0.75,0.9),QIT_crossing_rates_bool.par=TRUE,
                                                          QIT.percentile.par2=c(0,25,50,75,100),wishart_percentiles.par=NA,
                                                          old_directory.par="",
                                                          #Cyclic ACVS analysis.
                                                          extracted_frequency_indices.par=NA,max_size_Loeve.par=400,max_size_ACVF.par=1e3,
                                                          cyclic_ACVS_bool.par=FALSE,bifrequency_plot_bool.par=FALSE,
                                                          measured_quantity.par="",measured_quantity_units.par="",
                                                          plot_bool.par=FALSE,verbose_bool.par=FALSE,
                                                          wishart_bool.par=TRUE){
  if(is.na(wishart_percentiles.par)==TRUE){
    wishart_percentiles.par<-(1:11-1)/10*100
  }
  temp.eigencoefficients_statistical_analysis.object<-
    eigencoefficients_statistical_analysis.function(eigencoeffs.par=eigencoefficients.par,frequencies.par=frequencies.par,
                                                    energy_concentrations.par=energy_concentrations.par,N.par=N.par,
                                                    slepian_functions.par=slepian_functions.par,spectral_powers.par=spectral_powers.par,
                                                    sampling_rate.par=sampling_rate.par,first_time.par=first_time.par,
                                                    F_test_threshold.par=F_test_threshold.par,
                                                    old_directory.par=old_directory.par,
                                                    impropriety_abscissa_measurement.par=abscissa_value.par,
                                                    impropriety_abscissa_units.par=abscissa_units.par,
                                                    QIT_abscissa_measurement.par=abscissa_value.par,
                                                    QIT_abscissa_units.par=abscissa_units.par,
                                                    QIT.percentile.par1=QIT.percentile.par1,QIT_crossing_rates_bool.par=QIT_crossing_rates_bool.par,
                                                    QIT.percentile.par2=QIT.percentile.par2,wishart_percentiles.par=wishart_percentiles.par,
                                                    plot_bool.par=plot_bool.par,verbose_bool.par=verbose_bool.par,
                                                    wishart_bool.par=wishart_bool.par)
  temp.wishart_correlation_coefficient=temp.eigencoefficients_statistical_analysis.object$out.correlation_coefficient
  temp.num_positive_bin_heights<-temp.eigencoefficients_statistical_analysis.object$out.num_positive_bin_heights
  closeAllConnections()
  setwd(old_directory.par)
  dir.create("Cyclostationary_Analysis",showWarnings=FALSE)
  sink("Cyclostationary_Analysis/ACS_Output_File.txt", append=FALSE, split=FALSE)
  if(cyclic_ACVS_bool.par==TRUE){
    #Cyclostationary analysis.
    cyclic_ACVS.matrix<-cyclostationary_analysis.function(eigencoefficients.par,energy_concentrations.par,
                                                          extracted_frequency_indices.par=extracted_frequency_indices.par,N.par=N.par,
                                                          sampling_rate.par=sampling_rate.par,max_size_Loeve.par=max_size_Loeve.par,
                                                          max_size_ACVF.par=max_size_ACVF.par,first_time.par=first_time.par,
                                                          measured_quantity.par=measured_value.par,measured_units.par=measured_units.par,
                                                          bifrequency_plot_bool.par=bifrequency_plot_bool.par,
                                                          cyclic_ACVS_plot_bool.par=cyclic_ACVS_bool.par,frequencies.par=frequencies.par,
                                                          band_frequency_first.par=frequency_band.par[1],cutoff.par=frequency_band.par[2],
                                                          old_directory.par=old_directory.par)
  }
  sink()
  temp.list<-list(out.wishart_correlation_coefficient=temp.wishart_correlation_coefficient,
                  out.num_positive_bin_heights=temp.num_positive_bin_heights)
  return(temp.list)
}



basic_mtsa_single_section.function<-function(ts.par,time_sequence.par,changepoint_times.par,
                                             epoch_labels.par,index.par=1,NW.par=5,
                                             #Harmonic and cepstral analysis.
                                             truncation_bool.par=TRUE,
                                             jackknife.par=FALSE,F_test_jackknife.par=FALSE,
                                             plot.par=FALSE,measured_quantity.par="Measured quantity",
                                             measured_units.par="units",sampling_rate.par=1,first_time.par=0,
                                             F_test_threshold.par=NA,output.par=FALSE,spectral_power_bool.par=FALSE,
                                             jk_output.par=FALSE,ha_bool.par=FALSE,residual_bool.par=FALSE,threshold_crossings_LB.par=3,num_sections.par=2,
                                             spectral_power_directory_string.par="",old_directory.par="",reconstruction_bool.par=FALSE,verbose.par=FALSE,
                                             cepstral_bool.par=FALSE,reconstruction_directory.par="",ends_reconstruction_bool.par=FALSE,
                                             F_test_diagnostics_bool.par=FALSE,
                                             #Eigencoefficient analysis.
                                             eigencoeff_analysis_bool.par=TRUE,
                                             #Cepstral analysis parameters.
                                             cepstral_analysis_bool.par=FALSE,cepstral_F_threshold.par=threshold.percentile,
                                             Rsq_threshold.par=0.95,Kolmogorov_percentile.par=0,TPT_threshold.par=0,outlier_percentile.par=0.99,
                                             units.par1="units",units.par2="units",
                                             ts_interp_bool.par=FALSE,mdss_bool.par=FALSE,remove_outliers_bool.par=FALSE,
                                             residual_eigencoeffs_bool.par=TRUE,
                                             whitened_log_spectrum_bool.par=FALSE,cleaned_log_spectrum_bool.par=FALSE,
                                             plot_quadratic_diagnostics_bool.par=FALSE,cepstral_jk_spectral_power_bool.par=FALSE,
                                             cepstral_measured_quantity.par="Measured quantity",cepstral_units.par="units",cepstral_output.par=FALSE,
                                             cepstral_plot_spectral_power_bool.par=FALSE,cepstral_power_bool.par=FALSE,
                                             cepstral_output_jk_spectral_power.par=FALSE,cepstral_ha_bool.par=FALSE,
                                             cepstral_residual_eigencoeffs_bool.par=FALSE,cepstral_power_directory_string.par="",
                                             cepstral_power.verbose_par=FALSE,spectral_powers.par=NA,M_exponent.par=1,
                                             #Ends reconstruction booleans.
                                             periodic_reconstruction_bool.par=FALSE,ts_interp_ends_bool.par=FALSE,mdss_bool_ends.par=FALSE,gn_bool_ends.par=FALSE,
                                             num_iterations.par=1,max_length.par=200,
                                             main_directory_string.par="",directory_label.par="",old_directory_interp.par="",
                                             revised_specific_directory_string.par="",
                                             #Remaining parameters.
                                             specific_subdirectory_string.par="",eigencoeff_plot_bool.par=FALSE,cyclic_ACVS_bool.par=FALSE,
                                             verbose_bool.par=FALSE){
  temp.epoch_string<-epoch_labels.par[index.par]
  temp.epoch_label<-as.vector(paste(index.par,"_",temp.epoch_string,sep=""))
  temp.create_and_set_multiple_directories_object<-
    create_and_set_multiple_directories.function(directory_strings.par=temp.epoch_label,
                                                 specific_subdirectory_string.par=specific_subdirectory_string.par,
                                                 working_directory_string.par=old_directory.par)
  setwd(paste(old_directory.par,temp.epoch_label,sep=""))
  dir.create("Multitaper_Spectral_Power",showWarnings=FALSE)
  temp.specific_subdirectory_string<-temp.create_and_set_multiple_directories_object$out.specific_subdirectory_string
  temp.working_directory_string<-temp.create_and_set_multiple_directories_object$out.working_directory_string
  temp.revised_specific_directory_string<-temp.create_and_set_multiple_directories_object$out.revised_specific_subdirectory_string
  #Start of the epoch under analysis should be midway into the section to avoid transient effects in the transition interval between epochs.
  temp.changepoints_initialize_training_object<-changepoints_initialize_training.function(time_sequence.par=time_sequence.par,
                                                                                          ts_sequence.par=ts.par,
                                                                                          changepoint_times.par=
                                                                                            changepoint_times.par,index.par=index.par,
                                                                                          frequency_band.par=
                                                                                            frequency.band/sampling_rate.par,
                                                                                          first_time.par=first_time.par,
                                                                                          NW.par=NW.par,
                                                                                          truncation_bool.par=truncation_bool.par)
  temp.training_times<-temp.changepoints_initialize_training_object$out.training_times
  temp.training_ts_sequence<-temp.changepoints_initialize_training_object$out.training_ts_sequence
  temp.time_sequence_original_base_time<-temp.changepoints_initialize_training_object$out.time_sequence_original_base_time
  temp.changepoint_times<-temp.changepoints_initialize_training_object$out.changepoint_times
  temp.section_changepoint_indices<-temp.changepoints_initialize_training_object$out.section_changepoint_indices
  temp.section_size=temp.changepoints_initialize_training_object$out.section_size
  temp.training_interval_bounds<-temp.changepoints_initialize_training_object$out.training_interval_bounds
  temp.N=temp.changepoints_initialize_training_object$out.N
  #Harmonic and cyclostationary analyses.
  temp.cyclic_and_harmonic_analyses.object<-cyclic_and_harmonic_analyses.function(ts.par=temp.training_ts_sequence,time_sequence.par=temp.training_times,
                                                                                  NW.par=NW.par,
                                                                                  jackknife.par=jackknife.par,F_test_jackknife.par=F_test_jackknife.par,
                                                                                  plot.par=plot.par,
                                                                                  measured_quantity.par=measured_quantity.par,
                                                                                  measured_units.par=measured_units.par,
                                                                                  sampling_rate.par=sampling_rate.par,
                                                                                  F_test_threshold.par=F_test_threshold.par,
                                                                                  output.par=output.par,spectral_power_bool.par=spectral_power_bool.par,
                                                                                  jk_output.par=jk_output.par,ha_bool.par=ha_bool.par,
                                                                                  residual_bool.par=residual_bool.par,
                                                                                  threshold_crossings_LB.par=threshold_crossings_LB.par,
                                                                                  num_sections.par=num_sections.par,
                                                                                  new_directory.par=paste(temp.specific_subdirectory_string,
                                                                                                          spectral_power_directory_string.par,"/",sep=""),
                                                                                  old_directory.par=temp.working_directory_string,
                                                                                  reconstruction_bool.par=reconstruction_bool.par,
                                                                                  verbose.par=verbose.par,cepstral_bool.par=cepstral_bool.par,
                                                                                  reconstruction_directory.par=reconstruction_directory.par,
                                                                                  ends_reconstruction_bool.par=ends_reconstruction_bool.par,
                                                                                  F_test_diagnostics_bool.par=F_test_diagnostics_bool.par,
                                                                                  #Cyclic analysis parameters.
                                                                                  cepstral_analysis_bool.par=cepstral_analysis_bool.par,
                                                                                  cepstral_F_threshold.par=cepstral_F_threshold.par,
                                                                                  Rsq_threshold.par=Rsq_threshold.par,
                                                                                  Kolmogorov_percentile.par=Kolmogorov_percentile.par,
                                                                                  TPT_threshold.par=TPT_threshold.par,
                                                                                  outlier_percentile.par=outlier_percentile.par,
                                                                                  units.par1=units.par1,units.par2=units.par2,
                                                                                  cepstral_new_directory.par=paste(temp.specific_subdirectory_string,
                                                                                                                   "Log_Spectrum_Analysis/",sep=""),
                                                                                  ts_interp_bool.par=ts_interp_bool.par,mdss_bool.par=mdss_bool.par,
                                                                                  remove_outliers_bool.par=remove_outliers_bool.par,
                                                                                  residual_eigencoeffs_bool.par=residual_eigencoeffs_bool.par,
                                                                                  whitened_log_spectrum_bool.par=whitened_log_spectrum_bool.par,
                                                                                  cleaned_log_spectrum_bool.par=cleaned_log_spectrum_bool.par,
                                                                                  plot_quadratic_diagnostics_bool.par=plot_quadratic_diagnostics_bool.par,
                                                                                  cepstral_jk_spectral_power_bool.par=cepstral_jk_spectral_power_bool.par,
                                                                                  cepstral_measured_quantity.par=cepstral_measured_quantity.par,
                                                                                  cepstral_units.par=cepstral_units.par,
                                                                                  cepstral_output.par=cepstral_output.par,
                                                                                  cepstral_plot_spectral_power_bool.par=
                                                                                    cepstral_plot_spectral_power_bool.par,
                                                                                  cepstral_power_bool.par=cepstral_power_bool.par,
                                                                                  cepstral_output_jk_spectral_power.par=
                                                                                    cepstral_output_jk_spectral_power.par,
                                                                                  cepstral_ha_bool.par=cepstral_ha_bool.par,
                                                                                  cepstral_residual_eigencoeffs_bool.par=
                                                                                    cepstral_residual_eigencoeffs_bool.par,
                                                                                  cepstrum_new_directory.par=paste(temp.specific_subdirectory_string,
                                                                                                                   cepstral_power_directory_string.par,
                                                                                                                   sep=""),
                                                                                  cepstral_power.verbose_par=cepstral_power.verbose_par,
                                                                                  spectral_powers.par=spectral_powers.par,M_exponent.par=M_exponent.par,
                                                                                  #Ends reconstruction booleans.
                                                                                  periodic_reconstruction_bool.par=reconstruct_ends_bool.par,
                                                                                  ts_interp_ends_bool.par=ts_interp_ends_bool.par,
                                                                                  first_time.par=first_time.par,
                                                                                  mdss_bool_ends.par=mdss_bool_ends.par,
                                                                                  gn_bool_ends.par=gn_bool_ends.par,num_iterations.par=num_iterations.par,
                                                                                  max_length.par=max_length.par,
                                                                                  main_directory_string.par=main_directory_string.par,
                                                                                  directory_label.par=directory_label.par,
                                                                                  old_directory_interp.par=old_directory_interp.par,
                                                                                  specific_subdirectory_string.par=temp.specific_subdirectory_string,
                                                                                  revised_specific_directory_string.par=temp.revised_specific_directory_string)
  temp.M<-temp.cyclic_and_harmonic_analyses.object$out.M
  temp.M2=temp.cyclic_and_harmonic_analyses.object$out.M2
  temp.ts_eigencoeffs<-temp.cyclic_and_harmonic_analyses.object$out.ts_eigencoeffs
  temp.extracted_frequency_indices<-temp.cyclic_and_harmonic_analyses.object$out.extracted_frequency_indices
  temp.frequencies<-temp.cyclic_and_harmonic_analyses.object$out.frequencies
  temp.energy_concentrations<-temp.cyclic_and_harmonic_analyses.object$out.energy_concentrations
  temp.slepian_functions<-temp.cyclic_and_harmonic_analyses.object$out.slepian_functions
  temp.spectral_power_estimates<-temp.cyclic_and_harmonic_analyses.object$out.spectral_power_estimates
  temp.residual_spectral_powers<-temp.cyclic_and_harmonic_analyses.object$out.ts_residual_spectral_powers
  if(is.null(temp.residual_spectral_powers)==TRUE){
    temp.residual_spectral_powers<-temp.spectral_power_estimates
  }
  #Sort the harmonic-analysis output.
  temp.all_significant_frequencies<-unlist(temp.cyclic_and_harmonic_analyses.object$out.significant_frequencies_list)
  temp.num_significant_frequencies=length(temp.all_significant_frequencies)
  temp.residual_eigencoefficients<-temp.ts_eigencoeffs
  temp.cosine_reconstruction<-rep(0,temp.N)
  temp.significant_frequencies<-c()
  temp.harmonic_amplitudes<-c()
  temp.harmonic_ACS_amplitudes<-c()
  temp.significant_cyclic_frequencies<-c()
  temp.all_section_significant_frequencies<-c()
  temp.peak_frequencies<-c()
  temp.peak_areas<-c()
  if(temp.num_significant_frequencies>0){
    temp.significant_frequencies<-sort(temp.all_significant_frequencies)
    temp.all_section_significant_frequencies<-unlist(temp.significant_frequencies)
    temp.all_harmonic_amplitudes<-unlist(temp.cyclic_and_harmonic_analyses.object$out.harmonic_amplitudes_list)
    temp.harmonic_amplitudes<-unlist(temp.all_harmonic_amplitudes)[order(temp.all_significant_frequencies)]
    temp.harmonic_coefficients<-temp.harmonic_amplitudes
    if(!length(temp.harmonic_coefficients)){
      temp.harmonic_coefficients=0
    }
    temp.residual_eigencoefficients<-temp.cyclic_and_harmonic_analyses.object$out.residual_eigencoefficients
    temp.cosine_reconstruction<-temp.cyclic_and_harmonic_analyses.object$out.cosine_reconstruction
    temp.peak_frequencies<-temp.cyclic_and_harmonic_analyses.object$out.peak_frequencies
    temp.peak_areas<-temp.cyclic_and_harmonic_analyses.object$out.peak_areas
  }
  temp.extracted_cyclic_frequency_indices<-temp.cyclic_and_harmonic_analyses.object$out.extracted_cyclic_frequency_indices
  temp.num_significant_cyclic_frequencies=length(temp.extracted_cyclic_frequency_indices)
  temp.all_cyclic_frequency_indices<-temp.extracted_cyclic_frequency_indices
  if(temp.num_significant_cyclic_frequencies<temp.M2){
    if(temp.num_significant_cyclic_frequencies<2){
      temp.all_cyclic_frequency_indices<-unique(c(1,temp.all_cyclic_frequency_indices))
    }
  }
  temp.num_significant_cyclic_frequencies=length(temp.all_cyclic_frequency_indices)
  if(temp.num_significant_cyclic_frequencies>0){
    temp.significant_cyclic_frequencies<-temp.cyclic_and_harmonic_analyses.object$out.significant_frequencies
    temp.harmonic_ACS_amplitudes<-temp.cyclic_and_harmonic_analyses.object$out.harmonic_ACS_amplitudes
  }
  temp.list<-list(out.epoch_string=temp.epoch_string,
                  out.specific_subdirectory_string=temp.specific_subdirectory_string,
                  out.working_directory_string=temp.working_directory_string,
                  out.training_times=temp.training_times,
                  out.training_ts_sequence=temp.training_ts_sequence,
                  out.time_sequence_original_base_time=temp.time_sequence_original_base_time,
                  out.changepoint_times=temp.changepoint_times,
                  out.section_changepoint_indices=temp.section_changepoint_indices,
                  out.section_size=temp.section_size,
                  out.training_interval_bounds=temp.training_interval_bounds,
                  out.N=temp.N,
                  out.num_significant_frequencies=temp.num_significant_frequencies,
                  out.frequencies=temp.frequencies,
                  out.extracted_frequency_indices=temp.extracted_frequency_indices,
                  out.all_cyclic_frequency_indices=temp.all_cyclic_frequency_indices,
                  out.residual_eigencoefficients=temp.residual_eigencoefficients,
                  out.cosine_reconstruction=temp.cosine_reconstruction,
                  out.significant_frequencies=temp.significant_frequencies,
                  out.harmonic_amplitudes=temp.harmonic_amplitudes,
                  out.harmonic_coefficients=temp.harmonic_coefficients,
                  out.significant_cyclic_frequencies=temp.significant_cyclic_frequencies,
                  out.harmonic_ACS_amplitudes=temp.harmonic_ACS_amplitudes,
                  out.all_section_significant_frequencies=temp.all_section_significant_frequencies,
                  out.peak_frequencies=temp.peak_frequencies,
                  out.peak_areas=temp.peak_areas,
                  out.residual_spectral_powers=temp.residual_spectral_powers)
  if(eigencoeff_analysis_bool.par==TRUE){
    #Eigencoefficient statistical analysis.
    temp.harmonizable_eigencoefficient_analysis_object<-
      harmonizable_eigencoefficient_analysis.function(eigencoefficients.par=temp.residual_eigencoefficients,frequencies.par=temp.frequencies,
                                                      energy_concentrations.par=temp.energy_concentrations,N.par=temp.N,
                                                      slepian_functions.par=temp.slepian_functions,spectral_powers.par=temp.spectral_power_estimates,
                                                      sampling_rate.par=sampling_rate.par,first_time.par=first_time.par,
                                                      F_test_threshold.par=NA,frequency_band.par=frequency.band,
                                                      abscissa_value.par="Frequency",abscissa_units.par="Hz",
                                                      QIT.percentile.par1=QIT.percentile.par1,QIT_crossing_rates_bool.par=QIT_crossing_rates_bool.par,
                                                      QIT.percentile.par2=QIT.percentile.par2,wishart_percentiles.par=wishart_percentiles.par,
                                                      old_directory.par=temp.working_directory_string,
                                                      #Cyclic ACVS analysis.
                                                      extracted_frequency_indices.par=NA,max_size_Loeve.par=max_size_Loeve.par,
                                                      max_size_ACVF.par=max_size.cyclic_ACVS,
                                                      cyclic_ACVS_bool.par=cyclic_ACVS_bool.par,bifrequency_plot_bool.par=bifrequency_plot_bool.par,
                                                      measured_quantity.par=measured_quantity.par,measured_quantity_units.par=measured_units.par,
                                                      plot_bool.par=eigencoeff_plot_bool.par,verbose_bool.par=verbose_bool.par)
    temp.wishart_correlation_coefficient=temp.harmonizable_eigencoefficient_analysis_object$out.wishart_correlation_coefficient
    temp.num_positive_bin_heights<-temp.harmonizable_eigencoefficient_analysis_object$out.num_positive_bin_heights
    list.append(temp.list,
                out.wishart_correlation_coefficient=temp.wishart_correlation_coefficient,
                out.num_positive_bin_heights=temp.num_positive_bin_heights)
  }
  return(temp.list)
}


single_section_harmonic_ACS_analysis.function<-function(index.par,time_sequence.par,ts.par,M_exponent.par=1,
                                                        changepoint_times.par,epoch_labels.par,NW.par=5,
                                                        #Spectral and harmonic analyses.
                                                        truncation_bool.par=TRUE,
                                                        threshold_crossings_LB.par=3,num_sections.par=2,
                                                        measured_quantity.par="Measured quantity",measured_units.par="units",
                                                        spectral_power_directory_string.par="",old_directory.par="",
                                                        sampling_rate.par=1,first_time.par=0,start_time.par=0,F_test_threshold.par=NA,
                                                        jackknife.par=FALSE,F_test_jackknife.par=FALSE,
                                                        plot.par=FALSE,output.par=FALSE,spectral_power_bool.par=FALSE,
                                                        jk_output.par=FALSE,ha_bool.par=FALSE,residual_bool.par=FALSE,
                                                        reconstruction_bool.par=FALSE,verbose.par=FALSE,cepstral_bool.par=FALSE,
                                                        reconstruction_directory.par="",ends_reconstruction_bool.par=FALSE,
                                                        F_test_diagnostics_bool.par=FALSE,
                                                        #Eigencoefficient analysis Boolean.
                                                        eigencoeff_analysis_bool.par=TRUE,
                                                        #Cyclic analysis parameters.
                                                        cepstral_analysis_bool.par=FALSE,cepstral_F_threshold.par=NA,
                                                        Rsq_threshold.par=0.95,Kolmogorov_percentile.par=0.95,TPT_threshold.par=0.95,
                                                        outlier_percentile.par=0.6,
                                                        units.par1="units",units.par2="units",cepstral_measured_quantity.par="Measured quantity",
                                                        cepstral_units.par="units",specific_subdirectory_string.par="",cepstral_power_directory_string.par="",
                                                        ts_interp_bool.par=FALSE,mdss_bool.par=FALSE,remove_outliers_bool.par=FALSE,
                                                        residual_eigencoeffs_bool.par=FALSE,whitened_log_spectrum_bool.par=FALSE,
                                                        cleaned_log_spectrum_bool.par=FALSE,plot_quadratic_diagnostics_bool.par=FALSE,
                                                        cepstral_jk_spectral_power_bool.par=FALSE,cepstral_output.par=FALSE,
                                                        cepstral_plot_spectral_power_bool.par=FALSE,cepstral_power_bool.par=FALSE,
                                                        cepstral_output_jk_spectral_power.par=FALSE,cepstral_ha_bool.par=FALSE,
                                                        cepstral_residual_eigencoeffs_bool.par=FALSE,cepstral_power.verbose_par=FALSE,
                                                        #Ends reconstruction booleans, mean computations.
                                                        num_iterations.par=1,max_length.par=200,
                                                        main_directory_string.par="",directory_label.par="",old_directory_interp.par="",
                                                        revised_specific_directory_string.par="",
                                                        periodic_reconstruction_bool.par=FALSE,ts_interp_ends_bool.par=FALSE,mdss_bool_ends.par=FALSE,
                                                        gn_bool_ends.par=FALSE,eigencoeff_plot_bool.par=FALSE,cyclic_ACVS_bool.par=FALSE,
                                                        verbose_bool.par=FALSE,
                                                        #LAPTV and ACS analyses.
                                                        #laptv_ACVS.function
                                                        normal_quantile.par=1,max_size.par=100,
                                                        abscissa_quantity.par="Time",
                                                        abscissa_units.par=time_units.string,
                                                        ordinates_quantity.par=measure_quantity.string,
                                                        ordinates_units.par=measure_units.string,
                                                        measured_quantity_ACS.par=measure_quantity.string,
                                                        conjugate_correlation.par=FALSE,plot_ACVS_bool.par=FALSE,
                                                        #laptv_vs_signal_comparison.function
                                                        num_realizations.par=10,student_dof.par=5,nominal_distribution_string.par="Gaussian",
                                                        alternative_distribution_strings.par=c("logistic","Student","uniform" ),
                                                        correlation_memory_threshold.par=0.01,crude_rv_num_samples.par=5e3,
                                                        random_seeds.par=c(1,2),
                                                        measure_quantity_string.par="Measured quantity",measure_units_string.par="units",
                                                        pdf_title.par="",
                                                        prewhitening_bool.par=FALSE,plot_acvs_bool.par=FALSE,prewhitening_verbose_bool.par=TRUE,
                                                        time_efficieny_bool.par=TRUE,synthetic_data.par=TRUE,
                                                        #Ends reconstruction booleans, variance computations.
                                                        num_iterations_variance.par=1,max_length_variance.par=200,
                                                        main_directory_string_variance.par="",
                                                        periodic_reconstruction_bool_variance.par=FALSE,ts_interp_ends_bool_variance.par=TRUE,
                                                        mdss_bool_ends_variance.par=FALSE,gn_bool_ends_variance.par=FALSE){
  #Ensure that the maximum changepoint does not exceed the maximum record time.
  temp.means_ends_reconstruction_label<-"Means_Ends_Reconstruction"
  temp.basic_mtsa_single_section_function<-
    basic_mtsa_single_section.function(ts.par=ts.par,time_sequence.par=time_sequence.par,changepoint_times.par=changepoint_times.par,
                                       epoch_labels.par=epoch_labels.par,index.par=index.par,NW.par=NW.par,
                                       truncation_bool.par=truncation_bool.par,
                                       jackknife.par=jackknife.par,F_test_jackknife.par=F_test_jackknife.par,
                                       plot.par=plot.par,
                                       measured_quantity.par=measured_quantity.par,measured_units.par=measured_units.par,
                                       sampling_rate.par=sampling_rate.par,first_time.par=first_time.par,F_test_threshold.par=F_test_threshold.par,
                                       output.par=output.par,spectral_power_bool.par=spectral_power_bool.par,
                                       jk_output.par=jk_output.par,ha_bool.par=ha_bool.par,residual_bool.par=residual_bool.par,
                                       threshold_crossings_LB.par=threshold_crossings_LB.par,num_sections.par=num_sections.par,
                                       spectral_power_directory_string.par=spectral_power_directory_string.par,
                                       old_directory.par=old_directory.par,
                                       reconstruction_bool.par=reconstruction_bool.par,verbose.par=verbose.par,
                                       cepstral_bool.par=cepstral_bool.par,reconstruction_directory.par=reconstruction_directory.par,
                                       ends_reconstruction_bool.par=ends_reconstruction_bool.par,
                                       F_test_diagnostics_bool.par=F_test_diagnostics_bool.par,
                                       #Eigencoefficient analysis Boolean.
                                       eigencoeff_analysis_bool.par=eigencoeff_analysis_bool.par,
                                       #Cyclic analysis parameters.
                                       cepstral_analysis_bool.par=cepstral_analysis_bool.par,cepstral_F_threshold.par=cepstral_F_threshold.par,
                                       Rsq_threshold.par=Rsq_threshold.par,Kolmogorov_percentile.par=Kolmogorov_percentile.par,
                                       TPT_threshold.par=TPT_threshold.par,outlier_percentile.par=outlier_percentile.par,
                                       units.par1=units.par1,units.par2=units.par2,
                                       ts_interp_bool.par=ts_interp_bool.par,mdss_bool.par=mdss_bool.par,remove_outliers_bool.par=remove_outliers_bool.par,
                                       residual_eigencoeffs_bool.par=residual_eigencoeffs_bool.par,
                                       whitened_log_spectrum_bool.par=whitened_log_spectrum_bool.par,
                                       cleaned_log_spectrum_bool.par=cleaned_log_spectrum_bool.par,
                                       plot_quadratic_diagnostics_bool.par=plot_quadratic_diagnostics_bool.par,
                                       cepstral_jk_spectral_power_bool.par=cepstral_jk_spectral_power_bool.par,
                                       cepstral_measured_quantity.par=cepstral_measured_quantity.par,
                                       cepstral_units.par=cepstral_units.par,
                                       cepstral_output.par=cepstral_output.par,
                                       cepstral_plot_spectral_power_bool.par=cepstral_plot_spectral_power_bool.par,
                                       cepstral_power_bool.par=cepstral_power_bool.par,
                                       cepstral_output_jk_spectral_power.par=cepstral_output_jk_spectral_power.par,
                                       cepstral_ha_bool.par=cepstral_ha_bool.par,
                                       cepstral_residual_eigencoeffs_bool.par=cepstral_residual_eigencoeffs_bool.par,
                                       cepstral_power_directory_string.par=cepstral_power_directory_string.par,
                                       cepstral_power.verbose_par=cepstral_power.verbose_par,
                                       specific_subdirectory_string.par=specific_subdirectory_string.par,
                                       #Ends reconstruction booleans.
                                       periodic_reconstruction_bool.par=periodic_reconstruction_bool.par,ts_interp_ends_bool.par=ts_interp_ends_bool.par,
                                       mdss_bool_ends.par=mdss_bool_ends.par,gn_bool_ends.par=gn_bool_ends.par,
                                       num_iterations.par=num_iterations.par,max_length.par=max_length.par,
                                       main_directory_string.par=main_directory_string.par,
                                       directory_label.par=paste("Multitaper_Spectral_Power/",
                                                                 temp.means_ends_reconstruction_label,sep=""),
                                       old_directory_interp.par=old_directory_interp.par,
                                       revised_specific_directory_string.par=revised_specific_directory_string.par,
                                       eigencoeff_plot_bool.par=eigencoeff_plot_bool.par,cyclic_ACVS_bool.par=cyclic_ACVS_bool.par,
                                       verbose_bool.par=verbose_bool.par)
  #Output to be used in the input for the LAPTV function.
  temp.epoch_string<-temp.basic_mtsa_single_section_function$out.epoch_string
  temp.specific_subdirectory_string<-temp.basic_mtsa_single_section_function$out.specific_subdirectory_string
  temp.working_directory_string<-temp.basic_mtsa_single_section_function$out.working_directory_string
  temp.revised_specific_directory_string<-temp.basic_mtsa_single_section_function$out.revised_specific_directory_string
  #Output to be used by the source code and other functions.
  temp.training_times<-temp.basic_mtsa_single_section_function$out.training_times
  temp.training_ts_sequence<-temp.basic_mtsa_single_section_function$out.training_ts_sequence
  temp.time_sequence_original_base_time<-temp.basic_mtsa_single_section_function$out.time_sequence_original_base_time
  temp.changepoint_times<-temp.basic_mtsa_single_section_function$out.changepoint_times
  temp.section_changepoint_indices<-temp.basic_mtsa_single_section_function$out.section_changepoint_indices
  temp.frequencies<-temp.basic_mtsa_single_section_function$out.frequencies
  temp.M2=length(temp.frequencies)
  temp.M=2*(temp.M2-1)
  temp.significant_frequencies<-temp.basic_mtsa_single_section_function$out.significant_frequencies
  temp.residual_eigencoefficients<-temp.basic_mtsa_single_section_function$out.residual_eigencoefficients
  temp.residual_spectral_powers<-temp.basic_mtsa_single_section_function$out.residual_spectral_powers
  temp.means<-temp.basic_mtsa_single_section_function$out.cosine_reconstruction
  temp.num_significant_frequencies=temp.basic_mtsa_single_section_function$out.num_significant_frequencies
  #Output to be used in lists for full-record and survey-strata statistical analysis.
  temp.N=temp.basic_mtsa_single_section_function$out.N
  temp.training_interval_bounds<-temp.basic_mtsa_single_section_function$out.training_interval_bounds
  temp.harmonic_coefficients<-temp.basic_mtsa_single_section_function$out.harmonic_coefficients
  temp.list<-list(out.N=temp.N,
                  out.training_interval_bounds=temp.training_interval_bounds,
                  out.harmonic_coefficients=temp.harmonic_coefficients)
  if(cepstral_analysis_bool.par==TRUE){
    temp.all_cyclic_frequency_indices<-temp.basic_mtsa_single_section_function$out.all_cyclic_frequency_indices
    cat("temp.all_cyclic_frequency_indices\n")
    print(temp.all_cyclic_frequency_indices)
    temp.cyclic_frequency_index_list<-list(temp.all_cyclic_frequency_indices)
    if(!is.na(temp.all_cyclic_frequency_indices)){
      temp.cyclic_frequency_index_list<-list.append(temp.cyclic_frequency_index_list,NA)
    }
    temp.all_cyclic_frequencies<-temp.frequencies[temp.all_cyclic_frequency_indices]/(sampling_rate.par/temp.M)
    cat("temp.basic_mtsa_single_section_function$out.significant_cyclic_frequencies\n")
    print(temp.basic_mtsa_single_section_function$out.significant_cyclic_frequencies)
    temp.significant_cyclic_frequencies<-temp.basic_mtsa_single_section_function$out.significant_cyclic_frequencies
    temp.num_significant_cyclic_frequencies=length(temp.significant_cyclic_frequencies)
    for(temp.i in 1:temp.num_significant_cyclic_frequencies){
      temp.significant_cyclic_frequencies[[temp.i]]<-temp.significant_cyclic_frequencies[[temp.i]]/(sampling_rate.par/temp.M)
    }
    temp.harmonic_ACS_amplitudes<-temp.basic_mtsa_single_section_function$out.harmonic_ACS_amplitudes
    temp.all_section_significant_frequencies<-temp.basic_mtsa_single_section_function$out.all_section_significant_frequencies
    temp.wishart_correlation_coefficient=temp.basic_mtsa_single_section_function$out.wishart_correlation_coefficient
    temp.num_positive_bin_heights<-temp.basic_mtsa_single_section_function$out.num_positive_bin_heights
    #LAPTV statistics.
    temp.variances_ends_reconstruction_label<-"Variance_Ends_Reconstruction"
    temp.previous_changepoint=changepoint_times.par[index.par]
    temp.current_changepoint=changepoint_times.par[index.par+1]
    temp.basic_laptv_single_section_object<-basic_laptv_single_section.function(training_times.par=temp.training_times,
                                                                                training_ts_values.par=temp.training_ts_sequence,
                                                                                previous_changepoint.par=temp.previous_changepoint,
                                                                                current_changepoint.par=temp.current_changepoint,
                                                                                specific_subdirectory_string.par=temp.specific_subdirectory_string,
                                                                                old_directory.par=temp.working_directory_string,
                                                                                revised_specific_directory_string.par=temp.revised_specific_directory_string,
                                                                                NW.par=NW.par,sampling_rate.par=sampling_rate.par,
                                                                                first_time.par=first_time.par,start_time.par=start_time.par,
                                                                                #laptv_ACVS.function
                                                                                normal_quantile.par=normal_quantile.par,
                                                                                conjugate_correlation.par=conjugate_correlation.par,
                                                                                plot_ACVS_bool.par=plot_ACVS_bool.par,
                                                                                abscissa_quantity.par=abscissa_quantity.par,
                                                                                abscissa_units.par=abscissa_units.par,
                                                                                ordinates_quantity.par=ordinates_quantity.par,
                                                                                ordinates_units.par=ordinates_units.par,
                                                                                laptv_ordinates_quantity.par=measured_quantity.par,
                                                                                laptv_ordinates_units.par=measured_units.par,
                                                                                max_size.par=max_size.par,
                                                                                measured_quantity.par=measured_quantity_ACS.par,
                                                                                plot_titles.par=epoch_labels.par[index.par],
                                                                                #laptv_vs_signal_comparison.function
                                                                                spectral_power_estimates.par=temp.residual_spectral_powers,
                                                                                frequencies.par=temp.frequencies,
                                                                                time_sequence.par=time_sequence.par,ts.par=ts.par,
                                                                                N_truncated.par=temp.N,
                                                                                cyclic_frequency_indices.par=temp.cyclic_frequency_index_list,
                                                                                cosine_reconstruction.par=temp.means,
                                                                                num_realizations.par=num_realizations.par,student_dof.par=student_dof.par,
                                                                                nominal_distribution_string.par=nominal_distribution_string.par,
                                                                                alternative_distribution_strings.par=alternative_distribution_strings.par,
                                                                                correlation_memory_threshold.par=correlation_memory_threshold.par,
                                                                                crude_rv_num_samples.par=crude_rv_num_samples.par,
                                                                                random_seeds.par=index.par+c(1,2),
                                                                                measure_quantity_string.par=measure_quantity_string.par,
                                                                                measure_units_string.par=measure_units_string.par,
                                                                                pdf_title.par=pdf_title.par,prewhitening_bool.par=prewhitening_bool.par,
                                                                                plot_acvs_bool.par=plot_acvs_bool.par,
                                                                                prewhitening_verbose_bool.par=prewhitening_verbose_bool.par,
                                                                                time_efficieny_bool.par=time_efficieny_bool.par,
                                                                                synthetic_data.par=synthetic_data.par,
                                                                                #Ends reconstruction booleans.
                                                                                periodic_reconstruction_bool.par=periodic_reconstruction_bool_variance.par,
                                                                                ts_interp_ends_bool.par=ts_interp_ends_bool_variance.par,
                                                                                mdss_bool_ends.par=mdss_bool_ends_variance.par,
                                                                                gn_bool_ends.par=gn_bool_ends_variance.par,
                                                                                num_iterations.par=num_iterations_variance.par,
                                                                                max_length.par=max_length_variance.par,
                                                                                main_directory_string.par=main_directory_string_variance.par,
                                                                                directory_label.par=temp.variances_ends_reconstruction_label,
                                                                                old_directory_interp.par=paste(temp.working_directory_string,
                                                                                                               "LAPTV_Analysis/",sep=""))
    temp.ar_coefficients<-temp.basic_laptv_single_section_object$out.ar_coefficients_LAPTV
    temp.prewhitened_process_variances=temp.basic_laptv_single_section_object$out.prewhitened_process_variance_LAPTV
    temp.time_vector<-temp.basic_laptv_single_section_object$out.all_times
    temp.ts_vector<-temp.basic_laptv_single_section_object$out.all_ts_values
    temp.mean_vector<-temp.basic_laptv_single_section_object$out.all_reconstructions
    temp.sd_vector<-temp.basic_laptv_single_section_object$out.all_sd
    list.append(temp.list,
                out.wishart_correlation_coefficient=temp.wishart_correlation_coefficient,
                out.num_positive_bin_heights=temp.num_positive_bin_heights,
                #Cyclic harmonic analysis.
                out.harmonic_ACS_amplitudes=temp.harmonic_ACS_amplitudes,
                out.all_section_significant_frequencies=temp.all_section_significant_frequencies,
                out.all_section_cyclic_frequencies=temp.significant_cyclic_frequencies,
                #LAPTV
                out.ar_coefficients=temp.ar_coefficients,
                out.prewhitened_process_variances=temp.prewhitened_process_variances,
                out.time_vector=temp.time_vector,
                out.ts_vector=temp.ts_vector,
                out.mean_vector=temp.mean_vector,
                out.sd_vector=temp.sd_vector)
  }
  return(temp.list)
}













###################################################################################################################
#Jackknife functions.
source(paste(starting.directory,"Bifrequency_Spectrum_Header.R",sep=""))


###################################################################################################################
#Jackknife functions.
source(paste(starting.directory,"Jackknife_Header.R",sep=""))


###################################################################################################################
#Time-series parameter estimators.
source(paste(starting.directory,"Multitaper_Statistics_Header.R",sep=""))


###################################################################################################################
#Quadratic inverse theory.
source(paste(starting.directory,"Quadratic_Inverse_Theory_Header.R",sep=""))



###################################################################################################################
#Re-shaping.
reshaping<-function(ts.par,pr_eigencoefficients.par,mb_functions.par,mb_eigencoefficients.par,frequencies.par,NW.par,K.par,M.par){
  temp.N=length(ts.par)
  temp.M=nrow(pr_eigencoefficients.par)
  temp.half_bandwidth=floor(NW.par/temp.N*temp.M)
  temp.zero_index=M.par/2
  temp.max_index=temp.zero_index
  significant_F_peaks.object<-significant.F_peaks(mb_eigencoefficients.par,mb_functions.par,frequencies.par,K.par,M.par)
  temp.peak_indices<-significant_F_peaks.object[[3]]
  temp.n_significant=significant_F_peaks.object[[4]]
  temp.mu_values<-significant_F_peaks.object[[5]]
  temp.demodulate_reconstruction<-rep(0,temp.N)
  if(temp.n_significant){
    for(i in 1:temp.n_significant){
      temp.frequency_index=temp.peak_indices[i]-1
      temp.min_frequency_index=temp.frequency_index-w.factor*temp.half_bandwidth
      temp.max_frequency_index=temp.frequency_index+w.factor*temp.half_bandwidth
      if(temp.min_frequency_index>1 && temp.max_frequency_index<temp.max_index){
        temp.local_indices<-temp.min_frequency_index:temp.max_frequency_index
        #Re-shape the spectrum.
        temp.initial_energy=sum(pr_eigencoefficients.par[temp.zero_index-rev(temp.local_indices),]^2)
        pr_eigencoefficients.par[temp.zero_index-rev(temp.local_indices),]<-mb_eigencoefficients.par[temp.zero_index-rev(temp.local_indices),]
        temp.final_energy=sum(pr_eigencoefficients.par[temp.zero_index-rev(temp.local_indices),]^2)
        pr_eigencoefficients.par[temp.zero_index-rev(temp.local_indices),]<-pr_eigencoefficients.par[temp.zero_index-rev(temp.local_indices),]*sqrt(temp.initial_energy/temp.final_energy)
        #Repeat for positive frequencies.
        temp.initial_energy=sum(pr_eigencoefficients.par[temp.zero_index+temp.local_indices,]^2)
        pr_eigencoefficients.par[temp.zero_index+temp.local_indices,]<-mb_eigencoefficients.par[temp.zero_index+temp.local_indices,]
        temp.final_energy=sum(pr_eigencoefficients.par[temp.zero_index+temp.local_indices,]^2)
        pr_eigencoefficients.par[temp.zero_index+temp.local_indices,]<-pr_eigencoefficients.par[temp.zero_index+temp.local_indices,]*sqrt(temp.initial_energy/temp.final_energy)
      }#endif
    }
  }
  temp.list<-list(pr_eigencoefficients.par)
  return(temp.list)
}







###################################################################################################################
#Gapped time series.

gapped.spectrum_estimate<-function(time_series.par,eigen_matrix.par,K.par,M.par){
  temp.N=length(time_series.par)
  temp.tapered_matrix<-matrix(0,nrow=M.par,ncol=K.par)
  temp.eigen_matrix<-matrix(0,nrow=M.par,ncol=K.par)
  #cat("nrow = ",nrow(eigen_matrix.par),", ncol = ",ncol(eigen_matrix.par),", temp.N = ",temp.N,"\n")
  temp.eigen_matrix[1:temp.N,]<-eigen_matrix.par
  #temp.eigen_matrix<-rbind(eigen_matrix.par,temp.zero_matrix)
  temp.zero_vector<-rep(0,M.par-temp.N)
  #cat("length1 = ",nrow(temp.eigen_matrix),"\n")
  #cat("length2 = ",length(c(time_series.par,temp.zero_vector)),"\n")
  for(k in 1:K.par){
    temp.tapered_matrix[,k]<-temp.eigen_matrix[,k]*c(time_series.par,temp.zero_vector)
  }
  temp.y_k<-mvfft(temp.tapered_matrix)
  temp.y_k<-fft.rearrange_matrix(temp.y_k)
  temp.S_hat<-rowSums(Mod(temp.y_k)^2)/K.par
  temp.list<-list(temp.y_k,temp.S_hat)
  return(temp.list)
}


###################################################################################################################
#Spectral statistics for minimum-bias tapers.

mb.eigencoefficients_peaks_removed<-function(ts.par,eigen_matrix.par,eigencoefficients.par,slepian_functions.par,slepian_sequences.par,frequencies.par,frequencies_full.par,NW.par,K.par,M.par){
  temp.N=length(ts.par)
  temp.M=nrow(eigencoefficients.par)
  temp.half_bandwidth=floor(NW.par/temp.N*M.par)
  temp.zero_index=M.par/2
  temp.max_index=temp.zero_index
  significant_F_peaks.object<-significant.F_peaks(eigencoefficients.par,slepian_functions.par,frequencies.par,K.par,M.par)
  temp.peak_indices<-significant_F_peaks.object[[3]]
  temp.n_significant=significant_F_peaks.object[[4]]
  temp.mu_values<-significant_F_peaks.object[[5]]
  temp.F_statistics<-significant_F_peaks.object[[6]]
  temp.log_threshold_quantile=log10(qf(threshold.interpolation_F_percentile,2,2*K.par-2))
  temp.filter_K=K.par
  filter.slepian_sequences<-mb.tapers(temp.N,temp.filter_K)
  temp.slepian_functions<-Slepian.functions(filter.slepian_sequences,temp.M)
  temp.demodulate_reconstruction<-rep(0,temp.N)
  if(temp.n_significant){
    for(i in 1:temp.n_significant){
      temp.frequency_index=temp.peak_indices[i]-1
      temp.min_frequency_index=temp.frequency_index-w.factor*temp.half_bandwidth
      temp.max_frequency_index=temp.frequency_index+w.factor*temp.half_bandwidth
      if(temp.min_frequency_index>1 && temp.max_frequency_index<temp.max_index){
        temp.local_indices<-temp.min_frequency_index:temp.max_frequency_index
        temp.local_slepian_functions<-slepian_functions.par[temp.zero_index+(temp.local_indices-temp.frequency_index),]
        #For the negative frequency components, remove harmonic means from the eigencoefficients.
        temp.mu_band<-temp.mu_values[temp.zero_index-rev(temp.local_indices)]
        temp.amplitudes<-Mod(temp.mu_band)
        temp.max_amplitude=max(temp.amplitudes)
        temp.optimal_index=min(which(temp.amplitudes==temp.max_amplitude))
        temp.optimal_mu=temp.mu_band[temp.optimal_index]
        temp.harmonic_eigencoefficients.matrix<-temp.optimal_mu*temp.local_slepian_functions
        eigencoefficients.par[temp.zero_index-rev(temp.local_indices),]<-eigencoefficients.par[temp.zero_index-rev(temp.local_indices),]-temp.harmonic_eigencoefficients.matrix
        temp.eigencoefficients_minus<-temp.harmonic_eigencoefficients.matrix
        #Same again for the positive frequency component.
        temp.mu_band<-temp.mu_values[temp.zero_index+temp.local_indices]
        temp.amplitudes<-Mod(temp.mu_band)
        temp.max_amplitude=max(temp.amplitudes)
        temp.optimal_index=min(which(temp.amplitudes==temp.max_amplitude))
        temp.optimal_mu=temp.mu_band[temp.optimal_index]
        temp.harmonic_eigencoefficients.matrix<-temp.optimal_mu*temp.local_slepian_functions
        eigencoefficients.par[temp.zero_index+temp.local_indices,]<-eigencoefficients.par[temp.zero_index+temp.local_indices,]-temp.harmonic_eigencoefficients.matrix
        temp.eigencoefficients_plus<-temp.harmonic_eigencoefficients.matrix
        temp.eigencoefficients<-matrix(0,nrow=temp.M,ncol=K.par)
        temp.eigencoefficients[temp.zero_index-temp.local_indices,]<-temp.eigencoefficients_minus
        temp.eigencoefficients[temp.zero_index+temp.local_indices,]<-temp.eigencoefficients_plus
        for(k in 1:K.par){
          temp.eigencoefficients[,k]<-return.to.fft_ordering(temp.eigencoefficients[,k])
        }
        temp.current_demodulate_reconstruction<-Re(fft(temp.eigencoefficients[,1],inverse=TRUE))
        temp.current_demodulate_reconstruction<-temp.current_demodulate_reconstruction[1:temp.N]
        temp.demodulate_reconstruction<-temp.demodulate_reconstruction+temp.current_demodulate_reconstruction
      }#endif
    }
    temp.demodulate_reconstruction<-temp.demodulate_reconstruction/temp.M/slepian_sequences.par[,1]
  }
  temp.demodulate_reconstruction<-2*temp.demodulate_reconstruction
  ts.par<-ts.par-temp.demodulate_reconstruction
  temp.list<-list(eigencoefficients.par,ts.par,temp.demodulate_reconstruction,temp.F_statistics)
  return(temp.list)
}







