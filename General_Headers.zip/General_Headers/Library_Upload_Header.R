#Francois Marshall, Boston University
#Header file for upload of libraries.

###################################################################################################################

#Upload some relevant libraries.
#https://vbaliga.github.io/verify-that-r-packages-are-installed-and-loaded/
FUN=function(x){
  if(!require(x,character.only=TRUE)){
    if(x=="HMisc"){
      devtools::install_version("latticeExtra",version="0.6-28",repos='http://cran.rstudio.com/')
      devtools::install_version("HMisc",version="4.3-0",repos='http://cran.rstudio.com/')
    }
    else if(x=="tsinterp"){
      install_github("wesleyburr/tsinterp")
    }
    else if(x %in% c("spsmooth","ppls","parcor","reticulate","sjmisc","stringr","plotrix","magick","cowplot","reshape2","gridExtra","plot3D","lavaan",
                     "pracma","wq","Deriv","mrbsizeR","gsl","ggraph","mda","penalizedLDA","kolmim")){
      install_github(paste("cran/",x,sep=""))
    }
    else if(x %in% c("R.matlab","RConics","glmc","conics","seewave","FBN")){
      install_github(paste("cran/",x,sep=""))
    }
    else{
      install.packages(x,dependencies=TRUE,repos='http://cran.rstudio.com/')
    }
  }
  library(x,character.only=TRUE)
}


## First specify the packages of interest
packages<-c("data.table",
            "Hmisc",
            "devtools",
            "scales",
            "multitaper",
            "astsa",
            "locfit",
            "zoo",
            "xts",
            "outliers",
            "e1071",
            "FBN",
            "Rmpfr",
            "IDPmisc",
            "date",
            "moments",
            "phonTools",
            "gtools",
            "splines",
            "formattable",
            "car",
            "MASS",
            "lars",
            "splines",
            "akima",
            "statmod",
            "kolmim",
            "signal",
            #"matlib",
            "fields",
            "BMS",
            "hypergeo",
            "Cairo",
            "stats",
            "sde",
            "complexplus",
            "tsinterp",
            "tseries",
            "coda",
            "evd",
            "data.table",
            "gdata",
            "pracma",
            "complexplus",
            "tictoc",
            "forecast",
            "dichromat",
            "matrixcalc",
            "rARPACK",
            "spsmooth",
            "R.matlab",
            "matconv",
            "sjmisc",
            "stringr",
            "mixdist",
            "mixtools",
            "rlist",
            "broom",
            "shape",
            "plotrix",
            "ContourFunctions",
            "ggplot2",
            "magick",
            "cowplot",
            "reshape2",
            "gridExtra",
            "plot3D",
            "glmc",
            "lavaan",
            "conics",
            "itsmr",
            "randtests",
            "wq",
            "Deriv",
            "mrbsizeR",
            "ggraph",
            "seewave",
            "mda",
            "penalizedLDA")

## Now load or install and load all.
cat("Loading libraries.")
package.check<-lapply(packages,FUN)

























