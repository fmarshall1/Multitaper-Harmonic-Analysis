#Francois Marshall, Boston University
#Header file for multitaper functions.
###################################################################################################################

#The factor required because of the fact that 2W is not precisely a large enough frequency band to separate between independent FFT frequencies.

mean_removed.series<-function(ts.par,NW.par,slepian_sequences.par,Slepian_functions.par,K.par=0){
  temp.K=2*NW.par-1
  if(K.par!=0){
    temp.K=K.par
  }
  temp.M=nrow(Slepian_functions.par)
  temp.N=length(ts.par)
  #Introduce a nugget to avoid discontinuities at the zeros of the Slepian sequences in the divisions.
  temp.slepian_zero_indices<-which(!slepian_sequences.par)
  slepian_sequences.par[!slepian_sequences.par]<-1e-10
  #Compute the eigencoefficients of the time series.
  temp.eigencoefficients_matrix<-eigencoefficients(ts.par,slepian_sequences.par,temp.M)
  #Estimate the mean of the time series.
  temp.mean_estimate=multitaper.mean_estimate(temp.eigencoefficients_matrix,Slepian_functions.par)
  #Compute the eigenspectra.
  temp.eigenspectra<-Mod(temp.eigencoefficients_matrix)^2
  #Compute the average multitaper spectrum estimate.
  temp.multitaper_spectrum<-multitaper.average_spectrum(temp.eigenspectra)
  temp.process_variance=mean(temp.multitaper_spectrum)
  temp.spectrum_estimate<-non_negative.principle_domain(temp.multitaper_spectrum)
  temp.demeaned_series<-ts.par-temp.mean_estimate
  temp.list<-list(out.demeaned_series=temp.demeaned_series,
                  out.mean_estimate=temp.mean_estimate,
                  out.process_variance=temp.process_variance,
                  out.spectrum_estimate=temp.spectrum_estimate,
                  out.eigenspectra=temp.eigenspectra,
                  out.multitaper_spectrum_estimate=temp.multitaper_spectrum)
  return(temp.list)
}


harmonic_amplitude.function<-function(index.par,eigencoefficent.par,Slepian_function.par){
  temp.M=nrow(Slepian_function.par)
  temp.zero_index=temp.M/2
  temp.zero_frequency_Slepian_functions<-Re(Slepian_function.par[temp.zero_index,])
  temp.numerator<-sum(temp.zero_frequency_Slepian_functions*eigencoefficent.par[index.par,])
  temp.denominator<-crossprod(temp.zero_frequency_Slepian_functions)
  temp.mu<-temp.numerator/temp.denominator
  return(temp.mu)
}


harmonic_signal_power.function<-function(index.par,eigencoefficent.par,harmonic_amplitude.par,Slepian_function.par){
  temp.M=nrow(Slepian_function.par)
  temp.zero_index=temp.M/2
  temp.zero_frequency_Slepian_functions<-Re(Slepian_function.par[temp.zero_index,])
  temp.signal_eigencoefficients<-harmonic_amplitude.par[index.par-temp.zero_index+1]*temp.zero_frequency_Slepian_functions
  temp.signal_power<-sum(Mod(temp.signal_eigencoefficients)^2)
  return(temp.signal_power)
}


residual_eigencoefficient_full.function<-function(index.par,eigencoefficent.par,harmonic_amplitude.par,Slepian_function.par){
  temp.M=nrow(Slepian_function.par)
  temp.zero_index=temp.M/2
  temp.zero_frequency_Slepian_functions<-Re(Slepian_function.par[temp.zero_index,])
  temp.residual_eigencoefficients<-eigencoefficent.par[index.par,]-harmonic_amplitude.par[index.par]*temp.zero_frequency_Slepian_functions
  return(temp.residual_eigencoefficients)
}

residual_eigencoefficient.function<-function(index.par,eigencoefficent.par,harmonic_amplitude.par,Slepian_function.par){
  temp.M=nrow(Slepian_function.par)
  temp.zero_index=temp.M/2
  temp.zero_frequency_Slepian_functions<-Re(Slepian_function.par[temp.zero_index,])
  temp.residual_eigencoefficients<-eigencoefficent.par[index.par,]-
    harmonic_amplitude.par[index.par-temp.zero_index+1]*temp.zero_frequency_Slepian_functions
  return(temp.residual_eigencoefficients)
}


harmonic_residual_power.function<-function(index.par,eigencoefficent.par,harmonic_amplitude.par,Slepian_function.par){
  temp.residual_eigencoefficients<-residual_eigencoefficient.function(index.par,eigencoefficent.par,harmonic_amplitude.par,Slepian_function.par)
  temp.residual_power<-sum(Mod(temp.residual_eigencoefficients)^2)
  return(temp.residual_power)
}


harmonic_power.function<-function(eigencoefficent.par,Slepian_function.par,num_diffs.par=0){
  temp.K=ncol(Slepian_function.par)
  temp.M=nrow(Slepian_function.par)
  temp.zero_index=temp.M/2
  temp.M2=temp.zero_index+1
  temp.dof=min(2+3*num_diffs.par,2*temp.K)
  temp.indices<-temp.zero_index+1:temp.M2-1
  temp.harmonic_amplitudes=sapply(temp.indices,harmonic_amplitude.function,eigencoefficent.par,Slepian_function.par)
  temp.signal_powers<-sapply(temp.indices,harmonic_signal_power.function,eigencoefficent.par,temp.harmonic_amplitudes,
                             Slepian_function.par)
  temp.residual_powers<-sapply(temp.indices,harmonic_residual_power.function,eigencoefficent.par,temp.harmonic_amplitudes,Slepian_function.par)
  temp.residual_F_statistics=(2*temp.K-temp.dof)/temp.dof*temp.signal_powers/temp.residual_powers
  temp.F_statistics=(temp.K-1)*temp.signal_powers/temp.residual_powers
  temp.list<-list(out.harmonic_amplitudes=temp.harmonic_amplitudes,
                  out.signal_powers=temp.signal_powers,
                  out.residual_powers=temp.residual_powers,
                  out.F_statistics=temp.F_statistics,
                  out.residual_F_statistics=temp.residual_F_statistics)
  return(temp.list)
}


single_F_statistic.function<-function(index.par,eigencoefficent.par,Slepian_function.par,num_diffs.par=0){
  temp.dof=2+3*num_diffs.par
  temp.K=ncol(Slepian_function.par)
  temp.M=nrow(Slepian_function.par)
  temp.zero_index=temp.M/2
  temp.M2=temp.zero_index+1
  temp.index=temp.zero_index+index.par-1
  temp.harmonic_amplitudes<-harmonic_amplitude.function(temp.index,eigencoefficent.par,Slepian_function.par)
  temp.signal_powers<-harmonic_signal_power.function(temp.zero_index,eigencoefficent.par,temp.harmonic_amplitudes,Slepian_function.par)
  temp.residual_powers<-harmonic_residual_power.function(temp.zero_index,eigencoefficent.par,temp.harmonic_amplitudes,Slepian_function.par)
  temp.F_statistic=(2*temp.K-temp.dof)/temp.dof*temp.signal_powers/temp.residual_powers
  return(temp.F_statistic)
}


F_peak_reconstruction.function<-function(indices.par,F_statistics.par,frequencies.par,training_size.par=5,Rsq_threshold.par=0.95,
                                         Kolmogorov_percentile.par=0,TPT_threshold.par=0,outlier_percentile.par=0.99){
  if(!Kolmogorov_percentile.par){
    Kolmogorov_percentile.par=1-alpha.par
  }
  if(!TPT_threshold.par){
    TPT_threshold.par=1-alpha.par
  }
  #Set up an initial training sample.
  temp.num_indices=length(indices.par)
  temp.centre_index=(temp.num_indices-1)/2
  temp.training_half_width=(training_size.par-1)/2
  temp.training_indices<-(temp.centre_index-temp.training_half_width):(temp.centre_index+temp.training_half_width)
  temp.training_inverted_SNR<-1/F_statistics.par[temp.training_indices]
  #Omit outliers.
  temp.remove_outliers_object<-remove_outliers.function(temp.training_inverted_SNR,temp.training_indices,outlier_percentile.par=outlier_percentile.par)
  temp.training_inverted_SNR<-temp.remove_outliers_object$out.ts
  temp.ndiffs=temp.remove_outliers_object$out.ndiffs
  temp.num_outliers=temp.remove_outliers_object$out.num_outliers
  #Determine the size of training sample about the centre frequency index for which first differences of the inverted F-statistic values behave linearly.
  temp.abscissa<-2:training_size.par
  temp.first_diffs<-temp.training_inverted_SNR[temp.abscissa]-temp.training_inverted_SNR[temp.abscissa-1]
  temp.linear_lm<-lm(temp.first_diffs~temp.abscissa)
  temp.linear_coefficients<-temp.linear_lm$coefficients
  temp.slope=temp.linear_coefficients[2]
  temp.fitted_line_values<-temp.linear_lm$fitted.values
  temp.linear_residuals<-temp.first_diffs-temp.fitted_line_values
  temp.line_residual_analysis_object<-residual_analysis.function(temp.fitted_line_values,temp.linear_residuals,TPT_threshold.par=TPT_threshold.par)
  temp.line_Rsq=temp.line_residual_analysis_object$out.Rsq
  if(temp.line_Rsq<0){
    temp.line_Rsq=0
  }
  temp.line_KS_percentile=temp.line_residual_analysis_object$out.KS_percentile
  temp.line_TPT_percentile=temp.line_residual_analysis_object$out.TPT_percentile
  temp.line_Rsq_previous=temp.line_Rsq
  temp.line_KS_percentile_previous=temp.line_KS_percentile
  temp.line_TPT_percentile_previous=temp.line_TPT_percentile
  temp.ndiffs_previous=temp.ndiffs
  temp.training_indices_previous<-temp.training_indices
  temp.training_inverted_SNR_previous<-temp.training_inverted_SNR
  temp.training_min_index=max(1,temp.centre_index-temp.training_half_width-1)
  temp.training_max_index=min(temp.num_indices,temp.centre_index+temp.training_half_width+1)
  if(temp.slope>0 & temp.line_Rsq>Rsq_threshold.par & temp.line_KS_percentile<=(Kolmogorov_percentile.par*100) &
     (temp.training_min_index>1 || temp.training_max_index<temp.num_indices)){
    temp.stop_bool=FALSE
    while(temp.slope>0 & temp.line_Rsq>Rsq_threshold.par & temp.line_KS_percentile<=(Kolmogorov_percentile.par*100) &
          (temp.training_min_index>1 || temp.training_max_index<temp.num_indices) & temp.stop_bool==FALSE){
      temp.line_Rsq_previous=temp.line_Rsq
      temp.line_KS_percentile_previous=temp.line_KS_percentile
      temp.line_TPT_percentile_previous=temp.line_TPT_percentile
      temp.ndiffs_previous=temp.ndiffs
      temp.training_indices_previous<-temp.training_indices
      temp.training_inverted_SNR_previous<-temp.training_inverted_SNR
      temp.training_min_index=max(1,temp.centre_index-temp.training_half_width-1)
      temp.training_max_index=min(temp.num_indices,temp.centre_index+temp.training_half_width+1)
      temp.training_indices0<-temp.training_min_index:temp.training_max_index
      temp.training_size0=length(temp.training_indices)
      temp.training_inverted_SNR0<-1/F_statistics.par[temp.training_indices0]
      #Omit outliers.
      temp.remove_outliers_object<-remove_outliers.function(temp.training_inverted_SNR0,temp.training_indices0,
                                                            outlier_percentile.par=outlier_percentile.par)
      temp.training_inverted_SNR0<-temp.remove_outliers_object$out.ts
      temp.ndiffs0=temp.remove_outliers_object$out.ndiffs
      temp.num_outliers0=temp.remove_outliers_object$out.num_outliers
      temp.abscissa0<-2:temp.training_size0
      temp.first_diffs0<-temp.training_inverted_SNR0[temp.abscissa0]-temp.training_inverted_SNR0[temp.abscissa0-1]
      temp.linear_lm<-lm(temp.first_diffs0~temp.abscissa0)
      temp.linear_coefficients0<-temp.linear_lm$coefficients
      temp.slope0=temp.linear_coefficients0[2]
      if(temp.slope>0){
        temp.training_indices<-temp.training_indices0
        temp.training_size=temp.training_size0
        temp.training_inverted_SNR<-temp.training_inverted_SNR0
        temp.ndiffs=temp.ndiffs0
        temp.num_outliers=temp.num_outliers0
        temp.abscissa<-temp.abscissa0
        temp.first_diffs<-temp.first_diffs0
        temp.linear_coefficients=temp.linear_coefficients0
        temp.slope=temp.slope0
        temp.fitted_line_values<-temp.linear_lm$fitted.values
        temp.linear_residuals<-temp.first_diffs-temp.fitted_line_values
        temp.line_residual_analysis_object<-residual_analysis.function(temp.fitted_line_values,temp.linear_residuals,TPT_threshold.par=TPT_threshold.par)
        temp.line_Rsq=temp.line_residual_analysis_object$out.Rsq
        if(temp.line_Rsq<0){
          temp.line_Rsq=0
        }
        temp.line_KS_percentile=temp.line_residual_analysis_object$out.KS_percentile
        temp.line_TPT_percentile=temp.line_residual_analysis_object$out.TPT_percentile
      }
      else{
        temp.stop_bool=TRUE
      }
    }
  }
  temp.line_Rsq=temp.line_Rsq_previous
  temp.line_KS_percentile=temp.line_KS_percentile_previous
  temp.line_TPT_percentile=temp.line_TPT_percentile_previous
  temp.training_indices<-temp.training_indices_previous
  temp.training_inverted_SNR<-temp.training_inverted_SNR_previous
  temp.frequencies<-frequencies.par[temp.training_indices]
  temp.num_training_indices=length(temp.training_indices)
  temp.fitted_values<-rep(0,temp.num_training_indices)
  temp.Rsq=0
  temp.TPT_percentile=0
  temp.KS_percentile=0
  temp.fitted_values<-rep(0,1)
  tryCatch({
    #Fit a reciprocal Lorentzian curve to the peak.
    temp.lm_object<-lm(temp.training_inverted_SNR~temp.training_indices+I(temp.training_indices^2))
    temp.coefficients<-temp.lm_object$coefficients
    temp.constant=temp.coefficients[1]
    temp.linear=temp.coefficients[2]
    temp.quadratic=temp.coefficients[3]
    temp.derivatives<-2*temp.quadratic*c(temp.training_indices[1],temp.training_indices[temp.num_training_indices])+temp.linear
    temp.median=-temp.linear/2/temp.quadratic
    #Residual diagnostics.
    temp.fitted_values<-temp.lm_object$fitted.values
    temp.residuals<-temp.training_inverted_SNR-temp.fitted_values
    temp.residual_analysis_object<-residual_analysis.function(temp.fitted_values,temp.residuals,TPT_threshold.par=TPT_threshold.par)
    temp.Rsq=temp.residual_analysis_object$out.Rsq
    if(temp.Rsq<0){
      temp.Rsq=0
    }
    temp.TPT_percentile=temp.residual_analysis_object$out.TPT_percentile
    temp.KS_percentile=temp.residual_analysis_object$out.KS_percentile
  },error=function(e)"Error: Parabolic fitting will not be performed due to insufficient number of elements.\n")#end tryCatch
  temp.list<-list(out.fitted_values=temp.fitted_values,
                  out.frequencies=temp.frequencies,
                  out.training_inverted_SNR=temp.training_inverted_SNR,
                  out.median=temp.median,
                  out.Rsq=temp.Rsq,
                  out.TPT_percentile=temp.TPT_percentile,
                  out.KS_percentile=temp.KS_percentile,
                  out.line_Rsq=temp.line_Rsq,
                  out.line_KS_percentile=temp.line_KS_percentile,
                  out.line_TPT_percentile=temp.line_TPT_percentile,
                  out.training_size=temp.num_training_indices,
                  out.derivatives=temp.derivatives,
                  out.ndiffs=temp.ndiffs,
                  out.num_outliers=temp.num_outliers)
  return(temp.list)
}


significant.F_peaks<-function(eigencoefficients.par,Slepian_functions.par,frequencies.par,threshold_percentile.par=threshold.percentile,
                              num_diffs.par=0,N.par=NA){
  #Compute the F-statistic.
  temp.K=ncol(eigencoefficients.par)
  temp.M=nrow(eigencoefficients.par)
  temp.zero_index=temp.M/2
  temp.M2=temp.zero_index+1
  temp.indices<-temp.zero_index+1:temp.M2-1
  temp.harmonic_power_object<-harmonic_power.function(eigencoefficients.par,Slepian_functions.par,num_diffs.par=num_diffs.par)
  temp.F_statistics<-temp.harmonic_power_object$out.F_statistics
  temp.residual_F_statistics<-temp.harmonic_power_object$out.residual_F_statistics
  temp.harmonic_amplitudes=temp.harmonic_power_object$out.harmonic_amplitudes
  temp.signal_powers=temp.harmonic_power_object$out.signal_powers
  temp.residual_powers=temp.harmonic_power_object$out.residual_powers
  temp.threshold_quantile=qf(threshold_percentile.par,2,2*temp.K-2-num_diffs.par*3)
  #Find the peaks of the F-spectrum.
  temp.peak_frequencies<-c()
  temp.peak_heights<-c()
  temp.peak_indices<-c()
  counter=1
  for(temp.i in 1:temp.M2){
    if(temp.residual_F_statistics[temp.i]>temp.threshold_quantile){
      temp.bool=0
      if(temp.i==1 & temp.residual_F_statistics[temp.i]>temp.residual_F_statistics[temp.i+1]){
        temp.bool=1
      }
      else if(temp.i==temp.M2){
        if(temp.residual_F_statistics[temp.i]>temp.residual_F_statistics[temp.i-1]){
          temp.bool=1
        }
      }
      else if(temp.i>1 & temp.i<temp.M2){
        if((temp.residual_F_statistics[temp.i]>temp.residual_F_statistics[temp.i-1]) & (temp.residual_F_statistics[temp.i]>temp.residual_F_statistics[temp.i+1])){
          temp.bool=1
        }
      }
      if(temp.bool==TRUE){
        temp.peak_frequencies[counter]=frequencies.par[temp.i]
        temp.peak_heights[counter]=temp.residual_F_statistics[temp.i]
        temp.peak_indices[counter]=temp.i
        counter=counter+1
      }
    }
  }
  temp.n_significant=length(temp.peak_frequencies)
  if(temp.n_significant>50){
    temp.order_indices<-rev(order(temp.peak_heights))
    temp.peak_frequencies<-temp.peak_frequencies[temp.order_indices]
    temp.peak_heights<-temp.peak_heights[temp.order_indices]
    temp.peak_indices<-temp.peak_indices[temp.order_indices]
    temp.n_significant=50
    temp.peak_frequencies<-temp.peak_frequencies[1:temp.n_significant]
    temp.peak_heights<-temp.peak_heights[1:temp.n_significant]
    temp.peak_indices<-temp.peak_indices[1:temp.n_significant]
  }
  temp.list=list(out.frequencies=temp.peak_frequencies,
                 out.peak_heights=temp.peak_heights,
                 out.peak_indices=temp.peak_indices,
                 out.n_significant=temp.n_significant,
                 out.harmonic_amplitudes=temp.harmonic_amplitudes,
                 out.signal_powers=temp.signal_powers,
                 out.residual_powers=temp.residual_powers,
                 out.F_statistics=temp.F_statistics,
                 out.residual_F_statistics=temp.residual_F_statistics)
  return(temp.list)
}


extract.F_peaks<-function(peak_indices.par,SNR_values.par,frequencies.par,N.par,NW.par,M.par){
  temp.n_significant=length(peak_indices.par)
  temp.zero_index=M.par/2
  temp.max_index=temp.zero_index+1
  temp.half_bandwidth=floor(NW.par/N.par*M.par)
  temp.current_frequency_index=0
  temp.frequency_counter=1
  temp.effective_bandwidth=w.factor*temp.half_bandwidth
  temp.independent_sample_spacing=temp.effective_bandwidth
  temp.frequency_index_list<-list()
  if(temp.n_significant){
    for(temp.i in 1:temp.n_significant){
      temp.frequency_index=peak_indices.par[temp.i]
      temp.max_frequency_index=temp.frequency_index+temp.effective_bandwidth
      temp.diff=abs(temp.frequency_index-temp.current_frequency_index)
      if(temp.diff>temp.independent_sample_spacing & temp.max_frequency_index<temp.max_index){
        temp.min_frequency_index=temp.frequency_index-temp.effective_bandwidth
        temp.local_indices<-temp.min_frequency_index:temp.max_frequency_index
        temp.local_indices[temp.local_indices==0]<-1
        #The peak indexes are retained only if the peak contains a local maximum and if its (4W*w.factor) bandwidth is does not include a
        #non-positive frequency or one exceeding the Nyquist frequency.
        #Check that the magnitude of the harmonic mean at the centre of the (4W*w.factor)-wide peak is a local maximum.
        temp.SNR_band<-SNR_values.par[temp.local_indices]
        temp.max_SNR=max(temp.SNR_band)
        temp.optimal_index=min(which(temp.SNR_band==temp.max_SNR))
        temp.current_frequency_index=temp.min_frequency_index+temp.optimal_index-1
        temp.optimal_min=temp.current_frequency_index-temp.effective_bandwidth
        temp.optimal_max=temp.current_frequency_index+temp.effective_bandwidth
        if(temp.optimal_min>1 && temp.optimal_max<temp.max_index){
          temp.frequency_index_list[[temp.frequency_counter]]<-temp.optimal_min:temp.optimal_max
          temp.frequency_counter=temp.frequency_counter+1
        }#endif
      }#endif
    }
  }
  temp.num_significant=length(unlist(temp.frequency_index_list))
  temp.list=list(out.frequency_index_list=temp.frequency_index_list,
                 out.num_significant=temp.num_significant,
                 out.independent_sample_spacing=temp.independent_sample_spacing)
  return(temp.list)
}


harmonic_peaks.function<-function(eigencoeffs.par,Slepian_functions.par,frequencies.par,N.par,NW.par,sampling_rate.par=1,measured_quantity.par="",
                                  F_test_threshold.par=threshold.percentile,num_diffs.par=0,verbose.par=TRUE){
  temp.M=nrow(eigencoeffs.par)
  temp.K=ncol(eigencoeffs.par)
  #Harmonic Fisher tests for harmonic signal elements.
  if(verbose.par==TRUE){
    tic()
    cat("Multitaper harmonic F-tests: ")
  }
  temp.F_test_object<-significant.F_peaks(eigencoeffs.par,Slepian_functions.par,frequencies.par,F_test_threshold.par,num_diffs.par=num_diffs.par)
  temp.num_significant=temp.F_test_object$out.n_significant
  temp.significant_frequencies<-temp.F_test_object$out.frequencies
  temp.significant_SNRs<-temp.F_test_object$out.peak_heights
  temp.significant_indices<-temp.F_test_object$out.peak_indices
  temp.harmonic_amplitudes<-temp.F_test_object$out.harmonic_amplitudes
  temp.signal_powers=temp.F_test_object$out.signal_powers
  temp.residual_powers=temp.F_test_object$out.residual_powers
  temp.F_statistic_spectrum<-temp.F_test_object$out.F_statistics
  temp.residual_F_statistics<-temp.F_test_object$out.residual_F_statistics
  #Extract the frequencies not lying less than 2W apart, and which correspond to the optimal point of a spectral peak.
  temp.extracted_frequencies_object<-extract.F_peaks(temp.significant_indices,temp.F_statistic_spectrum,temp.significant_frequencies,
                                                     N.par,NW.par,temp.M)
  temp.num_extracted_significant_frequencies=temp.extracted_frequencies_object$out.num_significant
  temp.frequency_index_list<-temp.extracted_frequencies_object$out.frequency_index_list
  temp.independent_sample_spacing=temp.extracted_frequencies_object$out.independent_sample_spacing
  temp.frequency_indices<-unlist(temp.frequency_index_list)
  temp.extracted_significant_frequencies<-frequencies.par[temp.frequency_indices]
  temp.extracted_significant_SNR<-temp.residual_F_statistics[temp.frequency_indices]
  if(verbose.par==TRUE){
    toc()
  }
  temp.list<-list(out.frequency_indices=temp.frequency_indices,
                  out.extracted_significant_frequencies=temp.extracted_significant_frequencies,
                  out.extracted_significant_SNR=temp.extracted_significant_SNR,
                  out.num_extracted_significant_frequencies=temp.num_extracted_significant_frequencies,
                  out.significant_frequencies=temp.significant_frequencies,
                  out.num_significant=temp.num_significant,
                  out.significant_indices=temp.significant_indices,
                  out.harmonic_amplitudes=temp.harmonic_amplitudes,
                  out.signal_powers=temp.signal_powers,
                  out.residual_powers=temp.residual_powers,
                  out.significant_SNRs=temp.significant_SNRs,
                  out.F_statistics=temp.F_statistic_spectrum,
                  out.residual_F_statistics=temp.residual_F_statistics,
                  out.independent_sample_spacing=temp.independent_sample_spacing)
  return(temp.list)
}


var_efficiency_K<-function(v_n.par){
  temp_K=ncol(v_n.par)
  temp_N=nrow(v_n.par)
  for(k in 1:temp_K){
    v_n.par[,k]<-v_n.par[,k]^2
  }
  vk_sums<-rowSums(v_n.par)
  vn_sums<-sum(vk_sums^2)
  return(temp_K^2/temp_N/vn_sums)
}

f_var.CR<-function(dpss.par,period.par,SNR.par,sampling_period.par){
  temp.K=ncol(dpss.par)
  temp.N=nrow(dpss.par)
  temp.T=temp.N*sampling_period.par
  temp.squared_dpss<-dpss.par^2
  temp.sums<-crossprod(rowSums(temp.squared_dpss))
  temp.variance_efficiency=temp.K^2/temp.N/temp.sums
  temp.CR_variance=6*period.par^2/temp.variance_efficiency/(2*pi*temp.T)^2/SNR.par
  temp.list<-list(out.variance_efficiency=temp.variance_efficiency,
                  out.CR_variance=temp.CR_variance)
  return(temp.list)
}


residual_eigencoefficient_reconstruction.function<-function(eigencoefficients.par,significant_frequency_indices.par,slepian_functions.par,N.par,
                                                            energy_concentrations.par,NW.par=5,verbose.par=FALSE){
  temp.M=nrow(eigencoefficients.par)
  temp.zero_index=temp.M/2
  temp.M2=temp.zero_index+1
  temp.all_significant_frequency_indices<-c(rev(temp.zero_index-significant_frequency_indices.par+1),temp.zero_index+significant_frequency_indices.par-1)
  temp.all_significant_frequency_indices<-unique(temp.all_significant_frequency_indices)
  temp.num_all_significant_frequencies=length(temp.all_significant_frequency_indices)
  temp.harmonic_amplitudes=0
  temp.residual_eigencoefficients<-eigencoefficients.par
  if(temp.num_all_significant_frequencies<temp.zero_index){
    if(verbose.par==TRUE){
      cat("temp.num_all_significant_frequencies = ",temp.num_all_significant_frequencies,"\n")
    }
    if(temp.num_all_significant_frequencies>0){
      temp.band_width=floor(2*NW.par/N.par*temp.M)
      temp.harmonic_amplitudes<-sapply(temp.all_significant_frequency_indices,harmonic_amplitude.function,eigencoefficients.par,
                                       slepian_functions.par)
      for(temp.i in 1:temp.num_all_significant_frequencies){
        temp.index=temp.all_significant_frequency_indices[temp.i]
        temp.min_index=max(1,temp.index-temp.band_width)
        temp.max_index=min(temp.M,temp.index+temp.band_width)
        temp.indices<-temp.min_index:temp.max_index
        for(temp.j in temp.indices){
          temp.zero_frequency_Slepian_functions<-(slepian_functions.par[temp.zero_index-(max(temp.indices)-min(temp.indices))/2+temp.j-min(temp.indices),])
          temp.residuals<-eigencoefficients.par[temp.j,]-temp.harmonic_amplitudes[temp.i]*temp.zero_frequency_Slepian_functions
          #Raw power.
          temp.normalized_eigencoefficients<-eigencoefficients.par[temp.j,]/sqrt(energy_concentrations.par)
          temp.power<-crossprod(Mod(temp.normalized_eigencoefficients))
          #Residual power.
          temp.normalized_eigencoefficients<-temp.residuals/sqrt(energy_concentrations.par)
          temp.residual_power<-crossprod(Mod(temp.normalized_eigencoefficients))
          if(temp.power>temp.residual_power){
            temp.residual_eigencoefficients[temp.j,]<-temp.residuals
          }
        }
      }
    }
  }
  return(temp.residual_eigencoefficients)
}





harmonic.reconstruction<-function(index.par,frequencies.par,amplitudes.par){
  temp.amplitudes<-Mod(amplitudes.par)
  temp.phases<-atan2(Im(amplitudes.par),Re(amplitudes.par))
  temp.cosines<-temp.amplitudes*cos(2*pi*frequencies.par*index.par+temp.phases)
  temp.sum<-2*sum(temp.cosines)
  return(temp.sum)
}


demodulate_reconstruction.function<-function(harmonic_analysis_object.par,frequencies.par,log_frequencies.par,
                                             extracted_frequency_indices.par,N.par,NW.par=5,spectral_powers.par=NA,
                                             sampling_rate.par=1,F_test_threshold.par=0.99,
                                             threshold_crossings_LB.par=3,units.par1="units",units.par2="units",
                                             specific_directory_string.par="",
                                             old_directory.par="",ts_interp_bool.par=FALSE,
                                             verbose.par=FALSE,first_time.par=0){
  temp.sampling_period=1/sampling_rate.par
  temp.eigencoeffs<-harmonic_analysis_object.par$out.eigencoeffs
  temp.energy_concentrations<-harmonic_analysis_object.par$out.energy_concentrations
  temp.slepian_functions<-harmonic_analysis_object.par$out.slepian_functions
  temp.M=harmonic_analysis_object.par$out.M
  temp.zero_index=temp.M/2
  temp.M2=harmonic_analysis_object.par$out.M2
  temp.frequency_indices<-1:temp.M2
  temp.residual_spectral_powers<-c()
  if(verbose.par==TRUE){
    cat("Log spectrum\n")
  }
  #try({
    temp.log_spectrum_object<-log_spectrum_analysis.function(mt_sa_ha_object.par=harmonic_analysis_object.par,sampling_period.par=temp.sampling_period,
                                                             log_frequencies.par=log_frequencies.par,frequencies.par=frequencies.par,
                                                             voltage_extracted_frequency_indices.par=extracted_frequency_indices.par,
                                                             F_test_threshold.par=F_test_threshold.par,NW.par=NW.par,sampling_rate.par=sampling_rate.par,
                                                             outlier_percentile.par=outlier_percentile.par,
                                                             units.par1=units.par1,units.par2=units.par2,
                                                             threshold_crossings_LB.par=threshold_crossings_LB.par,
                                                             new_directory.par=paste(specific_directory_string.par,"/Log_Spectrum_Analysis/",sep=""),
                                                             old_directory.par=old_directory.par,mdss_bool.par=TRUE,
                                                             remove_outliers_bool.par=TRUE,spectral_power_bool.par=TRUE,residual_eigencoeffs_bool.par=TRUE,
                                                             whitened_log_spectrum_bool.par=FALSE,cleaned_log_spectrum_bool.par=TRUE,
                                                             spectral_powers.par=spectral_powers.par,first_time.par=first_time.par)
    temp.frequency_indices<-temp.log_spectrum_object$out.all_indices
    temp.frequencies<-frequencies.par[temp.frequency_indices]
    temp.residual_spectral_powers<-10^temp.log_spectrum_object$out.log_spectrum
    temp.tf<-rep(0,temp.M2)
    for(temp.m in 1:temp.M2){
      temp.frequency=frequencies.par[temp.m]
      temp.tf[temp.m]=1/Ap_f(temp.frequency,1)
    }
    temp.whitened_spectral_powers<-temp.residual_spectral_powers/Mod(temp.tf)^2
  #},silent=T)
    temp.num_open_sinks=seq_len(sink.number())
    if(length(temp.num_open_sinks)>0){
      if(temp.num_open_sinks>1){
        for(temp.i in (temp.num_open_sinks-1)){
          sink()
        }
      }
    }
  setwd(old_directory.par)
  temp.num_indices=length(temp.frequency_indices)
  temp.prediction_variance=(2*sum(temp.whitened_spectral_powers[2:temp.M2])+temp.whitened_spectral_powers[1])/temp.M
  #Demodulate reconstruction to interpolate the spectral components at line frequencies.
  temp.num_indices=length(temp.frequency_indices)
  temp.increments_sequence<-spectral_process_reconstruction.function(eigencoefficients.par=temp.eigencoeffs,
                                                                     slepian_functions.par=temp.slepian_functions,
                                                                     eigenvalues.par=temp.energy_concentrations)
  temp.increments_sequence<-temp.increments_sequence[temp.zero_index+temp.frequency_indices-1]
  temp.spectral_component_matrix<-matrix(0,nrow=N.par,ncol=temp.num_indices)
  for(temp.i in 1:temp.num_indices){
    temp.increment=temp.increments_sequence[temp.i]
    temp.frequency=temp.frequencies[temp.i]
    temp.residual_increment=sqrt(temp.prediction_variance)/Ap_f(temp.frequency,1)/temp.M
    temp.peak_increment=temp.increment-temp.residual_increment
    temp.amplitude=Mod(temp.peak_increment)
    if(Mod(temp.residual_increment)<Mod(temp.increment)){
      temp.phase=atan2(Im(temp.peak_increment),Re(temp.peak_increment))
      temp.spectral_component_matrix[,temp.i]<-temp.amplitude*cos(2*pi*temp.frequency*(1:N.par-1)+temp.phase)
    }
  }
  temp.list<-list(out.frequency_indices=temp.frequency_indices,
                  out.residual_spectral_powers=temp.residual_spectral_powers,
                  out.spectral_component_matrix=temp.spectral_component_matrix)
  return(temp.list)
}


cosine_reconstruction.function<-function(ts.par,NW.par=5,sampling_rate.par=1,F_test_threshold.par=0.99,N_F_statistics.par=3,frequency_band.par=NA,
                                         residual_bool.par=FALSE,all_frequencies_bool.par=FALSE,demodulate_bool.par=FALSE,units.par1="units",
                                         units.par2="units",specific_directory_string.par="",old_directory.par="",
                                         ts_interp_bool.par=FALSE,verbose.par=FALSE,first_time.par=0,ha_bool.par=FALSE,
                                         reconstruction_bool.par=FALSE){
  temp.N=length(ts.par)
  temp.mt_sa_ha_object<-mt_sa_ha.function(ts.par=ts.par,NW.par=NW.par,sampling_rate.par=sampling_rate.par,
                                          F_test_threshold.par=F_test_threshold.par,spectral_power_bool.par=TRUE,
                                          threshold_crossings_LB.par=N_F_statistics.par,ha_bool.par=TRUE)
  temp.M=temp.mt_sa_ha_object$out.M
  temp.M2=temp.mt_sa_ha_object$out.M2
  temp.zero_index=temp.M2-1
  temp.frequencies<-temp.mt_sa_ha_object$out.frequencies
  temp.log_frequencies<-temp.mt_sa_ha_object$out.log_frequencies
  temp.slepian_functions<-temp.mt_sa_ha_object$out.slepian_functions
  temp.energy_concentrations<-temp.mt_sa_ha_object$out.energy_concentrations
  temp.eigencoeffs<-temp.mt_sa_ha_object$out.eigencoeffs
  temp.residual_eigencoefficients<-temp.eigencoeffs
  temp.significant_frequencies<-temp.mt_sa_ha_object$out.significant_frequencies
  if(!is.na(frequency_band.par)){
    temp.plotting_significant_frequencies<-temp.significant_frequencies*sampling_rate.par
    temp.stopband_indices<-
      c(which(temp.plotting_significant_frequencies<=frequency_band.par[1]),which(temp.plotting_significant_frequencies>=frequency_band.par[2]))
    temp.significant_frequencies<-temp.significant_frequencies[temp.stopband_indices]
    temp.significant_frequencies<-unique(temp.significant_frequencies)
  }
  temp.significant_frequency_indices<-round(temp.significant_frequencies*temp.M)
  temp.num_significant=length(temp.significant_frequencies)
  temp.power_spectrum<-temp.mt_sa_ha_object$out.spectral_power_estimates
  temp.harmonic_amplitudes<-c()
  if(temp.num_significant>0){
    temp.significant_frequency_indices<-temp.significant_frequency_indices[temp.significant_frequency_indices>0 & temp.significant_frequency_indices<=temp.M2]
    if(length(temp.significant_frequency_indices)>0){
      temp.num_significant=length(temp.significant_frequency_indices)
      temp.significant_frequencies<-temp.frequencies[temp.significant_frequency_indices]
    }
    else{
      temp.num_significant=1
      temp.significant_frequencies<-c(0)
      temp.significant_frequency_indices<-c(1)
    }
  }
  else{
    temp.num_significant=1
    temp.significant_frequencies<-c(0)
    temp.significant_frequency_indices<-c(1)
  }
  temp.harmonic_amplitudes<-sapply(temp.zero_index+temp.significant_frequency_indices-1,harmonic_amplitude.function,temp.eigencoeffs,
                                   temp.slepian_functions)
  if(all_frequencies_bool.par==TRUE & temp.num_significant>0){
    temp.residual_eigencoefficients<-residual_eigencoefficient_reconstruction.function(eigencoefficients.par=temp.eigencoeffs,
                                                                                       significant_frequency_indices.par=temp.significant_frequency_indices,
                                                                                       slepian_functions.par=temp.slepian_functions,
                                                                                       N.par=temp.N,energy_concentrations.par=temp.energy_concentrations,
                                                                                       NW.par=NW.par)
    temp.all_complex_coefficients<-temp.eigencoeffs-temp.residual_eigencoefficients
    temp.running_complex_coefficients<-temp.all_complex_coefficients[temp.zero_index+1:temp.M2-1,]
    temp.significant_frequency_indices<-which(rowSums(temp.running_complex_coefficients)!=0)
    temp.running_num_significant=length(temp.significant_frequency_indices)
    temp.residual_spectrum<-multitaper.regularized_spectrum(temp.residual_eigencoefficients,temp.frequencies,temp.energy_concentrations)
    temp.indices_list<-list()
    if(length(temp.significant_frequency_indices)>0){
      temp.counter=1
      for(temp.i in 1:temp.running_num_significant){
        temp.index=temp.significant_frequency_indices[temp.i]
        if(temp.residual_spectrum[temp.index]<temp.power_spectrum[temp.index]){
          temp.indices_list[[temp.counter]]=temp.index
          temp.counter=temp.counter+1
        }
      }
    }
    temp.running_significant_frequency_indices<-unlist(temp.indices_list)
    if(!is.null(temp.running_significant_frequency_indices)){
      if(length(temp.running_significant_frequency_indices)>0){
        temp.harmonic_amplitudes<-sapply(temp.zero_index+temp.significant_frequency_indices-1,harmonic_amplitude.function,temp.all_complex_coefficients,
                                         temp.slepian_functions)
        temp.significant_frequency_indices<-temp.running_significant_frequency_indices
      }
    }
  }
  temp.num_significant=length(temp.significant_frequency_indices)
  if(!temp.num_significant){
    temp.num_significant=1
    temp.significant_frequencies<-c(0)
    temp.significant_frequency_indices<-c(1)
  }
  temp.harmonic_reconstructions<-rep(0,temp.N)
  temp.cosine_reconstruction<-temp.harmonic_reconstructions
  temp.spectral_component_matrix<-temp.harmonic_reconstructions
  if(temp.num_significant>0){
    temp.harmonic_amplitudes<-temp.harmonic_amplitudes[temp.significant_frequency_indices>0 & temp.significant_frequency_indices<=temp.M2]
    temp.significant_frequency_indices<-temp.significant_frequency_indices[temp.significant_frequency_indices>0 & temp.significant_frequency_indices<=temp.M2]
    temp.significant_frequencies<-temp.frequencies[temp.significant_frequency_indices]
    temp.num_significant=length(temp.significant_frequency_indices)
    temp.harmonic_reconstructions<-matrix(0,nrow=temp.N,ncol=temp.num_significant)
    for(temp.m in 1:temp.num_significant){
      temp.harmonic_reconstructions[,temp.m]<-sapply(1:temp.N-1,harmonic.reconstruction,temp.significant_frequencies[temp.m],temp.harmonic_amplitudes[temp.m])
    }
    temp.cosine_reconstruction<-rowSums(temp.harmonic_reconstructions)
    temp.spectral_component_matrix<-matrix(0,nrow=temp.N,ncol=temp.num_significant)
    #Demodulates.
    if(demodulate_bool.par==TRUE){
      #try({
      temp.demodulate_reconstruction_object<-demodulate_reconstruction.function(temp.mt_sa_ha_object,frequencies.par=temp.frequencies,
                                                                                log_frequencies.par=temp.log_frequencies,
                                                                                extracted_frequency_indices.par=temp.significant_frequency_indices,
                                                                                N.par=temp.N,NW.par=NW.par,spectral_powers.par=temp.power_spectrum,
                                                                                sampling_rate.par=sampling_rate.par,F_test_threshold.par=F_test_threshold.par,
                                                                                threshold_crossings_LB.par=threshold_crossings_LB.par,units.par1=units.par1,
                                                                                units.par2=units.par2,specific_directory_string.par=specific_directory_string.par,
                                                                                old_directory.par=old_directory.par,
                                                                                ts_interp_bool.par=ts_interp_bool.par,verbose.par=verbose.par,
                                                                                first_time.par=first_time.par)
      temp.spectral_component_matrix<-temp.demodulate_reconstruction_object$out.spectral_component_matrix
      temp.cosine_reconstruction<-temp.cosine_reconstruction+rowSums(temp.spectral_component_matrix)
      #},silent=T)
    }
  }#endif
  if(is.null(temp.significant_frequency_indices)==TRUE){
    temp.significant_frequency_indices<-c(1)
  }
  temp.list<-list(out.cosine_reconstruction=temp.cosine_reconstruction,
                  out.significant_frequencies=temp.significant_frequencies,
                  out.significant_frequency_indices=temp.significant_frequency_indices,
                  out.harmonic_reconstructions=temp.harmonic_reconstructions,
                  out.spectral_component_matrix=temp.spectral_component_matrix,
                  out.residual_eigencoefficients=temp.residual_eigencoefficients,
                  out.harmonic_amplitudes=temp.harmonic_amplitudes)
  return(temp.list)
}




overlapped_harmonic_reconstruction.function<-function(ts.par,num_sections.par=2,NW.par=5,F_test_threshold.par=0.99,
                                                      sampling_rate.par=1,N_F_statistics.par=3,frequency_band.par=NA,residual_bool.par=FALSE,
                                                      ends_reconstruction_bool.par=FALSE,all_frequencies_bool.par=FALSE,
                                                      new_directory.par="",old_directory.par="",first_time.par=0,demodulate_bool.par=FALSE,
                                                      ha_bool.par=FALSE,reconstruction_bool.par=FALSE,
                                                      #Ends reconstruction booleans.
                                                      periodic_reconstruction_bool.par=FALSE,
                                                      ts_interp_bool.par=FALSE,mdss_bool.par=FALSE,gn_bool.par=FALSE,
                                                      num_iterations.par=1,max_length.par=200,
                                                      main_directory_string.par="",directory_label.par="",old_directory_interp.par="",
                                                      revised_specific_directory_string.par="",measured_quantity.par="",
                                                      main_directory.par=main_directory.string,
                                                      method_directory_string.par=method_directory_string.par){
  #Overlapping-sections periodic reconstruction using 50% overlap fraction (Percival and Walden, 1998, as well as Marshall et al. (2019)).
  temp.N=length(ts.par)
  cat("temp.N=",temp.N,"\n")
  temp.section_size=floor(temp.N/num_sections.par)
  temp.section_size=temp.section_size-temp.section_size%%4
  cat("temp.section_size=",temp.section_size,"\n")
  temp.indices_list<-list()
  if(temp.section_size<(2*(2*NW.par+1))){
    num_sections.par=1
    temp.section_size=floor(temp.N/num_sections.par)
    temp.section_size=temp.section_size-temp.section_size%%4
    temp.running_indices<-1:temp.section_size
    temp.indices_list[[1]]<-temp.running_indices
  }
  else{
    temp.counter=1
    temp.running_indices<-1:temp.section_size
    while(temp.running_indices[temp.section_size]<=(temp.N-temp.section_size/2)){
      if(temp.counter>1){
        temp.running_indices<-temp.running_indices+temp.section_size/2
      }
      temp.indices_list[[temp.counter]]<-temp.running_indices
      temp.counter=temp.counter+1
    }
  }
  temp.num_sections=length(temp.indices_list)
  temp.cosine_sections_reconstruction<-c()
  temp.all_indices<-c()
  temp.harmonic_reconstructions_list<-list()
  temp.harmonic_reconstruction_indices_list<-list()
  temp.significant_frequencies_list<-list()
  temp.harmonic_amplitudes_list<-list()
  for(temp.i in 1:temp.num_sections){
    temp.indices<-temp.indices_list[[temp.i]]
    temp.ts<-ts.par[temp.indices]
    temp.cosine_reconstruction_object<-cosine_reconstruction.function(temp.ts,NW.par=NW.par,sampling_rate.par=sampling_rate.par,
                                                                      F_test_threshold.par=F_test_threshold.par,
                                                                      N_F_statistics.par=N_F_statistics.par,frequency_band.par=frequency_band.par,
                                                                      residual_bool.par=residual_bool.par,
                                                                      all_frequencies_bool.par=all_frequencies_bool.par,demodulate_bool.par=demodulate_bool.par,
                                                                      specific_directory_string.par=new_directory.par,old_directory.par=old_directory.par,
                                                                      first_time.par=first_time.par,ha_bool.par=ha_bool.par,
                                                                      reconstruction_bool.par=reconstruction_bool.par)
    temp.reconstruction<-temp.cosine_reconstruction_object$out.cosine_reconstruction
    temp.significant_frequencies_list[[temp.i]]<-temp.cosine_reconstruction_object$out.significant_frequencies
    cat("temp.significant_frequencies_list[[",temp.i,"]]=",temp.significant_frequencies_list[[temp.i]],"\n")
    temp.harmonic_amplitudes_list[[temp.i]]<-temp.cosine_reconstruction_object$out.harmonic_amplitudes
    temp.indices2<-temp.section_size/4+1:(temp.section_size/2)
    if(ends_reconstruction_bool.par==TRUE){
      if(temp.i==1){
        temp.indices2<-1:(3*temp.section_size/4)
      }
      else if(temp.i==temp.num_sections){
        temp.indices2<-temp.section_size/4+1:(3*temp.section_size/4)
      }
    }
    temp.cosine_sections_reconstruction<-c(temp.cosine_sections_reconstruction,temp.reconstruction[temp.indices2])
    temp.all_indices<-c(temp.all_indices,temp.indices[temp.indices2])
    temp.harmonic_reconstructions<-temp.cosine_reconstruction_object$out.harmonic_reconstructions
    temp.spectral_component_matrix<-temp.cosine_reconstruction_object$out.spectral_component_matrix
    temp.first_terms<-c()
    if(!is.matrix(temp.harmonic_reconstructions)){
      temp.first_terms<-temp.harmonic_reconstructions[temp.indices2]
    }
    else{
      temp.first_terms<-temp.harmonic_reconstructions[temp.indices2,]
    }
    temp.second_terms<-c()
    if(!is.matrix(temp.spectral_component_matrix)){
      temp.second_terms<-temp.spectral_component_matrix[temp.indices2]
    }
    else{
      temp.second_terms<-temp.spectral_component_matrix[temp.indices2,]
    }
    temp.harmonic_reconstructions_list[[temp.i]]<-temp.first_terms+temp.second_terms
    temp.harmonic_reconstruction_indices_list[[temp.i]]<-temp.indices2
  }
  temp.num_cosine=length(temp.cosine_sections_reconstruction)
  if(temp.num_cosine<temp.N){
    temp.cosine_reconstruction_intermediate<-rep(0,temp.N)
    temp.min_all_indices=min(temp.all_indices)
    temp.max_all_indices=max(temp.all_indices)
    temp.num_gap=temp.N-length(temp.cosine_sections_reconstruction)
    temp.num_end=floor((temp.num_gap+temp.num_gap%%2)/2)
    temp.cosine_reconstruction_intermediate[temp.num_end+1:temp.num_cosine]<-temp.cosine_sections_reconstruction
    if(temp.min_all_indices>temp.num_end){
      temp.cosine_reconstruction_intermediate[1:temp.num_end]<-temp.cosine_sections_reconstruction[1:temp.num_end+temp.num_cosine-temp.num_end]
    }
    if(temp.max_all_indices<=(temp.N-temp.num_end)){
      temp.indices<-1:temp.num_end+temp.N-temp.num_end
      temp.cosine_reconstruction_intermediate[temp.indices]<-temp.cosine_sections_reconstruction[1:temp.num_end]
    }
    temp.all_indices<-1:temp.N
    temp.cosine_sections_reconstruction<-temp.cosine_reconstruction_intermediate
  }
  #Reconstruct the ends
  temp.num_significant_frequencies=length(unlist(temp.significant_frequencies_list))
  if(periodic_reconstruction_bool.par==TRUE & temp.num_significant_frequencies>0){
    temp.cosine_sections_reconstruction<-ends_interpolation.function(ts.par=temp.cosine_sections_reconstruction,first_time.par=first_time.par,
                                                                     ts_interp_bool.par=ts_interp_bool.par,mdss_bool.par=mdss_bool.par,gn_bool.par=gn_bool.par,
                                                                     num_iterations.par=num_iterations.par,max_length.par=max_length.par,
                                                                     main_directory_string.par=main_directory_string.par,
                                                                     directory_label.par=directory_label.par,old_directory.par=old_directory.par,
                                                                     new_directory.par=new_directory.par,
                                                                     revised_specific_directory_string.par=revised_specific_directory_string.par,
                                                                     measured_quantity.par=measured_quantity.par,
                                                                     main_directory.par=main_directory.par,
                                                                     method_directory_string.par=method_directory_string.par)
  }
  temp.list<-list(out.cosine_sections_reconstruction=temp.cosine_sections_reconstruction,
                  out.all_indices=temp.all_indices,
                  out.harmonic_reconstructions_list=temp.harmonic_reconstructions_list,
                  out.harmonic_reconstruction_indices_list=temp.harmonic_reconstruction_indices_list,
                  out.significant_frequencies_list=temp.significant_frequencies_list,
                  out.harmonic_amplitudes_list=temp.harmonic_amplitudes_list)
  return(temp.list)
}





