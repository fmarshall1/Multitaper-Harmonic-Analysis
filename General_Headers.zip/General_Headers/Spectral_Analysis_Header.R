#Francois Marshall, Boston University
#Header file for presenting output of results.
###################################################################################################################

#FFT functions.

frequencies.principle_domain<-function(M.par,sampling_period.par=1,N.par=1){
  #Returns the frequencies for a spectrum with M samples between the Nyquist bounds.
  indices<-1:M.par
  temp.frequencies<-indices-M.par/2 #Centre the frequencies.
  temp.frequencies<-temp.frequencies/M.par #Scale the frequencies to {-1/2+1/M,...,1/2}
  temp.frequencies1<-temp.frequencies/sampling_period.par #Scale the frequencies to lie between the Nyquist bounds
  #(e.g., set to units of cycles per year).
  temp.frequencies2<-temp.frequencies*N.par #Multiplying by N to convert to Rayleighs.
  frequencies.object<-data.frame(temp.frequencies1,temp.frequencies2)
  return(frequencies.object)
}

non_negative.principle_domain<-function(vector.par){
  #Return the values of the vector which are associated with non-negative frequencies.
  temp.M=length(vector.par)
  temp.M_2=temp.M/2
  return(vector.par[temp.M_2:temp.M])
}

return.to.fft_ordering<-function(vector.par){
  #Return the vector to the order of the FFT output.
  temp.M=length(vector.par)
  temp.M_2=temp.M/2
  temp.vector<-rep(0,temp.M)
  temp.vector[1:(temp.M_2+1)]<-vector.par[temp.M_2:temp.M]
  temp.vector[(temp.M_2+2):temp.M]<-vector.par[1:(temp.M_2-1)]
  return(temp.vector)
}

pad.matrix<-function(matrix.par,M.par){
  temp.N=nrow(matrix.par)
  temp.K=ncol(matrix.par)
  temp.matrix<-matrix.par
  num.padded=M.par-temp.N
  temp.matrix<-rbind(temp.matrix,matrix(0,num.padded,temp.K))
  return(temp.matrix)
}

fft.rearrange_matrix<-function(matrix.par){
  #Rearrange the FFT output to have the same ordering as in Blackman and Tukey: {-1/2+1/M,...,1/2}.
  temp.M=nrow(matrix.par)
  temp.K=ncol(matrix.par)
  temp.M_2=temp.M/2
  temp.matrix<-matrix(0,nrow=temp.M,ncol=temp.K)
  temp.matrix[1:(temp.M_2-1),]<-matrix.par[(temp.M_2+2):temp.M,]
  temp.matrix[temp.M_2:temp.M,]<-matrix.par[1:(temp.M_2+1),]
  return(temp.matrix)
}

## Slow Discrete Fourier Transform (DFT) - e.g., for checking the formula
discrete.Fourier_transform<-function(index.par,ts.par,frequency.par,inverse=FALSE){
  temp.N<-length(ts.par)
  temp.times<-1:temp.N-1
  argument<-(if(inverse) 1 else -1)*2*pi*1i*frequency.par[index.par]*temp.times
  return(sum(ts.par*exp(argument)))
}




###################################################################################################################
#General math functions.

Fourier_matrix.function<-function(rank.par){
  temp.Fourier_matrix<-matrix(0,nrow=rank.par,ncol=rank.par)
  temp.column_indices<-1:rank.par-1
  for(temp.j in 1:rank.par){
    temp.Fourier_matrix[temp.j,]<-exp(1i*2*pi*(temp.j-1)*temp.column_indices/rank.par)
  }
  return(temp.Fourier_matrix)
}

sinc.function<-function(index.par,x.par,arguments.par){
  temp.argument=arguments.par[index.par]
  temp.sinc_value=1
  if(temp.argument!=0){
    temp.sinc_value=sin(pi*temp.argument)/pi/temp.argument
  }
  return(temp.sinc_value)
}

dpss_kernel.function<-function(NW.par,N.par,time_indices.par){
  temp.N_times=length(time_indices.par)
  temp.W=NW.par/N.par
  temp.indices<-1:temp.N_times
  temp.kernel_matrix<-matrix(0,nrow=temp.N_times,ncol=temp.N_times)
  for(temp.i in temp.indices){
    temp.index=time_indices.par[temp.i]
    temp.index_diffs<-temp.index-time_indices.par
    temp.sinc_arguments<-2*temp.W*temp.index_diffs
    temp.sinc_values<-sapply(temp.indices,sinc.function,arguments.par=temp.sinc_arguments)
    temp.kernel_matrix[temp.i,]<-temp.sinc_values
  }
  temp.kernel_matrix<-2*temp.W*temp.kernel_matrix
  return(temp.kernel_matrix)
}






###################################################################################################################
#Coherency functions.

coherency.matrix<-function(vector1.par,vector2.par,equal_vectors.par=FALSE){
  temp.rank=length(vector1.par)
  temp.coherency_matrix<-vector1.par%*%hermitian.conjugate(vector2.par)
  if(equal_vectors.par){
    for(i in 1:temp.rank){
      temp.coherency_matrix[i,i]<-Re(temp.coherency_matrix[i,i])
    }
  }
  return(temp.coherency_matrix)
}


BM_random_numbers.function<-function(num_sim.par=100,variance.par=1,start_abscissa.par=0,end_abscissa.par=1,seed.par=c(0,0),
                                     normal_numbers.par=NA){
  #cat("Brownian-motion simulation:\n")
  temp.num_sim=num_sim.par-1
  temp.BM_sd=sqrt(variance.par)
  #cat("\tSimulating ",temp.num_sim," Gaussian numbers.\n")
  temp.standardized_normal_numbers<-c()
  if(is.na(normal_numbers.par)==TRUE){
    temp.standardized_normal_numbers<-gaussian.RNG(temp.num_sim,seed.par)$out.random_numbers
    set.seed(10)
  }
  else{
    set.seed(seed.par[1])
    temp.standardized_normal_numbers<-normal_numbers.par
  }
  temp.standardized_normal_numbers<-sample(temp.standardized_normal_numbers)
  temp.sampling_period=(end_abscissa.par-start_abscissa.par)/(temp.num_sim+1)
  temp.standardized_normal_numbers<-temp.BM_sd*temp.standardized_normal_numbers
  temp.standard_deviation_sequence<-sqrt(start_abscissa.par+1:temp.num_sim*temp.sampling_period)
  temp.normal_numbers<-temp.standard_deviation_sequence*temp.standardized_normal_numbers
  #cat("\tGenerating the cumulative sums.\n")
  temp.BM_numbers<-rep(0,temp.num_sim+1)
  temp.BM_numbers[1]=0
  for(temp.i in 1:temp.num_sim){
    temp.BM_numbers[temp.i+1]=temp.BM_numbers[temp.i]+temp.normal_numbers[temp.i]
  }
  temp.list<-list(out.normal_numbers=temp.standardized_normal_numbers,
                  out.BM=temp.BM_numbers)
  return(temp.list)
}

standard_normal_spectral_representation.function<-function(N.par,M.par=0,seed.par=c(0,0)){
  #Generate a sample of Gaussian random numbers from the population.
  temp.standardized_normal_numbers<-gaussian.RNG(N.par,seed.par)
  set.seed(20)
  temp.standardized_normal_numbers<-sample(temp.standardized_normal_numbers)
  #Compute the finite sums.
  temp.M=M.par
  if(!M.par){
    temp.zero_padding_object<-zero_padding_number.function(N.par)
    temp.M=temp.zero_padding_object$out.M
  }
  #Generate the Brownian-motion numbers.
  temp.variance_parameter=0.25
  temp.BM_object<-BM_random_numbers.function(temp.M+1,temp.variance_parameter,seed.par=seed.par+2)
  temp.BM_numbers<-temp.BM_object$out.BM
  #Extract the finite differences of the increment process.
  temp.differences<-temp.BM_object$out.normal_numbers
  #Compute the principal aliases.
  temp.frequencies<-(1:temp.M-1)/temp.M-0.5
  cat("Computing the finite sums.\n")
  temp.finite_sums<-rep(0,N.par)
  for(temp.i in 1:N.par){
    temp.n=temp.i-1
    temp.exponentials<-exp(1i*2*pi*temp.n*temp.frequencies)
    temp.function_sequence<-(1+1i)*Conj(temp.exponentials)+(1-1i)*temp.exponentials
    temp.summands<-temp.function_sequence*temp.differences
    temp.sum=sum(temp.summands)
    temp.finite_sums[temp.i]=Re(temp.sum)
  }
  #Standardize to ensure that the corresponding variance estimator is unbiased.
  temp.finite_sums<-temp.finite_sums/sqrt(temp.M)
  temp.list<-list(out.SWN=temp.standardized_normal_numbers,
                  out.BM=temp.BM_numbers,
                  out.differences=temp.differences,
                  out.frequencies=temp.frequencies,
                  out.finite_sums=temp.finite_sums)
  return(temp.list)
}


white_noise_spectral_jump_process.function<-function(BM_numbers.par){
  temp.M=length(BM_numbers.par)
  temp.zero_index=temp.M/2
  temp.WN_IS_process_realization<-rep(0,temp.M)
  for(temp.m in 1:temp.M){
    if(temp.m<temp.M){
      temp.negative_frequency_index=0
      temp.positive_frequency_index=0
      if(temp.m<temp.zero_index){
        temp.negative_frequency_index=temp.m
        temp.positive_frequency_index=temp.zero_index+temp.m
      }
      else if(temp.m>temp.zero_index & temp.m<temp.M){
        temp.negative_frequency_index=temp.zero_index-(temp.m-temp.zero_index)
        temp.positive_frequency_index=temp.m
      }
      else if(temp.m==temp.zero_index){
        temp.negative_frequency_index=temp.m
        temp.positive_frequency_index=temp.m
      }
      temp.negative_frequency_BM_element=BM_numbers.par[temp.negative_frequency_index]
      temp.positive_frequency_BM_element=BM_numbers.par[temp.positive_frequency_index]
      temp.real_part=temp.negative_frequency_BM_element+temp.positive_frequency_BM_element
      temp.imaginary_part=temp.negative_frequency_BM_element-temp.positive_frequency_BM_element
      temp.WN_IS_process_realization[temp.m]=temp.real_part+1i*temp.imaginary_part
    }
    else{
      temp.WN_IS_process_realization[temp.m]=0
    }
  }
  return(temp.WN_IS_process_realization)
}


AR_TS_sequence<-function(wn.par,alphas.par,variance.par=1,num_extra.par=0,seed.par=0){
  #Add more white-noise variables to avoid transient behaviour at the start of the approximation process.
  temp.standard_deviation=sqrt(variance.par)
  temp.p=length(alphas.par)
  temp.N=length(wn.par)
  temp.num_extra=2*temp.p
  if(num_extra.par>0 & num_extra.par<=temp.num_extra){
    temp.num_extra=num_extra.par
  }
  temp.seed=70
  if(seed.par!=0){
    temp.seed=seed.par
  }
  set.seed(temp.seed)
  temp.extra_wn_numbers<-temp.standard_deviation*rnorm(temp.num_extra)
  set.seed(temp.seed+1)
  temp.extra_wn_numbers<-sample(temp.extra_wn_numbers)
  temp.wn<-c(temp.extra_wn_numbers,wn.par)
  temp.num_times=temp.num_extra+temp.N
  temp.ar_series<-rep(0,temp.num_times)
  temp.ar_series[1:temp.p]=temp.wn[1:temp.p]
  for(temp.n in (temp.p+1):temp.num_times){
    temp.predictor_values<-rev(temp.ar_series[temp.n-1:temp.p])
    temp.ar_series[temp.n]=crossprod(alphas.par,temp.predictor_values)+temp.wn[temp.n]
  }
  temp.ar_series<-temp.ar_series[temp.num_extra+1:temp.N]
  return(temp.ar_series)
}

AR_TF.function<-function(index.par,frequencies.par,alphas.par){
  temp.frequency=frequencies.par[index.par]
  temp.num_coefficients=length(alphas.par)
  temp.tf_value=1-sum(alphas.par*exp(-1i*2*pi*temp.frequency*1:temp.num_coefficients))
  return(temp.tf_value)
}

AR_TF_sequence<-function(frequencies.par,alphas.par){
  temp.num_frequencies=length(frequencies.par)
  temp.index_sequence<-1:temp.num_frequencies
  temp.tf_sequence<-1/sapply(temp.index_sequence,AR_TF.function,frequencies.par,alphas.par)
  return(temp.tf_sequence)
}


AR_spectral_representation.function<-function(N.par,alphas.par,variance.par=1,M.par=0,seed.par=c(1,2),
                                              uniform_numbers.par=NA,crude_rv_num_samples.par=NA){
  #Generate a sample of Gaussian random numbers from the population.
  temp.standardized_normal_numbers<-basic_rng.function(num_innovations.par=N.par,N.par=N.par,mean.par=0,variance.par=variance.par,
                                                       crude_rv_num_samples.par=crude_rv_num_samples.par,
                                                       seeds.par=seed.par,
                                                       uniform_numbers.par=NA)
  seed.par<-seed.par+1
  set.seed(seed.par[1])
  temp.standardized_normal_numbers<-sample(temp.standardized_normal_numbers)
  temp.ar_numbers<-AR_TS_sequence(temp.standardized_normal_numbers,alphas.par,variance.par=variance.par)
  #Compute the finite sums.
  temp.M=M.par
  temp.normalized_sd=sqrt(variance.par/temp.M)
  temp.zero_index=0
  temp.M2=0
  if(!temp.M){
    temp.multitaper_parameters_object<-multitaper_parameters.function(N.par=N.par)
    temp.M=temp.multitaper_parameters_object$out.M
    temp.zero_index=temp.multitaper_parameters_object$out.zero_index
    temp.M2=temp.multitaper_parameters_object$out.M2
  }
  else{
    temp.zero_index=temp.M/2
    temp.M2=temp.zero_index+1
  }
  cat("temp.M=",temp.M,"\n")
  #Generate the Brownian-motion numbers.
  temp.variance_parameter=0.25
  seed.par<-seed.par+2
  temp.BM_object<-BM_random_numbers.function(temp.M+1,temp.variance_parameter,seed.par=seed.par)
  temp.BM_numbers<-temp.BM_object$out.BM
  temp.BM_numbers<-temp.BM_numbers[1:temp.M]*temp.normalized_sd
  #Compute the principal aliases.
  temp.frequencies<-(1:temp.M)/temp.M-0.5
  temp.truncated_frequencies<-(1:temp.M2-1)/temp.M
  temp.ar_tf_sequence<-AR_TF_sequence(temp.frequencies,alphas.par)
  temp.wn_IS_process_realization<-white_noise_spectral_jump_process.function(temp.BM_numbers)
  temp.wn_jump_numbers<-c(0,temp.wn_IS_process_realization[2:temp.M]-temp.wn_IS_process_realization[2:temp.M-1])
  temp.wn_jump_numbers_truncated<-temp.wn_jump_numbers[temp.zero_index+1:temp.zero_index-1]
  temp.ar_IS_numbers<-temp.ar_tf_sequence*temp.wn_IS_process_realization
  temp.ar_jump_numbers<-c(0,temp.ar_IS_numbers[2:temp.M]-temp.ar_IS_numbers[2:temp.M-1])
  temp.ar_jump_numbers_truncated<-temp.ar_jump_numbers[temp.zero_index+1:temp.M2-1]
  temp.finite_sums_WN<-rep(0,N.par)
  temp.finite_sums_AR<-temp.finite_sums_WN
  for(temp.i in 1:N.par){
    temp.n=temp.i-1
    #White noise.
    temp.wn_amplitudes<-rep(0,temp.zero_index)
    temp.wn_phases<-temp.wn_amplitudes
    temp.ar_amplitudes<-temp.wn_amplitudes
    temp.ar_phases<-temp.wn_amplitudes
    temp.wn_amplitudes[1]=Mod(temp.wn_jump_numbers_truncated[1])
    temp.wn_amplitudes[2:temp.zero_index]<-2*Mod(temp.wn_jump_numbers_truncated[2:temp.zero_index])
    temp.wn_phases<-atan2(Im(temp.wn_jump_numbers_truncated),Re(temp.wn_jump_numbers_truncated))
    temp.cosines<-cos(2*pi*temp.n*temp.truncated_frequencies+temp.wn_phases)
    temp.summands<-temp.wn_amplitudes*temp.cosines
    temp.sum=sum(temp.summands)
    temp.finite_sums_WN[temp.i]=Re(temp.sum)
    #AR series.
    temp.ar_amplitudes[1]=Mod(temp.ar_jump_numbers_truncated[1])
    temp.ar_amplitudes[2:temp.zero_index]<-2*Mod(temp.ar_jump_numbers_truncated[2:temp.zero_index])
    temp.ar_phases<-atan2(Im(temp.ar_jump_numbers_truncated),Re(temp.ar_jump_numbers_truncated))
    temp.cosines<-cos(2*pi*temp.n*temp.truncated_frequencies+temp.ar_phases)
    temp.summands<-temp.ar_amplitudes*temp.cosines
    temp.sum=sum(temp.summands)
    temp.finite_sums_AR[temp.i]=Re(temp.sum)
  }
  temp.list<-list(out.SWN=temp.standardized_normal_numbers,
                  out.AR=temp.ar_numbers,
                  out.WN_series=temp.finite_sums_WN,
                  out.AR_series=temp.finite_sums_AR,
                  out.BM=temp.BM_numbers,
                  out.ar_IS_numbers=temp.ar_IS_numbers,
                  out.wn_differences=temp.wn_jump_numbers,
                  out.ar_differences=temp.ar_jump_numbers,
                  out.wn_IS_process_realization=temp.wn_IS_process_realization,
                  out.ar_jump_numbers_truncated=temp.ar_jump_numbers_truncated,
                  out.frequencies=temp.frequencies,
                  out.seeds=seed.par)
  return(temp.list)
}


AR1_normalized_IS_process_simulation.function<-function(plotting_times.par,ACS_deviates.par,N.par,M.par=0,
                                                        sampling_rate.par=1,
                                                        seed_values.par=c(1,2),crude_rv_num_samples.par=NA,
                                                        working_directory_string.par="",
                                                        plot_bool.par=FALSE,output_bool.par=FALSE){
  dir.create("AR1_Simulation",showWarnings=FALSE)
  setwd("AR1_Simulation")
  #Fit an AR(1) model to ACS_deviates.par.
  temp.num_realizations=ncol(ACS_deviates.par)
  temp.N=nrow(ACS_deviates.par)
  temp.ar1_coefficient_realizations<-rep(0,temp.num_realizations)
  temp.innovation_variance_realizations<-temp.ar1_coefficient_realizations
  temp.ar1_fit_signals_matrix<-matrix(0,nrow=temp.N,ncol=temp.num_realizations)
  temp.ar1_residual_signals_matrix<-temp.ar1_fit_signals_matrix
  temp.ar1_fit_mean_realization<-rep(0,temp.N)
  temp.ar1_fit_ss_realization<-temp.ar1_fit_mean_realization
  temp.ar1_fit_sum_realization<-temp.ar1_fit_mean_realization
  temp.ar1_residual_ss_realization<-temp.ar1_fit_mean_realization
  temp.ar1_residual_sum_realization<-temp.ar1_fit_mean_realization
  for(temp.j in 1:temp.num_realizations){
    temp.ACS_deviates<-ACS_deviates.par[,temp.j]
    temp.sarima_object<-arima(x=temp.ACS_deviates,order=c(1,0,0))
    temp.ar1_coefficient_realizations[temp.j]=temp.sarima_object$coef[1]
    temp.innovation_variance_realizations[temp.j]=temp.sarima_object$sigma2
    temp.ar1_residuals<-temp.sarima_object$residuals
    temp.fitted_values<-temp.ACS_deviates-temp.ar1_residuals
    temp.ar1_fit_signals_matrix[,temp.j]<-temp.fitted_values
    temp.ar1_fit_sum_realization<-temp.ar1_fit_sum_realization+temp.fitted_values
    temp.ar1_fit_ss_realization<-temp.ar1_fit_ss_realization+temp.fitted_values^2
    temp.ar1_residual_sum_realization<-temp.ar1_residual_sum_realization+temp.ar1_residuals
    temp.ar1_residual_ss_realization<-temp.ar1_residual_ss_realization+temp.ar1_residuals^2
  }
  #Extract the median signal.
  temp.median_index=floor(0.5*temp.num_realizations)
  temp.sorted_fits_matrix<-matrix(0,nrow=temp.N,ncol=temp.num_realizations)
  temp.sorted_residuals_matrix<-temp.sorted_fits_matrix
  for(temp.n in 1:temp.N){
    temp.sorted_fits_matrix[temp.n,]<-sort(temp.ar1_fit_signals_matrix[temp.n,])
    temp.sorted_residuals_matrix[temp.n,]<-sort(temp.ar1_residual_signals_matrix[temp.n,])
  }
  temp.ar1_fit_median_signal<-temp.sorted_fits_matrix[,temp.median_index]
  temp.ar1_residual_median_signal<-temp.sorted_residuals_matrix[,temp.median_index]
  #Extract the minimum and maximum signals.
  temp.ar1_fit_min_signal<-temp.sorted_fits_matrix[,1]
  temp.ar1_residual_min_signal<-temp.sorted_residuals_matrix[,1]
  temp.ar1_fit_max_signal<-temp.sorted_fits_matrix[,temp.num_realizations]
  temp.ar1_residual_max_signal<-temp.sorted_residuals_matrix[,temp.num_realizations]
  #
  temp.ar1_fit_mean_signal<-temp.ar1_fit_sum_realization/temp.num_realizations
  temp.ar1_residual_mean_signal<-temp.ar1_residual_sum_realization/temp.num_realizations
  temp.ar1_fit_variance_signal<-(temp.ar1_fit_ss_realization-temp.ar1_fit_sum_realization^2/temp.num_realizations)/(temp.num_realizations-1)
  temp.ar1_residual_variance_signal<-(temp.ar1_residual_ss_realization-temp.ar1_residual_sum_realization^2/temp.num_realizations)/(temp.num_realizations-1)
  temp.ar1_coefficient=median(temp.ar1_coefficient_realizations)
  temp.coefficient_abs_diffs<-abs(temp.ar1_coefficient_realizations-temp.ar1_coefficient)
  temp.min_abs_diff=min(temp.coefficient_abs_diffs)
  temp.optimal_coefficient_index=min(which(temp.coefficient_abs_diffs==temp.min_abs_diff))
  temp.optimal_ar1_fit<-temp.ar1_fit_signals_matrix[,temp.optimal_coefficient_index]
  temp.ar1_mean_coefficient=mean(temp.ar1_coefficient_realizations)
  temp.ar_innovation_variance=mean(temp.innovation_variance_realizations)
  temp.ar1_fit_CI_LB<-temp.ar1_fit_mean_signal-qnorm(0.975)*sqrt(temp.ar1_fit_variance_signal/temp.N)
  temp.ar1_fit_CI_UB<-temp.ar1_fit_mean_signal+qnorm(0.975)*sqrt(temp.ar1_fit_variance_signal/temp.N)
  temp.ar1_residual_CI_LB<-temp.ar1_fit_mean_signal-qnorm(0.975)*sqrt(temp.ar1_fit_variance_signal/temp.N)
  temp.ar1_residual_CI_UB<-temp.ar1_fit_mean_signal+qnorm(0.975)*sqrt(temp.ar1_fit_variance_signal/temp.N)
  #Ensure that the pole does not lie at an FFT-frequency.
  if(output_bool.par==TRUE){
    sink("AR1_Simulation_Parameters.txt", append=FALSE, split=FALSE)
    cat("AR(1) process:\n")
    cat("Coefficient = ",temp.ar1_coefficient,"\n")
    cat("Innovation variance = ",temp.ar_innovation_variance,"\n")
  }
  if(plot_bool.par==TRUE){
    #Distributional information.
    temp.x_list0<-list()
    temp.y_list0<-list()
    temp.col_vector0<-rep(1,temp.num_realizations)
    for(temp.j in 1:temp.num_realizations){
      temp.x_list0[[temp.j]]<-plotting_times.par
      temp.y_list0[[temp.j]]<-ACS_deviates.par[,temp.j]
    }
    temp.x_list<-list.append(temp.x_list0,
                             plotting_times.par,plotting_times.par,plotting_times.par,
                             plotting_times.par,plotting_times.par,plotting_times.par)
    temp.y_list<-list.append(temp.y_list0,
                             temp.ar1_fit_mean_signal,temp.ar1_fit_CI_LB,temp.ar1_fit_CI_UB,
                             temp.ar1_fit_median_signal,temp.ar1_fit_min_signal,temp.ar1_fit_max_signal)
    temp.col_vector<-c(temp.col_vector0,rep(2,3),rep(4,3))
    plot.graph(x_list.par=temp.x_list,y_list.par=temp.y_list,col.par=temp.col_vector,
               x_label.par=paste("Time, in ",time_units.string,sep=""),
               y_label.par=paste(measure_quantity.string,", in ",measure_units.string,sep=""),
               pdf_title.par="AR1_Fits_Empirical_Distribution.pdf")
    #The selected fit.
    temp.x_list<-list.append(temp.x_list0,plotting_times.par)
    temp.y_list<-list.append(temp.y_list0,temp.optimal_ar1_fit)
    temp.col_vector<-c(temp.col_vector0,2)
    plot.graph(x_list.par=temp.x_list,y_list.par=temp.y_list,col.par=temp.col_vector,
               x_label.par=paste("Time, in ",time_units.string,sep=""),
               y_label.par=paste(measure_quantity.string,", in ",measure_units.string,sep=""),
               pdf_title.par="AR1_Fit.pdf")
    temp.optimal_ar1_fit
  }
  #AR(1) simulation.
  dir.create("Spectral_Representation_Reconstruction",showWarnings=FALSE)
  setwd("Spectral_Representation_Reconstruction")
  dir.create("White_Noise",showWarnings=FALSE)
  dir.create("AR_Process",showWarnings=FALSE)
  #Simulate a Brownian-motion-driven AR(1) process.
  #Generate the spectral-representation approximations.
  temp.frequencies<-rep(0,M.par)
  temp.zero_index=M.par/2
  temp.wn_series_realizations<-matrix(0,nrow=N.par,ncol=temp.num_realizations)
  temp.ar_series_realizations<-temp.wn_series_realizations
  temp.wn_increments_realizations<-matrix(0,nrow=M.par,ncol=temp.num_realizations)
  temp.ar_increment_realizations<-temp.wn_increments_realizations
  temp.wn_IS_process_realizations<-temp.wn_increments_realizations
  temp.ar_IS_process_realizations<-temp.wn_increments_realizations
  temp.wn_representation_realizations<-temp.wn_series_realizations
  temp.ar_representation_realizations<-temp.wn_series_realizations
  for(temp.j in 1:temp.num_realizations){
    seed_values.par<-seed_values.par+temp.j+2
    if(output_bool.par==TRUE){
      cat(temp.j," out of ",temp.num_realizations,"\n")
    }
    temp.spectral_representation_object<-
      AR_spectral_representation.function(N.par=N.par,alphas.par=temp.ar1_coefficient,
                                          variance.par=temp.ar_innovation_variance,M.par=M.par,seed.par=seed_values.par,
                                          uniform_numbers.par=NA,crude_rv_num_samples.par=crude_rv_num_samples.par)
    if(temp.j==1){
      temp.frequencies<-temp.spectral_representation_object$out.frequencies
    }
    temp.wn_series<-temp.spectral_representation_object$out.SWN
    temp.ar_series<-temp.spectral_representation_object$out.AR
    temp.wn_series_realizations[,temp.j]<-temp.wn_series
    temp.ar_series_realizations[,temp.j]<-temp.ar_series
    temp.wn_increments<-temp.spectral_representation_object$out.wn_differences
    temp.wn_increments_realizations[,temp.j]<-temp.wn_increments
    temp.wn_IS_process_realization<-temp.spectral_representation_object$out.wn_IS_process_realization
    temp.BM_numbers<-temp.spectral_representation_object$out.BM
    temp.wn_IS_process_realization<-temp.wn_IS_process_realization[1:M.par]
    temp.wn_IS_process_realizations[,temp.j]<-temp.wn_IS_process_realization
    temp.ar_IS_process_realization<-temp.spectral_representation_object$out.ar_IS_numbers
    temp.ar_IS_process_realization<-temp.ar_IS_process_realization[1:M.par]
    temp.ar_increments_realization<-temp.spectral_representation_object$out.ar_differences
    temp.ar_jump_numbers_truncated<-temp.spectral_representation_object$out.ar_jump_numbers_truncated
    temp.ar_IS_process_realizations[,temp.j]<-temp.ar_IS_process_realization
    temp.ar_increment_realizations[,temp.j]<-temp.ar_increments_realization
    temp.WN_spectral_representation_series<-temp.spectral_representation_object$out.WN_series
    temp.AR_spectral_representation_series<-temp.spectral_representation_object$out.AR_series
    temp.wn_representation_realizations[,temp.j]<-temp.WN_spectral_representation_series
    temp.ar_representation_realizations[,temp.j]<-temp.AR_spectral_representation_series
    seed_values.par<-temp.spectral_representation_object$out.seeds
    temp.plotting_frequencies<-temp.frequencies*sampling_rate.par
    temp.BM_series<-c()
    if(temp.j==1){
      if(plot_bool.par==TRUE){
        #Plot the Brownian-motion realization.
        plot.graph(x_list.par=list(temp.plotting_frequencies),y_list.par=list(temp.BM_numbers),
                   pdf_title.par=paste("White_Noise/BM_Series.pdf",sep=""),
                   x_label.par=paste("Frequency, in ",frequency_units.string,sep=""),
                   y_label.par=paste(measure_quantity.string,", in ",measure_units.string,sep=""))
        #Plot the white-noise jumps.
        temp.jumps_real<-Re(temp.wn_increments)
        temp.jumps_real<-basic_cleaner.function(temp.jumps_real)
        temp.jumps_imaginary<-Im(temp.wn_increments)
        temp.jumps_imaginary<-basic_cleaner.function(temp.jumps_imaginary)
        pdf("White_Noise/WN_Increment_Series.pdf",width=8,height=6)
        #http://www.sthda.com/english/wiki/impressive-package-for-3d-and-4d-graph-r-software-and-data-visualization
        scatter3D(x=temp.plotting_frequencies,y=temp.jumps_real,z=temp.jumps_imaginary,phi=0,bty="g",type="l",ticktype="detailed",lwd=0.5,
                  xlab=paste("Frequency, in ",frequency_units.string,sep=""),ylab="Real",zlab="Imaginary")
        dev.off()
        #Plot the white-noise IS process.
        temp.wn_IS_process_real<-Re(temp.wn_IS_process_realization)
        temp.wn_IS_process_real<-basic_cleaner.function(temp.wn_IS_process_real)
        temp.wn_IS_process_imaginary<-Im(temp.wn_IS_process_realization)
        temp.wn_IS_process_imaginary<-basic_cleaner.function(temp.wn_IS_process_imaginary)
        pdf("White_Noise/WN_IS_Process_Series.pdf",width=8,height=6)
        scatter3D(x=temp.plotting_frequencies,y=temp.wn_IS_process_real,z=temp.wn_IS_process_imaginary,phi=0,bty="g",type="l",ticktype="detailed",lwd=0.5,
                  xlab=paste("Frequency, in ",frequency_units.string,sep=""),ylab="Real",zlab="Imaginary")
        dev.off()
        #Plot the white-noise demodulate-representation series.
        plot.graph(x_list.par=list(plotting_times.par,plotting_times.par),y_list.par=list(temp.wn_series,temp.WN_spectral_representation_series),
                   pdf_title.par=paste("White_Noise/Spectral_Representation_Series_WN.pdf",sep=""),
                   x_label.par=paste("Time, in ",time_units.string,sep=""),
                   y_label.par=paste(measure_quantity.string,", in ",measure_units.string,sep=""),col.par=c(1,2))
        #Plot the AR(1)-noise jumps.
        temp.jumps_real<-Re(temp.ar_increments_realization)
        temp.jumps_real<-basic_cleaner.function(temp.jumps_real)
        temp.jumps_imaginary<-Im(temp.ar_increments_realization)
        temp.jumps_imaginary<-basic_cleaner.function(temp.jumps_imaginary)
        pdf("AR_Process/AR_Increment_Series.pdf",width=8,height=6)
        scatter3D(x=temp.plotting_frequencies,y=temp.jumps_real,z=temp.jumps_imaginary,phi=0,bty="g",type="l",ticktype="detailed",lwd=0.5,
                  xlab=paste("Frequency, in ",abbreviated_frequency_units.string,sep=""),ylab="Real",zlab="Imaginary")
        dev.off()
        #Plot the white-noise IS process.
        temp.ar_IS_process_real<-Re(temp.ar_IS_process_realization)
        temp.ar_IS_process_real<-basic_cleaner.function(temp.ar_IS_process_real)
        temp.ar_IS_process_imaginary<-Im(temp.ar_IS_process_realization)
        temp.ar_IS_process_imaginary<-basic_cleaner.function(temp.ar_IS_process_imaginary)
        pdf("AR_Process/AR_IS_Process_Series.pdf",width=8,height=6)
        scatter3D(x=temp.plotting_frequencies,y=temp.ar_IS_process_real,z=temp.ar_IS_process_imaginary,phi=0,bty="g",type="l",ticktype="detailed",lwd=0.5,
                  xlab=paste("Frequency, in ",frequency_units.string,sep=""),ylab="Real",zlab="Imaginary")
        dev.off()
        #Plot the AR(1) demodulate-representation series.
        plot.graph(x_list.par=list(plotting_times.par,plotting_times.par),y_list.par=list(temp.ar_series,temp.AR_spectral_representation_series),
                   pdf_title.par=paste("AR_Process/Spectral_Representation_Series_AR.pdf",sep=""),
                   x_label.par=paste("Time, in ",time_units.string,sep=""),
                   y_label.par=paste(measure_quantity.string,", in ",measure_units.string,sep=""),col.par=c(1,2))
      }
    }
  }
  if(output_bool.par==TRUE){
    sink()
  }
  setwd(working_directory_string.par)
  temp.list<-list(out.ar1_coefficient=temp.ar1_coefficient,
                  out.ar_innovation_variance=temp.ar_innovation_variance,
                  out.wn_increments_realizations=temp.wn_increments_realizations,
                  out.ar_increment_realizations=temp.ar_increment_realizations,
                  out.wn_IS_process_realizations=temp.wn_IS_process_realizations,
                  out.ar_IS_process_realizations=temp.ar_IS_process_realizations,
                  out.wn_series_realizations=temp.wn_series_realizations,
                  out.ar_series_realizations=temp.ar_series_realizations,
                  out.seed_values=seed_values.par)
  return(temp.list)
}

















