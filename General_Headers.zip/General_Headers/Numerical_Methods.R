#Francois Marshall, Boston University
#Header file for presenting output of results.

###################################################################################################################
#Established tapers.

#https://www.rdocumentation.org/packages/pracma/versions/1.9.9/topics/gaussLegendre
##  Quadrature with Gauss-Legendre nodes and weights
#https://www.rdocumentation.org/packages/stats/versions/3.6.2/topics/deriv
## Higher derivatives:
DD.function<-function(expr.par,name.par,order.par=1){
  if(order.par<1) stop("'order.par' must be >= 1")
  if(order.par==1) D(expr.par,name.par)
  else DD.function(D(expr.par,name.par),name.par,order.par-1)
}
evaluate_character_expression_function.function<-function(x,object.par){
  temp.values<-eval(object.par)
  return(temp.values)
}
evaluate_complementary_character_expression_function.function<-function(x,object.par){
  temp.values<-(-1)*eval(object.par)
  return(temp.values)
}

Richardson_fourth_derivative_estimate.function<-function(index.par,abscissa.par,ordinates.par,a.par=0,b.par=1,h_index_value.par=2){
  temp.num_abscissa=length(abscissa.par)
  temp.range=b.par-a.par
  temp.h_index_values<-c(h_index_value.par,h_index_value.par/2)
  temp.h_values<-temp.h_index_values*temp.range/temp.num_abscissa
  temp.f4_values<-rep(0,2)
  for(temp.i in 1:2){
    temp.h_i=temp.h_index_values[temp.i]
    temp.running_indices<-c(index.par+2*temp.h_i,
                            index.par+temp.h_i,
                            index.par,
                            index.par-temp.h_i,
                            index.par-2*temp.h_i)
    temp.abscissa<-abscissa.par[temp.running_indices]
    temp.ordinates<-ordinates.par[temp.running_indices]
    temp.numerator_terms<-rep(0,5)
    temp.numerator_terms[1]=temp.ordinates[1]
    temp.numerator_terms[2]=-4*temp.ordinates[2]
    temp.numerator_terms[3]=6*temp.ordinates[3]
    temp.numerator_terms[4]=-4*temp.ordinates[4]
    temp.numerator_terms[5]=temp.ordinates[5]
    temp.numerator=sum(temp.numerator_terms)
    temp.denominator=temp.h_values[temp.i]^4
    temp.f4_values[temp.i]=temp.numerator/temp.denominator
  }
  temp.Richardson_estimate=(4*temp.f4_values[1]-temp.f4_values[2])/3
  return(temp.Richardson_estimate)
}

numerical_sinc2_integration_error.function<-function(a.par=0,b.par=1,num_nodes.par=2,num_trial_x_values.par=50){
  temp.indices<-1:num_trial_x_values.par
  temp.h=(b.par-a.par)/num_trial_x_values.par
  temp.abscissa<-a.par+(temp.indices-1)*temp.h
  temp.derivative_order0=2*(num_nodes.par+1)
  temp.derivative_order=temp.derivative_order0
  if(num_nodes.par>2){
    temp.derivative_order0=2*(2+1)
    num_nodes.par=4
    temp.derivative_order=2*(num_nodes.par+1)
    temp.indices<-5:(num_trial_x_values.par-5)
  }
  temp.optimal_derivative=0
  if(num_nodes.par==4){
    temp.DD_object<-DD.function(expression(4*(sin(2*pi*x)/(2*pi*x))^2),"x",temp.derivative_order0)
    temp.second_derivatives<-evaluate_character_expression_function.function(x=c(temp.abscissa[2:num_trial_x_values.par-1]),
                                                                             object.par=temp.DD_object)
    temp.second_derivatives<-c(0,temp.second_derivatives[2:num_trial_x_values.par-1])
    if(length(which(is.nan(temp.second_derivatives)==TRUE)>0)){
      temp.second_derivatives[is.nan(temp.second_derivatives)==TRUE]<-.Machine$double.xmax
    }
    if(length(which(is.infinite(temp.second_derivatives)==TRUE)>0)){
      temp.second_derivatives[is.infinite(temp.second_derivatives)==TRUE]<-.Machine$double.xmax
    }
    #https://search.r-project.org/CRAN/refmans/pracma/html/numderiv.html
    temp.Richardson_fourth_der_estimates<-sapply(temp.indices,Richardson_fourth_derivative_estimate.function,
                                                 temp.abscissa,temp.second_derivatives,a.par=a.par,b.par=b.par,h_index_value.par=2)
    if(length(which(is.nan(temp.Richardson_fourth_der_estimates)==TRUE)>0)){
      temp.Richardson_fourth_der_estimates[is.nan(temp.Richardson_fourth_der_estimates)==TRUE]<-.Machine$double.xmax
    }
    if(length(which(is.infinite(temp.Richardson_fourth_der_estimates)==TRUE)>0)){
      temp.Richardson_fourth_der_estimates[is.infinite(temp.Richardson_fourth_der_estimates)==TRUE]<-.Machine$double.xmax
    }
    temp.minimum_derivative=min(temp.Richardson_fourth_der_estimates)
    temp.optimal_index=min(which(temp.Richardson_fourth_der_estimates==temp.minimum_derivative))
    temp.optimal_derivative=temp.Richardson_fourth_der_estimates[temp.optimal_index]
  } else{
    temp.DD_object<-DD.function(expression(4*(sin(2*pi*x)/(2*pi*x))^2),"x",temp.derivative_order)
    temp.x<-(1:num_trial_x_values.par-1)/num_trial_x_values.par*(b.par-a.par)+a.par
    temp.candidate_minima<-evaluate_character_expression_function.function(x=temp.abscissa[2:num_trial_x_values.par-1],
                                                                           object.par=temp.DD_object)
    temp.candidate_minima<-c(0,temp.candidate_minima[2:num_trial_x_values.par-1])
    if(length(which(is.nan(temp.candidate_minima)==TRUE)>0)){
      temp.candidate_minima[is.nan(temp.candidate_minima)==TRUE]<-.Machine$double.xmax
    }
    if(length(which(is.infinite(temp.candidate_minima)==TRUE)>0)){
      temp.candidate_minima[is.infinite(temp.candidate_minima)==TRUE]<-.Machine$double.xmax
    }
    temp.minimum_derivative=min(temp.candidate_minima)
    temp.optimal_index=min(which(temp.candidate_minima==temp.minimum_derivative))
    temp.optimal_derivative=temp.candidate_minima[temp.optimal_index]
  }
  #Compute the error of the Gauss-Legendre integral estimate.
  temp.minimum_log_error_terms<-rep(0,4)
  temp.minimum_log_error_terms[1]=(2*num_nodes.par+3)*log(b.par-a.par)
  temp.minimum_log_error_terms[2]=4*(sum(log(1:(num_nodes.par+1))))
  temp.minimum_log_error_terms[3]=-log(2*num_nodes.par+3)
  temp.minimum_log_error_terms[4]=-3*sum(log(1:(2*(num_nodes.par+1))))
  temp.minimum_error_value=exp(sum(temp.minimum_log_error_terms))*temp.minimum_derivative
  temp.output_list<-list(out.h=temp.h,
                         out.minimum_derivative=temp.minimum_derivative,
                         out.minimum_error_value=temp.minimum_error_value)
  return(temp.output_list)
}
















