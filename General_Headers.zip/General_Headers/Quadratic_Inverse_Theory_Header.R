#Francois Marshall, Boston University
#Header file for functions involved in quadratic inverse theory.
###################################################################################################################

Slepian.projection<-function(frequency_index1.par,frequency_index2.par,Slepians.par){
  temp.Slepian_vector1<-Slepians.par[frequency_index1.par,]
  temp.Slepian_vector2<-Conj(Slepians.par[frequency_index2.par,])
  temp.projection<-sum(temp.Slepian_vector1*temp.Slepian_vector2)
  return(temp.projection)
}

Slepian_projection.matrix<-function(Slepians.par,N.par,NW.par){
  temp.M=nrow(Slepians.par)
  temp.zero_index=temp.M/2
  temp.half_bandwidth=floor(NW.par/N.par*temp.M)
  temp.lower_index=temp.zero_index-temp.half_bandwidth
  temp.upper_index=temp.zero_index+temp.half_bandwidth
  temp.interior_indices<-temp.lower_index:temp.upper_index
  temp.num_in_band=length(temp.interior_indices)
  temp.matrix<-matrix(0,nrow=temp.num_in_band,ncol=temp.num_in_band)
  for(m in temp.interior_indices){
    temp.index=m-temp.lower_index+1
    temp.matrix[,temp.index]<-sapply(temp.interior_indices,Slepian.projection,m,Slepians.par)
  }
  temp.matrix<-temp.matrix/sqrt(temp.M)
  return(temp.matrix)
}

Bl_matrix.element<-function(j.par,k.par,l.par,Slepians.par,eigenvectors.par,N.par,NW.par){
  temp.M=nrow(Slepians.par)
  temp.zero_index=temp.M/2
  temp.half_bandwidth=floor(NW.par/N.par*temp.M)
  temp.lower_index=temp.zero_index-temp.half_bandwidth
  temp.upper_index=temp.lower_index+length(eigenvectors.par[,l.par])-1#temp.zero_index+temp.half_bandwidth
  temp.interior_indices<-temp.lower_index:temp.upper_index
  temp.slepian_vector1<-Slepians.par[temp.interior_indices,j.par]
  temp.slepian_vector2<-Conj(Slepians.par[temp.interior_indices,k.par])
  temp.eigenvector<-eigenvectors.par[,l.par]
  temp.integrand<-temp.slepian_vector1*temp.slepian_vector2*temp.eigenvector
  temp.inner_product=sum(temp.integrand)/temp.M
  return(temp.inner_product)
}

Bl.matrix<-function(l.par,Slepians.par,eigenvectors.par,N.par,NW.par){
  temp.K=ncol(Slepians.par)
  temp.matrix<-matrix(0,nrow=temp.K,ncol=temp.K)
  for(k in 1:temp.K){
    temp.matrix[,k]<-sapply(1:temp.K,Bl_matrix.element,k,l.par,Slepians.par,eigenvectors.par,N.par,NW.par)
  }
  return(temp.matrix)
}

bl.coefficient<-function(frequency_index.par,l.par,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,N.par,NW.par,K.par){
  temp.M=nrow(eigencoefficients.par)
  temp.eigencoefficient_vector1<-eigencoefficients.par[frequency_index.par,]
  temp.Bl_matrix<-eigenmatrices.par[[l.par]]
  temp.coherency_matrix<-coherency.matrix(temp.eigencoefficient_vector1,temp.eigencoefficient_vector1)
  temp.product_matrix<-temp.coherency_matrix%*%temp.Bl_matrix
  temp.inner_product<-matrix.trace(temp.product_matrix)
  temp.eigenvalue=eigenvalues.par[l.par]
  temp.bl=temp.inner_product/(2*NW.par/N.par*temp.eigenvalue)
  return(temp.bl)
}

C_tilde.matrix<-function(frequency_index.par,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,N.par,NW.par,K.par){
  temp.L=ncol(eigenmatrices.par[[1]])
  temp.matrix<-matrix(0,nrow=K.par,ncol=K.par)
  for(temp.l in 1:temp.L){
    temp.bl=bl.coefficient(frequency_index.par,temp.l,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,N.par,NW.par,K.par)
    temp.Bl<-eigenmatrices.par[[temp.l]]
    temp.matrix<-temp.matrix+temp.bl*temp.Bl
  }
  return(temp.matrix)
}


sphericity_analysis.function<-function(eigencoefficients.par,frequencies.par,slepian_functions.par,energy_concentrations.par,N_samples.par=NA,
                                       first_time.par=0,sampling_rate.par=1,NW.par=5,F_test_threshold.par=NA,
                                       old_directory.par="",new_directory.par="",measured_quantity.par="",
                                       abscissa_value.par="",abscissa_units.par="",percentile.par=c(0.1,0.25,0.5,0.75,0.9),M_exponent.par=1,
                                       crossing_rates_bool.par=FALSE,plot_bool.par=FALSE,verbose_bool.par=FALSE){
  if(is.na(N_samples.par)==TRUE){
    N_samples.par=length(frequencies.par)
  }
  temp.K=ncol(eigencoefficients.par)
  temp.M=nrow(eigencoefficients.par)
  temp.M2=temp.M/2+1
  temp.QIT_analysis_object<-QIT.analysis(eigencoefficients.par,slepian_functions.par,energy_concentrations.par,N_samples.par,NW.par)
  temp.QIT_eigenmatrices<-temp.QIT_analysis_object$out.eigenmatrices
  temp.QIT_eigenvalues<-temp.QIT_analysis_object$out.eigenvalues
  temp.projections_eigenvectors<-temp.QIT_analysis_object$out.projections_eigenvectors
  temp.QIT_L=length(temp.QIT_eigenvalues)
  temp.sphericity_statistics<-sapply(1:temp.M2,sphericity.test_statistic,temp.QIT_eigenvalues,temp.QIT_eigenmatrices,slepian_functions.par,
                                eigencoefficients.par,N_samples.par,NW.par,temp.K)
  temp.percentile_values<-c(0.95,1-1/N_samples.par)
  if(plot_bool.par==TRUE){
    temp.percentile1=temp.percentile_values[1]*100
    temp.percentile1=round(temp.percentile1,ceil(log10(temp.percentile1))+1)
    temp.percentile2=temp.percentile_values[2]*100
    temp.percentile2=round(temp.percentile2,ceil(log10(temp.percentile2))+1)
    plot.graph(list(frequencies.par*sampling_rate.par),list(temp.sphericity_statistics),
               plot_title.par=paste("L = ",temp.QIT_L,"\n{",temp.percentile1,",",temp.percentile2,"}%",sep=""),
               x_label.par=paste(abscissa_value.par,", in ",abscissa_units.par,sep=""),y_label.par="Sphericity statistic",
               pdf_title.par="Sphericity_Statistic_Spectrum.pdf",horizontal_line.par=qchisq(temp.percentile_values,temp.QIT_L-1))
  }
  if(crossing_rates_bool.par==TRUE){
    #Determine if the number of crossings is consistent with that expected for a chi-squared process.
    chi_squared_crossing.object<-chi_squared_crossing.function(ts.par=temp.sphericity_statistics,time_sequence.par=frequencies.par,dof.par=temp.QIT_L,
                                                               percentile.par=percentile.par,first_time.par=first_time.par,
                                                               NW.par=NW.par,sampling_rate.par=1/sampling_rate.par,
                                                               M_exponent.par=M_exponent.par,F_test_threshold.par=F_test_threshold.par,
                                                               old_directory.par=old_directory.par,new_directory.par=new_directory.par,
                                                               measured_quantity.par=measured_quantity.par,abscissa_measurement.par=abscissa_measurement.par,
                                                               abscissa_units.par=abscissa_units.par,verbose_bool.par=verbose_bool.par)
  }
  temp.list<-list(out.sphericity_statistics=temp.sphericity_statistics,
                  out.QIT_L=temp.QIT_L,
                  out.projections_eigenvectors=temp.projections_eigenvectors,
                  out.QIT_eigenmatrices=temp.QIT_eigenmatrices,
                  out.QIT_eigenvalues=temp.QIT_eigenvalues)
  return(temp.list)
}




nonstationary_QI_eigenvectors.function<-function(NW.par,N.par,K.par=NA,L.par=NA){
  temp.K=K.par
  if(is.na(K.par)==TRUE){
    temp.K=2*NW.par-1
  }
  temp.L=L.par
  if(is.na(L.par)==TRUE){
    temp.L=2*temp.K-1
  }
  temp.index_sequence<-1:N.par
  temp.kernel_matrix<-dpss_kernel.function(NW.par,N.par,temp.index_sequence)
  temp.kernel_matrix<-temp.kernel_matrix^2
  temp.eigen_object<-eigs_sym(temp.kernel_matrix,temp.L)
  temp.eigenvalues<-temp.eigen_object$values
  temp.eigenvectors<-temp.eigen_object$vectors
  temp.list<-list(out.eigenvalues=temp.eigenvalues,
                  out.eigenvectors=temp.eigenvectors)
  return(temp.list)
}


Al_matrix.element<-function(j.par,k.par,l.par,dpss.par,eigenvectors.par,concentrations.par){
  temp.slepian_vector1<-dpss.par[,j.par]
  temp.slepian_vector2<-dpss.par[,k.par]
  temp.eigenvector<-eigenvectors.par[,l.par]
  temp.integrand<-temp.slepian_vector1*temp.slepian_vector2*temp.eigenvector
  temp.inner_product=sqrt(concentrations.par[j.par]*concentrations.par[k.par])*sum(temp.integrand)
  return(temp.inner_product)
}


Al.matrix<-function(l.par,dpss.par,eigenvectors.par,concentrations.par){
  temp.K=length(concentrations.par)
  temp.matrix<-matrix(0,nrow=temp.K,ncol=temp.K)
  for(temp.k in 1:temp.K){
    temp.matrix[,temp.k]<-sapply(1:temp.K,Al_matrix.element,temp.k,l.par,dpss.par,eigenvectors.par,concentrations.par)
  }
  return(temp.matrix)
}


Al_list.function<-function(dpss.par,NW.par,concentrations.par){
  temp.N=nrow(dpss.par)
  temp.K=length(concentrations.par)
  temp.nonst_QI_object<-nonstationary_QI_eigenvectors.function(NW.par,temp.N)
  temp.nonst_QI_eigenvalues<-temp.nonst_QI_object$out.eigenvalues
  temp.nonst_QI_eigenvectors<-temp.nonst_QI_object$out.eigenvectors
  temp.L=2*temp.K-1
  temp.Al_list<-list()
  for(temp.l in 1:temp.L){
    temp.Al<-Al.matrix(temp.l,dpss.par,temp.nonst_QI_eigenvectors,concentrations.par)
    temp.Al_list[[temp.l]]<-temp.Al
  }
  temp.list<-list(out.nonst_QI_eigenvalues=temp.nonst_QI_eigenvalues,
                  out.nonst_QI_eigenvectors=temp.nonst_QI_eigenvectors,
                  out.Al_list=temp.Al_list)
  return(temp.list)
}

al.cross_coefficient<-function(frequency_index.par,l.par,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,eigencoefficients2.par,
                               N.par,NW.par){
  temp.M=nrow(eigencoefficients.par)
  temp.K=ncol(eigencoefficients.par)
  temp.eigencoefficient_vector1<-eigencoefficients.par[frequency_index.par,]
  temp.eigencoefficient_vector2<-eigencoefficients2.par[frequency_index.par,]
  temp.Al_matrix<-eigenmatrices.par[[l.par]]
  temp.coherency_matrix<-coherency.matrix(temp.eigencoefficient_vector1,temp.eigencoefficient_vector2)
  temp.product_matrix<-temp.coherency_matrix%*%temp.Al_matrix
  temp.inner_product<-matrix.trace(temp.product_matrix)
  temp.eigenvalue=eigenvalues.par[l.par]
  temp.al=temp.inner_product/temp.eigenvalue
  return(temp.al)
}

PSD_single_logarithmic_derivative.function<-function(frequency_index.par,eigenvalues.par,Al_list.par,Slepians.par,eigencoefficients.par,N.par,NW.par){
  temp.al_vector<-rep(0,2)
  for(temp.l in 1:2){
    temp.al=al.cross_coefficient(frequency_index.par,temp.l,eigenvalues.par,Al_list.par,Slepians.par,eigencoefficients.par,eigencoefficients.par,
                                 N.par,NW.par)
    temp.al_vector[temp.l]=temp.al
  }
  temp.CT_factor=pi/N.par/sqrt(2*N.par)
  temp.logarithmic_derivative=temp.CT_factor*temp.al_vector[2]/temp.al_vector[1]
  temp.logarithmic_derivative=Re(temp.logarithmic_derivative)
  return(temp.logarithmic_derivative)
}


PSD_logarithmic_derivative.function<-function(eigenvalues.par,Al_list.par,Slepians.par,eigencoefficients.par,N.par,NW.par){
  temp.M=nrow(eigencoefficients.par)
  temp.M2=temp.M/2+1
  temp.indices<-1:temp.M2
  temp.logarithmic_derivatives<-sapply(temp.indices,PSD_single_logarithmic_derivative.function,eigenvalues.par,Al_list.par,Slepians.par,
                                       eigencoefficients.par,N.par,NW.par)
  return(temp.logarithmic_derivatives)
}





pl.coefficient<-function(frequency_index.par,l.par,eigenvalues.par,eigenmatrices.par,dpss.par,eigencoefficients.par,N.par,NW.par,K.par){
  temp.M=nrow(eigencoefficients.par)
  temp.eigencoefficient_vector1<-eigencoefficients.par[frequency_index.par,]
  temp.Al_matrix<-eigenmatrices.par[[l.par]]
  temp.coherency_matrix<-coherency.matrix(temp.eigencoefficient_vector1,temp.eigencoefficient_vector1)
  temp.product_matrix<-temp.coherency_matrix%*%temp.Al_matrix
  temp.inner_product<-matrix.trace(temp.product_matrix)
  temp.eigenvalue=eigenvalues.par[l.par]
  temp.bl=temp.inner_product/temp.eigenvalue
  return(temp.bl)
}



bl.cross_coefficient<-function(frequency_index.par,l.par,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,eigencoefficients2.par,
                               N.par,NW.par,K.par){
  temp.M=nrow(eigencoefficients.par)
  temp.eigencoefficient_vector1<-eigencoefficients.par[frequency_index.par,]
  temp.eigencoefficient_vector2<-eigencoefficients2.par[frequency_index.par,]
  temp.Bl_matrix<-eigenmatrices.par[[l.par]]
  temp.coherency_matrix<-coherency.matrix(temp.eigencoefficient_vector1,temp.eigencoefficient_vector2)
  temp.product_matrix<-temp.coherency_matrix%*%temp.Bl_matrix
  temp.inner_product<-matrix.trace(temp.product_matrix)
  temp.eigenvalue=eigenvalues.par[l.par]
  temp.bl=temp.inner_product/(2*NW.par/N.par*temp.eigenvalue)
  return(temp.bl)
}

cross_C_tilde.matrix<-function(frequency_index.par,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,eigencoefficients2.par,N.par,
                               NW.par,K.par){
  temp.L=ncol(eigenmatrices.par[[1]])
  temp.matrix<-matrix(0,nrow=K.par,ncol=K.par)
  for(l in 1:temp.L){
    temp.bl=bl.cross_coefficient(frequency_index.par,l,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,eigencoefficients2.par,
                                 N.par,NW.par,K.par)
    temp.Bl<-eigenmatrices.par[[l]]
    temp.matrix<-temp.matrix+temp.bl*temp.Bl
  }
  return(temp.matrix)
}



average.PSD<-function(frequency_index.par,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,N.par,NW.par,K.par){
  temp.coherency_matrix<-C_tilde.matrix(frequency_index.par,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,N.par,NW.par,K.par)
  temp.psd=matrix.trace(Re(temp.coherency_matrix))/K.par
  temp.list<-list(temp.coherency_matrix,temp.psd)
  return(temp.list)
}

qi.spectrum<-function(eigenvalues.par,eigenvectors.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,N.par,NW.par,K.par){
  temp.L=length(eigenmatrices.par)
  temp.M=nrow(eigencoefficients.par)
  temp.zero_index=temp.M/2
  temp.half_bandwidth=floor(NW.par/N.par*temp.M)
  temp.lower_index=-temp.half_bandwidth
  temp.upper_index=temp.half_bandwidth
  temp.interior_indices<-temp.lower_index:temp.upper_index
  temp.bl_matrix<-matrix(0,nrow=temp.M,ncol=temp.L)
  for(l in 1:temp.L){
    temp.bl_matrix[,l]=sapply(1:temp.M,bl.coefficient,l,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,N.par,NW.par,K.par)
  }
  temp.num_in_band=nrow(eigenvectors.par)
  temp.acvs<-rep(0,temp.M)
  for(l in 1:temp.L){
    temp.eigenvector<-eigenvectors.par[,l]
    temp.bl<-temp.bl_matrix[,l]
    temp.Bl_transform<-rep(0,temp.M)
    temp.bl_transform<-sum(temp.bl_matrix[temp.zero_index+temp.interior_indices,l])
    for(m in 1:temp.M){
      temp.Bl_transform[m]=sum(temp.eigenvector*exp(1i*2*pi*(temp.interior_indices/temp.M)*(m-1)))
    }
    temp.Bl_transform<-temp.Bl_transform/temp.M
    temp.acvs<-temp.acvs+temp.Bl_transform*temp.bl_transform
  }
  temp.acvs[(N.par+1):temp.M]<-0
  temp.qi_spectrum<-Re(fft(temp.acvs))
  temp.qi_spectrum[!temp.qi_spectrum]<-zero.threshold
  return(temp.qi_spectrum)
}

sphericity.test_statistic<-function(frequency_index.par,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,N.par,NW.par,K.par=NA){
  temp.L=length(eigenmatrices.par)
  if(is.na(K.par)==TRUE){
    K.par=ncol(eigencoefficients.par)
  }
  temp.M=nrow(eigencoefficients.par)
  temp.average_PSD_object=average.PSD(frequency_index.par,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,N.par,NW.par,K.par)
  temp.average_PSD=temp.average_PSD_object[[2]]
  temp.test_statistic=0
  for(temp.l in 1:temp.L){
    temp.gl=eigenvalues.par[temp.l]
    temp.bl=bl.coefficient(frequency_index.par,temp.l,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,N.par,NW.par,K.par)
    temp.matrix<-eigenmatrices.par[[temp.l]]
    temp.test_statistic=temp.test_statistic+temp.gl*Mod(temp.bl/temp.average_PSD-matrix.trace(temp.matrix)/(2*NW.par/N.par*temp.gl))^2
  }
  temp.test_statistic=temp.test_statistic*(2*NW.par/N.par)
  return(temp.test_statistic)
}

spectrogram.row_vector<-function(frequency_index.par,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,N.par,NW.par=5,K.par=NA,L.par=NA,
                                 eigenvectors.par){
  if(is.na(K.par)==TRUE){
    K.par=2*NW.par-1
  }
  if(is.na(L.par)==TRUE){
    L.par=2*K.par-1
  }
  temp.vector<-rep(0,N.par)
  for(temp.l in 1:L.par){
    temp.pl=pl.coefficient(frequency_index.par,temp.l,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,N.par,NW.par,K.par)
    temp.Al<-eigenvectors.par[,temp.l]
    temp.vector<-temp.vector+temp.pl*temp.Al
  }
  temp.vector<-Re(temp.vector)
  return(temp.vector)
}

average.spectrogram<-function(frequency_index.par,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,N.par,NW.par,K.par,L.par,
                              eigenvectors.par){
  temp.vector<-spectrogram.row_vector(frequency_index.par,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,N.par,NW.par,K.par,L.par,
                                      eigenvectors.par)
  temp.average=mean(temp.vector)
  return(temp.average)
}


nonstationary.test_statistic<-function(frequency_index.par,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,N.par,NW.par,K.par,
                                       eigenvectors.par){
  temp.L=length(eigenmatrices.par)
  temp.K=ncol(eigencoefficients.par)
  temp.M=nrow(eigencoefficients.par)
  cat(frequency_index.par," out of ",temp.M,"\n")
  temp.average_spectrogram=average.spectrogram(frequency_index.par,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,N.par,NW.par,
                                               K.par,temp.L,eigenvectors.par)
  temp.test_statistic=0
  for(l in 1:temp.L){
    temp.gl=eigenvalues.par[l]
    temp.pl=pl.coefficient(frequency_index.par,l,eigenvalues.par,eigenmatrices.par,Slepians.par,eigencoefficients.par,N.par,NW.par,K.par)
    temp.matrix<-eigenmatrices.par[[l]]
    temp.test_statistic=temp.test_statistic+temp.gl*Mod(temp.pl/temp.average_spectrogram-sum(eigenvectors.par[,l]))^2
  }
  return(temp.test_statistic)
}


sample.log_likelihood_ratio<-function(c_vector.par,theta_vector.par){
  temp.N=length(c_vector.par)
  temp.log_likelihood=0
  for(n in 1:temp.N){
    temp.log_likelihood=temp.log_likelihood-log(theta_vector.par[n])-Mod(c_vector.par[n])^2/theta_vector.par[n]
  }
  temp.log_likelihood=temp.log_likelihood-log(pi)
  return(temp.log_likelihood)
}

KL.C_tilde<-function(frequency_index.par,eigenvalues.par,eigenmatrices.par,eigencoefficients.par,N.par,NW.par,K.par,C_hat.par){
  temp.K=ncol(eigencoefficients.par)
  temp.M=nrow(eigencoefficients.par)
  temp.L=ncol(eigenmatrices.par[[1]])
  temp.C_hat<-C_hat.par+diag(rep(zero.threshold,temp.K))
  temp.delta=10
  temp.tolerance=0.5
  temp.previous_likelihood=0
  temp.current_likelihood=0
  temp.counter=1
  temp.expansion_coefficients<-rep(0,temp.K)
  temp.updated_eigenvalues<-rep(0,temp.K)
  while((temp.delta>=temp.tolerance) & (temp.counter<10)){
    temp.C_hat2<-matrix(0,nrow=nrow(temp.C_hat),ncol=ncol(temp.C_hat))
    for(l in 1:temp.L){
      temp.eigenvalue=eigenvalues.par[l]
      temp.bl=matrix.trace(temp.C_hat%*%eigenmatrices.par[[l]])/(2*NW.par/N.par*temp.eigenvalue)
      cat(temp.counter,",","l",": temp.bl = ",temp.bl,"\n")
      temp.C_hat2<-temp.C_hat2+temp.bl*eigenmatrices.par[[l]]
    }
    temp.eigen_object<-eigen(temp.C_hat2)
    temp.eigenvectors<-temp.eigen_object$vectors
    temp.eigenvalues<-Re(temp.eigen_object$values)
    for(k in 1:temp.K){
      temp.expansion_coefficients[k]=sum(Conj(temp.eigenvectors[,k])*eigencoefficients.par[frequency_index.par,])
      temp.updated_eigenvalue=Mod(temp.expansion_coefficients[k])^2
      if(temp.eigenvalues[k]>0){
        temp.updated_eigenvalue=mean(c(temp.updated_eigenvalue,temp.eigenvalues[k]))
      }
      temp.updated_eigenvalues[k]=temp.updated_eigenvalue
    }
    temp.C_hat3<-matrix(0,nrow=nrow(temp.C_hat),ncol=ncol(temp.C_hat))
    for(k in 1:temp.K){
      temp.C_hat3<-temp.C_hat3+temp.updated_eigenvalues[k]*temp.eigenvectors[,k]%*%t(Conj(temp.eigenvectors[,k]))
    }
    if(temp.counter==1){
      temp.previous_likelihood=sample.log_likelihood_ratio(temp.expansion_coefficients,temp.updated_eigenvalues)
    }
    else{
      temp.current_likelihood=sample.log_likelihood_ratio(temp.expansion_coefficients,temp.updated_eigenvalues)
      cat(temp.counter,"temp.current_likelihood = ",temp.current_likelihood,"\n")
      temp.delta=abs(temp.current_likelihood-temp.previous_likelihood)
      if(temp.delta<temp.tolerance){
        break
      }
      else{
        temp.previous_likelihood=temp.current_likelihood
      }
    }
    temp.C_hat<-temp.C_hat3
    temp.counter=temp.counter+1
  }
  return(temp.C_hat)
}


QIT.analysis<-function(eigencoeff.par,slepian_functions.par,energy_concentrations.par,N.par,NW.par){
  temp.M=nrow(eigencoeff.par)
  temp.zero_index=temp.M/2
  temp.M2=temp.zero_index+1
  temp.K=ncol(eigencoeff.par)
  temp.normalized_slepian_functions<-matrix(0,nrow=temp.M,ncol=temp.K)
  for(temp.k in 1:temp.K){
    temp.normalized_slepian_functions[,temp.k]<-slepian_functions.par[,temp.k]/sqrt(energy_concentrations.par[temp.k])
  }
  #Solve the eigenvalue equation for the projection matrix.
  temp.projections_matrix<-Slepian_projection.matrix(temp.normalized_slepian_functions,N.par,NW.par)
  temp.squared_projection_matrix<-Mod(temp.projections_matrix)^2
  temp.projections_eigenvalue_object<-eigen(temp.squared_projection_matrix)
  temp.projections_eigenvalues<-temp.projections_eigenvalue_object$values
  temp.projections_eigenvalues[temp.projections_eigenvalues<0]<-0
  temp.projections_eigenvectors<-temp.projections_eigenvalue_object$vectors
  #Choice of L has been determined graphically, and does not change notably from 2K-1 for the general case.
  temp.L=min(ncol(temp.projections_eigenvectors),2*temp.K-1)
  temp.projections_eigenvectors<-temp.projections_eigenvectors[,1:temp.L]
  temp.final_energy=2*NW.par/N.par*temp.M
  for(temp.l in 1:temp.L){
    temp.energy_normalization_factor=sqrt(temp.final_energy)
    temp.projections_eigenvectors[,temp.l]<-temp.projections_eigenvectors[,temp.l]*temp.energy_normalization_factor
  }
  temp.eigen_matrices<-list()
  for(temp.l in 1:temp.L){
    temp.eigen_matrices[[temp.l]]<-Bl.matrix(temp.l,temp.normalized_slepian_functions,temp.projections_eigenvectors,N.par,NW.par)
  }
  #Convert the eigencoefficient estimates to idealized eigencoefficient estimates.
  for(temp.k in 1:temp.K){
    eigencoeff.par[,temp.k]<-eigencoeff.par[,temp.k]/sqrt(energy_concentrations.par[temp.k])
  }
  temp.QIT_spectrum<-rep(0,temp.M2)
  temp.index_vector<-temp.zero_index+1:temp.M2-1
  for(temp.m in temp.index_vector){
    temp.index=temp.m-temp.zero_index+1
    temp.QIT_spectrum[temp.index]=average.PSD(temp.m,temp.projections_eigenvectors,temp.eigen_matrices,temp.normalized_slepian_functions,
                                              eigencoeff.par,N.par,NW.par,temp.K)[[2]]
  }
  temp.list<-list(out.eigenvalues=temp.projections_eigenvalues,
                  out.eigenmatrices=temp.eigen_matrices,
                  out.normalized_slepian_functions=temp.normalized_slepian_functions,
                  out.eigencoeffs=eigencoeff.par,
                  out.QIT_PSD=temp.QIT_spectrum,
                  out.L=temp.L,
                  out.projections_eigenvectors=temp.projections_eigenvectors)
}


QIT.cepstral_ratio_statistic<-function(index.par,QIT_spectrum.par,projections_eigenvalues.par,eigen_matrices.par,eigencoeffs.par,
                                      normalized_slepian_functions.par,zero_index.par,N.par,NW.par){
  temp.K=ncol(eigen_matrices.par)
  temp.index=index.par-zero_index.par+1
  temp.b1=bl.coefficient(index.par,1,projections_eigenvalues.par,eigen_matrices.par,normalized_slepian_functions.par,eigencoeffs.par,N.par,NW.par,temp.K)
  temp.b1=Re(temp.b1)
  temp.ratio=temp.b1/QIT_spectrum.par[temp.index]
  return(temp.ratio)
}

QIT.single_cepstral_coefficient<-function(index.par,ratio_spectrum.par,frequencies.par,M.par){
  temp.cepstral_coefficient=sum(ratio_spectrum.par*sin(2*pi*frequencies.par*index.par))
  return(temp.cepstral_coefficient)
}

QIT.cepstral_ratio_spectrum<-function(projections_eigenvalues.par,eigen_matrices.par,QIT_PSD.par,frequencies.par,normalized_slepian_functions.par,
                                    eigencoeffs.par,N.par,NW.par){
  temp.M=nrow(eigencoeffs.par)
  temp.zero_index=temp.M/2
  temp.M2=temp.zero_index+1
  temp.K=ncol(eigencoeffs.par)
  #Compute the ratio spectrum.
  temp.index_sequence<-temp.zero_index+1:temp.M2-1
  temp.QIT_ratio_spectrum<-lapply(temp.index_sequence,QIT.cepstral_ratio_statistic,QIT_PSD.par,projections_eigenvalues.par,
                                  eigen_matrices.par,eigencoeffs.par,normalized_slepian_functions.par,temp.zero_index,N.par,NW.par)
  temp.QIT_ratio_spectrum<-unlist(temp.QIT_ratio_spectrum)
  return(temp.QIT_ratio_spectrum)
}

QIT.cepstral_coefficients<-function(QIT_ratio_spectrum.par,frequencies.par){
  temp.M2=length(QIT_ratio_spectrum.par)
  temp.M=2*(temp.M2-1)
  temp.cepstral_coefficients<-sapply(1:temp.M2-1,QIT.single_cepstral_coefficient,QIT_ratio_spectrum.par,frequencies.par,temp.M)
  temp.cepstral_coefficients<-(-1)*temp.cepstral_coefficients/pi/temp.M
}





