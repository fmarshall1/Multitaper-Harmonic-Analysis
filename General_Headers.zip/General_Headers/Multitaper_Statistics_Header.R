#Francois Marshall, Boston University
#Header file for multitaper functions.
###################################################################################################################

multitaper.acvs<-function(spectrum.par,return.bool=TRUE){
  #Computes the multitaper estimate of the autocovariance function.
  #Returns both the autocovariance sequence and the associated lags, where lags are in units of the sampling period.
  temp.M=length(spectrum.par)
  temp.M_2=temp.M/2
  temp.spectrum<-spectrum.par
  if(return.bool){
    temp.spectrum<-return.to.fft_ordering(spectrum.par)
  }
  temp.acvs<-fft(temp.spectrum,inverse=TRUE)/temp.M
  temp.acvs<-Re(temp.acvs)
  temp.acvs<-temp.acvs[1:(temp.M_2+1)]
  temp.lags<-1:temp.M-1
  temp.lags<-temp.lags[1:(temp.M_2+1)]
  temp.acvs_object<-data.frame(temp.acvs,temp.lags)
  return(temp.acvs_object)
}

multitaper.acrs<-function(spectrum.par,return.bool=TRUE){
  temp.multitaper_acvs_object<-multitaper.acvs(spectrum.par,return.bool)
  temp.acvs<-temp.multitaper_acvs_object$temp.acvs
  temp.lags<-temp.multitaper_acvs_object$temp.lags
  temp.variance<-temp.acvs[1]
  temp.acrs<-temp.acvs/temp.variance
  temp.acrs_object<-data.frame(temp.acvs,temp.acrs,temp.lags)
  return(temp.acrs_object)
}

multitaper_acvs_analysis.function<-function(spectral_power_estimates.par,NW.par=5,sampling_rate.par=1,plot_bool.par=FALSE){
  #Compute the ACVS.
  temp.mt_acvs<-multitaper_ACVS.function(spectral_power_estimates.par,NW.par=NW.par,sampling_rate.par=sampling_rate.par)
  temp.num_lags=length(temp.mt_acvs)
  temp.time_lags<-(1:temp.num_lags-temp.num_lags/2)/sampling_rate.par
  temp.mt_acvs<-temp.mt_acvs[temp.time_lags>=0]
  temp.time_lags<-temp.time_lags[temp.time_lags>=0]
  temp.time_lags_list<-list(temp.time_lags)
  temp.process_variance=temp.mt_acvs[1]
  temp.autocorrelation_coefficient_sequence<-temp.mt_acvs/temp.process_variance
  temp.acvs_list<-list(temp.autocorrelation_coefficient_sequence)
  if(plot_bool.par==TRUE){
    plot.graph(temp.time_lags_list,temp.acvs_list,x_label.par=paste("Lag, in seconds",sep=""),
               y_label.par="Autocorrelation coefficient",plot_title.par="",pdf_title.par="Autocorrelation_coefficient_stationary.pdf")
  }
  temp.list<-list(out.mt_acvs=temp.mt_acvs,
                  out.process_variance=temp.process_variance,
                  out.autocorrelation_coefficient_sequence=temp.autocorrelation_coefficient_sequence)
  return(temp.list)
}

multitaper.mean_estimate<-function(eigencoefficients.par,Slepian_function.par){
  temp.M=nrow(eigencoefficients.par)
  zero.index=temp.M/2
  temp.K=ncol(eigencoefficients.par)
  even.indices<-seq(from=1,to=temp.K,by=2)
  y_k.0<-eigencoefficients.par[zero.index,]
  y_k.0<-y_k.0[even.indices]
  U_k.0<-Re(Slepian_function.par[zero.index,])
  U_k.0<-U_k.0[even.indices]
  temp.numerator_sum=crossprod(y_k.0,U_k.0)
  temp.denominator.sum=crossprod(U_k.0)
  temp.mean_estimate=as.numeric(Re(temp.numerator_sum/temp.denominator.sum))
  return(temp.mean_estimate)
}


multitaperTrend_FM = function(xd, B, deltat, t.in, K_par) {
  
  temp_N <- length(t.in)
  w <- B*deltat
  
  if(length(xd)!=temp_N) { stop("Time array and data array not the same length!")} 
  if((B <= 0) || (B > 0.5)) { stop("B outside acceptable limits: 0 < B < 0.5.")}
  
  ttbar <- t.in - (t.in[temp_N]-t.in[1])/2
  k <- K_par
  vt <- (dpss(temp_N,k=k,nw=temp_N*w))$v
  vk <- colSums(vt)
  
  ## solve for a
  subsel <- seq(1,k,by=2)
  vk <- colSums(vt)[subsel]
  xk <- colSums(xd*vt[,subsel])
  a <- sum(xk*vk) / sum(vk*vk)
  
  ## solve for b
  subsel <- seq(2,k,by=2)
  t_v<-ttbar*vt[,subsel]
  cat("length = ",length(subsel),"\n\n")
  if(length(subsel)>=2){
    tvk <- colSums(t_v)
    xk <- colSums(xd*vt[,subsel])
  }
  else{
    tvk<-sum(t_v)
    xk<-sum(xd*vt[,subsel])
  }
  b <- sum(tvk*xk)/sum(tvk*tvk)
  b<-b/(-2*pi)
  return(list(a,b,ttbar))
}


multitaper_innovations_RNG.function<-function(mt_autocorrelation_coefficients.par=NA,N.par,mean.par=0,variance.par=1,seeds.par=c(1,2),
                                              correlation_memory_threshold.par=0.01,student_dof.par=5,distribution_string.par="Gaussian",
                                              uniform_numbers.par=NA,crude_rv_num_samples.par=NA){
  #Generate "temp.num_innovations" random deviates from the innovation distribution specified by "distribution_string.par", where the
  #specific selection of available distributions provided by this function has been decided from the distributions considered in the dissertation,
  #Marshall (2020).  i.e., the distributions are ones for which it is likely that the DFT-eigencoefficient variables of the simulated stochastic process jointly
  #behave as a multivariate complex-Gaussian distribution, with the sense of this behaviour specified in the aforementioned dissertation.
  temp.transient_offset=0
  if(!is.na(mt_autocorrelation_coefficients.par)){
    temp.num_coefficients=length(mt_autocorrelation_coefficients.par)
    #Estimate the process memory, i.e. how far back in time to go before the correlation between the process elements at n=-tau and n=0 begins to fade.
    temp.absolute_acvs_coefficients<-abs(mt_autocorrelation_coefficients.par)
    #"correlation_memory_threshold.par" default threshold has been chosen from an ACVS plot similar to the ones considered in Marshall (2020).
    temp.coefficients_beyond_threshold<-which(temp.absolute_acvs_coefficients>correlation_memory_threshold.par)
    temp.num_beyond_threshold=length(temp.coefficients_beyond_threshold)
    if(!temp.num_beyond_threshold){
      temp.transient_offset=temp.num_coefficients
    }
    else{
      temp.transient_offset=max(temp.coefficients_beyond_threshold)
    }
  }
  temp.num_innovations=temp.transient_offset+N.par
  temp.innovations_sequence<-c()
  temp.uniform_numbers<-c()
  if(distribution_string.par=="Gaussian"){
    #Generate Gaussian innovations.
    temp.rng_object<-c()
    temp.innovations_sequence_standardized_normal_numbers<-c()
    if(!is.na(crude_rv_num_samples.par) & temp.num_innovations>crude_rv_num_samples.par){
      if(N.par>crude_rv_num_samples.par){
        temp.rng_object<-gaussian.RNG(crude_rv_num_samples.par,seed.par=seeds.par,uniform_numbers.par=uniform_numbers.par)
        temp.innovations_sequence_standardized_normal_numbers<-temp.rng_object$out.random_numbers
        temp.running_seeds<-running_seed.function(seeds.par)
        temp.innovations_sequence_standardized_normal_numbers<-c(temp.innovations_sequence_standardized_normal_numbers,
                                                                 rnorm(temp.num_innovations-crude_rv_num_samples.par))
        running_seed.function(temp.running_seeds)
        temp.innovations_sequence_standardized_normal_numbers<-sample(temp.innovations_sequence_standardized_normal_numbers)
        running_seed.function(temp.running_seeds)
      }
    }
    else{
      temp.rng_object<-gaussian.RNG(temp.num_innovations,seed.par=seeds.par,uniform_numbers.par=uniform_numbers.par)
      temp.innovations_sequence_standardized_normal_numbers<-temp.rng_object$out.random_numbers
    }
    temp.innovations_sequence<-mean.par+sqrt(variance.par)*temp.innovations_sequence_standardized_normal_numbers
    temp.uniform_numbers<-temp.rng_object$out.uniform_rvs
    if(!is.na(crude_rv_num_samples.par)){
      if(N.par>crude_rv_num_samples.par){
        temp.uniform_numbers<-c(temp.uniform_numbers,runif(temp.num_innovations-crude_rv_num_samples.par))
      }
    }
  }
  else if(distribution_string.par=="Gumbel"){
    #Generate Gumbel innovations.
    temp.rng_object<-gumbel_rng.function(population_variance.par=variance.par,num_deviates.par=temp.num_innovations,seeds.par=seeds.par,
                                         uniform_numbers.par=uniform_numbers.par)
    temp.innovations_sequence<-temp.rng_object$out.innovations_sequence
    temp.uniform_numbers<-temp.rng_object$temp.uniform_numbers
  }
  else if(distribution_string.par=="logistic"){
    #Generate logistic innovations.
    temp.rng_object<-logistic_rng.function(population_variance.par=variance.par,num_deviates.par=temp.num_innovations,seeds.par=seeds.par,
                                           uniform_numbers.par=uniform_numbers.par)
    temp.innovations_sequence<-temp.rng_object$out.innovations_sequence
    temp.uniform_numbers<-temp.rng_object$temp.uniform_numbers
  }
  else if(distribution_string.par=="Student"){
    temp.rng_object<-student_rng.function(population_variance.par=variance.par,num_deviates.par=temp.num_innovations,num_dof.par=student_dof.par,
                                          seeds.par=seeds.par,uniform_numbers.par=uniform_numbers.par)
    temp.innovations_sequence<-temp.rng_object$out.innovations_sequence
    temp.uniform_numbers<-temp.rng_object$temp.uniform_numbers
  }
  else{
    temp.rng_object<-uniform_rng.function(population_variance.par=variance.par,num_deviates.par=temp.num_innovations,seeds.par=seeds.par,
                                          uniform_numbers.par=uniform_numbers.par)
    temp.innovations_sequence<-temp.rng_object$out.innovations_sequence
    temp.uniform_numbers<-temp.rng_object$temp.uniform_numbers
  }
  temp.num_reconstruction=temp.num_innovations-temp.transient_offset
  temp.list<-list(out.transient_offset=temp.transient_offset,
                  out.innovations_sequence=temp.innovations_sequence,
                  out.num_reconstruction=temp.num_reconstruction,
                  out.uniform_numbers=temp.uniform_numbers)
  return(temp.list)
}










