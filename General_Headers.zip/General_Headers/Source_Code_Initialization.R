#Francois Marshall, Boston University
#Header file for RNG.
###################################################################################################################


create_nested_directories.function<-function(directory_strings.par){
  temp.num_nested_directories=length(directory_strings.par)
  temp.nested_directory_strings<-rep("",temp.num_nested_directories)
  temp.nested_directory_strings[1]<-directory_strings.par[1]
  for(temp.i in 1:temp.num_nested_directories){
    if(temp.i>1){
      temp.nested_directory_strings[temp.i]<-paste(temp.nested_directory_strings[temp.i-1],"/",directory_strings.par[temp.i],sep="")
    }
    dir.create(temp.nested_directory_strings[temp.i],showWarnings=FALSE)
  }
  return(temp.nested_directory_strings)
}


source_directory_initialization.function<-function(main_directory_string.par,specific_subdirectory_string.par,nested_directory_strings.par){
  #"main_directory_string.par" is the name of the user directory under which the specific project directory is stored.
  #"specific_subdirectory_string.par" is the name of the project directory.
  #"nested_directory_strings.par" is a vector of names for the nested directories.  The lowest of these nested directories is the one for which the working
  #directory will be set.
  #Create the working directory by creating all of the relevant subdirectories if they do not exist.
  temp.nested_directory_input_strings<-paste(main_directory_string.par,specific_subdirectory_string.par,sep="")
  temp.nested_directory_input_strings<-c(temp.nested_directory_input_strings,nested_directory_strings.par)
  temp.nested_directory_strings<-create_nested_directories.function(directory_strings.par=temp.nested_directory_input_strings)
  temp.num_nested_directories=length(temp.nested_directory_strings)
  temp.working_directory_string<-temp.nested_directory_strings[temp.num_nested_directories]
  #Create the working directory unless it already exists.
  dir.create(temp.working_directory_string,showWarnings=FALSE)
  setwd(temp.working_directory_string)
  temp.working_directory_string<-getwd()
  temp.list<-list(out.working_directory_string=temp.working_directory_string,
                  out.nested_directory_strings=temp.nested_directory_strings)
  return(temp.list)
}

























