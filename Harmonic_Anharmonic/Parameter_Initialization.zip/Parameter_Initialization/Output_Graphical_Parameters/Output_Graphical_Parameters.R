#Francois Marshall
#Postdoctoral assistant under the supervision of Dr. Mark Kramer
#Mathematics and Statistics
#Boston University
#2021
##################################################################################
#Initialize the output and graphical parameters.
###################################################################################################################

#Graphical parameters.
#Reciprocal of number of time units in the duration between time points in the abscissum scale (e.g., 1/60s for minutes on x-axis).
plotting.time_scale<<-1/60 #Ensure that the variable, "first_time_units.string", below is consistent with the units here.
#Reciprocal of number of state-variable units in the interval between ordinate points in the state-variable scale
#(e.g., 1e-6s for volts on y-axis if the raw voltage is measured in microvolts).
plotting.voltage_scale<<-1 #Ensure that the variable, "measure_units.string", below is consistent with the units here.
num.plotting_points<<-5e3

#Output and graphical parameters.
measured_abscissa.string<<-"Time"
measure_quantity.string<<-"Voltage"
measure_quantity_string.lower_case<<-"voltage"
time_units.string<<-"seconds"
first_time_units.string<<-"minutes"
abscissa_units.string<-time_units.string
abbreviated_time_units.string="s"
measure_units.string<<-"microvolts"
frequency_units.string<<-"cycles per second"
abbreviated_frequency_units.string="cps"
measure_units_SI.string<-measure_units.string
abbreviated.frequency_units<<-abbreviated_frequency_units.string















