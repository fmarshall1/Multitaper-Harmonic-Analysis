#Francois Marshall
#Postdoctoral assistant under the supervision of Dr. Mark Kramer
#Mathematics and Statistics
#Boston University
#2021
##################################################################################
#Initialize parameters.

###################################################################################################################

######################################################################################################################################
#Directory parameters.
######################################################################################################################################
spectral_power_directory_string.par<-"Multitaper_Spectral_Power"
harmonic_analysis_directory_string.par<-"Raw_Data_Multitaper_F_Test"
cepstral_power_directory_string.par<-"Cepstral_Multitaper_Spectral_Power"

######################################################################################################################################
#Basic parameters.
######################################################################################################################################
NW.par<<-5 #The multitaper time-bandwidth parameter.
gl.node_number<<-32 #For the Gauss-Legendre approximation of the PSWF-sequences.

######################################################################################################################################
#Harmonic-analysis parameters.
######################################################################################################################################
#Threshold values for determining the size of the training time window when reconstructing a peak of the harmonic Fisher-statistic
#spectrum which has been deemed statistically significant by a multitaper harmonic F-test.
alpha.par<<-0.05
#Starting size of the training sample for the linear-reconstruction of first differences of the reciprocal F-statistics in a
#calculation for the largest training size before which the R-squared value drops below the threshold value above and the
#Kolmogorov-percentile of the standardized residuals vs. a standard normal law reduces exceeds the threshold value above.
training_size.par<<-5
#Threshold for the multitaper harmonic Fisher test for the voltage series itself.
#Ideally, this should be the maximum empirical quantile to achieve the minimum Bonferoni false-alarm rate.
F_test.threshold<<-NA


######################################################################################################################################
#Cleaning parameters.
######################################################################################################################################
#The threshold percentile of the standard normal law beyond which the absolute value of a standardized residual is considered an outlier.
outlier_percentile.par=0.6
interpolation_NW.par=3
#The number of sections on either side of a data gap for interpolation of that gap, where the section size is num.interpolation_sections
#times the size of the gap.
num.interpolation_sections<<-3
#The number of iterations to use for the interpolation performed using Burr's method.
num_iterations.interpolation<<-1
#The number of iterations to use for the interpolation performed using Burr's method.
#Ends reconstruction for periodic extension.
num_iterations.ends_interpolation_harmonic<<-1
max_length.ends_interpolation_harmonic<<-200

######################################################################################################################################
#Parameters for some combined tests of sphericity and impropriety of the DFT eigencoefficient variables.
######################################################################################################################################
QIT.percentile.par1=c(0.1,0.25,0.5,0.75,0.9)
QIT_crossing_rates_bool.par=TRUE
QIT.percentile.par2=c(0,25,50,75,100)
wishart_percentiles.par=(1:11-1)/10*100

######################################################################################################################################
#Cepstral analysis.
######################################################################################################################################
#Size of the sections used to compute the dynamic spectra of F-statistic values based on quadratic-inverse estimates of the
#time derivative of the cepstral coefficients.
section.size=1.5e4
cepstral_units.par=measure_units.string
cepstral_measured_quantity.par=measure_quantity.string
#Threshold for the harmonic F-test when applied either for the cepstral-coefficient time derivative or for the log-PSD estimates series itself.
#Should omit one of the "9"'s if few or no peaks are turning up, but the code can handle this and use a default of N.F_statistics F statistics
#from the total of M/2+1.
cepstral.F_threshold=0.9999
N.F_statistics=3



######################################################################################################################################
#Cyclostationary analysis.
######################################################################################################################################
#When the record size exceeds 2e3, the computations can become excessive for the Loève bifrequency spectrum.
max_size.Loeve<<-2e3
#A second size for plotting the Loeve bifrequency map, this time for the case of cyclostationary modelling.
max_size_Loeve.par=200
#When the size of the FFT grid exceeds 1e3 for the cyclic spectra, the computations can become excessive for the ACVS maps.
max_size.cyclic_ACVS<<-1e3
#The number of realizations to use in the simulation of the LAPTV processes of interest.
num.realizations<<-300
#The nominal distribution to use for the LAPTV innovations fit.
nominal_distribution.string<<-"Gaussian"
#The alternative distribution strings to be used in the model-uncertainty analysis for the LAPTV reconstruction.
alternative_distribution.strings<<-c("Gumbel","logistic","Student","uniform")
#The threshold correlation below which two elements of the equivalent stationary representation of the model process are assumed independent.
correlation_memory.threshold<<-0.01
#The number of deviates to obtain from an MLCG before using the "rnorm" function to simulate the remainder of the deviates.  The default value is
#NA, in which case the entire sequence of deviates is to be generated using an MLCG.
crude_rv_num.samples<<-5e3
#Number of sigma for the confidence-bound traces of the simulated LAPTV process.
temp.normal_quantile=1
#Number of LAPTV realizations to simulate.
num.realizations=100
#Simulate only 30 LAPTV realizations when N_truncated.par>5e3 (i.e., the time series is long).
time_efficieny.bool=TRUE
#Prewhitening analysis for the LAPTV?
prewhitening.bool=TRUE
#Output the values of the competing metrics at the end of the prewhitening algorithm.
prewhitening_verbose.bool=TRUE
#Plot the time-zero autocorrelation sequence.
plot_ACVS.bool=FALSE
#Takes time to plot the ACVS map for the ACS model, so set the following boolean to FALSE when time efficiency is a concern.
plot_acvs.bool=FALSE
#Maximum number of points to compute over time for the correlogram.
max_size.ACVS_bitemporal_map<<-100
temp.spectrogram_directory<-"Spectrogram"











