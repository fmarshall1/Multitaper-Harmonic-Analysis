#Francois Marshall
#Postdoctoral assistant under the supervision of Dr. Mark Kramer
#Mathematics and Statistics
#Boston University
#2021
##################################################################################
#Initialize parameters for the spectral analysis of the raw time series.
###################################################################################################################

######################################################################################################################################
#Secondary boolean parameters.
#Jackknife boolean parameters.
output.jk_spectral_power<<-TRUE #Should a text file containing the jackknifed statistics of the spectral-power estimators be generated?
jk_spectral_power.bool<<-TRUE #Should the jackknife calculations be performed for the spectral-power estimation?
F_test_jackknife.par<<-FALSE #Should the jackknife calculations be performed on the F-statistic spectrum?
######################################################################################################################################

######################################################################################################################################
#Tertiary boolean parameters.
######################################################################################################################################
#Spectral-power estimates, boolean parameters.
output.spectral_power<<-TRUE #Should a text file containing the spectral-power estimates be generated?
plot_spectral_power.bool<<-TRUE #Should a plot of the spectral-power estimates be generated?
multitaper_spectral_power_verbose.par<<-FALSE #Output the spectral-power estimates and summary statistics to file?
#Jackknife boolean parameters.
output.jk_spectral_power<<-FALSE #Should a text file containing the jackknifed statistics of the spectral-power estimators be generated?
#Simulate the LAPTV series.
simulation.bool=FALSE
#Cyclostationary boolean parameters.
cyclic_ACVS_plot.bool<<-FALSE
#Compute and plot the cyclic ACVS.
cyclic_ACVS.bool=FALSE
#Eigencoefficient analysis boolean.
eigencoeff_analysis_bool.par<<-FALSE


















