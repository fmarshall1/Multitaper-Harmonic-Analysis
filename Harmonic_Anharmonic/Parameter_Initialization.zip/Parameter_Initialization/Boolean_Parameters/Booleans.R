#Francois Marshall, Boston University
#Initialize parameters.

###################################################################################################################

boolean.directory<-paste(parameter_initialization.directory,"Boolean_Parameters/",sep="")
source(paste(boolean.directory,"Spectral_Analysis_Booleans.R",sep=""))
source(paste(boolean.directory,"Harmonic_Analysis_Booleans.R",sep=""))
source(paste(boolean.directory,"Log_Spectrum_Booleans.R",sep=""))
source(paste(boolean.directory,"Demodulate_Booleans.R",sep=""))

######################################################################################################################################
#Time-series parameters.
######################################################################################################################################


######################################################################################################################################
#Primary boolean parameters.
######################################################################################################################################
#Do the data files each contain a header line?
header.bool=TRUE



#Important boolean parameters.
truncation_bool.par<<-FALSE #Truncate the series for computational efficiency?
#Spectral-power estimates, boolean parameters.
spectral_power.bool<<-TRUE #Compute the spectral-power estimates?
#Harmonic signal statistics, boolean parameters.
ha_bool.par<<-TRUE #Perform a harmonic analysis?
residual_eigencoeffs.bool<<-TRUE #Compute the residual eigencoefficients and the associated statistics?
#Log-spectrum series analysis.
spectral_power_bool.par<<-FALSE #Compute the spectral-power estimates?
residual_eigencoeffs_bool.par<<-FALSE #Compute the residual eigencoefficients and the associated statistics?
#Cepstral analysis, boolean parameters.
cepstral_bool.par<<-FALSE #Perform a spectral analysis on the time series of logarithmic spectral-power estimates?
cepstral_ha_bool.par<<-FALSE #Perform a harmonic analysis for the logarithmic spectral power?
cepstral_residual_eigencoeffs.bool<<-FALSE #Compute the residual eigencoefficients and the associated statistics?
#Bifrequency spectrum, boolean parameters.
bifrequency_plot_bool.par<<-FALSE
######################################################################################################################################


######################################################################################################################################
#Tertiary boolean parameters.
######################################################################################################################################

#Time-series input, boolean parameters.
plot_ts.bool<<-TRUE #Should a plot of the time series be generated?
ts_input.verbose_par<<-TRUE #Output summary time-series statistics?
quadratic_AR_one_PSD_condition_bool=TRUE #Compute the frequency bounds where an AR(1) spectrum would be quadratic?




















