#Francois Marshall, Boston University
#Header file for analysis of logarithmic spectrum.

###################################################################################################################


######################################################################################################################################
#Tertiary boolean parameters.
######################################################################################################################################

#Harmonic signal statistics, boolean parameters.
output.harmonic_Fisher_statistics<<-TRUE #Should a text file containing the multitaper harmonic Fisher-statistic values be generated?




















