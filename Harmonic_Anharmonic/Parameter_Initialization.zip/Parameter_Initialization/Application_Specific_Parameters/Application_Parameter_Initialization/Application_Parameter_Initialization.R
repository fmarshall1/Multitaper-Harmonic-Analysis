#Francois Marshall
#Postdoctoral assistant under the supervision of Dr. Mark Kramer
#Mathematics and Statistics
#Boston University
#2021
##################################################################################
#Initialize parameters.
###################################################################################################################

#Data file name.
if(!strcmp(code.string,"")){
  temp.directory_file_name<-paste(code.string,"/Data/",data_directory.string,sep="")
}

#Number of tapers for the multitaper spectral analysis.
K.par=2*NW.par-1















