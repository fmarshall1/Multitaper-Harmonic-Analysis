#Francois Marshall
#Postdoctoral assistant under the supervision of Dr. Mark Kramer
#Mathematics and Statistics
#Boston University
#2021
##################################################################################

selected_time_window.indices<-c(2,11,20,32)
#selected_time_window.indices<-c(2)
#selected_time_window.indices<-c(11)
#selected_time_window.indices<-c(20)
#selected_time_window.indices<-c(32)

frequency.band<-c(0,0.5)


#Parameters for the seizure epochs as based on the presentation slide.
epoch.change_points<-c(17.05,17.2,17.5,17.8,18.25)

prerecruitment.start_time<<-17.05
prerecruitment.end_time<<-17.2
ictal_wf.end_time<<-17.5
postrecruitment.end_time<<-17.8
pretermination.end_time<<-18.25

#Strings for the different seizure epochs.
epoch.strings<-c("No seizure",
                 "Pre-recruitment",
                 "Ictal wavefront",
                 "Ictal wavefront",
                 "Post-recruitment",
                 "No seizure")

######################################################################################################################################
#Fitting parameters.
######################################################################################################################################
Rsq_threshold.par<<-1-alpha.par
Kolmogorov_percentile.par<<-1-alpha.par
TPT_threshold.par<<-Kolmogorov_percentile.par
num_fitting_indices.par=10












