#Francois Marshall, Boston University
#Initialize parameters.
###################################################################################################################

parameter_initialization.directory<<-paste(specific_subdirectory1.string,"/Parameter_Initialization/",sep="")

######################################################################################################################################
#Graphical and output parameters.
######################################################################################################################################
source(paste(parameter_initialization.directory,"Output_Graphical_Parameters/Output_Graphical_Parameters.R",sep=""))

######################################################################################################################################
#Time-series parameters.
######################################################################################################################################
source(paste(parameter_initialization.directory,"Time_Series_Parameters/Time_Series_Parameters.R",sep=""))
######################################################################################################################################
#Follow-up initializations.
######################################################################################################################################
#The maximum empirical quantile, beyond which the data can say nothing about the distribution of a test statistic
#and the threshold associated with the minimum Bonferoni false-alarm rate.
bonferoni.threshold<<-1-1/N.par

######################################################################################################################################
#Boolean parameters.
######################################################################################################################################
#Load the specified boolean parameters to assess which tasks the user has asked to be performed.
source(paste(parameter_initialization.directory,"Boolean_Parameters/Booleans.R",sep=""))

######################################################################################################################################
#Multitaper initializations.
######################################################################################################################################
source(paste(parameter_initialization.directory,"Time_Series_Parameters/Multitaper_Parameters.R",sep=""))
W.par<<-NW.par/N.par
if(decimation.step_size>1){
  temp.decimation_indices<-seq(from=1,to=N.par,by=decimation.step_size)
  W.par<<-W.par*N.par/length(temp.decimation_indices)
}

######################################################################################################################################
#Application data specifications.
######################################################################################################################################
temp.list_files_vector<-list.files(paste(main_directory.string,source.directory,code.string,"/Setup/Parameters",sep=""))
temp.num_parameter_header_files=length(temp.list_files_vector)
for(temp.i in 1:temp.num_parameter_header_files){
  source(paste(main_directory.string,source.directory,code.string,"/Setup/Parameters/",temp.list_files_vector[temp.i],sep=""))
}
source(paste(parameter_initialization.directory,"Application_Specific_Parameters/Application_Data_Parameters.R",sep=""))

######################################################################################################################################
#Follow-up initializations.
######################################################################################################################################
specific_subdirectory.string<-paste(source.directory,code.string,"/Section_",selected_time_window.index,"/",sep="")
specific_subdirectory2.string<-paste(specific_subdirectory1.string,"Section_",selected_time_window.index,"/",sep="")
working_directory.string<-paste(specific_subdirectory2.string,sep="")


if(cepstral_bool.par==TRUE || output.jk_spectral_power==TRUE || jk_spectral_power.bool==TRUE
   || output.jk_spectral_power==TRUE || eigencoeff_analysis_bool.par==TRUE){
  spectral_power.bool<<-TRUE
  spectral_power_bool.par==TRUE
  ha_bool.par<<-TRUE
}

if(F_test_jackknife.par==TRUE || residual_eigencoeffs.bool==TRUE || output.harmonic_Fisher_statistics==TRUE){
  ha_bool.par<<-TRUE
}

#Cepstral analysis requires significant computation, so it is best to truncate the record for computational efficiency,
#and so consider smaller sections and lots of sections rather than one long, contiguous series.
if(cepstral_bool.par==TRUE){
  truncation_bool.par<<-TRUE
}










