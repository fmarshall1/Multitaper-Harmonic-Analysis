#Francois Marshall
#Postdoctoral assistant under the supervision of Dr. Mark Kramer
#Mathematics and Statistics
#Boston University
#2021
##################################################################################
#Initialize the parameters for filtering.
###################################################################################################################

######################################################################################################################################
#Tertiary boolean parameters.
######################################################################################################################################

#Filter boolean parameters.
filters_bool.par<<-TRUE #
select_filter_bool.par<<-TRUE #Assess the performance of different filters by their transfer functions?
filter_output_bool.par<<-TRUE
filter_plot_bool.par<<-TRUE
filter_verbose.par<<-TRUE
#Diagnostic boolean parameters.
filter_diagnostic_selected_filters.verbose.par<<-TRUE
filter_reconstruction_bool.par<<-TRUE
filter_reconstruction_plot_bool.par<<-TRUE
filter_diagnostics.verbose.par<<-TRUE




















