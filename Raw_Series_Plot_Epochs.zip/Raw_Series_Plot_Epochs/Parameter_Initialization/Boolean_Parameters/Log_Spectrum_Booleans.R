#Francois Marshall, Boston University
#Initialize parameters for an analysis of the logarithmic spectrum.
###################################################################################################################

######################################################################################################################################
#Primary boolean parameters.
cepstral_analysis.bool<<-FALSE
######################################################################################################################################

######################################################################################################################################
#Secondary boolean parameters.
cepstral_jk_spectral_power.bool<<-FALSE
######################################################################################################################################

######################################################################################################################################
#Tertiary boolean parameters.
######################################################################################################################################

#Cleaning, boolean parameters.
remove_outliers_bool.par<<-FALSE
#Booleans to decide which interpolation method to use.
mdss_bool.par<<-FALSE #Apply the gapped-taper method of Chave (2020) for the pilot reconstruction?
ts_interp_bool.par<<-FALSE #Apply the iterative trend-subtraction interpolation method of Burr (2012) for the pilot reconstruction?

#Generate diagnostic plots to determine the quality of the linear estimate of the AR(1) or ARIMA(0,1,0) spectral model?
plot_quadratic_diagnostics_bool.par=TRUE

#Cepstral analysis, boolean parameters.
cepstral_output.par<<-FALSE #Output details of the cepstral analysis to text files?
cepstral_power.bool<<-FALSE #Compute the spectral power of the logarithmic spectrum?
#Plotting and output parameters.
cepstral_plot_spectral_power.bool<<-FALSE #Plot the spectra of log spectral power, whitened log spectral power and whitened+cleaned log spectral power?
cepstral_measured_quantity.par<<-"Spectral power" #y axis.
cepstral_units.par<<-"s" #x axis
cepstral_output.jk_spectral_power<<-FALSE #Output the jackknife-computation statistics for the harmonic analysis?
cepstral_power_verbose.par<<-FALSE #Output the spectral-power estimates and summary statistics to file?
whitened_log_spectrum_bool.par<<-FALSE #Consider the cepstrum of the whitened log spectrum?
cleaned_log_spectrum_bool.par<<-FALSE #Consider the cepstrum of the cleaned log spectrum?
log_spectrum_verbose.par=FALSE
cepstral_power.verbose_par<<-FALSE













