#Francois Marshall, Boston University
#Initialize parameters.

###################################################################################################################

#General parameters for the time series selected from the data file.
N.par<<-6e4 #The desired record size to be extracted from the full time series read in.
min.record_size<<-1e3 #The minimum record size after decimation.
decimation.step_size<<-10












