#Francois Marshall
#Postdoctoral assistant under the supervision of Dr. Mark Kramer
#Mathematics and Statistics
#Boston University
#2021
##################################################################################

######################################################################################################################################
#Statistics parameters.
######################################################################################################################################
alpha.par=0.05 #Diagnostic-statistic threshold percentile.











