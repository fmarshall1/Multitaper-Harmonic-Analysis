#Francois Marshall
#Postdoctoral assistant under the supervision of Dr. Mark Kramer
#Mathematics and Statistics
#Boston University
#2021
##################################################################################

######################################################################################################################################
#Starting analysis.
######################################################################################################################################

#Global tic.
tic()

nested_directory.input_strings<-paste("",sep="")
source_directory_initialization.object<-
  source_directory_initialization.function(main_directory_string.par=main_directory.string,
                                           specific_subdirectory_string.par=specific_subdirectory.string,
                                           nested_directory_strings.par=nested_directory.input_strings)
working_directory.string<-source_directory_initialization.object$out.working_directory_string
working_directory.string0<-working_directory.string
specific_subdirectory.string0<-specific_subdirectory.string

##################################################################################
#Create and set the working directory.
##################################################################################
directory.strings<-c("1_Preliminary_Analysis")
create_and_set_multiple_directories.object<-
  create_and_set_multiple_directories.function(directory_strings.par=directory.strings,
                                               specific_subdirectory_string.par=specific_subdirectory.string0,
                                               working_directory_string.par=
                                                 paste(working_directory.string0,
                                                       "/",sep=""))
specific_subdirectory.string<-create_and_set_multiple_directories.object$out.specific_subdirectory_string
working_directory.string<-create_and_set_multiple_directories.object$out.working_directory_string
revised.specific_directory_string<-create_and_set_multiple_directories.object$out.revised_specific_subdirectory_string

setwd(working_directory.string)

temp.ts_parameters_directory_name<-paste(working_directory.string0,"/../Data/Parameters",sep="")
temp.ts_parameters_directory_files_list<-list.files(temp.ts_parameters_directory_name)
temp.ts_directory_name<-paste(working_directory.string0,"/../Data/Time_Series",sep="")
temp.ts_directory_files_list<-list.files(temp.ts_directory_name)

temp.parameter_file_name<-paste(code.string,"/Data/Parameters/",temp.ts_parameters_directory_files_list[[1]],sep="")
temp.ts_file_name<-paste(code.string,"/Data/Time_Series/",temp.ts_directory_files_list[[1]],sep="")

######################################################################################################################################################
#Plot the pre-recruitment window, where the term for the time window in question is based on the slideshow.
#Below, the choice of time window is from "Starting_Considerations/Voltage_Series_Raw_Sections.pdf", where the time window contains
#a section series exhibiting periodicity.
######################################################################################################################################################
temp.application_TS_text_input_object<-
  TS_data_upload_text.function(file_name.par=temp.ts_file_name,ts_parameters_file.par=temp.parameter_file_name,
                               x_measurement.par=measured_abscissa.string,
                               y_measurement.par=measure_quantity.string,time_units.par=time_units.string,
                               abbreviated_time_units_string.par=abbreviated_time_units.string,
                               y_units.par=measure_units.string,
                               pdf_title.par=paste("Section_",measure_quantity.string,"_Series_Raw.pdf",sep=""),
                               x_scale.par=1,y_scale.par=plotting.voltage_scale,plot.par=plot_ts.bool,
                               num_plotting.par=num.plotting_points,header.par=FALSE)
time_series.values<-temp.application_TS_text_input_object$out.voltage_series
N.samples=temp.application_TS_text_input_object$out.N_samples
time.sequence<-temp.application_TS_text_input_object$out.time_sequence
sampling.rate=temp.application_TS_text_input_object$out.sampling_rate
sampling.period=temp.application_TS_text_input_object$out.sampling_period
temp.N=length(time_series.values)
temp.index_sequence<-1:temp.N
num.series=floor(N.samples/N.par)
cat("The number of ",N.par,"-point sections in the time series is ",num.series,".\n")

#if(FALSE){

#Plot the full time series.
num.epochs=length(epoch.strings)
epoch.start_times<-c(0,epoch.change_points)
epoch.end_times<-c(epoch.start_times[2:num.epochs],max(time.sequence))
plot_series_epochs.function(time.sequence*plotting.time_scale,time_series.values,epoch.start_times,epoch.end_times,epoch.strings,
                            N.par,num.series,measured_abscissa.par=measured_abscissa.string,measured_value.par=measure_quantity.string,
                            abscissa_units.par=time_units.string,ordinate_units.par=measure_units.string,
                            num_plotting.par=num.plotting_points,x_scale.par=plotting.time_scale,
                            y_scale.par=plotting.voltage_scale)

#}#endif


setwd(working_directory.string)



sink("Total_Computation_Time.txt", append=FALSE, split=FALSE)
cat("Time for all computations = ")
toc()
sink()


closeAllConnections()
graphics.off()



